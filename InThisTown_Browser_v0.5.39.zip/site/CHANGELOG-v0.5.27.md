# In This Town Browser v0.5.27

## Compatibilidad iPhone + PC
- El selector de IA comprueba que exista un adaptador WebGPU real antes de elegir la GPU en PC; si no, evita ese intento y pasa directamente a WASM.
- Añadido un panel de diagnóstico que comprueba WebGL 2, MediaRecorder, captura del canvas, Web Audio, formato de vídeo y WebGPU.
- El panel identifica el tipo de dispositivo y muestra si el navegador cumple los requisitos esenciales antes de empezar.
- Añadido un botón para repetir las comprobaciones, útil después de cambiar de navegador o activar aceleración gráfica.
- En móviles, Kokoro intenta primero Q4 para reducir el pico de memoria y conserva Q8 como alternativa si Q4 falla.
- Actualizados los identificadores de versión y caché para evitar que el navegador mezcle archivos antiguos y nuevos.

## Límites de verificación
- Pruebas automáticas y comprobaciones de sintaxis ejecutadas en el entorno de desarrollo.
- No se ha realizado una prueba física de generación completa en iPhone 13 Pro ni en el HP Victus con GTX 1650. El panel de compatibilidad permitirá recoger las capacidades reales de cada navegador, pero no garantiza por sí solo una exportación correcta.

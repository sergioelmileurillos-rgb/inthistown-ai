# v0.5.22 — corrección de premisas descriptivas y variedad

- Corrige un fallo del analizador que interpretaba frases como “everyone is poor except the mayor” como verbos inexistentes (por ejemplo, `iing`).
- Añade una ruta narrativa para premisas descriptivas y de excepción, sin transformarlas automáticamente en reglas de prohibición.
- Incorpora dos desarrollos alternativos para el caso de desigualdad económica, con pistas, pruebas, personajes y desenlaces distintos.
- Elimina el generador de narraciones antiguas que ya no se utilizaba y podía confundir el mantenimiento.
- Añade pruebas de regresión para la premisa del vídeo y para variación entre generaciones.
- Mantiene los tres paquetes de modelos adicionales y el flujo de generación local/Kokoro.

- Respeta la iluminación definida por cada beat y mantiene el cielo anterior cuando no se especifica, evitando el cambio arbitrario a noche en los últimos segundos.
- El arquetipo de laguna dispone de desenlaces alternativos y deja de asignar siempre al protagonista el trabajo de inspector.
- El rótulo de apertura de las premisas descriptivas ya no afirma que exista una regla.

# In This Town Browser v0.5.34

## Facial rendering reliability
- Increased the face plane's clearance from the head and reduced its footprint slightly to reduce depth overlap at oblique camera angles.
- Increased atlas-cell UV inset to four pixels to further reduce neighbouring-cell sampling.
- Rendered face textures unlit so scene lighting cannot wash out or darken facial features.
- Kept face geometry out of shadow rendering.

## Validation
- Added regression tests for unlit facial rendering and revised face-plane placement.
- Run `npm test` and `npm run check` before release.

# In This Town Browser v0.5.12

- Fixed story/visual mismatches: objects appear at the spoken cue and in named spatial positions.
- Shadow reveals are attached to the word “shadow”, positioned relative to the actor, and framed with that actor.
- Fixed two lamps spawning at the same coordinates; lamps now have real timeline-controlled on/off emissive states.
- Fixed mirror alias to a real mirror model and enlarged creature reveal scale.
- Added customization controls to the local Roblox-style character forge: shirt, trousers, hair, skin, hairstyle and accessory.
- Added stable deterministic floor-space separation for overlapping actors (render-time correction).
- Removed unrelated generic props and synthetic witness reactions from semantic story beats.
- Bumped service-worker cache to v5-14.

Automated test suite and JS syntax checks pass. Full Kokoro + WebGL + MediaRecorder export still needs to be checked on the target Chromebook.

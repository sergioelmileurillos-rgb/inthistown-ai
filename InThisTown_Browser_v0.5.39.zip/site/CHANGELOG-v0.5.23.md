# In This Town Browser v0.5.23

## IA de historias integrada en el navegador
- Añadido `local-story-ai.js`, un guionista local basado en Transformers.js y el modelo `onnx-community/SmolLM2-360M-Instruct`.
- La IA se ejecuta en el dispositivo mediante WebGPU cuando está disponible, con fallback a WASM.
- El modelo se descarga bajo demanda y Transformers.js utiliza la caché del navegador para reutilizar los archivos.
- Al crear un vídeo, si no hay un guion importado, la web genera una historia nueva y la valida con el director de escenas existente.
- Se muestran el estado de carga y el progreso de descarga.
- Se conserva la importación externa como herramienta opcional.
- No se envía la premisa ni el guion a un servicio de inferencia; la descarga inicial del modelo sí requiere conexión a internet.

## Limitaciones conocidas
- No es una IA ilimitada: la velocidad y la calidad dependen de la memoria, CPU/GPU y compatibilidad del dispositivo.
- El modelo es pequeño para que pueda ejecutarse en navegadores; algunos guiones pueden no superar la validación y requerir otro intento.
- El primer uso puede descargar varios cientos de MB. El tamaño real depende de los archivos de modelo seleccionados por Transformers.js.
- No se ha podido verificar una generación completa en un Chromebook físico; se debe probar allí antes de publicar como versión estable.

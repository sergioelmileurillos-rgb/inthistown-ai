# In This Town Browser v0.5.24

## Revisión de calidad de historias IA
- La generación local ahora admite hasta tres intentos cuando el modelo devuelve JSON incorrecto, una premisa cambiada o un guion que no supera las validaciones.
- Los reintentos incluyen el motivo concreto del fallo para que el modelo corrija el guion completo, en lugar de continuar con una respuesta defectuosa.
- Se añade un control narrativo previo al render: frases duplicadas, diversidad de vocabulario, progresión de roles y repetición entre inicio y final.
- Se aumenta el presupuesto de tokens para reducir cortes en guiones de 10–18 escenas.
- Si los tres intentos fallan, la aplicación se detiene y explica el problema; no sustituye silenciosamente la historia por una plantilla.
- Se actualizan las versiones y la caché del service worker.

## Verificación
- 100 pruebas automatizadas superadas.
- Comprobación sintáctica de todos los archivos JavaScript superada.
- No se ha podido probar una generación real en un Chromebook físico; esa comprobación sigue pendiente.

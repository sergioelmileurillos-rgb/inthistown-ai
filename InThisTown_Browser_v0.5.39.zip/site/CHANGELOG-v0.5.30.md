# In This Town Browser v0.5.30

## Síntesis de voz adaptada al dispositivo
- iPhone y otros móviles usan bloques de narración más pequeños (máximo 2 escenas y 18 palabras por bloque) para reducir la memoria temporal necesaria durante la inferencia de Kokoro.
- Chromebook y equipos con poca memoria o pocos núcleos aplican el mismo perfil conservador.
- PC de sobremesa mantiene bloques de hasta 3 escenas y 25 palabras para evitar llamadas innecesarias al motor de voz.
- La agrupación conserva el orden y el contenido de todas las frases; solo cambia cómo se distribuye el trabajo.

La mejora reduce el tamaño de cada operación, pero no garantiza que Safari o un navegador concreto pueda completar la generación. Hace falta una prueba real en el iPhone 13 Pro y el HP Victus.

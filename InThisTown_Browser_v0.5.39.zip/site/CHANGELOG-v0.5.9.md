# v0.5.9 — estabilidad y memoria

- Cierra el worker Kokoro una vez generada la narración, antes de renderizar las escenas 3D.
- Descarta la copia PCM adicional cuando el AudioBuffer ya contiene el audio.
- Limita el render a 24 FPS en lugar de dibujar en cada refresco de pantalla.
- Muestra un error identificable si se pierde el contexto WebGL.
- Renueva la caché del service worker.

La validación automatizada no equivale a una exportación real en el Chromebook.

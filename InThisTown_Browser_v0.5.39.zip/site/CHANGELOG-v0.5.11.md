# In This Town — v0.5.11

## Coherence and model-maker update
- Only choose shadow or creature story beats when the premise gives a matching cue.
- Fix semantic shadow, book, paper, door, window and lamp model mappings.
- Remove automatic witness reactions that invented performances.
- Semantic beats no longer receive generic unrelated props or fallback choreography.
- Add a Character Forge panel: generate, save, select and delete persistent block-style characters.
- Generate deterministic visual variations for the story cast.
- Resolve character-character intersections on every rendered frame and report tight actor spacing during validation.
- Bump service-worker cache to v5-13.

Automated tests only; a full render/export on the user's Chromebook still needs to be checked on-device.

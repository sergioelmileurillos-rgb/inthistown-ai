# In This Town Browser v0.5.15

The app now supports an external AI Story Director workflow. It prepares a tailored prompt for the entered rule/tone/duration, imports the JSON response from ChatGPT or Claude, validates its story beats and visual plan, and sends the plan through the existing semantic adapter into the 3D engine. The local story engine remains the offline fallback.

The validation layer checks scene count, supported actions and assets, exact spoken cues, visible-actor requirements, character position conflicts, object continuity and unsupported shadow/monster props. No API key is exposed in the public static website.

See `site/CHANGELOG-v0.5.15.md` for details.

## Verification
- 45 automated tests passed.
- All JavaScript files pass `node --check`.
- Full Kokoro + WebGL2 + MediaRecorder render still needs a real Chromebook run.

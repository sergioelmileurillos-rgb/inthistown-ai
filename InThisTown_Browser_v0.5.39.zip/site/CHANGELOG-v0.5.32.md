# In This Town Browser v0.5.32

## Movimiento de reposo más natural
- Se amplía la animación idle con respiración sutil, balanceo de torso, micro movimientos de cabeza y variaciones pequeñas en brazos.
- Cada personaje recibe una fase estable derivada de su identificador para evitar que todos se muevan sincronizados.
- La fase es determinista: el mismo personaje y el mismo instante producen exactamente la misma pose, importante para renderizar fotogramas fuera de orden.
- Las animaciones dirigidas por la historia mantienen prioridad y no se sustituyen por el movimiento idle.

## Verificación
- 120 pruebas automatizadas superadas.
- `npm run check` superado.
- ZIP verificado tras la creación.
- No se ha realizado una prueba física completa en iPhone 13 Pro ni en HP Victus.

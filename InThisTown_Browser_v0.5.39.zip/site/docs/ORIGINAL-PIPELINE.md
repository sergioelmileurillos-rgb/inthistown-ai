---
name: roblox-story-studio
description: Create viral vertical (9:16) Roblox-style 3D story animations from a one-line premise (e.g. "a town where every time someone sneezes, they teleport") without Roblox Studio or Blender. Runs the full pipeline - references, style rules, own 3D engine, story, animation, ElevenLabs voice sync, word-by-word subtitles, music/SFX, render and per-scene fixes.
---

# Roblox Story Studio

Self-contained studio: a WebGL2 3D engine (`engine/`) driven headlessly by Chromium, plus Python/Node scripts. No Roblox Studio, no Blender, no three.js, no network needed at render time.
**Never pretend a video exists: only report files that the pipeline actually wrote.**

Requirements (already present in the Claude workspace): `node` + `playwright` (Chromium), `ffmpeg`, `python3` with `numpy` and `opencv-python`. Env vars if Playwright is not global: `NODE_PATH`, `PW_PATH`.

## One-line trigger
User says e.g. *"Create a video about a town where every time someone sneezes, they teleport."* → run the **whole workflow below** without asking for permission step by step. Only stop to ask for the two external inputs (references, ElevenLabs audio) when they are really needed.

## Workflow (the 6 steps)

### 1. REFERENCES
- `style-rules.md` already exists (built from the user's 3 reference videos). If it exists, use it. If the user supplies 2–3 *new* videos (files or YouTube URLs), run
  `python3 scripts/analyze_refs.py references/analysis <video1> <video2> [video3]` and go to step 2.
- URLs need `yt-dlp` + network (usually unavailable in the cloud workspace) → ask the user to upload the mp4 files instead.

### 2. STUDY
- Run the analyzer (numbers: shot length, palette, subtitle band) and **look at** `references/analysis/ref*/sheet.jpg` plus extra frames (`ffmpeg -ss T -i video -frames:v 1 f.png`) with the Read tool: characters, scenery, camera, light, subtitle look.
- Update `style-rules.md` (sections: characters, colours/sets, animation, camera, lighting, pacing, subtitles, audio). Every later step must obey it.

### 3. ENGINE (built once, reuse forever – do NOT rebuild per episode)
`engine/` = math, primitives, renderer (shadows, fog, sky, overlays), `character.js` (R6 Roblox characters, 16 faces, hair, accessories, chest decals), `anim.js` (≈45 procedural clips), `world.js` (city, suburb, park, school, townhall, rooms, crowd, void + 8 sky/light presets), `props.js` (cars, tv, bed, couch, animals, rocket, ufo…), `fx.js` (teleport, explosion, confetti, coins, rain, snow…), `director.js` (scene JSON → deterministic timeline, camera, A* path planning, validator).
List everything available: `node scripts/render.js assets`. To add a prop/world/clip/face, edit the module and run a test frame (`node scripts/render.js frame story.json <sceneIdx> <t> out.png`). Extending the engine is allowed; keep it backward compatible.

### 4. STORY
Create the episode: `python3 scripts/story_tools.py new <slug> "<rule>"` then write `episodes/<slug>/story.json` (format: `references/scene-format.md`; narrative method: `references/story-playbook.md`).
Structure (mandatory): **weird rule → protagonist exploits it → 3–5 escalating funny/surprising situations → twist ending**. 20–60 s, English narration, ~2.7 words/s, ONE scene per sentence/clause (≈1.9 s), hook in the first 2 s.
Then `python3 scripts/story_tools.py check episodes/<slug>` and `... voice-script episodes/<slug>` (writes the text to paste into ElevenLabs).

### 5. ANIMATE & RENDER
- **Ask the user for the ElevenLabs audio** (English). Give them `voice_script.txt`. Accepted: `episodes/<slug>/voice.mp3` (one file, whole narration; optional exact timings `voice.mp3.alignment.json` from ElevenLabs "with timestamps") or one file per scene `voice/<scene_id>.mp3` (best sync, allows silent beats). See `references/elevenlabs-voice.md`.
- Without audio the pipeline still renders a **DRAFT** (estimated subtitle timing, music + SFX, no voice) so the user can approve visuals first. Say clearly it is a draft.
- Run everything: `python3 scripts/pipeline.py episodes/<slug>` (stages: align → validate → render → audio → subs → compose → qa). Render is cached per scene; ≈ 0.4 s/frame/worker (a 35 s video ≈ 5 min with 2 workers) – run it in the background (`nohup … &`) and poll the log.
- Output: `episodes/<slug>/out/<slug>.mp4` (1080×1920, 30 fps, H.264+AAC). Word-by-word subtitles synced to the voice (`subs.ass`), music ducked under the voice, SFX from scene events.

### 6. FIX
- `python3 scripts/fix.py episodes/<slug> list` shows validator + QA problems (wall clipping, camera inside geometry, subject off-screen, scenes too long/short, black frames, A/V mismatch).
- Look at the result: `episodes/<slug>/review/sheet.jpg` (one frame per scene) and `review/subs_*.jpg` – open them with Read and judge them against `style-rules.md` (is the subject framed? any weird pose? subtitle readable?).
- Repair surgically (only touched scenes re-render):
  `fix.py <ep> auto` · `fix.py <ep> set s3 actions.0.to "[2,0,4]"` · `fix.py <ep> set s5 cam.0.shot '"close"'` · `fix.py <ep> cut s6 '{"at":1.2,"shot":"close","on":"max"}'` · `fix.py <ep> retime s4 --end-delta -0.4` · `fix.py <ep> subs-offset 0.08` · `fix.py <ep> subs-word 12 --s 3.2 --e 3.5` · `fix.py <ep> subs-style goopie` · `fix.py <ep> frame s3 1.2` · `fix.py <ep> sheet s3`.
- Subtitle/audio fixes never re-render 3D.

## Conventions you must remember
- World units = studs (character ≈ 5.2 tall). Streets run along Z; the default camera stands at +Z looking toward −Z. `yawDeg 0` = character faces +Z (toward that camera); walking sets yaw automatically.
- Time anchors in scene JSON: seconds (`1.5`), word index (`"w3"`, `"w3e"`), word text (`"@sneeze"`, `"@teleports-0.1"`), `"end-0.5"`, `"40%"` – use word anchors so animation follows the voice.
- Walking uses A* around solid colliders automatically; `phase:true` on an actor lets it pass through walls on purpose.
- Keep each scene one idea, ≥1 action/fx, and a camera that moves; reaction close-up after every surprise.
- Tell the user honestly what was produced, what is a draft, and what they still need to provide.

## Folder map
```
SKILL.md  style-rules.md
engine/       reusable 3D studio (index.html + modules)
scripts/      analyze_refs.py  story_tools.py  align.py  subtitles.py  audio.py  render.js  pipeline.py  qa.py  fix.py
assets/       subtitle-styles.json  audio/{sfx,music}  (generated, reproducible: python3 scripts/audio.py --library)
references/   scene-format.md  story-playbook.md  elevenlabs-voice.md  analysis/ (reference measurements + contact sheets)
episodes/<slug>/  story.json  voice*.mp3  timing.json  validation.json  cache/  out/  review/
```

---
## v2 quality pack (añadido)
- **Catálogo**: `references/assets-catalog.md` (190 props, 45 personajes, 114 animaciones, 28 caras, 37 fx, 27 mundos, 18 cielos, 37 sfx, 7 músicas, 5 looks) y **imágenes reales** en `gallery/*.jpg`. Antes de escribir una historia, mira el catálogo y usa recursos variados (cada escena = imagen nueva).
- Módulos nuevos del motor: `engine/props_extra.js`, `characters_extra.js`, `anim_extra.js`, `fx_extra.js`, `world_extra.js` (cargados desde `index.html`; mejoras de render: oclusión de contacto, rim light, cielos nuevos).
- **Looks**: `assets/looks.json` (bloom, viñeta, grano, nitidez) aplicados en `compose`.
- **Voz bien sincronizada**: con UN mp3 de ElevenLabs la alineación por energía puede ir 0,4–0,7 s adelantada. Usa `python3 scripts/voice_split.py episodes/<slug>` (corta el mp3 por las pausas reales en `voice/<scene>.mp3`) y luego `pipeline.py`. Revisa la tabla que imprime.
- Galería: `python3 scripts/gallery.py <kind>`.

### Lecciones de cámara/escala (episodios liar-shrink y feed-monster, en `episodes/`)
- `scale` de un actor es **absoluto** (el preset `monster` ya trae 2.6): para un bicho pequeño usa 0.1–0.2 y `grow` hasta ~1.5 para gigante.
- Cámaras absolutas (`pos`/`look`) son más fiables que `shot` para cosas muy grandes o muy pequeñas. Streets corren por Z; cámara por defecto en +Z mirando a −Z; un actor con `yawDeg 0` mira a +Z (hacia cámara), `180` mira a −Z.
- No pongas `crowd` entre la cámara y el sujeto (tapa el plano). `music.twist_at` solo admite `"last"` o segundos, no `@palabra`.
- Un personaje diminuto necesita `close` con `dist` 4–8 o cámara absoluta a ~2 studs.
- Siempre mira `review/sheet.jpg` (un frame por escena) antes de dar el vídeo por bueno.

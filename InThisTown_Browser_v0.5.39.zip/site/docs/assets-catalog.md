# Catálogo de recursos (v2 quality pack)

Todo se usa desde `story.json` (formato en `scene-format.md`). Ver imágenes reales de cada recurso en `gallery/*.jpg`
(se regeneran con `python3 scripts/gallery.py <props|presets|clips|faces|fx|worlds|skies>`).
Lista completa en vivo: `node scripts/render.js assets`.

| Tipo | Total | Dónde se usa |
|---|---|---|
| Props 3D | 190 | `"objects":[{"id":"x","type":"dragon","pos":[0,0,10],"scale":2}]` |
| Personajes (presets) | 45 | `"characters":{"a":{"preset":"wizard"}}` |
| Animaciones | 114 | `{"actor":"a","at":"@word","do":"anim","clip":"faint","dur":1.5}` |
| Caras | 28 | `"face":"sus"` o `{"do":"expr","face":"love"}` |
| Efectos (fx) | 37 | `{"do":"fx","kind":"fire","on":"a","dur":2}` |
| Mundos | 26 | `"world":[{"type":"beach"}]`, interiores: `{"type":"interior","kind":"hospital"}` |
| Cielos | 18 | `"sky":"nightblue"` |
| Sonidos (SFX) | 37 | `{"do":"sfx","name":"fanfare"}` |
| Música | 7 loops | `"music":{"mood":"epic"}` |
| Looks (postproducción) | 5 | `"look":"night"` (ver `assets/looks.json`) |

## Personajes
`hero`, `girl`, `boy2`, `oldman`, `grandma`, `mayor`, `kid`, `teacher`, `cop`, `student`, `monster`, `robber`, `chef`, `doctor`, `nurse`, `astronaut`, `king`, `queen`, `knight`, `ninja`, `farmer`, `cowboy`, `zombie`, `robot`, `alien`, `pirate`, `scientist`, `baby`, `athlete`, `wizard`, `princess`, `firefighter`, `builder`, `mailman`, `bully`, `nerd`, `rich`, `gamer`, `reporter`, `hero2`, `villain`, `stalker`, `angel`, `bunny`, `catgirl`

## Caras
`smile`, `neutral`, `shock`, `angry`, `sad`, `laugh`, `sleep`, `wink`, `smirk`, `scared`, `dead`, `cute`, `talk`, `grin`, `worried`, `cry`, `tongue`, `love`, `dizzy`, `evil`, `sus`, `blush`, `bored`, `terrified`, `pout`, `star`, `smug`, `sob`

## Animaciones
`idle`, `walk`, `run`, `panic`, `jump`, `hop`, `wave`, `point`, `shock`, `scared`, `cheer`, `laugh`, `clap`, `talk`, `think`, `shrug`, `sit`, `sleep`, `lie`, `fall`, `fly`, `dance`, `punch`, `swing`, `sneeze`, `warp`, `arrive`, `spin`, `lookAround`, `hang`, `pullup`, `kick`, `crouch`, `bow`, `salute`, `thumbs`, `flail`, `carry`, `hide`, `tpose`, `slump`, `angry`, `cry`, `slide`, `climb`, `sprint`, `sneak`, `tiptoe`, `strut`, `limp`, `tiredwalk`, `drunk`, `zombiewalk`, `sleepwalk`, `moonwalk`, `crawl`, `swim`, `surf`, `ride`, `drive`, `skate`, `backflip`, `frontflip`, `cartwheel`, `superjump`, `dive`, `slip`, `bounce`, `float`, `faint`, `dizzy`, `shiver`, `tremble`, `jumpscare`, `facepalm`, `nod`, `headshake`, `shy`, `proud`, `flex`, `victory`, `dab`, `heart_hands`, `shush`, `listen`, `scratchhead`, `knock`, `phone`, `typing`, `eat`, `yawn`, `stretch`, `reach`, `pickup`, `throw`, `catch`, `push`, `pull`, `boxing`, `karate`, `kneel`, `worship`, `beg`, `sobsit`, `peek`, `robot`, `wave_big`, `hug`, `cheer2`, `rage`, `explode`, `shrink`, `melt`, `glitch`

## Efectos
`poof`, `sparkle`, `teleport`, `explosion`, `confetti`, `coins`, `hearts`, `smoke`, `impact`, `rain`, `snow`, `dust`, `speed`, `fire`, `embers`, `lightning`, `bubbles`, `dizzy_stars`, `sweat`, `tears`, `shockwave`, `pulse`, `godrays`, `leaves`, `petals`, `glitter`, `fireworks`, `moneyrain`, `magiccircle`, `beam`, `meteor`, `anger`, `stars_burst`, `speedlines2`, `balloons_up`, `zzz`, `heartbeat`

## Mundos
`city`, `suburb`, `house`, `mountains`, `park`, `school`, `townhall`, `room`, `void`, `crowd`, `plaza`, `studio`, `beach`, `desert`, `snow`, `forest`, `farm`, `playground`, `stadium`, `space`, `candy`, `graveyard`, `underwater`, `rooftop`, `cave`, `interior`
Interiores (`"type":"interior","kind":...`): hospital, bathroom, restaurant, gym, library, bakery, throne, garage, studio, bank, shop.

## Cielos
`day`, `sunset`, `night`, `fog`, `storm`, `red`, `interior`, `void`, `nightblue`, `dawn`, `overcast`, `neon`, `candy`, `cave`, `underwater`, `spooky`, `desert`, `space`

## Props
`car`, `taxi`, `tv`, `pepper`, `cheese`, `coin`, `umbrella`, `balloon`, `ball`, `crate`, `rocket`, `ufo`, `hammer`, `popcorn`, `bench`, `lamp`, `tree`, `pine`, `bush`, `flower`, `cloud`, `mountain`, `fountain`, `frog`, `dog`, `cat`, `fox`, `bird`, `trophy`, `cake`, `burger`, `phone`, `sign`, `door`, `bed`, `couch`, `table`, `desk`, `shelf`, `fridge`, `blackboard`, `slide`, `pullupbar`, `flag`, `hydrant`, `mailbox`, `trashcan`, `trafficlight`, `busstop`, `bus`, `policecar`, `ambulance`, `truck`, `helicopter`, `drone`, `skyscraper`, `clocktower`, `fountain2`, `statue`, `streetsign`, `stopsign`, `cone_traffic`, `barrier`, `billboard`, `storefront`, `house`, `tower_block`, `windowframe`, `garage`, `palm`, `cactus`, `rock`, `boulder`, `hill`, `log`, `stump`, `mushroom`, `sunflower`, `tulip`, `fence_wood`, `pond`, `bridge`, `rainbow`, `moon`, `sun`, `star3d`, `tvset`, `chair`, `stool`, `armchair`, `rug`, `plant`, `floorlamp`, `tablelamp`, `clock_wall`, `grandfather`, `alarmclock`, `digitalclock`, `doorknob`, `toilet`, `sink`, `bathtub`, `stove`, `piano`, `guitar`, `giftbox`, `treasure`, `goldpile`, `moneystack`, `bomb`, `button_big`, `lever`, `megaphone`, `microphone`, `camera_video`, `laptop`, `remote`, `hammock`, `pizza`, `donut`, `icecream`, `steak`, `apple`, `banana`, `carrot`, `hotdog`, `soda`, `coffee`, `cheese_wedge`, `soccerball`, `basketball`, `hoop`, `goalpost`, `trampoline`, `swing`, `dumbbell`, `barbell`, `skateboard`, `bike`, `kite`, `trophy_big`, `podium`, `stage`, `speaker`, `discoball`, `portal`, `crystal`, `robot`, `alien`, `dragon`, `castle`, `tent`, `campfire`, `sword`, `shield`, `magicwand`, `spaceship`, `satellite`, `planet`, `giantcarrot`, `skullsign`, `warningsign`, `missingposter`, `arrow3d`, `heart3d`, `gray_stalker`, `speechbubble3d`, `snowman`, `igloo`, `barn`, `haybale`, `windmill`, `silo`, `lollipop`, `candycane`, `gumdrop`, `gravestone`, `deadtree`, `coral`, `stalagmite`, `sandcastle`, `beachumbrella`, `towel`, `surfboard`, `mesa`, `sandbox`, `seesaw`, `lollitree`, `cloudplat`, `bleacher`

## Looks de postproducción (`assets/looks.json`)
`candy` (por defecto, colores vivos) · `night` (brillo fuerte en luces/neones) · `horror` (desaturado, viñeta, grano) · `clean` (solo nitidez) · `none`.
Elegir con `"look":"night"` en story.json o `pipeline.py <ep> --look night`.

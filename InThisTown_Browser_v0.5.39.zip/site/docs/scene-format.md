# story.json / scene format

```jsonc
{
 "title": "...", "slug": "sneeze-teleport", "rule": "the weird town rule", "seed": 11,
 "music": {"mood":"quirky|tense|chill|epic","twist_at":"last|<seconds>","twist_mood":"tense","volume":0.2},
 "subtitles": {"style":"zaylento|goopie|sailor","size":112,"offset":0},
 "defaults": {"sky":"day","world":[{"type":"city"}]},
 "characters": {"max":{"preset":"hero"}, "bob":{"preset":"oldman","spec":{"shirt":"#ff0000"}}},
 "scenes":[ { ...scene... } ]
}
```
## Scene
| key | meaning |
|---|---|
| `id` | unique ("s1"…) – also the voice file name in per-scene mode |
| `vo` | exact narration of this scene (English). Wrap emphasis in `*stars*` |
| `sky` | `day sunset night fog storm red interior void` (+ `env:{...}` overrides: fogNear, fogFar, sat, expo, tint…) |
| `world` | list of builders: `city{landmark,length,palette}` `suburb` `park` `school{name}` `townhall{name}` `room{kind:living|bedroom|office|classroom|kitchen,w,d,h,floor,wall}` `crowd{n,area:[x0,z0,x1,z1],yawDeg,spread}` `void`. Per-scene `seed` changes the random layout |
| `actors` | `{id:{pos:[x,z]|[x,y,z], yawDeg, face, anim, scale, visible, phase, spec:{…}, ref:"characterId"}}` – if `pos` is omitted the actor continues from the previous scene |
| `objects` | `[{id,type,pos,yawDeg,scale,opts{color,…},alpha,spin,bob}]` types: `engine props` (see `render.js assets`) |
| `actions` | timeline, see below |
| `cam` | one cut or a list of cuts (below) |
| `fx`, `texts`, `sfx` | optional arrays (same objects as the `fx`/`text`/`sfx` actions) |
| `ignoreColliders`, `allowOverlap`, `cutSfx:false`, `minDur` | validator / audio switches |

## Time anchors (`at`, `until`)
`1.5` seconds · `"w3"` start of 4th word (0-based) · `"w3e"` its end · `"@teleports"` first word starting with that text · `"@teleports+0.2"` · `"end-0.5"` · `"60%"`.

## Actor actions (`{"actor":id,"at":T,"do":…}`)
`walkTo|runTo|moveTo|goTo {to:[x,z]|actorId,speed,dur,anim,path:"straight",margin,stop}` · `flyTo|slideTo|glideTo {to,height}` · `jumpTo {to,h,dur}` · `teleport {to,warp,yaw,color}` (adds ring+beam fx, flash, sfx) · `turn {to:[x,z]|id | yawDeg}` · `anim {clip,dur,loop,params,expr}` · `expr {face}` · `talk {dur}` · `hide|show` · `grow {to,dur}` · `hover {to}` · `bubble {text,dur}`.
Clips: idle walk run panic jump hop wave point shock scared cheer laugh clap talk think shrug sit sleep lie fall fly dance punch swing sneeze warp arrive spin lookAround hang pullup kick crouch bow salute thumbs flail carry hide tpose slump angry cry slide climb.
Faces: smile grin neutral shock angry sad laugh sleep wink smirk scared dead cute talk worried cry.
Presets: hero girl boy2 oldman grandma mayor kid teacher cop student monster. Spec keys: skin hair hairStyle(bald short spiky messy long bob bun afro cap) shirt pants shoes decal(star heart bolt smiley stripe skull dot cross) face sleeves(short|long) jacket accessory[glasses sunglasses tophat crown headband mustache headphones tie sash backpack cape scarf] beard scale.

## Object actions (`{"obj":id,"at":T,"do":…}`)
`moveTo {to,dur,ease}` `yawTo` `pitchTo` `rollTo` `scaleTo` `fadeTo` `show|hide` `spin {rate}` `attach {actor,bone:handR|handL|head|back,off:[x,y,z],until}` `detach`.

## Global actions (no actor)
`fx {kind:poof|sparkle|teleport|explosion|confetti|coins|hearts|smoke|impact|rain|snow|dust|speed, at, pos|on, dur}` · `title|text {text,at,dur,y,size,color,on,pos,style:title|pop}` · `flash {dur,color,amount}` · `fade {dur,dir:in|out}` · `shake {dur,amp}` · `sfx {name,vol}`.
SFX names: whoosh swish pop boing warp boom ding coin thud sneeze poof rumble sparkle cheer giggle glass alarm zap fail click bell.

## Camera cuts (`cam: [ {at, …}, … ]`, hard cut at each `at`)
`shot`: close extreme medium wide low high over follow profile front top pov dutch hero long · `on`: actorId | objectId | [ids] | [x,z] · params: `dist height az(deg, 0=in front of target's face, 180=behind) lookY fov side lead roll` · `move`: push pull orbit(deg) crane dolly zoom rise drift whip dutch (+`amount`, `to:{…}`) · `ease` · `shake` · absolute: `pos:[x,y,z], look:[x,y,z]|{on,y}, fov, to:{pos,look,fov}` · `refYaw` for multi-target.

# Guía narrativa — historias cortas de In This Town

La generación principal de historias utiliza un modelo neuronal pequeño ejecutado en el navegador. El modelo no garantiza originalidad ilimitada y puede necesitar reintentos; el guion se valida antes de renderizarse y no debe sustituirse silenciosamente por una plantilla. El motor procedural se conserva para adaptar y dirigir visualmente los beats, no como guionista principal.

## Principios obligatorios

1. **Respetar la premisa.** Distinguir reglas, efectos y descripciones. No inventar verbos a partir de frases que no contienen una acción.
2. **Causalidad.** Cada escena debe explicar por qué ocurre la siguiente. El giro final debe resolver la idea inicial, no introducir un trabajo, monstruo o alcalde sin motivo.
3. **Variedad.** Alternar investigación, desafío, consecuencia, efecto dominó, descubrimiento y otros desarrollos. Evitar repetir la misma secuencia de «truco, alcalde, libro de normas, inspector».
4. **Personajes coherentes.** Mantener nombre, aspecto, función y posición; no cambiar de escenario sin una transición o desplazamiento narrado.
5. **Acciones visibles.** Cada movimiento, objeto y efecto debe corresponder a palabras concretas de la narración.
6. **Montaje motivado.** Cambiar de plano cuando la acción lo pida, sin movimientos de cámara aleatorios. Mantener la iluminación salvo que la historia justifique un cambio.
7. **Texto limpio.** Una frase por escena, subtítulos sincronizados, sin palabras inventadas, duplicaciones accidentales ni frases cortadas.

## Comprobación antes de exportar

- El guion trata la premisa original.
- No hay escenas que repitan la misma frase o acción sin motivo.
- Todos los personajes visibles están identificados.
- Cada objeto aparece cuando se menciona y conserva continuidad cuando se transporta.
- No hay cambios de iluminación o localización gratuitos.
- Los subtítulos corresponden exactamente a la narración.
- El preflight no informa de errores bloqueantes.

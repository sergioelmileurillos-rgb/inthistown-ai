# In This Town Browser v0.5.19

## Goal
Improve the link between what the story says and what the 3D scene actually does. This release focuses on the external LLM director and semantic continuity, not the UI.

## Changes
- Actor action inference now checks the grammatical subject instead of assigning any verb in a sentence to the visible character.
- If one actor is visible, simple subject pronouns can refer to them. Passive/object references such as “the door opened in front of Max” no longer make Max perform the opening.
- The director warns when a character changes scene location without a narrated journey or time transition.
- An object is no longer carried between different sets based only on a repeated noun mention. The narration must indicate that the character carried, brought, took, held, moved or still possessed it.
- The external story prompt preserves the open-ended brief: no mandatory mayor, shadow, monster, fixed chain of events or repeated loophole plot; it asks for a new causal mechanism and beat-by-beat visual plan.
- Updated page/app version and service-worker cache to v0.5.19 / v5-21.

## Verification
- 83 automated tests pass.
- All JavaScript syntax checks pass.
- Device-level Kokoro/WebGL2/MediaRecorder rendering has not yet been verified on the Chromebook.

## Architecture note
GitHub Pages remains a static deployment. The external LLM director uses a copy/paste prompt and JSON import. The local story engine is procedural and finite; this release does not add an embedded neural model or direct API integration.

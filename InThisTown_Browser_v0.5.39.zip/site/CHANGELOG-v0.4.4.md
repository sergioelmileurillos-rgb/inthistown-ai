# In This Town Browser v0.4.4

## Fixes
- Checks for a real WebGPU adapter before selecting WebGPU for Kokoro. If there is no adapter, the browser starts with the lighter q8 WASM path.
- Keeps the requested Kokoro-82M model and `am_adam` voice.
- Accepts the documented RawAudio Float32Array output shape and a compatible nested shape, and reports an explicit error if audio is missing.
- Adds generation-stage diagnostics so failures identify whether they happened during Kokoro loading, speech synthesis, 3D preview, or 3D recording.
- Adds scene-specific context if the original 3D engine throws while compiling or drawing a scene.
- Increments the service-worker cache to v0.4.4 so the browser does not keep stale v0.4.3 scripts.

## Verification
- JavaScript syntax checks passed for the app and every original engine module.
- All original `engine/` files match the user's `roblox-story-studio-v2.zip` byte-for-byte.
- All local script references in `index.html` exist.
- ZIP integrity check passed.
- A live Kokoro model download and full WebGL2/MediaRecorder export have not been verified in this environment.

# In This Town Browser v0.4.6

## Fix for Chromebook tab freezes during Kokoro synthesis
- Moved Kokoro-82M model loading and speech generation into `kokoro-worker.js` (module Web Worker).
- Uses Kokoro-JS 1.2.1, `q8`, `wasm`, voice `am_adam`.
- Transfers Float32 PCM buffers back to the UI thread rather than running ONNX/WASM inference in the page.
- Added progress/error messaging for worker initialization, model loading and synthesis.
- Added a clear `file://` guard: opening `index.html` from the ZIP preview is not a supported deployment; the app must be served from HTTPS or localhost for reliable worker loading.
- Updated service-worker cache to v4-6 and precaches the worker file.
- The original engine directory is retained; only the browser canvas bridge `engine/api.js` differs from the supplied original archive.

## Verification
- JavaScript syntax and ZIP integrity checked locally.
- Browser-side inference and Chromebook performance cannot be certified without a real Chromebook run.

## Additional 3D render optimization
- Cached sequential actor end-states in `engine/api.js` so scene N no longer recompiles all scenes 0..N-1 each time. This reduces repeated quadratic scene preparation to a single forward pass; the original rendering/director logic is otherwise unchanged.

/* app/story.js — v0.5 motor de historias (100 % local, sin APIs).
   premisa -> parseRule -> contexto (reparto, verbo, dominio) -> arquetipo -> beats.
   Cada beat = una frase narrada + un PLAN VISUAL explícito (actores, objeto destino, estado, animación, cámara, FX),
   anclado a palabras concretas de la frase ("opened" -> la puerta se abre justo ahí). */
(function(G){
'use strict';
const ITT=G.ITT=G.ITT||{};

/* ------------------------------------------------------------ utilidades */
function hash(str){let h=2166136261;for(let i=0;i<str.length;i++){h^=str.charCodeAt(i);h=Math.imul(h,16777619)}return h>>>0}
function rng(seed){let a=seed>>>0;return()=>{a|=0;a=a+0x6D2B79F5|0;let t=Math.imul(a^a>>>15,1|a);t=t+Math.imul(t^t>>>7,61|t)^t;return((t^t>>>14)>>>0)/4294967296}}
const cap=s=>s.charAt(0).toUpperCase()+s.slice(1);

/* ------------------------------------------------------------ morfología mínima de verbos */
const IRR={go:['went','going'],see:['saw','seeing'],run:['ran','running'],sit:['sat','sitting'],swim:['swam','swimming'],eat:['ate','eating'],speak:['spoke','speaking'],say:['said','saying'],make:['made','making'],take:['took','taking'],sleep:['slept','sleeping'],tell:['told','telling'],sing:['sang','singing'],write:['wrote','writing'],give:['gave','giving'],get:['got','getting'],come:['came','coming'],leave:['left','leaving'],hear:['heard','hearing'],drink:['drank','drinking'],stand:['stood','standing'],look:['looked','looking'],break:['broke','breaking'],keep:['kept','keeping'],find:['found','finding'],wear:['wore','wearing'],buy:['bought','buying'],hold:['held','holding'],lie:['lied','lying'],stay:['stayed','staying'],play:['played','playing'],pay:['paid','paying'],spend:['spent','spending'],throw:['threw','throwing'],ring:['rang','ringing'],read:['read','reading'],hide:['hid','hiding'],lose:['lost','losing'],fall:['fell','falling'],drive:['drove','driving'],ride:['rode','riding'],dance:['danced','dancing'],cry:['cried','crying'],win:['won','winning'],set:['set','setting'],put:['put','putting'],cut:['cut','cutting'],hit:['hit','hitting'],shut:['shut','shutting'],begin:['began','beginning'],meet:['met','meeting'],forget:['forgot','forgetting'],wake:['woke','waking'],touch:['touched','touching'],knock:['knocked','knocking']};
const DBL=new Set(['stop','step','hop','shop','plan','jog','tap','clap','chat','drop','skip','trip','whip','grab','nod','pop','sip','hug','jam','dip','rub','zip','wrap','slip','spin','swap','pat','pet','tag','beg','pin']);
function verbForms(v){v=v.toLowerCase();if(IRR[v])return{past:IRR[v][0],ing:IRR[v][1]};
  let past,ing;
  if(/e$/.test(v)){past=v+'d';ing=v.slice(0,-1)+'ing'}
  else if(/[^aeiou]y$/.test(v)){past=v.slice(0,-1)+'ied';ing=v+'ing'}
  else if(DBL.has(v)){past=v+v.slice(-1)+'ed';ing=v+v.slice(-1)+'ing'}
  else{past=v+'ed';ing=v+'ing'}
  return{past,ing}}
const PARTICLES=new Set(['up','down','out','in','on','off','over','away','back','around','outside','inside','forward','backward','backwards','along','through']);
/* "open a window" -> {verb:'open',rest:'a window'} ; "walk forward" ; "look out of a window" */
function splitAct(act){const w=act.trim().split(/\s+/);const verb=w.shift();return{verb,rest:w.join(' ')}}
function actForms(act){const {verb,rest}=splitAct(act);const f=verbForms(verb);return{base:act,verb,rest,past:f.past+(rest?' '+rest:''),ing:f.ing+(rest?' '+rest:''),pastV:f.past,ingV:f.ing}}

/* ------------------------------------------------------------ parseRule */
const MODAL='(?:is\\s+|are\\s+)?(?:allowed\\s+to|permitted\\s+to|able\\s+to|supposed\\s+to|can|may|could|should|dares?\\s+to|dared\\s+to|will|would|ever|ever\\s+dares?\\s+to)?';
function cleanRule(raw){let t=String(raw||'').replace(/\s+/g,' ').trim().replace(/^["“]|["”]$/g,'');
  t=t.replace(/^in\s+this\s+town\s*[,:\-–—]?\s*/i,'').replace(/[.!?…]+$/,'').trim();return t}
function splitMod(act){// "open a window after midnight" -> act + mod
  const m=act.match(/^(.*?)\s+((?:after|before|during|past|until|at|when|while|once|every|each)\s+(?:the\s+)?(?:midnight|night|sunset|sunrise|dawn|dusk|noon|dark(?:ness)?|school|class|dinner|lunch|breakfast|church|bedtime|[0-9]+(?::[0-9]+)?\s*(?:am|pm|a\.m\.|p\.m\.)?|[a-z]+\s+(?:o'clock|time)|\w+\s+(?:falls|rises|comes|ends|starts)))\s*$/i);
  if(m)return{act:m[1].trim(),mod:m[2].trim()};
  const m2=act.match(/^(.*?)\s+(after dark|at night|at midnight|in public|in the dark|on sundays?|on mondays?|in the morning|in the evening|in the street|indoors|outside)\s*$/i);
  if(m2)return{act:m2[1].trim(),mod:m2[2].trim()};
  return{act:act.trim(),mod:''}}
function parseRule(raw){
  const text=cleanRule(raw);const low=text.toLowerCase();let m;
  const out={raw:String(raw).trim(),text:low,kind:'prohibit',act:'',mod:'',effect:'',trigger:''};
  // Descriptive premises are not rules. Detect them before the broad
  // "everyone + verb" rule parser to avoid treating "is" as the verb "i".
  if(m=low.match(/^(everyone|everybody|all\s+(?:the\s+)?[a-z -]+?)\s+(?:is|are|was|were)\s+(.+?)\s+except\s+(?:for\s+)?(?:the\s+)?(.+)$/i)){
    out.kind='condition';out.group=m[1].trim();out.state=m[2].trim();out.exception=m[3].trim();out.act='investigate';out.f=actForms(out.act);return out;
  }
  // "Every lie makes you shrink by one inch"
  if(m=low.match(/^(?:every|each)\s+(.+?)\s+(?:makes?|will make|causes?)\s+(?:you|them|everyone|people|anyone)\s+(.+)$/)){out.kind='effect';out.trigger=m[1];out.effect=m[2];out.act=m[1];return finish(out)}
  if(m=low.match(/^if\s+(?:you|anyone|someone|somebody|people|they)\s+(.+?)\s*,?\s+(?:then\s+)?(?:you|they|it|everyone|something|the)\s*(.+)$/)){const sp=splitMod(m[1]);out.kind='effect';out.act=sp.act;out.mod=sp.mod;out.trigger=sp.act;out.effect=m[2];return finish(out)}
  if(m=low.match(new RegExp('^(?:nobody|no\\s?one|no\\s+person|nobody\\s+in\\s+town|no\\s+resident)\\s+'+MODAL+'\\s*(.+)$'))){const sp=splitMod(m[1]);out.act=sp.act;out.mod=sp.mod;out.kind='prohibit';return finish(out)}
  if(m=low.match(/^(?:you|everyone|people|residents|citizens|kids|children|all\s+\w+)\s+(?:can(?:not|'t)|cannot|must\s+not|mustn't|may\s+not|are\s+not\s+allowed\s+to|aren't\s+allowed\s+to|should\s+never|can\s+never|must\s+never|never|do\s+not|don't|are\s+forbidden\s+to|are\s+never\s+allowed\s+to)\s+(.+)$/)){const sp=splitMod(m[1]);out.act=sp.act;out.mod=sp.mod;out.kind='prohibit';return finish(out)}
  if(m=low.match(/^(?:you|everyone|people|residents|citizens)\s+(?:can|may|must)\s+only\s+(.+)$/)){const sp=splitMod(m[1]);out.act=sp.act;out.mod=sp.mod;out.kind='only';return finish(out)}
  if(m=low.match(/^(?:you|everyone|people|residents|citizens)\s+(?:must|have\s+to|need\s+to|are\s+required\s+to|should\s+always|always\s+have\s+to)\s+(.+)$/)){const sp=splitMod(m[1]);out.act=sp.act;out.mod=sp.mod;out.kind='must';return finish(out)}
  if(m=low.match(/^(?:it\s+is|it's)\s+(?:illegal|forbidden|against\s+the\s+law)\s+to\s+(.+)$/)){const sp=splitMod(m[1]);out.act=sp.act;out.mod=sp.mod;return finish(out)}
  if(m=low.match(/^(?:no|never)\s+(\w+ing)\s*(.*)$/)){const sp=splitMod((m[1]+' '+m[2]).trim());out.act=ingToBase(sp.act);out.mod=sp.mod;return finish(out)}
  if(m=low.match(/^(?:everyone|everybody|all\s+\w+)\s+(?:has|have)\s+to\s+(.+)$/)){const sp=splitMod(m[1]);out.act=sp.act;out.kind='must';out.mod=sp.mod;return finish(out)}
  if(m=low.match(/^(?:everyone|everybody|people|residents)\s+(\w+)\s*(.*)$/)){// "everyone whispers"
    out.kind='must';const v=m[1].replace(/ies$/,'y').replace(/(s|es)$/,'');const sp=splitMod((v+' '+m[2]).trim());out.act=sp.act;out.mod=sp.mod;return finish(out)}
  // Do not silently turn a plain description into an invented verb/rule.
  if(/^(?:everyone|everybody|all\s+(?:the\s+)?[a-z -]+|the\s+[a-z -]+|[a-z]+)\s+(?:is|are|was|were)\s+/i.test(low)){
    throw new Error('Esta premisa describe una situación, no una regla que el motor local pueda interpretar con seguridad. Usa una premisa con «except» o prepara un guion original en Director IA.');
  }
  // sin patrón: toda la frase como acto genérico
  const sp=splitMod(low);out.act=sp.act;out.mod=sp.mod;out.kind='prohibit';out.generic=true;return finish(out)}
function ingToBase(s){const {verb,rest}=splitAct(s);let b=verb.replace(/ing$/,'');if(/(.)\1$/.test(b))b=b.slice(0,-1);else if(IRR[b+'e']||/[^aeiou][aeiou][^aeiouwxy]$/.test(b)&&b.length<5)b=b+'e';return (b+' '+rest).trim()}
function finish(o){
  o.act=o.act.replace(/^(?:ever\s+|to\s+)/,'').replace(/\s+/g,' ').trim();
  if(!o.act)o.act='break the rule';
  o.f=actForms(o.act);return o}

/* ------------------------------------------------------------ dominios: qué significa romper la regla visualmente */
/* gesture: {k:'interact',kind,prop} | {k:'anim',clip,expr,fx} */
const NOUN_PROP=[[/window|curtain|blind|shutter/,'window_h'],[/door|gate|entrance/,'door_h'],[/light|lamp|switch|bulb|candle|lantern|flashlight/,'lamp_s'],[/\btv\b|television|screen|channel|video/,'tv_s'],[/mirror|reflection/,'mirror'],[/phone|call|text|message/,'phone'],[/clock|watch|time/,'clock_wall'],[/chest|box|crate|gift|present|package|parcel|treasure/,'chest'],[/fridge|refrigerator/,'fridge_h'],[/book|page|rule|newspaper|letter|note/,'rulebook'],[/pizza|cake|cookie|food|dinner|lunch|snack|burger|bread|pie|candy|ice cream|donut/,'pizza'],[/bird|parrot|crow|owl/,'parrot'],[/ball|toy/,'ball'],[/umbrella|rain/,'umbrella'],[/balloon/,'balloon']];
const VERB_CLASS=[
  [/^(open|unlock|unseal|crack|unlatch|pull)$/,'open'],[/^(close|shut|lock|seal|slam)$/,'close'],[/^(look|watch|stare|peek|peep|gaze|spy|glance|see|observe|check)$/,'look'],
  [/^(knock|ring|tap)$/,'knock'],[/^(turn|switch|flip|light|ignite|press|push|click|flick)$/,'switch'],
  [/^(run|jog|sprint|race|rush|hurry)$/,'run'],[/^(walk|step|stroll|wander|move|go|travel|cross|leave|exit|enter|come)$/,'walk'],[/^(jump|hop|leap|skip|bounce)$/,'jump'],
  [/^(sing|hum|whistle|chant)$/,'sing'],[/^(dance|twirl|boogie)$/,'dance'],[/^(laugh|giggle|smile|grin|chuckle|joke)$/,'laugh'],[/^(cry|weep|sob)$/,'cry'],[/^(sneeze|cough|yawn)$/,'sneeze'],
  [/^(speak|talk|say|shout|yell|scream|whisper|tell|lie|answer|ask|call|argue|complain|mention|name)$/,'speak'],
  [/^(sleep|dream|nap|snore|rest|lie\s*down)$/,'sleep'],[/^(eat|drink|chew|taste|bite|cook|bake|swallow|sip)$/,'eat'],
  [/^(read|write|draw|type|study|text)$/,'read'],[/^(touch|grab|take|pick|steal|hold|carry|borrow|bring|keep|collect)$/,'touch'],
  [/^(clap|wave|point|salute|bow|hug|kiss|shake|nod)$/,'gesture'],[/^(swim|dive|fly|climb|float|surf|ride|drive|slide|swing)$/,'move2'],[/^(stand|sit|stay|wait|stop|freeze|hide|kneel)$/,'still'],
  [/^(wear|put)$/,'touch'],[/^(forget|remember|think|wonder|ignore|trust|believe)$/,'think']];
function classifyVerb(v){for(const [re,c] of VERB_CLASS)if(re.test(v))return c;return 'other'}
function nounProp(txt){for(const [re,p] of NOUN_PROP)if(re.test(txt))return p;return null}
function nounPhrase(f){// "the window" a partir de "open a window"
  const r=f.rest.replace(/^(?:a|an|the|any|your|their|his|her|its|our|my)\s+/,'').replace(/\s+(?:outside|out|away|up|down|again|twice|once|alone|aloud|loudly|quietly)$/,'');
  return r?'the '+r:'it'}

function domainOf(rule,rnd){
  const f=rule.f,vc=classifyVerb(f.verb.toLowerCase()),txt=(f.rest+' '+rule.mod+' '+rule.text).toLowerCase();
  const prop=nounProp(f.rest.toLowerCase())||nounProp(f.verb+' '+f.rest);
  const d={vc,prop,home:'facade',breakKind:'anim',clip:'shrug',fx:null,expr:'smirk',sfx:'pop'};
  const isInteract=(prop==='window_h'||prop==='door_h'||prop==='chest'||prop==='fridge_h')&&(vc==='open'||vc==='close'||vc==='knock'||vc==='look'||vc==='touch'||vc==='other'||vc==='switch');
  if(vc==='look'&&(/window|outside|street|out of/.test(txt))){d.breakKind='interact';d.ikind='peek';d.prop='window_h';d.obj='winL';d.home='facade';return d}
  if(isInteract){d.breakKind='interact';d.ikind=vc==='knock'?'knock':vc==='close'?'close':(vc==='look'?'peek':'open');d.obj=prop==='window_h'?'winL':prop==='door_h'?'door':'item';d.home=prop==='fridge_h'?'interior:restaurant':prop==='chest'?'facade':'facade';return d}
  if(vc==='switch'||prop==='lamp_s'||/\b(lights?|lamp|dark)\b/.test(f.rest)){d.breakKind='interact';d.ikind=(/off|out/.test(txt)?'switchOff':'switchOn');d.prop='lamp_s';d.obj='lampL';d.home='facade';return d}
  if(vc==='sleep'||/\b(bed|sleep|dream|awake|midnight|night)\b/.test(txt)&&vc!=='look'&&vc!=='walk'&&vc!=='run'&&vc!=='speak'){d.home='bedroom';d.clip=vc==='sleep'?'sleep':'yawn';d.expr='sleep';d.fx='zzz';d.sfx='yawn';return d}
  switch(vc){
    case'run':d.clip='run';d.home='park';d.expr='grin';d.fx='speed';d.sfx='swish';d.travel=true;break;
    case'walk':d.clip=/back/.test(txt)?'moonwalk':'walk';d.home='park';d.expr=/back/.test(txt)?'dizzy':'neutral';d.travel=true;break;
    case'jump':d.clip='jump';d.home='park';d.expr='grin';d.fx='poof';d.sfx='boing';break;
    case'sing':d.clip='dance';d.home='park';d.expr='grin';d.fx='sparkle';d.sfx='sparkle';break;
    case'dance':d.clip='dance';d.home='park';d.expr='grin';d.fx='sparkle';break;
    case'laugh':d.clip='laugh';d.home='park';d.expr='laugh';d.fx='sparkle';d.sfx='giggle';break;
    case'cry':d.clip='cry';d.home='park';d.expr='cry';d.fx='tears';break;
    case'sneeze':d.clip='sneeze';d.home='park';d.expr='worried';d.fx='poof';break;
    case'speak':d.clip='talk';d.home='townhall';d.expr='talk';d.speech=true;d.fx=null;d.sfx='pop';break;
    case'eat':d.clip='eat';d.home='interior:restaurant';d.expr='grin';d.fx='sparkle';d.prop=d.prop||'pizza';break;
    case'read':d.clip='phone';d.home='interior:library';d.expr='neutral';d.prop=d.prop||'rulebook';break;
    case'touch':d.clip='pickup';d.home='facade';d.expr='sus';d.prop=d.prop||'chest';d.fx='sparkle';break;
    case'gesture':d.clip=/clap/.test(f.verb)?'clap':/wave/.test(f.verb)?'wave':/point/.test(f.verb)?'point':/bow/.test(f.verb)?'bow':/salute/.test(f.verb)?'salute':/hug/.test(f.verb)?'hug':'wave';d.home='park';d.expr='grin';d.fx='sparkle';break;
    case'move2':d.clip=/swim/.test(f.verb)?'swim':/fly/.test(f.verb)?'fly':/climb/.test(f.verb)?'climb':/slide/.test(f.verb)?'slide':'ride';d.home='park';d.expr='grin';d.fx='bubbles';break;
    case'still':d.clip=/sit/.test(f.verb)?'sit':/hide/.test(f.verb)?'hide':'kneel';d.home='park';d.expr='worried';break;
    case'think':d.clip='think';d.home='facade';d.expr='worried';break;
    case'close':d.clip='reach';d.home='facade';break;
    case'look':d.clip='lookAround';d.home='facade';d.expr='sus';d.prop=d.prop||'mirror';break;
    default:d.clip=rnd()<.5?'shrug':'point';d.home='facade';d.expr='smirk';d.fx='sparkle';
  }
  return d}

/* ------------------------------------------------------------ reparto */
const HEROES=[{preset:'hero',g:'m',names:['Max','Leo','Jack','Finn','Noah']},{preset:'girl',g:'f',names:['Lily','Mia','Zoe','Ruby','Nina']},{preset:'boy2',g:'m',names:['Sam','Eli','Theo','Kai','Omar']},{preset:'student',g:'m',names:['Ben','Alex','Hugo','Dan','Ethan']},{preset:'catgirl',g:'f',names:['Luna','Ivy','Maya','Cleo','Tess']}];
const NEIGHBORS=[{preset:'kid',g:'m',names:['Timmy','Oscar','Jojo']},{preset:'nerd',g:'m',names:['Gus','Walter','Percy']},{preset:'builder',g:'m',names:['Rex','Moe','Bruno']},{preset:'nurse',g:'f',names:['Daisy','Rosa','Pearl']},{preset:'farmer',g:'m',names:['Earl','Clyde','Hank']},{preset:'athlete',g:'f',names:['Skye','Jade','Tara']},{preset:'chef',g:'m',names:['Luigi','Marco','Gordo']}];
function pronouns(g){return g==='f'?{he:'she',He:'She',him:'her',his:'her',His:'Her',hims:'herself'}:{he:'he',He:'He',him:'him',his:'his',His:'His',hims:'himself'}}
function makeCast(r){
  const hero=HEROES[Math.floor(r()*HEROES.length)];let nb=NEIGHBORS[Math.floor(r()*NEIGHBORS.length)];
  const hn=hero.names[Math.floor(r()*hero.names.length)],nn=nb.names[Math.floor(r()*nb.names.length)];
  const tintShirt=['#2f6df6','#e84a4a','#32b36b','#f5a623','#a45be8','#17b7c8'][Math.floor(r()*6)];
  return{
    hero:{id:'hero',name:hn,g:hero.g,p:pronouns(hero.g),spec:{preset:hero.preset,shirt:tintShirt}},
    nbr:{id:'nbr',name:nn,g:nb.g,p:pronouns(nb.g),spec:{preset:nb.preset}},
    mayor:{id:'mayor',name:'the mayor',g:'m',p:pronouns('m'),spec:{preset:'mayor'}},
    shadow:{id:'shadow',name:'the shadow',g:'m',p:pronouns('m'),spec:{preset:'ninja',shirt:'#07070c',pants:'#07070c',face:'evil'}},
    extra1:{id:'extra1',name:'a neighbor',g:'f',p:pronouns('f'),spec:{preset:'grandma'}},
    extra2:{id:'extra2',name:'a neighbor',g:'m',p:pronouns('m'),spec:{preset:'oldman'}},
    extra3:{id:'extra3',name:'a neighbor',g:'f',p:pronouns('f'),spec:{preset:'teacher'}}}}

/* ------------------------------------------------------------ contexto de plantillas */
function makeCtx(rule,dom,cast,tone,rnd){
  const f=rule.f,H=cast.hero,N=cast.nbr,np=nounPhrase(f);
  const eff=rule.effect?rule.effect.replace(/\s+/g,' '):'';
  const c={rule,dom,cast,tone,rnd,H:H.name,N:N.name,he:H.p.he,He:H.p.He,him:H.p.him,his:H.p.his,His:H.p.His,hims:H.p.hims,nhe:N.p.he,nHe:N.p.He,nhim:N.p.him,nhis:N.p.his,nHis:N.p.His,
    act:f.base,ing:f.ing,past:f.past,thing:np,mod:rule.mod,effect:eff,
    modc:rule.mod?', '+rule.mod:'',modp:rule.mod?' '+rule.mod:'',
    ruleSent:'In this town, '+rule.text.replace(/\b(monday|tuesday|wednesday|thursday|friday|saturday|sunday)s?\b/g,m=>cap(m))+'.',
    when:rule.mod||'at night',
    forbid:rule.kind==='prohibit'?f.base:'',
    breakline:null};
  // frase "romper la regla" según tipo
  if(rule.kind==='prohibit'||rule.kind==='effect')c.breakI=c.past;       // H opened a window
  else c.breakI='stopped '+f.ing;                                         // H stopped opening a window
  c.breakN=c.breakI;
  c.doing=rule.kind==='prohibit'||rule.kind==='effect'?c.ing:c.ing;
  c.itPron=/^(?:the|a|an)\s/.test(np)||np==='it'?'it':'it';
  return c}
function fill(t,c){return t.replace(/\{(\w+)\}/g,(m,k)=>c[k]!==undefined?c[k]:m).replace(/\s+([,.!?])/g,'$1').replace(/\s{2,}/g,' ').replace(/,\s*,/g,',').trim()}

/* ------------------------------------------------------------ arquetipos */
const wk=(c,k)=>c.dom.breakKind;// helper
/* helper de plan: gesto de romper la regla para un actor */
function breakPlan(c,actor,word){
  const d=c.dom,A=actor;
  if(c.rule.kind!=='prohibit'&&c.rule.kind!=='effect')return[['anim',A,'headshake',word,1.1,'worried'],['anim',A,'idle',null]];
  if(d.breakKind==='interact'){const o=[['do',A,d.ikind,d.obj,word]];if(d.ikind==='open'||d.ikind==='peek')o.push(['fx','sparkle',d.obj,word]);return o}
  const o=[['anim',A,d.clip,word,1.6,d.expr]];if(d.fx)o.push(['fx',d.fx,A,word]);return o}
function copyPlan(c,actor,word){return breakPlan(c,actor,word)}

const ARCH={};
/* --- P: descriptive premise (not forced into a made-up rule) --- */
ARCH.condition=c=>{
 const H='hero',N='nbr',M='mayor',B=[];
 const T=(role,set,vo,plan,cam,extra)=>B.push(Object.assign({role,set,vo,plan:plan||[],cam},extra||{}));
 const exception=String(c.rule.exception||'').replace(/^(?:the|a|an)\s+/,'');
 const isMayor=/mayor|leader|president|boss|king|queen|owner/i.test(exception);
 const outlier=isMayor?'the mayor':(exception||'one person');
 const money=/poor|rich|wealth|money|broke|income|cash/i.test(c.rule.state||'');
 T('hook','street',c.ruleSent,[['cast',{hero:'front'}],['anim',H,'lookAround','town',1.5,'worried'],['hook', 'THE TRUTH ABOUT THIS TOWN']],[['wide',[H],{az:12,move:'crane',amount:.28}]]);
 if(money&&isMayor){
  if(c.rnd()<.5){
   T('setup','market',`${c.H} worked every day, but still could not afford rent.`,[['cast',{hero:'front',nbr:'yardL'}],['anim',H,'work','worked',1.1,'worried']],[['medium',[H,N],{az:-14,move:'drift'}]]);
   T('setup','market',`The mayor claimed the town had no money to spare.`,[['cast',{mayor:'right'}],['anim',M,'shrug','claimed',1,'smug']],[['medium',[M],{az:12,move:'push',amount:.18}]]);
   T('build','market',`${c.N} found a stack of unpaid wage slips.`,[['obj','wageSlips','paper_custom','slips','fadeIn'],['anim',N,'pickup','found',.9,'shock']],[['close',[N,'wageSlips'],{az:-8,move:'push',amount:.22}]]);
   T('build','market',`Every worker had been shortchanged for months.`,[['cast',{hero:'left',nbr:'right'}],['anim',H,'read','workers',1,'angry'],['anim',N,'point','months',.9,'worried']],[['medium',[H,N],{az:14,move:'dolly'}]]);
   T('turn','street',`They asked the shopkeepers what had happened.`,[['cast',{hero:'front',extra1:'street',extra2:'streetR'}],['anim',H,'talk','asked',1,'determined'],['anim','extra1','shrug','happened',.9,'worried']],[['wide',[H,'extra1','extra2'],{az:-16,move:'drift'}]]);
   T('build','townhall',`One shopkeeper pointed to a locked office.`,[['walk',H,'door','pointed',1.1],['obj','officeDoor','door','locked','fadeIn'],['anim',N,'point','office',.9,'sus']],[['medium',[H,N,'officeDoor'],{az:12,move:'push',amount:.2}]]);
   T('build','townhall',`Inside, they found the real town accounts.`,[['obj','accounts','book_custom','accounts','fadeIn'],['anim',H,'read','inside',1,'shock']],[['close',[H,'accounts'],{az:-10,move:'push',amount:.24}]]);
   T('reveal','townhall',`The missing wages had paid for the mayor's mansion.`,[['cast',{hero:'left',mayor:'right'}],['anim',M,'worried','mansion',1.1,'worried'],['anim',H,'point','paid',.9,'angry']],[['medium',[H,M],{az:18,move:'push',amount:.2}]]);
   T('turn','street',`${c.H} brought the accounts to the whole town.`,[['cast',{hero:'front',extra1:'street',extra2:'streetR',extra3:'yardR'}],['anim',H,'present','accounts',1.1,'determined'],['anim','extra1','shock','town',.9,'shock']],[['wide',[H,'extra1','extra2','extra3'],{az:-16,move:'crane',amount:.25}]]);
   T('twist','townhall',`The mayor tried to blame a missing page.`,[['cast',{hero:'left',mayor:'right'}],['anim',M,'headshake','blame',1,'angry'],['obj','missingPage','paper_custom','page','rise']],[['close',[M,'missingPage'],{az:8,move:'push',amount:.2}]]);
   T('reveal','townhall',`But the signed copy was still in the ledger.`,[['obj','accounts','book_custom','ledger','appear'],['anim',H,'point','signed',.9,'grin']],[['close',[H,'accounts'],{az:-8,move:'zoom',amount:.2}]]);
   T('turn','townhall',`The residents voted to remove the mayor.`,[['cast',{hero:'front',extra1:'street',extra2:'streetR'}],['anim','extra1','point','voted',1,'angry'],['anim',H,'cheer','remove',1,'grin']],[['wide',[H,'extra1','extra2'],{az:18,move:'pull',amount:.3}]]);
   T('payoff','street',`The workers finally received what they had earned.`,[['anim',H,'smile','finally',1,'grin'],['anim',N,'cheer','received',1,'grin'],['fx','confetti',H,'earned']],[['wide',[H,N],{az:-12,move:'rise',amount:.25}]]);
   T('payoff','townhall',`And the town kept its accounts open for everyone.`,[['anim',H,'present','everyone',1,'grin'],['anim',M,'shrug','accounts',1,'worried']],[['medium',[H,M],{az:12,move:'pull',amount:.2}]]);
   return B;
  }
  T('setup','street',`${c.H} lived in the smallest house on the street.`,[['cast',{hero:'front',nbr:'yardL'}],['anim',H,'lookAround','smallest',1.1,'worried']],[['wide',[H],{az:-16,move:'drift'}]]);
  T('setup','street',`Every family struggled to afford the basics.`,[['anim',N,'worried','families',1.1,'worried'],['anim',H,'shrug','basics',.9,'sad']],[['medium',[H,N],{az:14,move:'push',amount:.16}]]);
  T('build','street',`But the mayor's mansion kept getting bigger.`,[['cast',{mayor:'yardR'}],['anim',M,'proud','mansion',1.2,'smug']],[['wide',[H,M],{az:-18,move:'pull',amount:.2}]]);
  T('build','street',`${c.H} found a receipt outside town hall.`,[['obj','receipt','paper_custom','receipt','right','fadeIn'],['anim',H,'pickup','found',.9,'curious']],[['close',[H,'receipt'],{az:8,move:'push',amount:.24}]]);
  T('build','townhall',`It showed public money paying for private luxuries.`,[['cast',{hero:'left'}],['obj','ledger','book_custom','money','fadeIn'],['anim',H,'read','showed',1.1,'shock']],[['medium',[H,'ledger'],{az:-12,move:'push',amount:.2}]]);
  T('turn','street',`${c.N} recognized the mayor's signature.`,[['cast',{hero:'left',nbr:'right'}],['anim',N,'point','signature',1,'shock'],['anim',H,'think','recognized',.9,'worried']],[['over',[H,N],{az:18,move:'dolly'}]]);
  T('build','street',`Together, they followed the delivery truck.`,[['walk',H,'streetR','followed',1.6],['walk',N,'yardR','truck',1.5]],[['wide',[H,N],{az:20,move:'follow'}]]);
  T('build','townhall',`It led them to a locked storage room.`,[['obj','storageDoor','door','locked','fadeIn'],['anim',H,'inspect','locked',1,'sus']],[['medium',[H,'storageDoor'],{az:-10,move:'push',amount:.2}]]);
  T('turn','townhall',`Inside were supplies the town had paid for.`,[['obj','supplyBoxes','crate','supplies','rise'],['anim',N,'shock','inside',1,'shock']],[['wide',[H,N,'supplyBoxes'],{az:12,move:'pull',amount:.24}]]);
  T('reveal','townhall',`The mayor had kept them for himself.`,[['cast',{hero:'left',mayor:'right'}],['anim',M,'worried','himself',1.1,'worried'],['anim',H,'point','kept',.9,'angry']],[['medium',[H,M],{az:-16,move:'push',amount:.2}]]);
  T('build','townhall',`${c.H} showed the records to the residents.`,[['cast',{hero:'front',extra1:'street',extra2:'streetR'}],['anim',H,'present','records',1.1,'determined'],['anim','extra1','point','residents',.9,'shock']],[['wide',[H,'extra1','extra2'],{az:18,move:'crane',amount:.25}]]);
  T('twist','townhall',`The mayor denied it, until they showed his signature.`,[['cast',{hero:'left',mayor:'right'}],['anim',M,'headshake','denied',1,'angry'],['obj','receipt','paper_custom','signature','appear']],[['close',[M,'receipt'],{az:8,move:'push',amount:.22}]]);
  T('turn','townhall',`The whole town demanded the supplies back.`,[['cast',{hero:'front',extra1:'street',extra2:'streetR',extra3:'yardR'}],['anim','extra1','angry','demanded',1,'angry'],['anim','extra2','point','back',1,'determined']],[['wide',[H,'extra1','extra2','extra3'],{az:-16,move:'pull',amount:.3}]]);
  T('payoff','street',`By morning, every family had what it needed.`,[['anim',H,'smile','morning',1.1,'grin'],['anim',N,'cheer','family',1.1,'grin'],['fx','confetti',H,'morning']],[['wide',[H,N,'extra1','extra2'],{az:12,move:'rise',amount:.25}]]);
  T('payoff','townhall',`And the mayor had to live by the same budget.`,[['cast',{mayor:'center'}],['anim',M,'shrug','budget',1.1,'worried'],['anim',H,'wave_big','same',1,'grin']],[['medium',[H,M],{az:-12,move:'pull',amount:.2}]]);
  return B;
 }
 T('setup','street',`Everyone had accepted the situation for years.`,[['anim',H,'think','years',1.1,'worried']],[['medium',[H],{az:12,move:'drift'}]]);
 T('build','street',`${c.H} noticed one detail nobody else questioned.`,[['anim',H,'inspect','detail',1.1,'curious']],[['close',[H],{az:-10,move:'push',amount:.2}]]);
 T('build','street',`${c.N} helped compare what each person had.`,[['anim',N,'think','compare',1,'worried']],[['medium',[H,N],{az:14,move:'dolly'}]]);
 T('turn','townhall',`They found proof that the situation was not fair.`,[['obj','evidence','paper_custom','proof','fadeIn'],['anim',H,'read','proof',1,'shock']],[['close',[H,'evidence'],{az:8,move:'push',amount:.22}]]);
 T('reveal','townhall',`${outlier} had been hiding the truth.`,[['cast',{hero:'left',mayor:'right'}],['anim',M,'worried','truth',1,'worried']],[['medium',[H,M],{az:-12,move:'push',amount:.2}]]);
 T('payoff','street',`The residents finally decided to change things together.`,[['cast',{hero:'front',extra1:'street',extra2:'streetR'}],['anim',H,'present','together',1,'grin'],['anim','extra1','cheer','together',1,'grin']],[['wide',[H,'extra1','extra2'],{az:16,move:'crane',amount:.25}]]);
 return B;
};
/* --- L: la LAGUNA (divertida) --- */
ARCH.loophole=c=>{const H='hero',N='nbr',M='mayor';const V=a=>a[Math.floor(c.rnd()*a.length)];const home=c.dom.home;const P=breakPlan;const only=c.rule.kind!=='prohibit'&&c.rule.kind!=='effect';
 const B=[];const T=(role,set,vo,plan,cam,extra)=>B.push(Object.assign({role,set,vo,plan:plan||[],cam},extra||{}));
 T('hook',home,'{ruleSent}',[['cast',{hero:'front'}],['anim',H,'lookAround','In',2],['hook']],[['wide',[H],{az:12,move:'crane',amount:.3}]]);
 T('setup',home,V(['Everyone obeyed it.','And everyone obeyed it.','Nobody ever questioned it.']),[['cast',{hero:'front',nbr:'yardL',extra1:'street',extra2:'streetR'}],['anim','extra1','walk',null,0,'smile'],['anim','extra2','walk',null,0,'neutral'],['walkOff','extra1','streetR'],['walkOff','extra2','street'],['anim',N,'idle']],[['wide',[H,N],{az:-18,move:'drift'}]]);
 T('setup',home,'Everyone, except {H}.',[['anim',H,'idle'],['expr',H,'smirk','except'],['face',H,'camera','except']],[['close',[H],{az:10,move:'push',amount:.25}]]);
 T('setup',home,only?'{H} was tired of it.':'{H} had a plan.',[['anim',H,'think',null,1.6,'smirk'],['fx','sparkle',H,'plan']],[['medium',[H],{az:-20,move:'dolly'}]]);
 T('build',home,V(['{He} waited until nobody was looking.','{He} checked the street. Twice.','{He} made sure the coast was clear.']),[['anim',H,'sneak',null,0,'sus'],['expr',H,'sus','nobody'],['sfx','swish','waited']],[['medium',[H,N],{az:24,move:'push',amount:.2}]]);
 T('build',home,only?'Then {he} {breakI}.':'Then {he} {past}.',P(c,H,only?'stopped':c.rule.f.pastV),[['medium',[H],{az:-28,move:'push',amount:.18}]],{focus:H,key:'break'});
 T('build',home,V(['Nothing happened.','And nothing bad happened.','Not a single thing went wrong.']),[['anim',H,'shrug','Nothing',.9,'neutral'],['sfx','ding','happened']],[['close',[H],{az:14}]]);
 T('build',home,'But {N} had seen everything.',[['walk',N,'yardL',null],['anim',N,'shock','seen',1.2,'gasp'],['fx','stars_burst',N,'everything']],[['over',[N],{az:160}],['close',[N],{az:-12,at:'seen'}]]);
 T('build',home,'{N} tried it too.',P(c,N,'tried'),[['medium',[N],{az:22,move:'push',amount:.2}]],{focus:N});
 T('turn',home,'Soon, the whole street joined in.',[['cast',{extra1:'street',extra2:'streetR',nbr:'yardL'}],...[['extra1','Soon'],['extra2','joined'],[N,'whole']].map(([a,w])=>['anim',a,c.dom.clip==='walk'||c.dom.clip==='run'?'cheer':c.dom.clip==='sleep'?'cheer':c.dom.clip,w,0,c.dom.expr]),['fx','confetti',H,'joined']],[['wide',[H,N,'extra1','extra2'],{az:-24,move:'orbit',deg:30}]]);
 const ending=Math.floor(c.rnd()*3);
 if(ending===0){
  T('turn','townhall','The mayor arrived and demanded an explanation.',[['cast',{mayor:'podium',hero:'left'}],['walk',M,'plaza','arrived',1.8],['anim',M,'angry','demanded',1,'angry']],[['low',[M],{az:10,move:'pull',amount:.2}]]);
  T('turn','townhall','He announced that the trick was now forbidden.',[['anim',M,'point','announced',1,'angry'],['text','TRICK BANNED','forbidden',1.3,'title']],[['medium',[M],{az:-16,move:'push',amount:.2}]]);
  T('reveal','townhall','But the new rule had the same tiny loophole.',[['anim',H,'think','loophole',1,'smirk'],['obj','ruleNotice','paper_custom','rule','fadeIn']],[['close',[H,'ruleNotice'],{az:8,move:'push',amount:.22}]]);
  T('twist','street','{N} spotted it before anyone else.',[['cast',{hero:'left',nbr:'right'}],['anim',N,'point','spotted',1,'shock'],['anim',H,'shock','else',.9,'shock']],[['over',[H,N],{az:14,move:'dolly'}]]);
  T('payoff','street','This time, they used it to help the whole town.',[['anim',H,'present','help',1.1,'grin'],['anim',N,'cheer','town',1,'grin'],['fx','confetti',H,'town']],[['wide',[H,N,'extra1','extra2'],{az:-14,move:'rise',amount:.25}]]);
 }else if(ending===1){
  T('turn',home,'By sunset, everyone was copying the trick.',[['cast',{hero:'front',nbr:'yardL',extra1:'street',extra2:'streetR',extra3:'yardR'}],['anim','extra1','cheer','copying',1,'grin'],['anim','extra2','cheer','trick',1,'grin']],[['wide',[H,N,'extra1','extra2','extra3'],{az:-20,move:'pull',amount:.3}]]);
  T('turn',home,'The town could no longer use the old system.',[['anim',H,'lookAround','town',1,'worried'],['anim',N,'shrug','system',1,'worried']],[['wide',[H,N,'extra1','extra2'],{az:16,move:'drift'}]]);
  T('twist',home,'{H} realised the trick had gone too far.',[['anim',H,'facepalm','realised',1,'worried'],['anim',N,'think','far',.9,'worried']],[['close',[H],{az:-10,move:'push',amount:.2}]]);
  T('reveal','townhall','So {H} explained exactly how it worked.',[['cast',{hero:'left',nbr:'right'}],['anim',H,'talk','explained',1.1,'determined'],['anim',N,'point','worked',.9,'grin']],[['medium',[H,N],{az:14,move:'dolly'}]]);
  T('payoff','townhall','The residents agreed on a fairer rule together.',[['cast',{hero:'front',extra1:'street',extra2:'streetR'}],['anim',H,'present','together',1,'grin'],['anim','extra1','cheer','together',1,'grin']],[['wide',[H,'extra1','extra2'],{az:-14,move:'crane',amount:.25}]]);
 }else{
  T('turn','townhall','The mayor tried the same trick himself.',[['cast',{mayor:'center',hero:'left'}],['anim',M,'think','trick',1,'smirk'],['anim',H,'shock','himself',.9,'shock']],[['medium',[H,M],{az:12,move:'push',amount:.2}]]);
  T('turn','townhall','For once, the mayor was the one caught.',[['anim',M,'scared','caught',1,'worried'],['anim',H,'point','caught',.9,'grin'],['fx','stars_burst',M,'caught']],[['close',[M],{az:-12,move:'zoom',amount:.24}]]);
  T('build','street','{N} helped {H} show everyone what happened.',[['cast',{hero:'left',nbr:'right',extra1:'street'}],['anim',N,'present','helped',1,'grin'],['anim',H,'point','happened',.9,'determined']],[['medium',[H,N],{az:16,move:'dolly'}]]);
  T('twist','townhall','The mayor could not deny his own trick.',[['cast',{mayor:'center'}],['anim',M,'headshake','deny',1,'worried']],[['close',[M],{az:8,move:'push',amount:.2}]]);
  T('payoff','street','And the town finally got the last laugh.',[['anim',H,'laugh','finally',1.1,'laugh'],['anim',N,'cheer','laugh',1,'grin'],['fx','confetti',H,'laugh']],[['wide',[H,N,'extra1','extra2'],{az:-16,move:'rise',amount:.25}]]);
 }
 return B};

/* --- W: el AVISO (misterio/suspense) --- */
ARCH.warning=c=>{const H='hero',N='nbr';const only=c.rule.kind!=='prohibit'&&c.rule.kind!=='effect';const home=c.dom.home==='bedroom'?'bedroom':'facade';const P=breakPlan;const V=a=>a[Math.floor(c.rnd()*a.length)];
 const B=[];const T=(role,set,vo,plan,cam,extra)=>B.push(Object.assign({role,set,vo,plan:plan||[],cam},extra||{}));const night={sky:'night'};
 T('hook',home,'{ruleSent}',[['cast',{hero:'front'}],['anim',H,'lookAround','town',2,'worried'],['hook'],['fx','dust',H,'In']],[['wide',[H],{az:10,move:'crane',amount:.3}]],night);
 T('setup',home,V(['Everyone followed it. Without question.','For years, nobody dared to break it.','Everyone followed it, even the dogs.']),[['cast',{hero:'front',nbr:'yardL',extra1:'street'}],['walkOff','extra1','streetR'],['anim','extra1','tiredwalk',null,0,'worried'],['anim',N,'idle']],[['wide',[H,N],{az:-18,move:'drift'}]],night);
 T('setup',home,'Except {N}.',[['expr',N,'smirk','Except'],['anim',N,'lookAround',null,1.4,'sus'],['sfx','swish','Except']],[['close',[N],{az:12,move:'push',amount:.2}]],night);
 T('setup',home,V(['{N} was the curious type.','{N} never liked being told what to do.','{N} just had to know why.']),[['anim',N,'scratchhead',null,0,'sus'],['fx','sparkle',N,null]],[['medium',[N],{az:-20,move:'dolly'}]],night);
 T('build',home,V(['One night, {nhe} decided to test it.','One night, {nhe} snuck out alone.','Late one night, {nhe} gave in.']),[['walk',N,'door','test',1.6],['anim',N,'sneak','night',0,'sus']],[['medium',[N],{az:26,move:'follow'}]],night);
 T('build',home,'{nHe} {past}.',P(c,N,c.rule.f.pastV),[['medium',[N],{az:-26,move:'push',amount:.2}]],Object.assign({focus:N,key:'break'},night));
 T('build',home,V(['Nothing happened. At first.','Silence. Too much silence.','At first, everything seemed fine.']),[['anim',N,'shrug',null,.9,'neutral'],['expr',N,'worried',null],['fx','heartbeat',N,null]],[['close',[N],{az:10,move:'zoom',amount:.5}]],night);
 T('turn',home,V(['Then every light went out.','Then the whole street went dark.','Then the lights began to flicker.']),[['state','lampL','off','light'],['state','lampR','off','light'],['flash','light',.5],['sfx','rumble','out'],['expr',N,'scared','light']],[['wide',[N],{az:-14,move:'pull',amount:.3}]],{sky:'void'});
 T('turn',home,'A shadow appeared behind {nhim}.',[['obj','shadow','shadowfigure','shadow','behind','fadeIn'],['fx','pulse','shadow','shadow'],['expr',N,'terrified','shadow']],[['low',['nbr','shadow'],{az:6,move:'push',amount:.4}]],{sky:'void'});
 T('turn',home,'{N} never came back.',[['anim',N,'jumpscare','never',.6,'terrified'],['hide',N,'back'],['fx','poof',N,'never'],['hide','shadow','back'],['sfx','thud','never']],[['wide',['shadow'],{az:0}],['medium',[H],{az:20,at:'back'}]],{sky:'void'});
 T('reveal',home,V(['By morning, the house was empty.','The next day, {nhis} house was silent.','By sunrise, {nhe} was gone.']),[['cast',{hero:'front'}],['anim',H,'worried',null,0,'worried'],['state','door','open',.55,'morning',.6]],[['wide',[H],{az:-22,move:'push',amount:.18}]],{sky:'day'});
 T('reveal',home,'{H} found a note on the door.',[['do',H,'pickup','note','found'],['expr',H,'worried','note']],[['medium',[H],{az:24,move:'push',amount:.2}]],{sky:'day'});
 T('reveal',home,'It said: you saw nothing.',[['text','YOU SAW NOTHING','saw',1.7,'title'],['sfx','boom','nothing']],[['close',[H],{az:8,move:'zoom',amount:.45}]],{sky:'day'});
 T('build',home,V(['{H} wanted answers.','{H} refused to let it go.','{H} had to find the truth.']),[['anim',H,'angry',null,0,'angry'],['expr',H,'sus','answers']],[['medium',[H],{az:-16,move:'dolly'}]],{sky:'sunset'});
 T('build',home,'So {he} waited for night.',[['anim',H,'sneak','waited',0,'sus']],[['wide',[H],{az:20,move:'drift'}]],night);
 T('build',home,only?'And {he} {breakI}, too.':'And {he} {past}, too.',P(c,H,only?'too':c.rule.f.pastV),[['medium',[H],{az:-24,move:'push',amount:.2}]],Object.assign({focus:H,key:'break'},night));
 T('turn',home,'The shadow came back.',[['obj','shadow','shadowfigure','shadow','behind','fadeIn'],['anim',H,'scared','shadow',0,'scared'],['fx','pulse','shadow','shadow']],[['low',[H,'shadow'],{az:10,move:'push',amount:.3}]],{sky:'void'});
 T('twist',home,'But this time, {H} turned around.',[['anim',H,'idle'],['turnTo',H,'shadow','turned'],['expr',H,'angry','around']],[['close',[H],{az:-12}]],{sky:'void'});
 T('twist',home,'It was {N}. {nHe} had been the shadow all along.',[['hide','shadow','It'],['cast',{nbr:'door'}],['show',N,'It'],['expr',N,'evil','It'],['fx','explosion',N,'shadow'],['shake','shadow',.6,.8]],[['hero',[N],{az:8,move:'pull'}]],{sky:'void'});
 T('payoff',home,'Now {H} is the new shadow.',[['anim',H,'proud','Now',0,'evil'],['fx','pulse',H,'shadow']],[['low',[H],{az:10,move:'rise'}]],{sky:'void'});
 return B};

/* --- E: el EFECTO ("cada X te hace Y") --- */
ARCH.effect=c=>{const H='hero',N='nbr',P=breakPlan;const home='park';const B=[];const T=(role,set,vo,plan,cam,extra)=>B.push(Object.assign({role,set,vo,plan:plan||[],cam},extra||{}));
 const eff=c.effect,e=/shrink|small|tiny/.test(eff)?'shrink':/grow|big|tall|giant/.test(eff)?'grow':/float|fly|rise/.test(eff)?'float':/dance/.test(eff)?'dance':/sneez/.test(eff)?'sneeze':/laugh/.test(eff)?'laugh':/glow|shine|light/.test(eff)?'glow':'poof';
 const fxOf={shrink:'poof',grow:'shockwave',float:'sparkle',dance:'sparkle',sneeze:'poof',laugh:'sparkle',glow:'sparkle',poof:'poof'}[e];
 const doEff=(a,w)=>{const o=[];if(e==='shrink')o.push(['scale',a,.55,w,.6]);else if(e==='grow')o.push(['scale',a,1.5,w,.6]);else if(e==='float')o.push(['hover',a,4,w]);else if(e==='dance')o.push(['anim',a,'dance',w,2.2,'grin']);else if(e==='sneeze')o.push(['anim',a,'sneeze',w,1.2,'worried']);else if(e==='laugh')o.push(['anim',a,'laugh',w,2,'laugh']);else o.push(['anim',a,'shock',w,1,'shock']);o.push(['fx',fxOf,a,w]);return o};
 T('hook',home,'{ruleSent}',[['cast',{hero:'front'}],['anim',H,'lookAround','In',2],['hook']],[['wide',[H],{az:12,move:'crane',amount:.3}]]);
 T('setup',home,'Nobody believed it.',[['cast',{hero:'front',nbr:'yardL'}],['anim',N,'laugh','believed',1.6,'laugh'],['anim',H,'shrug','Nobody',1,'smirk']],[['wide',[H,N],{az:-18,move:'drift'}]]);
 T('setup',home,'So {H} decided to test it.',[['anim',H,'think','test',1.6,'smirk'],['fx','sparkle',H,'decided']],[['medium',[H],{az:20,move:'push',amount:.2}]]);
 T('build',home,'{He} took a deep breath.',[['anim',H,'stretch','deep',1.4,'worried'],['sfx','swish','breath']],[['close',[H],{az:-12,move:'push',amount:.25}]]);
 T('build',home,'And {he} did it.',P(c,H,'did'),[['medium',[H],{az:24}]],{focus:H,key:'break'});
 T('turn',home,'Instantly, {H} changed.',[...doEff(H,'Instantly'),['shake','Instantly',.4,.5]],[['medium',[H],{az:-18,move:'zoom',amount:.4}]],{focus:H});
 T('turn',home,'{N} screamed.',[['anim',N,'panic','screamed',1.4,'terrified'],['fx','sweat',N,'screamed']],[['medium',[N],{az:16,move:'push',amount:.2}]]);
 T('build',home,'{H} tried to hide it.',[['anim',H,'hide','hide',1.5,'worried'],['walk',H,'far','tried',1.6]],[['medium',[H],{az:-24,move:'follow'}]]);
 T('build',home,'But {N} told everyone.',[['anim',N,'point','told',1.4,'gasp'],['cast',{extra1:'street',extra2:'streetR',extra3:'yardR'}],['anim','extra1','shock','told',1.4,'gasp'],['anim','extra2','shock','everyone',1.4,'gasp']],[['wide',[N,'extra1','extra2'],{az:20,move:'orbit',deg:25}]]);
 T('turn',home,'Soon, the whole town wanted to try.',[...['extra1','extra2','extra3',N].flatMap((a,i)=>doEff(a,i<2?'Soon':'try')),['fx','confetti',H,'town']],[['wide',[H,N,'extra1','extra2','extra3'],{az:-20,move:'pull',amount:.3}]]);
 T('turn',home,'Then the mayor made a new rule.',[['cast',{mayor:'plaza'}],['walk','mayor','center','mayor',1.8],['anim','mayor','angry','rule',1.6,'angry'],['text','NEW RULE','rule',1.4,'title'],['sfx','boom','rule']],[['low',['mayor'],{az:8,move:'pull',amount:.2}]]);
 T('twist',home,'It said: everyone must {act}, forever.',[['text',c.act.toUpperCase(),'act',1.6,'title']],[['close',['mayor'],{az:-8}]]);
 T('twist',home,'Now, the whole town is {ing} all day.',[...['extra1','extra2','extra3',N,H].flatMap((a)=>doEff(a,'Now')),['fx','confetti',H,'day']],[['wide',[H,N,'extra1','extra2','extra3','mayor'],{az:14,move:'crane',amount:.5}]]);
 T('payoff',home,'And nobody was allowed to stop.',[['anim',H,'flail','stop',0,'worried']],[['hero',[H],{az:10,move:'rise'}]]);
 return B};


/* --- R: la RAZÓN (el alcalde esconde el motivo) --- */
ARCH.reason=c=>{const H='hero',M='mayor';const V=a=>a[Math.floor(c.rnd()*a.length)];const P=breakPlan;const only=c.rule.kind!=='prohibit'&&c.rule.kind!=='effect';const hasCreature=/(?:\bmonster\b|\bcreature\b|\bdragon\b|\bbeast\b|\bgiant\b)/i.test(c.rule.text||'');
 const B=[];const T=(role,set,vo,plan,cam,extra)=>B.push(Object.assign({role,set,vo,plan:plan||[],cam},extra||{}));const night={sky:'night'};
 T('hook','facade','{ruleSent}',[['cast',{hero:'front'}],['anim',H,'lookAround','In',2,'worried'],['hook']],[['wide',[H],{az:12,move:'crane',amount:.3}]]);
 T('setup','facade',V(['Nobody knew why.','Nobody remembered why.','Nobody ever asked why.']),[['cast',{hero:'front',nbr:'yardL'}],['anim','nbr','shrug','knew',1,'neutral'],['anim',H,'think','why',1.4,'worried']],[['medium',[H,'nbr'],{az:-20,move:'drift'}]]);
 T('setup','townhall','So {H} asked the mayor.',[['cast',{hero:'left',mayor:'podium'}],['walk',H,'plaza','asked',1.8],['anim',H,'point','asked',1.2,'sus'],['text','?','mayor',1,'pop']],[['medium',[H,M],{az:18,move:'push',amount:.2}]]);
 T('setup','townhall','The mayor just smiled.',[['anim',M,'proud','smiled',0,'smug'],['anim',H,'idle',null]],[['close',[M],{az:-10,move:'push',amount:.3}]]);
 T('build','facade','That night, {H} followed {nhim}.'.replace('{nhim}','him'),[['cast',{hero:'streetR',mayor:'center'}],['walk','mayor','door','followed',2.8],['anim',H,'sneak','followed',0,'sus'],['walk',H,'yardR','night',2.4]],[['wide',[H,M],{az:22,move:'follow'}]],Object.assign({},night));
 T('build','facade','The mayor looked around nervously.',[['anim',M,'lookAround','nervously',2,'worried'],['anim',H,'hide','looked',1.6,'sus']],[['medium',[M],{az:-24,move:'push',amount:.2}]],night);
 T('turn','facade',only?'Then he {breakI}!':'Then he {past}!',[...P(c,M,only?'stopped':c.rule.f.pastV),['expr',H,'gasp','Then']],[['medium',[M],{az:26,move:'push',amount:.22}]],Object.assign({focus:M,key:'break'},night));
 T('turn','facade','Suddenly, the ground shook.',[['shake','Suddenly',1.4,1],['sfx','rumble','ground'],['anim',H,'scared','shook',1.4,'terrified']],[['low',[H],{az:12,move:'pull',amount:.3}]],night);
 if(hasCreature){
   T('turn','facade','A giant creature rose behind the houses.',[['obj','beast','dragon','rose','rise'],['fx','smoke','beast','creature'],['fx','pulse','beast','rose']],[['wide',[H,M,'beast'],{az:-8,move:'crane',amount:.5}]],night);
   T('turn','facade','{H} froze.',[['anim',H,'tremble','froze',0,'terrified']],[['close',[H],{az:10,move:'zoom',amount:.5}]],night);
   T('reveal','facade','But the creature just waved.',[['state','beast','wave',1,'waved',.4],['expr',H,'shock','waved']],[['wide',[H,'beast'],{az:-14,move:'push',amount:.2}]],night);
   T('reveal','facade','It was the mayor\'s best friend.',[['anim',M,'wave','friend',1.6,'grin'],['fx','hearts',M,'friend']],[['medium',[M,H],{az:18}]],night);
 } else {
   T('turn','facade','A single lamp flickered behind the mayor\'s desk.',[['obj','officeLamp','lamp','flickered','fadeIn'],['fx','pulse','officeLamp','flickered']],[['wide',[H,M,'officeLamp'],{az:-8,move:'crane',amount:.35}]],night);
   T('turn','facade','{H} stepped closer to the desk.',[['walk',H,'center','closer',1.1],['anim',H,'inspect','desk',.9,'worried']],[['medium',[H,M],{az:10,move:'push',amount:.15}]],night);
   T('reveal','townhall','The mayor opened an old book.',[['obj','oldBook','book_custom','book','fadeIn'],['anim',M,'pickup','opened',1,'worried'],['do',M,'open','oldBook','opened']],[['medium',[M,'oldBook'],{az:-12}]],night);
   T('reveal','townhall','Inside was a note explaining the rule.',[['obj','note','paper_custom','note','fadeIn'],['anim',M,'point','note',.8,'worried'],['fx','sparkle','note','note']],[['close',['note'],{az:8,move:'push',amount:.18}]],night);
 }
 T('twist','facade','The rule was only there to keep the secret.',[['anim',H,'facepalm','secret',0,'worried'],['text','TOP SECRET','secret',1.6,'title']],[['close',[H],{az:-10}]],night);
 T('payoff','facade','So {H} promised to never tell.',[['anim',H,'salute','promised',1.4,'smirk'],['fx','sparkle',H,'promised']],[['hero',[H],{az:12,move:'rise'}]],night);
 T('payoff','facade',hasCreature?(only?'And every night, {he} visits the creature.':'And every night, {he} {past}, just to say hello.'):'The mayor promised to keep the reason a secret.',hasCreature?[['anim',H,'wave','hello',0,'grin'],['fx','hearts','beast','hello']]:[['anim',M,'salute','promised',1,'smirk'],['hide','note','secret'],['text','TOP SECRET','secret',1.4,'title']],[['wide',hasCreature?[H,'beast']:[H,M],{az:-16,move:'pull',amount:.3}]],night);
 return B};

/* --- C: el DESAFÍO (estructura de competición, no de "truco + alcalde") --- */
function ruleActionPlan(c,actor,word){
  const d=c.dom;
  if(c.rule.kind==='prohibit'||c.rule.kind==='effect')return breakPlan(c,actor,word);
  if(d.breakKind==='interact'){
    const ops=[['do',actor,d.ikind,d.obj,word]];
    if(d.ikind==='open'||d.ikind==='peek')ops.push(['fx','sparkle',d.obj,word]);
    return ops;
  }
  const ops=[['anim',actor,d.clip||'point',word,1.5,d.expr||'neutral']];
  if(d.fx)ops.push(['fx',d.fx,actor,word]);
  return ops;
}
ARCH.challenge=c=>{
  const H='hero',N='nbr',M='mayor',home=c.dom.home,B=[];
  const T=(role,set,vo,plan,cam,extra)=>B.push(Object.assign({role,set,vo,plan:plan||[],cam},extra||{}));
  const V=a=>a[Math.floor(c.rnd()*a.length)];
  const prohibited=c.rule.kind==='prohibit';
  T('hook',home,'{ruleSent}',[['cast',{hero:'front'}],['anim',H,'lookAround','town',1.5,'worried'],['hook']],[['wide',[H],{az:12,move:'crane',amount:.3}]]);
  T('setup','townhall','The mayor turned the rule into a public challenge.',[['cast',{hero:'left',nbr:'right',mayor:'podium'}],['anim',M,'point','challenge',1.2,'proud'],['text','THE TOWN CHALLENGE','challenge',1.5,'title']],[['wide',[H,N,M],{az:-14,move:'pull',amount:.25}]]);
  T('setup','townhall','The winner had to follow it until sunset.',[['anim',H,'think','winner',1.1,'smirk'],['anim',N,'shrug','sunset',1,'neutral']],[['medium',[H,N],{az:18,move:'push',amount:.15}]]);
  T('setup','townhall','The prize was a trophy, and the whole town wanted it.',[['anim',M,'present','prize',1,'proud'],['text','WIN A TROPHY','trophy',1.4,'title']],[['medium',[M],{az:-10,move:'push',amount:.2}]]);
  T('build',c.dom.home,'{H} stepped forward first.',[['walk',H,'center','forward',1.1],['anim',H,'determined','first',1.2,'smirk']],[['medium',[H],{az:-18,move:'dolly'}]]);
  T('build',c.dom.home,'{N} joined the challenge too.',[['walk',N,'yardL','joined',1.1],['anim',N,'point','challenge',.9,'grin']],[['medium',[H,N],{az:16,move:'drift'}]]);
  T('build',c.dom.home,'The crowd packed the square to watch.',[['cast',{extra1:'street',extra2:'streetR',extra3:'yardR'}],['anim','extra1','wave_big','crowd',1,'grin'],['anim','extra2','cheer','watch',1,'grin']],[['wide',[H,N,'extra1','extra2'],{az:-18,move:'pull',amount:.25}]]);
  T('build',c.dom.home,'The countdown began.',[['text','3… 2… 1…','began',1.1,'title'],['sfx','ding','began']],[['close',[H,N],{az:-8,move:'push',amount:.2}]]);
  T('build',c.dom.home,'For one long second, nobody moved.',[['anim',H,'idle','second',1,'worried'],['anim',N,'idle','moved',1,'worried']],[['medium',[H,N],{az:10,move:'drift'}]]);
  T('turn',c.dom.home,prohibited?'{N} {past}, right in front of everyone.':'{N} followed the rule exactly.',ruleActionPlan(c,N,prohibited?c.rule.f.pastV:'followed'),[['medium',[N],{az:22,move:'push',amount:.2}]],{focus:N,key:'break'});
  T('build',c.dom.home,prohibited?'{H} refused to copy {nhim}.':'{H} kept following the rule, even when it got difficult.',prohibited?[['anim',H,'headshake','copy',1.1,'worried']]:ruleActionPlan(c,H,'following'),[['close',[H],{az:-16,move:'push',amount:.18}]]);
  T('turn','townhall','At sunset, the mayor checked the scoreboard.',[['cast',{hero:'left',nbr:'right',mayor:'podium'}],['anim',M,'think','scoreboard',1.2,'worried'],['obj','scorecard','paper_custom','scoreboard','right','fadeIn']],[['medium',[M,'scorecard'],{az:10,move:'push',amount:.2}]]);
  T('turn','townhall','The scoreboard flashed as the sun went down.',[['text','SUNSET','sun',1.2,'title'],['fx','sparkle','scorecard','flashed'],['anim',H,'lookAround','sunset',1,'worried']],[['wide',[H,N,M],{az:16,move:'crane',amount:.2}]]);
  T('reveal','townhall','There was one more name on the list: the mayor.',[['anim',M,'shock','mayor',1.2,'shock'],['text','MAYOR: CONTESTANT #1','mayor',1.3,'title']],[['close',[M],{az:-10,move:'zoom',amount:.25}]]);
  T('twist','townhall',prohibited?'He had {past} before the challenge even started.':'He had been following the rule longer than anyone.',prohibited?ruleActionPlan(c,M,c.rule.f.pastV):ruleActionPlan(c,M,'following'),[['medium',[M],{az:18,move:'push',amount:.2}]],{focus:M,key:'break'});
  T('payoff','townhall','The mayor handed {H} the trophy, then quietly disqualified himself.',[['anim',M,'shrug','trophy',1.1,'worried'],['anim',H,'victory','trophy',1.4,'grin'],['fx','confetti',H,'trophy'],['text','WINNER','trophy',1.3,'title']],[['hero',[H,M],{az:12,move:'rise'}]]);
  T('payoff','townhall','Nobody asked for a rematch.',[['anim',N,'laugh','rematch',1.2,'laugh'],['anim',H,'shrug','rematch',1,'smirk']],[['wide',[H,N,M],{az:-18,move:'pull',amount:.3}]]);
  return B;
};

/* --- I: la INVESTIGACIÓN (pistas y revelación, sin monstruos gratuitos) --- */
ARCH.investigation=c=>{
  const H='hero',N='nbr',M='mayor',home=c.dom.home,B=[];
  const T=(role,set,vo,plan,cam,extra)=>B.push(Object.assign({role,set,vo,plan:plan||[],cam},extra||{}));
  const V=a=>a[Math.floor(c.rnd()*a.length)];
  T('hook',home,'{ruleSent}',[['cast',{hero:'front'}],['anim',H,'lookAround','town',1.6,'worried'],['hook']],[['wide',[H],{az:10,move:'crane',amount:.3}]]);
  T('setup',home,V(['But {H} noticed one detail nobody else had seen.','Something about the rule never made sense to {H}.','Everyone followed the rule, but nobody could explain it.']),[['cast',{hero:'front',nbr:'yardL'}],['anim',H,'think','detail',1.3,'worried'],['anim',N,'lookAround','rule',1.1,'sus']],[['medium',[H,N],{az:-18,move:'drift'}]]);
  T('setup',home,'{H} asked around, but every answer was the same.',[['anim',N,'shrug','answer',1,'neutral'],['anim',H,'shrug','same',1,'worried']],[['over',[H,N],{az:16,move:'drift'}]]);
  T('build',home,'{N} finally pointed {H} toward the town hall.',[['anim',N,'point','pointed',1,'sus'],['walk',H,'plaza','town hall',1.4]],[['follow',[H,N],{az:20,move:'follow'}]]);
  T('build','townhall','A folded note was waiting on the mayor\'s desk.',[['cast',{hero:'left',mayor:'podium'}],['obj','note','paper_custom','note','right','fadeIn'],['anim',H,'inspect','waiting',1.1,'worried']],[['medium',[H,'note'],{az:12,move:'push',amount:.2}]]);
  T('build','townhall','The handwriting looked strangely familiar.',[['anim',H,'inspect','handwriting',1.1,'sus'],['fx','sparkle','note','familiar']],[['close',['note'],{az:-8,move:'push',amount:.18}]]);
  T('turn','townhall','The note said: THE MAYOR STARTED IT.',[['anim',H,'pickup','note',.9,'shock'],['text','THE MAYOR STARTED IT','said',1.5,'title'],['fx','sparkle','note','note']],[['close',['note'],{az:-8,move:'zoom',amount:.25}]]);
  T('build','townhall','{H} turned the paper over. There was a date.',[['anim',H,'pickup','turned',.8,'worried'],['text','20 YEARS AGO','date',1.3,'title']],[['close',['note'],{az:12,move:'drift'}]]);
  T('build','townhall','Just then, the mayor walked in.',[['anim',M,'shock','mayor',1.1,'shock'],['walk',M,'podium','walked',1.2]],[['over',[H,M],{az:18,move:'push',amount:.2}]]);
  T('build','townhall','He reached for the note, but {H} stepped back.',[['walk',H,'left','back',.65],['anim',M,'reach','note',.8,'worried']],[['medium',[H,M,'note'],{az:-12,move:'push',amount:.2}]]);
  T('reveal','townhall','He admitted he had been the first person to {act}.',ruleActionPlan(c,M,c.rule.f.verb),[['medium',[H,M],{az:-16,move:'push',amount:.2}]],{focus:M,key:'break'});
  T('twist','townhall',V(['The rule was written after one mistake that changed the whole town.','He had created the rule to stop the same mistake happening twice.','The rule was not a warning about strangers. It was about the mayor.']),[['anim',M,'worried','mistake',1.2,'worried'],['anim',H,'think','rule',1.2,'sus'],['text','ONE OLD MISTAKE','mistake',1.3,'title']],[['close',[H,M],{az:10,move:'dolly'}]]);
  T('twist','townhall','The mayor had hoped nobody would remember the first day.',[['anim',M,'hide','remember',1.1,'worried'],['anim',H,'point','first',.9,'sus']],[['medium',[H,M],{az:18,move:'pull',amount:.15}]]);
  T('build',home,'{H} took the note back to the street.',[['walk',H,'street','street',1.5],['anim',H,'think','note',1,'worried']],[['wide',[H],{az:-20,move:'follow'}]]);
  T('payoff',home,'For the first time, the town knew who had made the rule.',[['cast',{hero:'front',nbr:'yardL',extra1:'street',extra2:'streetR'}],['anim',N,'point','town',1,'neutral'],['anim',H,'present','rule',1.2,'grin']],[['wide',[H,N,'extra1','extra2'],{az:18,move:'crane',amount:.35}]]);
  T('payoff',home,'And the mayor had to obey it with everyone else.',[['cast',{mayor:'yardR'}],['anim',M,'shrug','obey',1.2,'worried'],['anim',H,'wave_big','everyone',1.1,'grin']],[['wide',[H,N,M],{az:-12,move:'pull',amount:.3}]]);
  return B;
};

/* --- R2: el EFECTO DOMINÓ (la regla se propaga por el pueblo) --- */
ARCH.chain=c=>{
  const H='hero',N='nbr',M='mayor',home=c.dom.home,B=[],prohibited=c.rule.kind==='prohibit';
  const T=(role,set,vo,plan,cam,extra)=>B.push(Object.assign({role,set,vo,plan:plan||[],cam},extra||{}));
  const V=a=>a[Math.floor(c.rnd()*a.length)];
  const doRule=(actor,word)=>ruleActionPlan(c,actor,word);
  T('hook',home,'{ruleSent}',[['cast',{hero:'front'}],['anim',H,'lookAround','town',1.5,'worried'],['hook']],[['wide',[H],{az:12,move:'crane',amount:.3}]]);
  T('setup',home,V(['At first, only {H} tried it.','The first person to test the rule was {H}.','It started with one small decision.']),[['cast',{hero:'front',nbr:'yardL'}],['anim',H,'think','first',1.2,'smirk']],[['medium',[H],{az:-12,move:'push',amount:.2}]]);
  T('build',home,c.rule.kind==='prohibit'?'{H} {past}.':'{H} followed the rule exactly.',doRule(H,c.rule.kind==='prohibit'?c.rule.f.pastV:'followed'),[['medium',[H],{az:18,move:'push',amount:.2}]],{focus:H,key:'break'});
  T('build',home,'At first, nobody reacted.',[['anim',H,'lookAround','reacted',1,'neutral'],['anim',N,'idle','first',1,'neutral']],[['wide',[H,N],{az:-14,move:'drift'}]]);
  T('build',home,'{N} saw it and copied {nhim}.',doRule(N,'copied'),[['over',[H,N],{az:-18,move:'drift'}]]);
  T('build',home,'A shopkeeper across the street noticed them.',[['cast',{extra1:'street'}],['anim','extra1','lookAround','noticed',1,'curious'],['anim',N,'point','street',.8,'grin']],[['wide',[N,'extra1'],{az:20,move:'pull',amount:.2}]]);
  T('turn',home,'Then three more residents joined in.',[['cast',{extra1:'street',extra2:'streetR',extra3:'yardR'}],...['extra1','extra2','extra3'].map(id=>['anim',id,c.dom.clip||'point','joined',1,c.dom.expr||'neutral']),['fx','confetti',H,'joined']],[['wide',[H,N,'extra1','extra2','extra3'],{az:20,move:'orbit',deg:24}]]);
  T('turn',home,'By lunchtime, the entire street was involved.',[['anim',H,'present','lunchtime',1.2,'grin'],['anim',N,'cheer','street',1.2,'grin'],['text','EVERYONE JOINED IN','street',1.2,'title']],[['wide',[H,N,'extra1','extra2','extra3'],{az:-16,move:'pull',amount:.35}]]);
  T('turn',home,'People on the other side of town started copying them too.',[['anim','extra2','point','copying',1,'grin'],['anim','extra3','cheer','too',1,'grin'],['fx','confetti','extra2','town']],[['wide',['extra2','extra3'],{az:14,move:'orbit',deg:18}]]);
  T('build','townhall','The mayor rushed outside to stop it.',[['cast',{mayor:'podium'}],['walk',M,'plaza','rushed',1.1,'run'],['anim',M,'point','stop',1,'angry']],[['low',[M],{az:12,move:'pull',amount:.2}]]);
  T('build','townhall','He ordered everyone to stop at once.',[['anim',M,'angry','ordered',1.1,'angry'],['text','EVERYONE STOP','stop',1.1,'title']],[['close',[M],{az:-8,move:'push',amount:.2}]]);
  T('twist',home,prohibited?'But the mayor {past} himself.':'But the mayor demonstrated the rule himself.',doRule(M,prohibited?c.rule.f.pastV:'demonstrated'),[['medium',[M],{az:-18,move:'push',amount:.22}]],{focus:M,key:'break'});
  T('turn',home,'That was all the town needed to see.',[['anim',H,'shock','see',1,'shock'],['anim',N,'point','town',1,'gasp'],['fx','sparkle',M,'see']],[['close',[H,N],{az:12,move:'zoom',amount:.2}]]);
  T('turn',home,'For one second, the whole street went quiet.',[['anim',H,'idle','quiet',1,'neutral'],['anim',N,'idle','street',1,'neutral'],['anim',M,'lookAround','second',1,'worried']],[['wide',[H,N,M,'extra1','extra2'],{az:-12,move:'drift'}]]);
  T('payoff',home,'Now everyone copied the mayor instead of {H}.', [['anim',M,'present','copied',1.3,'proud'],['anim',H,'shrug','instead',1,'smirk'],['fx','confetti',M,'mayor']],[['wide',[H,N,M,'extra1','extra2'],{az:-18,move:'crane',amount:.35}]]);
  T('payoff',home,V(['The rule had become the town\'s most popular show.','And that is how one tiny action took over the whole town.','By the next morning, nobody remembered who started it.']),[['anim',H,'laugh','town',1.3,'laugh'],['anim',N,'wave_big','morning',1.2,'grin']],[['hero',[H,N],{az:10,move:'rise'}]]);
  return B;
};

function pickArchetype(rule,tone,variant,avoidArchetypes=[]){
  const premise=String(rule.text||'').toLowerCase();
  // Special premises no longer lock the generator into one fixed script. They influence
  // the pool, but the run seed still rotates the plot structure on every generation.
  const supportsShadow=/(?:\bshadow\b|\bghost\b|\bhaunt(?:ed|ing)?\b)/i.test(premise);
  const supportsCreature=/(?:\bmonster\b|\bcreature\b|\bdragon\b|\bbeast\b|\bgiant\b)/i.test(premise);
  const pools={
    mystery:['investigation','reason','chain','loophole','challenge','effect'],
    suspense:['investigation','reason','chain','challenge','loophole','effect'],
    funny:['challenge','chain','loophole','investigation','reason','effect']
  };
  let pool=(pools[tone]||pools.mystery).slice();
  if(rule.kind==='effect')pool=['effect','investigation','chain','challenge','reason','loophole'];
  if(supportsShadow)pool=['warning','investigation','reason','challenge','chain','loophole'];
  else if(supportsCreature)pool=['reason','investigation','challenge','chain','loophole','effect'];
  // The same rule can now travel through several distinct dramatic structures instead
  // of always using the same effect/shadow/creature template.
  const offset=hash(premise+'|'+tone)%pool.length;
  const step=Math.abs(Math.trunc(Number(variant)||0));
  const avoid=new Set(Array.isArray(avoidArchetypes)?avoidArchetypes:[]);
  for(let n=0;n<pool.length;n++){
    const candidate=pool[(offset+step+n)%pool.length];
    if(!avoid.has(candidate))return candidate;
  }
  return pool[(offset+step)%pool.length];
}

/* ------------------------------------------------------------ API pública */
function generate(idea,tone,length,variant,options={}){
  const raw=String(idea||'').trim();if(raw.length<4)throw new Error('Escribe primero una regla para el pueblo.');
  const rule=parseRule(raw);const seed=hash(raw.toLowerCase()+'|'+tone+'|'+(variant||0));const rnd=rng(seed);
  const cast=makeCast(rnd);const dom=domainOf(rule,rnd);const c=makeCtx(rule,dom,cast,tone,rnd);
  const name=rule.kind==='condition'?'condition':pickArchetype(rule,tone,variant,options.avoidArchetypes);let beats=ARCH[name](c);
  // Keep the opening, the turn and the payoff, but target different run times.
  // Optional setup/build beats are trimmed first; key rule-breaking beats remain.
  const targetBeats=length==='short'?13:17;
  if(beats.length>targetBeats){
    const candidates=beats.filter(b=>(b.role==='build'||b.role==='setup')&&!b.key);
    const drop=new Set();
    for(let i=0;i<beats.length-targetBeats&&i<candidates.length;i++){
      const pick=Math.floor((i+1)*candidates.length/(beats.length-targetBeats+1));
      drop.add(candidates[Math.min(candidates.length-1,pick)]);
    }
    beats=beats.filter(b=>!drop.has(b));
  }
  beats=beats.map((b,i)=>Object.assign({},b,{i,vo:fill(b.vo,c)}));
  const titleLead=({condition:'The truth about ',loophole:'The loophole in ',warning:'The shadow after ',effect:'The strange effect of ',reason:'The reason behind ',challenge:'The challenge of ',investigation:'The mystery of ',chain:'The rule that spread: '})[name]||'The town where ';
  const titleSubject=rule.kind==='condition'?rule.text:(rule.f.ing||rule.f.base);
  const title=(rule.kind==='condition'?'The truth about this town':(titleLead+titleSubject+(rule.mod?' '+rule.mod:''))).slice(0,88);
  const hookText=rule.kind==='condition'?'THE TRUTH ABOUT THIS TOWN':((rule.kind==='prohibit'&&rule.act.length<=26)?('NEVER '+rule.act.toUpperCase()):'ONE RULE. NO EXCEPTIONS.');
  return{hookText,title:cap(title),slug:'town-'+seed.toString(36),idea:raw,rule,arch:name,tone,seed,cast,domain:dom,beats,source:'local-engine'}}

ITT.Story={generate,parseRule,verbForms,actForms,domainOf,classifyVerb,hash,rng,fill};
if(typeof module!=='undefined'&&module.exports)module.exports=ITT.Story;
})(typeof window!=='undefined'?window:globalThis);

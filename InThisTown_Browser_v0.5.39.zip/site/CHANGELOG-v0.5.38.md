# In This Town Browser v0.5.38

## Character gaze and interaction continuity
- Added deterministic head-only gaze tracking toward a named actor or prop.
- Head yaw and pitch are smoothly eased and clamped to comfortable ranges.
- Interaction beats and `turnTo` now add a short gaze follow-through after the body turns, then return the head to neutral.
- Added explicit `lookAt` plan operation for authored scenes.
- Gaze is evaluated from timeline time, so seeking and exporting frames stays deterministic.

## Validation
- Added regression tests for gaze direction and angle limits.
- Full test suite and JavaScript syntax checks run for this release.
- Physical visual verification on iPhone and desktop remains pending.

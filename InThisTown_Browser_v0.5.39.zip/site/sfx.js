/* app/sfx.js — v0.5 efectos de sonido sintetizados localmente (sin ficheros ni derechos de autor). */
(function(G){
'use strict';const ITT=G.ITT=G.ITT||{};
function mk(ctx,dur,fn){const n=Math.max(1,Math.floor(ctx.sampleRate*dur)),b=ctx.createBuffer(1,n,ctx.sampleRate),d=b.getChannelData(0);let seed=12345;const rnd=()=>{seed=(seed*1664525+1013904223)>>>0;return seed/4294967296*2-1};for(let i=0;i<n;i++)d[i]=fn(i/ctx.sampleRate,rnd,dur);return b}
const TAU=Math.PI*2,env=(t,a,d)=>Math.min(1,t/a)*Math.exp(-t/d);
const LIB={
 swish:(c)=>mk(c,.35,(t,r,D)=>r()*.35*Math.sin(Math.PI*Math.min(1,t/D))**2*(.4+t/D)),
 whoosh:(c)=>mk(c,.7,(t,r,D)=>r()*.4*Math.sin(Math.PI*Math.min(1,t/D))**2),
 pop:(c)=>mk(c,.14,(t)=>Math.sin(TAU*(520-t*2200)*t)*env(t,.002,.03)*.8),
 thud:(c)=>mk(c,.35,(t,r)=>(Math.sin(TAU*(90-t*120)*t)+r()*.15)*env(t,.002,.09)*.9),
 boom:(c)=>mk(c,1.2,(t,r)=>(Math.sin(TAU*(60-t*30)*t)*.8+r()*.5*Math.exp(-t*6))*env(t,.004,.35)),
 rumble:(c)=>mk(c,1.1,(t,r,D)=>(Math.sin(TAU*38*t+Math.sin(t*9))*.7+r()*.25)*Math.sin(Math.PI*Math.min(1,t/D))*.8),
 creak:(c)=>mk(c,.8,(t,r,D)=>{const f=180+120*Math.sin(t*7)+t*160;return (((t*f)%1)*2-1)*.28*(.6+.4*Math.sin(t*38))*Math.sin(Math.PI*Math.min(1,t/D))}),
 slam:(c)=>mk(c,.4,(t,r)=>(Math.sin(TAU*110*t)*.8+r()*.5)*env(t,.001,.06)),
 knock:(c)=>mk(c,.9,(t,r)=>{let o=0;for(const k of[0,.26,.5])if(t>=k){const x=t-k;o+=Math.sin(TAU*160*x)*env(x,.001,.03)}return o*.9}),
 click:(c)=>mk(c,.08,(t,r)=>r()*env(t,.0005,.008)*.9),
 ding:(c)=>mk(c,.8,(t)=>(Math.sin(TAU*1320*t)+.4*Math.sin(TAU*1980*t))*env(t,.002,.25)*.45),
 boing:(c)=>mk(c,.45,(t)=>Math.sin(TAU*(200+90*Math.sin(t*28))*t)*env(t,.004,.18)*.6),
 sparkle:(c)=>mk(c,.7,(t)=>{let o=0;for(let k=0;k<5;k++){const x=t-k*.09;if(x>0)o+=Math.sin(TAU*(1500+k*320)*x)*env(x,.002,.07)}return o*.3}),
 poof:(c)=>mk(c,.35,(t,r)=>r()*env(t,.003,.07)*.6),
 warp:(c)=>mk(c,.6,(t,r,D)=>Math.sin(TAU*(300+1500*t/D)*t)*.35*Math.sin(Math.PI*t/D)),
 coin:(c)=>mk(c,.4,(t)=>(t<.07?Math.sin(TAU*988*t):Math.sin(TAU*1319*t))*env(t,.002,.2)*.5),
 cheer:(c)=>mk(c,.9,(t,r,D)=>r()*.35*Math.sin(Math.PI*t/D)*(.6+.4*Math.sin(t*50))),
 giggle:(c)=>mk(c,.5,(t)=>Math.sin(TAU*(700+200*Math.sin(t*40))*t)*.35*Math.max(0,Math.sin(t*34))*Math.exp(-t*2)),
 sneeze:(c)=>mk(c,.45,(t,r)=>r()*env(t,.01,.08)*.7),
 yawn:(c)=>mk(c,.8,(t,r,D)=>Math.sin(TAU*(260-90*t)*t)*.3*Math.sin(Math.PI*t/D))
};
LIB.cheer=LIB.cheer;
const cache=new WeakMap();
function get(ctx,name){let m=cache.get(ctx);if(!m){m={};cache.set(ctx,m)}const n=LIB[name]?name:'pop';return m[n]||(m[n]=LIB[n](ctx))}
ITT.Sfx={names:Object.keys(LIB),get};
if(typeof module!=='undefined'&&module.exports)module.exports=ITT.Sfx;
})(typeof window!=='undefined'?window:globalThis);

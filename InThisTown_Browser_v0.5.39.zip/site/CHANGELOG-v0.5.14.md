# In This Town Browser v0.5.14

- Rebuilt story selection around five rotating plot structures for ordinary rule prompts: loophole, challenge, investigation, chain reaction and mayor's hidden reason.
- The same prompt now advances through different story structures on each creation; the session also starts with a fresh variation offset.
- Story titles now reflect the selected narrative structure and parsed action.
- Shadow/ghost story structure is selected only when the premise explicitly mentions a shadow, ghost or haunting. Darkness, midnight and lights-out phrases no longer trigger a shadow plot by themselves.
- Added integration tests for plot rotation, complete-script diversity, visual-plan presence and shadow gating.
- Bumped app entry URL and service-worker shell cache to force the new story engine to load.

Automated tests do not replace a complete render test on the user's Chromebook.

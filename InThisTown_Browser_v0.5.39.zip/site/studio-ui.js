/* Small browser-only UX helpers. No network requests and no external dependencies. */
(() => {
  'use strict';
  const KEY = 'in-this-town-studio-draft-v1';
  const $ = id => document.getElementById(id);
  const idea = $('idea');
  const tone = $('tone');
  const length = $('length');
  const regen = $('regen');
  const status = $('draftStatus');
  if (!idea || !tone || !length || !regen || !status) return;

  const updateStatus = message => { status.textContent = message; };
  const readDraft = () => {
    try {
      const raw = localStorage.getItem(KEY);
      if (!raw) return null;
      const draft = JSON.parse(raw);
      if (!draft || typeof draft !== 'object') return null;
      return draft;
    } catch (error) {
      console.warn('No se pudo recuperar el borrador local:', error);
      return null;
    }
  };
  const saved = readDraft();
  if (!idea.value && saved) {
    if (typeof saved.idea === 'string') idea.value = saved.idea.slice(0, 300);
    if (['mystery', 'funny', 'suspense'].includes(saved.tone)) tone.value = saved.tone;
    if (['short', 'medium'].includes(saved.length)) length.value = saved.length;
    regen.checked = saved.regen === true;
    const count = $('count');
    if (count) count.textContent = `${idea.value.length} / 300`;
    updateStatus('Borrador recuperado · se guarda automáticamente en este navegador.');
  } else {
    updateStatus('El borrador se guarda automáticamente en este navegador.');
  }

  let pending = 0;
  const snapshot = () => ({
    idea: idea.value.slice(0, 300),
    tone: tone.value,
    length: length.value,
    regen: regen.checked,
    savedAt: Date.now()
  });
  const saveNow = () => {
    if (pending) {
      clearTimeout(pending);
      pending = 0;
    }
    try {
      localStorage.setItem(KEY, JSON.stringify(snapshot()));
      updateStatus('Borrador guardado en este navegador.');
    } catch (error) {
      updateStatus('No se ha podido guardar el borrador local en este navegador.');
      console.warn('No se pudo guardar el borrador local:', error);
    }
  };
  const scheduleSave = () => {
    if (pending) clearTimeout(pending);
    pending = setTimeout(saveNow, 220);
    updateStatus('Guardando borrador…');
  };

  idea.addEventListener('input', scheduleSave);
  tone.addEventListener('change', scheduleSave);
  length.addEventListener('change', scheduleSave);
  regen.addEventListener('change', scheduleSave);
  document.querySelectorAll('.example[data-idea]').forEach(button => {
    button.addEventListener('click', () => setTimeout(saveNow, 0));
  });
  document.querySelectorAll('.quicknav a').forEach(link => {
    link.addEventListener('click', () => {
      const target = document.querySelector(link.getAttribute('href'));
      if (target instanceof HTMLDetailsElement) target.open = true;
    });
  });
  window.addEventListener('pagehide', saveNow);
})();

# In This Town Browser v0.4.5

## Kokoro loading fix attempt
- Replaced the generic `esm.sh` import with the browser-specific `kokoro-js@1.2.1/dist/kokoro.web.js` entrypoint published by the package.
- Pinned the package version to avoid unannounced CDN/package changes.
- Uses Kokoro's documented `q8` + `wasm` configuration as the compatibility baseline on Chromebook/mobile devices rather than attempting WebGPU FP32 first.
- Added model download progress callbacks.
- Improved low-level error reporting, including numeric values and their hexadecimal representation.
- Updated the service-worker cache key to force the new app.js.
- Preserved the original 3D engine files; only the existing browser canvas bridge in `engine/api.js` differs from the archive.

## Honest test status
- JavaScript syntax and ZIP integrity are checked locally.
- The original engine modules remain copied unchanged from the user-provided archive.
- A live browser model download and Chromebook Kokoro inference cannot be verified in this offline build environment. The error code 438218736 is not enough by itself to conclusively identify the underlying runtime failure.

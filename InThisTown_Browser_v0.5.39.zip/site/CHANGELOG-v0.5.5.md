# In This Town Browser v0.5.5

## Integrated visual-plan director
- Added `story-plan-adapter.js` and wired it into the real browser app and the original WebGL2 engine.
- The app now uses the story engine's own per-beat action and camera plans rather than rebuilding most beats from generic labels.
- Word anchors resolve against Kokoro's measured per-word estimates and are clamped to the local scene duration.
- Preserves multiple authored camera cuts and camera moves when provided by a beat.
- Maps source aliases (`H`, `N`, `M`, `nbr`) to the real engine actor IDs and instantiates additional cast members when needed.
- Translates object reveal transitions: `fadeIn` begins transparent and fades up; `rise` starts below the set and moves into place.
- Supports face-to-camera, hover, actor movement, object interactions, light switching, facial expressions, FX, SFX, text, shake and flash using the existing engine action schema.
- Validates effect names against the actual FX catalog. Unsupported plan operations are counted and shown as warnings in the preflight report rather than silently producing fictional commands.
- Retains the earlier handcrafted choreography as a fallback for beats without usable semantic plans.

## Validation
- 11 automated tests pass.
- Integration corpus: 12 premises × 3 tones, with in-scene action and camera time checks.
- JavaScript syntax checked for every `.js` file in `site/`.
- Focused tests cover fade-in, rise, face-to-camera, switch-off and safe handling of unknown operations/FX.

## Limits
- Kokoro voice is still `am_adam` at speed 1.14. Word timing remains waveform-informed, not phoneme-level forced alignment.
- Export remains 576×1024 at 24 fps.
- No complete Kokoro/WebGL/MediaRecorder render has been performed on the user's actual iPhone or Chromebook.
- The story generator remains local, deterministic and template/archetype-based; this release does not add a cloud LLM or arbitrary AI mesh generation.

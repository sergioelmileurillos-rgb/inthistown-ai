# In This Town Browser v0.5.2

## Direction and animation
- Added sentence-level action cues for running, sitting, opening, closing, inspecting, building, speaking, waving, hiding, falling, operating and moving.
- Added prop-specific physical reactions and more precise interactions with the story object.
- Robot premises now use a visible robot character as the interaction target rather than animating a hidden prop.
- Improved timing of actor approaches, object interactions, camera focus and story beats.

## Reusable procedural assets
- Added 12 reusable prop families with 8 visual variations each (96 designs).
- New book, robot, puppet and chair families complement the existing windows, doors, lies, movement, speech, night and body props.
- Deterministic blueprints are saved in localStorage and reused on later videos.

## Voice and subtitles
- Kokoro-82M `am_adam`, American English, speed 1.14.
- Up to 3 short narration lines per TTS request (maximum 25 words per block), reducing the number of model calls.
- Inter-block silence reduced to 20 ms.
- Scene/subtitle boundaries now use measured audio duration, syllable weighting and nearby low-energy windows to reduce drift.
- Karaoke word emphasis remains an estimate, not phoneme-level alignment.

## Engine integrity
- Keeps the original custom WebGL2 renderer and the original engine modules.
- No 2D replacement renderer was introduced.

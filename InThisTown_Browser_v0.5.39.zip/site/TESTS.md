# v0.5.22 — informe de pruebas

- 95/95 pruebas automatizadas superadas.
- Todos los archivos JavaScript pasan `node --check`.
- ZIP y lista de precarga del service worker verificados antes de publicar.
- Se añadió una prueba de integración que ejecuta la premisa del vídeo por el pipeline de escenas, cámara y preflight.
- Se corrigió la interpretación de premisas descriptivas con excepción (por ejemplo, «everyone is poor except the mayor»).
- Se probaron finales alternativos del arquetipo de laguna y continuidad de iluminación.

## Límites de la validación

Las pruebas automatizadas no sustituyen una generación completa en el Chromebook del usuario. La carga real de Kokoro, el rendimiento WebGL2, la grabación MediaRecorder y la reproducción final deben comprobarse en ese dispositivo y navegador.

# In This Town Browser v0.5.28

## Reliability improvements for iPhone and PC
- Expanded device diagnostics to check the complete recording pipeline, not just the presence of MediaRecorder and AudioContext.
- Added explicit checks for WebGL2 context loss, canvas capture, MediaStream, Web Audio media-stream destination, supported recording MIME type, and secure context.
- The diagnostics and actual recorder now use the same `getMime()` selection, avoiding mismatches where the panel says a format is available but the recorder chooses a different one.
- Added an early compatibility preflight before downloading/loading the local story model and Kokoro voice model. Unsupported browsers now receive a list of missing capabilities instead of failing late after long downloads.
- Kept the same single browser app for iPhone 13 Pro and the HP Victus PC; device-specific model routing remains automatic.

## Verification
- Automated test suite and JavaScript syntax checks run locally before packaging.
- No physical end-to-end generation has been performed on the user's iPhone or PC; those checks still require testing in the actual browsers and hardware.

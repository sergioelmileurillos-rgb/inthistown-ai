(function(G){
/**
 * In This Town — Short-form Production Director v0.5.7
 * Renderer-neutral planning helpers. Deterministic, no network/API dependency.
 * This is an editorial assistant, not a neural language model or a guarantee of virality.
 */

const clamp = (n, min, max) => Math.max(min, Math.min(max, n));
const words = text => String(text ?? '').trim().split(/\s+/).filter(Boolean);
const countWords = text => words(text).length;
const has = (text, re) => re.test(String(text ?? ''));

const SIGNALS = {
  hook: /\b(what if|you won't believe|nobody knew|one day|the moment|everything changed|but then|until|secret|disappeared|woke up|found out|never expected)\b/i,
  escalation: /\b(but then|suddenly|meanwhile|however|worse|even worse|another|again|started to|began to|then)\b/i,
  reveal: /\b(revealed|realized|discovered|found out|the truth|turns out|was actually|behind|secretly)\b/i,
  payoff: /\b(finally|in the end|that was why|which meant|because of this|ever since|never again|the next day)\b/i,
  emotional: /\b(scared|terrified|shocked|surprised|angry|furious|happy|excited|sad|crying|laughed|relieved|confused)\b/i,
  visual: /\b(door|window|phone|letter|key|box|car|shadow|screen|photo|gift|room|street|stairs|bag|book|mirror|light)\b/i,
  dialogue: /[“"].+?[”"]|\b(said|asked|replied|whispered|shouted)\b/i
};

/** Split narration into sentence-like beats while retaining punctuation. */
function segmentNarration(script = '') {
  const clean = String(script ?? '').replace(/\s+/g, ' ').trim();
  if (!clean) return [];
  const chunks = clean.match(/[^.!?]+(?:[.!?]+|$)/g) || [clean];
  return chunks.map((text, index) => ({ id:`sf-${index+1}`, index, text:text.trim() })).filter(x => x.text);
}

/** Score script craft signals. Scores are diagnostics, not objective quality predictions. */
function scoreShortformScript(script = '', options = {}) {
  const beats = segmentNarration(script);
  const totalWords = countWords(script);
  const targetSeconds = Number(options.targetSeconds) || 60;
  const estimatedSeconds = totalWords / (Number(options.wordsPerMinute) || 155) * 60;
  const first = beats[0]?.text || '';
  const body = beats.slice(1, -1).map(x => x.text).join(' ');
  const ending = beats.at(-1)?.text || '';
  const metrics = {
    hook: has(first, SIGNALS.hook) || (countWords(first) <= 16 && /[?!]/.test(first)) ? 1 : 0.35,
    progression: beats.length >= 5 && has(body, SIGNALS.escalation) ? 1 : beats.length >= 3 ? 0.65 : 0.25,
    visualSpecificity: clamp((beats.filter(x => has(x.text, SIGNALS.visual)).length / Math.max(1, beats.length)) * 1.5, 0, 1),
    emotionalVariation: clamp(new Set(beats.map(x => (x.text.match(SIGNALS.emotional)?.[0] || '').toLowerCase()).filter(Boolean)).size / 3, 0, 1),
    reveal: has(script, SIGNALS.reveal) ? 1 : 0.35,
    payoff: has(ending, SIGNALS.payoff) || has(ending, /[.!?]$/) ? 0.8 : 0.35,
    pacing: clamp(1 - Math.abs(estimatedSeconds - targetSeconds) / Math.max(targetSeconds, 1), 0, 1)
  };
  const weighted = {hook:.22, progression:.17, visualSpecificity:.18, emotionalVariation:.12, reveal:.13, payoff:.08, pacing:.10};
  const score = Math.round(Object.entries(metrics).reduce((sum,[key,value]) => sum + value * weighted[key],0) * 100);
  const suggestions = [];
  if (metrics.hook < .7) suggestions.push('Reescribe la primera frase con una pregunta, anomalía o consecuencia concreta.');
  if (metrics.progression < .7) suggestions.push('Añade una escalada: cada nuevo beat debe complicar el anterior.');
  if (metrics.visualSpecificity < .55) suggestions.push('Sustituye ideas abstractas por acciones y objetos que puedan verse.');
  if (metrics.emotionalVariation < .34) suggestions.push('Introduce una reacción emocional clara cuando la historia lo justifique.');
  if (metrics.reveal < .7) suggestions.push('Prepara una revelación o un cambio de interpretación.');
  if (metrics.payoff < .7) suggestions.push('Cierra la historia con una consecuencia o remate claro.');
  if (Math.abs(estimatedSeconds-targetSeconds) > 8) suggestions.push(`La narración estimada dura ${estimatedSeconds.toFixed(1)} s; ajusta el texto o el objetivo de ${targetSeconds} s.`);
  return {score, metrics, suggestions, stats:{beats:beats.length,words:totalWords,estimatedSeconds:Number(estimatedSeconds.toFixed(1)),targetSeconds}};
}

/**
 * Assign editorial roles without changing narration. A role is not a camera cut:
 * renderer/editor must use it to choose framing only when the required asset exists.
 */
function classifyNarrativeBeats(beats = []) {
  const list = Array.isArray(beats) ? beats : segmentNarration(beats);
  return list.map((beat,index) => {
    const text = typeof beat === 'string' ? beat : beat.text;
    const role = index === 0 ? 'hook'
      : has(text,SIGNALS.reveal) ? 'reveal'
      : has(text,SIGNALS.payoff) ? 'payoff'
      : has(text,SIGNALS.escalation) ? 'escalation'
      : has(text,SIGNALS.dialogue) ? 'dialogue'
      : has(text,SIGNALS.emotional) ? 'reaction'
      : 'story_action';
    const visualPriority = role === 'hook' || role === 'reveal' || role === 'payoff' ? 'high' : role === 'escalation' || role === 'reaction' ? 'medium' : 'normal';
    return {...(typeof beat === 'object' ? beat : {text}), role, visualPriority};
  });
}

/**
 * Plan shot holds and motivated changes. It deliberately avoids a cut for every sentence.
 * Inputs can be enriched with duration, locationId, sceneId, visualPriority, forceCut.
 */
function planShotRhythm(beats = [], options = {}) {
  const maxHold = Number(options.maxHoldSeconds) || 7.5;
  const minHold = Number(options.minHoldSeconds) || 2.2;
  const enriched = classifyNarrativeBeats(beats);
  const shots = [];
  let current = null;
  for (const beat of enriched) {
    const duration = Number(beat.duration) > 0 ? Number(beat.duration) : clamp(countWords(beat.text) / 2.55, minHold, maxHold);
    const locationChanged = current && beat.locationId && current.locationId && beat.locationId !== current.locationId;
    const sceneChanged = current && beat.sceneId && current.sceneId && beat.sceneId !== current.sceneId;
    const motivatedCut = !!beat.forceCut || !!locationChanged || !!sceneChanged || (current && current.duration + duration > maxHold && beat.visualPriority === 'high');
    if (!current || motivatedCut) {
      current = {id:`shot-${shots.length+1}`, beatIds:[], duration:0, locationId:beat.locationId||current?.locationId||null,
        sceneId:beat.sceneId||current?.sceneId||null, framing:beat.role==='hook'?'hook_close':beat.role==='reveal'?'reveal_detail':beat.role==='payoff'?'payoff_hold':'medium_story',
        cutReason:!shots.length?'opening_shot':beat.forceCut?'explicit_direction':locationChanged?'location_change':sceneChanged?'scene_change':'hold_limit'};
      shots.push(current);
    }
    current.beatIds.push(beat.id ?? beat.index ?? shots.length);
    current.duration = Number((current.duration + duration).toFixed(2));
  }
  return shots;
}

/** Cross-check semantic plans against available scene inventory and timing. */
function auditProduction({script='', plans=[], shots=[], inventory={}, targetSeconds=60} = {}) {
  const issues = [];
  const score = scoreShortformScript(script,{targetSeconds});
  const actorIds = new Set((inventory.actors||[]).map(x=>typeof x==='string'?x:x.id));
  const propIds = new Set((inventory.props||inventory.objects||[]).map(x=>typeof x==='string'?x:(x.semanticId||x.id||x.name)));
  for (const plan of plans) {
    if (!plan.actor) issues.push({severity:'blocker',code:'actor_missing',sequence:plan.sequence});
    else if (actorIds.size && !actorIds.has(plan.actor)) issues.push({severity:'blocker',code:'actor_not_in_scene',sequence:plan.sequence,ref:plan.actor});
    if (plan.action?.target && plan.blocking?.type==='prop_interaction' && propIds.size && !propIds.has(plan.action.target)) issues.push({severity:'blocker',code:'prop_not_in_scene',sequence:plan.sequence,ref:plan.action.target});
    if (plan.requiresReview) issues.push({severity:'warning',code:'semantic_review',sequence:plan.sequence,details:plan.warnings||[]});
    if (plan.timing?.aligned === false) issues.push({severity:'warning',code:'timing_unaligned',sequence:plan.sequence});
  }
  if (score.stats.estimatedSeconds > targetSeconds + 8) issues.push({severity:'warning',code:'runtime_over_target',seconds:score.stats.estimatedSeconds});
  if (score.stats.estimatedSeconds < targetSeconds - 12) issues.push({severity:'warning',code:'runtime_under_target',seconds:score.stats.estimatedSeconds});
  if (!shots.length && plans.length) issues.push({severity:'warning',code:'shots_not_planned'});
  const blockers = issues.filter(x=>x.severity==='blocker').length;
  const warnings = issues.filter(x=>x.severity==='warning').length;
  return {readyForRender:blockers===0 && warnings===0 && plans.length>0, blockers, warnings, issues, scriptScore:score, summary:{plans:plans.length,shots:shots.length}};
}

/** Export a production brief for the real renderer/editor; no fictional clip IDs. */
function createProductionBrief({script='', actors=[], plans=[], shots=[], inventory={}} = {}) {
  return {
    schema:'inthistown.production-brief.v1', createdBy:'shortform-director-0.5.7',
    script:String(script), cast:actors, assets:{actors:inventory.actors||actors, props:inventory.props||inventory.objects||[], sceneAnchors:inventory.sceneAnchors||[]},
    editorial:{format:'9:16',subtitleStyle:'yellow_fill_black_outline_no_label',shots, rules:['No random camera motion','No action without a matching narration beat','No invented animation clips','Keep character and prop continuity','Use real word timings when available']},
    performance:{narrationLanguage:'en-US',captionTiming:'word-level-preferred',musicDucking:true,avoidLongDeadAir:true},
    actionPlans:plans
  };
}

G.ITT=G.ITT||{};G.ITT.Shortform={segmentNarration,scoreShortformScript,classifyNarrativeBeats,planShotRhythm,auditProduction,createProductionBrief};
})(window);

# In This Town Browser v0.5.17

## Studio interface redesign
- Reworked the browser UI into a clearer studio layout with quick navigation.
- Improved visual hierarchy, input and button states, spacing, contrast, mobile layout and keyboard navigation.
- Grouped character creation and the asset library into dedicated tool cards.
- Improved the external AI director's copy/paste instructions and music guidance.
- Preserved existing control IDs and all rendering/story modules.
- Added browser-only automatic draft saving and restore for the rule and basic story settings.

## Verification
Run `npm test` and `npm run check`. The Chromebook render still requires a real device check.

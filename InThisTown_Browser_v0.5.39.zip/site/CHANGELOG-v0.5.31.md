# In This Town Browser v0.5.31

## Mejoras del director de escenas
- `turnTo` ahora incluye en el reparto a un personaje que solo aparece como objetivo de la mirada. Antes podía interpretarse erróneamente como un objeto y crear una referencia visual inexistente.
- La colocación inicial y la recolocación de personajes usan el mismo cálculo de orientación. Los personajes situados a izquierda/derecha giran hacia el centro de la escena desde el primer fotograma.
- Se mantiene el sistema de acciones explícitas: no se inventan reacciones ni movimientos que no estén indicados por el plan narrativo.

## Validación
- Pruebas de regresión añadidas para objetivos `turnTo` y orientación del reparto.
- La compatibilidad real de renderizado y exportación sigue pendiente de probar en el iPhone 13 Pro y el HP Victus.

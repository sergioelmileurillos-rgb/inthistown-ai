# In This Town Browser v0.4.7

- Restores direct local-file use from an extracted ZIP folder.
- In `file://` mode Kokoro runs in an embedded Blob module worker, avoiding a sibling worker fetch from the local-file origin.
- Keeps q8 WASM inference off the UI thread.
- HTTPS deployments continue using `kokoro-worker.js`.
- Preserves the original Roblox Story Studio WebGL2 engine modules and scene pipeline.

## Chromebook usage
1. In the Files app, extract the ZIP (do not open files from inside the ZIP preview).
2. Open the extracted folder, then `site`, then `index.html`.
3. Keep an internet connection for the first Kokoro model download.

## Limitations
Direct `file://` operation depends on ChromeOS/Chromium permitting a Blob module worker to dynamically import the Kokoro browser bundle and download model assets from their CDN/model host. This compatibility has not been verified on the user's Chromebook. If Chrome blocks the import or model download, HTTPS hosting remains the fallback.

# In This Town Browser v0.5.26

- Perfil específico para iPhone/iPad con iOS 26+: comprueba que WebGPU tenga un adaptador real antes de intentar el modelo Q4 acelerado.
- Si WebGPU no está disponible o falla, utiliza WASM Q8 y después Q4 como alternativas.
- Android y versiones antiguas de iOS evitan intentar WebGPU a ciegas y empiezan con WASM.
- Se libera el modelo ONNX/WebGPU tras escribir y validar la historia, antes de cargar Kokoro y renderizar la escena 3D, para reducir presión de memoria en móviles.
- La IA sigue siendo local: no se envía el texto de las historias a un servicio de inferencia.
- Pendiente de prueba física en iPhone 13 Pro y Chromebook. La detección de compatibilidad no garantiza que iOS no cierre la pestaña por presión de memoria.

# In This Town Browser v0.5.3 — narrativa integrada

## Integración principal
- El motor narrativo modular de Claude (v0.5.0) ahora se carga dentro de la app Browser v0.5.2.
- Las premisas entendidas por el parser generan historias con arquetipos alternativos (loophole, warning, reason y effect), reparto y giros, en vez de depender siempre de las secuencias fijas del generador anterior.
- Las historias generadas se adaptan al compositor/coreógrafo v0.5.2: cada rol narrativo se convierte en una intención de escena (regla, reacción, descubrimiento, acción, expansión, revelación, contratiempo o cierre).
- Se conserva el generador v0.5.2 como fallback cuando el parser modular no entiende una premisa.
- El reparto narrativo se reutiliza cuando el preset existe en el motor gráfico; los presets desconocidos usan un personaje compatible.
- Se mantienen el motor WebGL2 original, Asset Forge, Kokoro am_adam, la mezcla de audio, los subtítulos y el render vertical del paquete v0.5.2.

## Validación
- Tests de generación de historias sobre 12 premisas y tres tonos.
- Tests de ausencia de placeholders, frases vacías y variantes.
- Sintaxis JS comprobada para los módulos del sitio.
- La exportación completa con Kokoro real y la validación en iPhone/Chromebook siguen pendientes de prueba en dispositivos reales.

/* app/timing.js — v0.5 voz: normalización de texto, recorte de silencios, tiempos de palabra A PARTIR DEL AUDIO real. */
(function(G){
'use strict';const ITT=G.ITT=G.ITT||{};
const ONES=['zero','one','two','three','four','five','six','seven','eight','nine','ten','eleven','twelve','thirteen','fourteen','fifteen','sixteen','seventeen','eighteen','nineteen'],TENS=['','','twenty','thirty','forty','fifty','sixty','seventy','eighty','ninety'];
function numWords(n){n=+n;if(n<20)return ONES[n];if(n<100)return TENS[Math.floor(n/10)]+(n%10?' '+ONES[n%10]:'');if(n<1000)return ONES[Math.floor(n/100)]+' hundred'+(n%100?' '+numWords(n%100):'');if(n<1e6)return numWords(Math.floor(n/1000))+' thousand'+(n%1000?' '+numWords(n%1000):'');return String(n)}
function normalizeForTTS(t){let s=String(t).replace(/[“”]/g,'"').replace(/[‘’]/g,"'").replace(/\s*[—–]\s*/g,', ').replace(/\*/g,'').replace(/…/g,'...');
  s=s.replace(/\b(\d{1,6})\b/g,(m,n)=>numWords(n));s=s.replace(/\bMr\./g,'Mister').replace(/\bMrs\./g,'Misses').replace(/\bDr\./g,'Doctor').replace(/&/g,' and ').replace(/%/g,' percent');
  s=s.replace(/:\s+/g,': ').replace(/\s{2,}/g,' ').trim();if(!/[.!?]$/.test(s))s+='.';return s}
/* sílabas aproximadas (peso de duración) */
function syl(w){w=w.toLowerCase().replace(/[^a-z]/g,'');if(!w)return 1;if(w.length<=3)return 1;w=w.replace(/(?:[^laeiouy]es|ed|[^laeiouy]e)$/,'').replace(/^y/,'');const m=w.match(/[aeiouy]{1,2}/g);return Math.max(1,m?m.length:1)}
function envelope(pcm,sr,hop=.01){const n=Math.floor(pcm.length/(sr*hop)),h=Math.floor(sr*hop),e=new Float32Array(n);for(let i=0;i<n;i++){let s=0;for(let j=i*h;j<(i+1)*h;j++)s+=pcm[j]*pcm[j];e[i]=Math.sqrt(s/h)}return e}
function trimSilence(pcm,sr){const e=envelope(pcm,sr);let pk=0;for(const v of e)if(v>pk)pk=v;const th=Math.max(.004,pk*.035);let a=0,b=e.length-1;while(a<e.length&&e[a]<th)a++;while(b>a&&e[b]<th)b--;
  const pad=2;const s=Math.max(0,(a-pad)*.01),en=Math.min(pcm.length/sr,(b+1+pad)*.01);return{start:s,end:en,pcm:pcm.subarray(Math.floor(s*sr),Math.floor(en*sr))}}
/* tiempos de palabra: pesos por sílabas+pausas de puntuación, afinados a los valles de energía del audio */
function wordTimes(text,pcm,sr){const toks=String(text).replace(/\*/g,'').split(/\s+/).filter(Boolean);const dur=pcm.length/sr;if(!toks.length)return[];
  const wts=toks.map(w=>{let x=syl(w)+.6;if(/[,:;]$/.test(w))x+=.55;if(/[.!?]$/.test(w))x+=.2;return x});
  // las pausas de coma/dos puntos se reparten a la palabra siguiente al medir el valle
  const tot=wts.reduce((a,b)=>a+b,0);const env=envelope(pcm,sr);const sm=new Float32Array(env.length);for(let i=0;i<env.length;i++){let s=0,c=0;for(let k=-2;k<=2;k++){const v=env[i+k];if(v!==undefined){s+=v;c++}}sm[i]=s/c}
  const bounds=[0];let acc=0;for(let i=0;i<toks.length-1;i++){acc+=wts[i];bounds.push(acc/tot*dur)}bounds.push(dur);
  for(let i=1;i<bounds.length-1;i++){const left=bounds[i]-bounds[i-1],right=bounds[i+1]-bounds[i];const win=Math.min(.14,Math.min(left,right)*.4);
    let best=bounds[i],bv=1e9;for(let t=bounds[i]-win;t<=bounds[i]+win;t+=.01){const k=Math.round(t/.01);const v=sm[k]===undefined?1e9:sm[k]+Math.abs(t-bounds[i])*.02;if(v<bv){bv=v;best=t}}
    bounds[i]=Math.max(bounds[i-1]+.07,Math.min(best,dur-.07*(bounds.length-1-i)))}
  return toks.map((w,i)=>({w,s:bounds[i],e:bounds[i+1]}))}
function gapAfter(text){return /\?$/.test(text)?.2:/!$/.test(text)?.15:/[.]$/.test(text)?.17:.1}
/* de una síntesis cruda -> {pcm recortado, speech, words, dur} */
function analyze(text,pcm,sr){const tr=trimSilence(pcm,sr);const sp=tr.pcm.length/sr;const lead=.06,gap=gapAfter(text);const dur=Math.max(1.25,lead+sp+gap);
  return{pcm:tr.pcm,sr,speech:sp,lead,gap,dur,words:wordTimes(text,tr.pcm,sr).map(w=>({w:w.w,s:w.s+lead,e:w.e+lead}))}}
ITT.Timing={normalizeForTTS,numWords,trimSilence,wordTimes,analyze,envelope,gapAfter,syl};
if(typeof module!=='undefined'&&module.exports)module.exports=ITT.Timing;
})(typeof window!=='undefined'?window:globalThis);

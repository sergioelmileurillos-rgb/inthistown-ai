# In This Town Browser v0.5.35

## Facial animation
- Added a dedicated closed-eye blink tile to the facial atlas and updated its UV layout.
- Added short, deterministic per-character blink cycles in the scene timeline.
- Blink timing is stable across frames and character-specific; sleeping and dead expressions are preserved.
- Existing talk-expression alternation remains active, so mouth movement continues while speaking apart from brief natural blinks.
- Updated app and service-worker cache versions.

## Validation
- Added regression tests for atlas dimensions, blink UVs, deterministic timing, expression preservation, and talk timeline compatibility.
- Browser rendering still requires a real-device visual check.

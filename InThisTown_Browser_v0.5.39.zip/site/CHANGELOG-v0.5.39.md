# v0.5.39 — iPhone memory-safe AI startup

- Story-generation model now starts with Q4 on mobile devices, including iPhone Safari, instead of attempting the larger Q8 allocation first.
- Manual AI preload warms the browser model cache and then releases the in-memory ONNX/WASM pipeline on mobile, reducing the chance of iOS terminating and reloading the tab.
- The next story-generation run loads the cached Q4 model as needed; no API key or remote inference service is introduced.
- Desktop model selection remains unchanged.

Validation: automated tests and JavaScript syntax checks. Physical iPhone testing remains pending.

# v0.5.21 — preparación de lanzamiento

- Alinea la versión visible, `package.json`, el Director IA, la URL versionada de `app.js` y la caché del service worker.
- Añade `START_HERE.txt` con instrucciones de publicación, primer vídeo, flujo opcional de IA externa y resolución de problemas en Chromebook.
- Añade pruebas automáticas de coherencia de versión, guía de inicio y existencia de todos los recursos precargados.
- Mantiene la arquitectura sin API keys ni backend: generación local y puente manual opcional con ChatGPT/Claude.

## Verificación
- 89/89 tests automatizados pasan.
- Todos los archivos JavaScript pasan `node --check`.
- Todos los recursos listados en la caché del service worker existen en el paquete.
- La exportación real con Kokoro + WebGL2 + MediaRecorder debe probarse en el Chromebook de destino; las pruebas automatizadas no pueden sustituir esa comprobación.

/* engine/world.js — scenery builders (city, suburb, park, school, town hall, rooms) + lighting presets.
   World units = studs. Streets run along Z; camera usually looks toward -Z. */
(function(S){
const {V,M,hex,shade,mix,rng}=S;
const norm=V.norm;
const ENV={
  day:{skyTop:[.30,.62,.98],skyHor:[.80,.92,1],sunDir:norm([-.45,.8,.4]),sunCol:[.78,.72,.62],ambSky:[.62,.66,.78],ambGnd:[.48,.46,.42],fogCol:[.82,.92,1],fogNear:140,fogFar:520,sat:1.14,expo:1.1,shadows:1,shadowStr:.78,sunSize:1},
  sunset:{skyTop:[.34,.3,.66],skyHor:[1,.68,.55],sunDir:norm([-.7,.28,.5]),sunCol:[.95,.66,.44],ambSky:[.5,.45,.62],ambGnd:[.45,.34,.3],fogCol:[.98,.7,.62],fogNear:120,fogFar:460,sat:1.15,expo:1.02,shadows:1,shadowStr:.8,sunDisk:[1,.7,.4]},
  night:{skyTop:[.03,.05,.2],skyHor:[.14,.2,.45],sunDir:norm([.3,.7,.5]),sunCol:[.42,.5,.92],ambSky:[.36,.42,.72],ambGnd:[.22,.24,.4],fogCol:[.08,.12,.3],fogNear:90,fogFar:420,sat:1.12,expo:1.25,shadows:1,shadowStr:.6,stars:.9,moonDir:norm([-.5,.55,-.65]),sunSize:0,sunDisk:[.4,.5,.9]},
  fog:{skyTop:[.74,.8,.86],skyHor:[.88,.92,.95],sunDir:norm([-.5,.55,.45]),sunCol:[.62,.62,.62],ambSky:[.55,.6,.68],ambGnd:[.42,.45,.5],fogCol:[.84,.89,.93],fogNear:25,fogFar:190,sat:.78,expo:1.0,shadows:1,shadowStr:.9,sunSize:.3,tint:[.97,1,1.04]},
  storm:{skyTop:[.2,.22,.3],skyHor:[.45,.5,.58],sunDir:norm([-.3,.6,.3]),sunCol:[.35,.36,.4],ambSky:[.4,.43,.52],ambGnd:[.25,.27,.32],fogCol:[.42,.46,.54],fogNear:40,fogFar:260,sat:.8,expo:1,shadows:1,shadowStr:.5,sunSize:0},
  red:{skyTop:[.35,.02,.04],skyHor:[1,.25,.18],sunDir:norm([0,.5,.8]),sunCol:[1,.35,.25],ambSky:[.6,.2,.2],ambGnd:[.35,.1,.12],fogCol:[.75,.15,.14],fogNear:60,fogFar:380,sat:1.2,expo:1.05,shadows:1,shadowStr:.8,sunSize:.5,sunDisk:[1,.3,.2]},
  interior:{skyTop:[.6,.75,.95],skyHor:[.85,.92,1],sunDir:norm([-.3,.9,.6]),sunCol:[.6,.56,.5],ambSky:[.66,.64,.62],ambGnd:[.5,.45,.4],fogCol:[.85,.8,.75],fogNear:200,fogFar:600,sat:1.1,expo:1.02,shadows:1,shadowStr:.6,sunSize:0},
  void:{skyTop:[.05,.02,.14],skyHor:[.22,.08,.4],sunDir:norm([0,.8,.5]),sunCol:[.8,.5,1],ambSky:[.5,.4,.8],ambGnd:[.3,.2,.5],fogCol:[.12,.05,.25],fogNear:80,fogFar:300,sat:1.3,expo:1.05,shadows:0,shadowStr:.5,stars:1,sunSize:0},
};
function env(name,over){const e=Object.assign({},ENV[name]||ENV.day);if(over)Object.assign(e,over);if(e.sunDir)e.sunDir=norm(e.sunDir);if(e.moonDir)e.moonDir=norm(e.moonDir);return e}
const PASTEL=['#f7c6d9','#ffe58a','#bfe3ff','#c9f0c4','#f2b98a','#ffffff','#d7c6f7','#ffd0a8','#9fd3f0'];
const BRICK=['#d97a5a','#c96a50','#e08a6a'];

class World{
  constructor(opts={}){this.batch=new S.Batch();this.colliders=[];this.signs=[];this.envName=opts.sky||'day';this.r=rng(opts.seed||1);this.night=['night','nightblue','neon','spooky'].includes(this.envName);this.spawn={};this.extent=60;this.lights=[]}
  tr(pos,rot){let m=M.T(pos[0],pos[1],pos[2]);if(rot){if(typeof rot==='number')m=M.mul(m,M.Ry(rot));else m=M.chain(m,M.Ry(rot[1]||0),M.Rx(rot[0]||0),M.Rz(rot[2]||0))}return m}
  add(prim,pos,size,color,o={}){this.batch.add(prim,this.tr(pos,o.rot),size,color,o.emis||0);
    if(o.collide){const r=Math.abs(Math.sin(o.rot||0))>.7;const sx=r?size[2]:size[0],sz=r?size[0]:size[2];this.colliders.push({name:typeof o.collide==='string'?o.collide:'solid',min:[pos[0]-sx/2,pos[1]-size[1]/2,pos[2]-sz/2],max:[pos[0]+sx/2,pos[1]+size[1]/2,pos[2]+sz/2],door:!!o.door})}}
  box(pos,size,color,o){this.add(S.prim('box'),pos,size,color,o)}
  cyl(pos,size,color,o){this.add(S.prim('cyl',14),pos,size,color,o)}
  sph(pos,size,color,o){this.add(S.prim('sphere',8,6,true),pos,size,color,o)}
  cone(pos,size,color,o){this.add(S.prim('cone',8,true),pos,size,color,o)}
  prism(pos,size,color,o){this.add(S.prim('prism'),pos,size,color,o)}
  block(x,z,w,d,h,color,o={}){this.box([x,h/2+(o.y0||0),z],[w,h,d],color,o)}
  prop(name,pos,yaw=0,o={}){const parts=S.Props.parts(name,o),m=this.tr(pos,yaw);
    for(const p of parts){const pm=M.chain(m,M.T(...p.off),p.rot?M.chain(M.Rx(p.rot[0]),M.Ry(p.rot[1]),M.Rz(p.rot[2])):M.ident());this.batch.add(S.prim(...p.p),pm,p.size,p.color,p.emis||0)}
    if(o.collide){const s=o.collide;this.colliders.push({name:name,min:[pos[0]-s[0]/2,0,pos[2]-s[1]/2],max:[pos[0]+s[0]/2,s[2]||6,pos[2]+s[1]/2]})}}
  sign(text,pos,yaw,size,o={}){this.signs.push({text,pos,yaw,size,color:o.color||'#fff',bg:o.bg||'#e84a4a',emis:o.emis||0,glow:o.glow})}
  ground(color,size=900,y=0){this.box([0,y-1,0],[size,2,size],color)}
  road(x0,x1,z0,z1){ // road along z
    const w=x1-x0,cx=(x0+x1)/2,L=z0-z1,cz=(z0+z1)/2;this.box([cx,.04,cz],[w,.08,L],'#5d6270');
    for(let z=z0-4;z>z1;z-=12)this.box([cx,.1,z],[.45,.04,5],'#f4f4f4');
    this.box([x0+.35,.1,cz],[.3,.04,L],'#ffffff');this.box([x1-.35,.1,cz],[.3,.04,L],'#ffffff')}
  crosswalk(z,cx=0,w=14){for(let i=-w/2+1;i<w/2;i+=1.9)this.box([cx+i,.11,z],[1,.04,5],'#f6f6f6')}
  windows(x0,side,z,wd,h,yBase,rowH,o={}){ // facade windows on plane x=x0 facing the street
    const cols=Math.max(1,Math.floor(wd/4.4)),rows=Math.max(1,Math.floor((h-yBase-1.5)/rowH)),r=this.r;
    for(let ro=0;ro<rows;ro++){const y=yBase+ro*rowH+rowH/2;
      this.box([x0-side*.18,y-rowH/2+.05,z],[.5,.35,wd-.8],o.ledge||'#ffffff');
      for(let c=0;c<cols;c++){const zz=z-wd/2+(c+.5)*wd/cols;let col,em=0;
        if(this.night){if(r()<.42){col=r()<.2?'#ffb86b':'#ffe48a';em=.9}else col='#2a3558'}
        else col=r()<.5?'#9fd6ff':'#8cc8f2';
        this.box([x0-side*.1,y,zz],[.3,rowH*.52,wd/cols*.55],col,{emis:em});
        this.box([x0-side*.06,y,zz],[.2,rowH*.52+.35,wd/cols*.55+.35],'#ffffff')}}}
  building(x0,side,z,wd,dp,h,color,o={}){
    const cx=x0+side*dp/2;this.box([cx,h/2,z],[dp,h,wd],color,{collide:'building'});
    this.box([cx,h+.3,z],[dp+.8,.6,wd+.8],o.cornice||'#f2f2f2');
    this.windows(x0,side,z,wd,h,o.shop===false?3:6.2,5,o);
    if(o.shop!==false){ // storefront
      this.box([x0-side*.12,2.4,z],[.3,3.3,wd*.7],this.night?'#ffd98a':'#bfe8ff',{emis:this.night?.7:0});
      const aw=['#e84a4a','#ffffff'];const n=Math.max(2,Math.floor(wd/3));
      for(let i=0;i<n;i++)this.box([x0-side*1.2,4.5,z-wd*.4+(i+.5)*(wd*.8)/n],[2.4,.2,(wd*.8)/n],aw[i%2],{rot:[0,0,side*.35]})}
    if(o.sign)this.sign(o.sign,[x0-side*.4,h*.8,z],side>0?-Math.PI/2:Math.PI/2,[wd*.8,4],{bg:o.signBg||'#ff4f9a',emis:.6});
    if(h>35&&this.r()<.6)this.box([cx+side*dp*.2,h+2.4,z+this.r()*wd*.3],[3,3.6,3],'#d6dbe4');
    if(this.r()<.35){this.cyl([cx,h+3.5,z],[.4,6,.4],'#ccc')}
  }
  tree(x,z,s=1,color){this.prop('tree',[x,0,z],this.r()*6.28,{s,color:color||(this.night?'#2e7a4a':'#46c25e')});this.colliders.push({name:'tree',min:[x-.7*s,0,z-.7*s],max:[x+.7*s,8*s,z+.7*s]})}
  lamp(x,z,yaw){this.prop('lamp',[x,0,z],yaw,{on:this.night});if(this.night)this.lights.push([x,8,z])}
  fence(x0,z0,x1,z1,color='#fff'){const n=Math.max(1,Math.floor(V.dist([x0,0,z0],[x1,0,z1])/1.2));for(let i=0;i<=n;i++){const t=i/n;this.box([x0+(x1-x0)*t,1.1,z0+(z1-z0)*t],[.4,2.2,.4],color)}
    const L=V.dist([x0,0,z0],[x1,0,z1]),yaw=Math.atan2(x1-x0,z1-z0);this.box([(x0+x1)/2,1.5,(z0+z1)/2],[.2,.3,L],color,{rot:yaw});this.box([(x0+x1)/2,.7,(z0+z1)/2],[.2,.3,L],color,{rot:yaw})}
  clouds(n=10,y=[60,110],spread=400){const r=this.r;for(let i=0;i<n;i++)this.prop('cloud',[(r()-.5)*spread,y[0]+r()*(y[1]-y[0]),-r()*spread*1.2],0,{})}
  setSpawn(name,p,yaw){this.spawn[name]={pos:p,yaw}}
}

/* ---------------- builders ---------------- */
const B={};
B.city=(w,o={})=>{const r=w.r,len=o.length||320,pal=o.palette||PASTEL;
  w.ground(o.ground||'#d9dde6');w.road(-7,7,90,-len);
  for(const s of[-1,1]){w.box([s*9.5,.1,-len/2+45],[5,.2,len+90],'#e9ecf2');w.box([s*12.1,.1,-len/2+45],[.4,.24,len+90],'#cfd4de')}
  let zl=[70,70];
  for(const s of[-1,1]){let z=75;while(z>-len){const wd=14+Math.floor(r()*14),h=26+Math.floor(r()*r()*80),col=r()<.25?BRICK[Math.floor(r()*3)]:pal[Math.floor(r()*pal.length)];
      w.building(s*12.3,s,z-wd/2,wd,20+r()*12,h,col,{sign:r()<.25?['CAFE','SHOP','PIZZA','BANK','TOYS','HOTEL','MARKET'][Math.floor(r()*7)]:null,signBg:['#ff4f9a','#2f6df6','#32b36b','#ff8a3d'][Math.floor(r()*4)]});
      z-=wd+(r()<.2?4:0)}}
  for(let z=60;z>-len;z-=22){w.tree(-10.5,z+r()*6,.9+r()*.3);w.tree(10.5,z-8+r()*6,.9+r()*.3)}
  for(let z=55;z>-len;z-=40){w.lamp(-8.4,z,Math.PI/2);w.lamp(8.4,z-20,-Math.PI/2)}
  for(const z of[20,-60,-140])w.crosswalk(z);
  for(let i=0;i<10;i++){const s=r()<.5?-1:1;w.prop('car',[s*4.8,0,40-i*34+r()*10],s>0?0:Math.PI,{color:['#e84a4a','#2f6df6','#ffc933','#32b36b','#ffffff','#a45be8'][i%6]})}
  // far skyline
  for(let i=0;i<22;i++){const s=i%2?1:-1,x=s*(60+r()*160),z=-80-r()*320,h=60+r()*160;w.box([x,h/2,z],[22+r()*20,h,22+r()*20],pal[Math.floor(r()*pal.length)])}
  if(o.landmark!==false){w.box([0,70,-len-30],[44,140,36],'#ffffff');w.box([0,98,-len-11.8],[28,18,.6],'#13131c');w.sign(o.landmark||'TV TOWN',[0,98,-len-11.2],0,[26,9],{bg:'#13131c',color:'#ff4f9a',emis:1})}
  w.clouds(10);w.extent=80;w.setSpawn('street',[0,0,45],Math.PI)};
B.suburb=(w,o={})=>{const r=w.r;w.ground('#58c46a');w.road(-7,7,90,-260);
  for(const s of[-1,1]){w.box([s*9.5,.1,-85],[5,.2,360],'#ecece8');
    let z=65;while(z>-230){const col=['#ffe58a','#f7a8c4','#a8d8ff','#ffc999','#c9f0c4','#d7c6f7'][Math.floor(r()*6)];B.house(w,{x:s*28,z,color:col,faceX:-s});
      w.fence(s*13.5,z-12,s*13.5,z+12);w.prop('bush',[s*16,0,z+9],0,{});w.prop('bush',[s*16,0,z-9],0,{});
      if(r()<.6)w.tree(s*20,z+14,1.1);z-=34}}
  for(let z=55;z>-240;z-=50)w.lamp(-8.4,z,Math.PI/2);
  B.mountains(w,{z:-330});w.clouds(10);w.extent=70;w.setSpawn('street',[0,0,45],Math.PI)};
B.house=(w,o={})=>{const {x,z,color='#ffe58a'}=o,fx=o.faceX||-1,wd=o.w||18,dp=o.d||16,h=o.h||11;
  // house faces +/-x toward street. body
  w.box([x,h/2,z],[dp,h,wd],color,{collide:'house'});
  const ry=fx<0?Math.PI/2:-Math.PI/2; // prism ridge along z; gable extrude along z -> scale x=dp
  w.prism([x,h+3,z],[dp+1.6,6,wd+1.6],o.roof||'#d9453d',{collide:false});
  const fxp=x+fx*dp/2; // front facade plane
  w.box([fxp+fx*.1,3,z],[.3,6,3.6],o.door||'#d9453d',{});w.box([fxp+fx*.3,3,z],[.12,.12,.12],'#ffd23a');
  w.box([fxp+fx*1.4,.5,z],[3,1,5],'#cfd0d6');
  for(const dz of[-5.2,5.2])for(const y of[3.6,8]){if(y>7&&dz!==0&&false)continue;w.box([fxp+fx*.08,y,z+dz],[.3,2.6,3],w.night?'#ffe48a':'#bfe8ff',{emis:w.night?.8:0});w.box([fxp+fx*.05,y,z+dz],[.2,3.1,3.5],'#fff')}
  w.box([x-fx*dp*.25,h+5.8,z+wd*.25],[1.8,4,1.8],'#b07a5a');};
B.mountains=(w,o={})=>{const r=w.r;for(let i=0;i<14;i++){const x=-300+i*46+r()*20,s=.8+r()*1.3;w.prop('mountain',[x,0,(o.z||-300)-r()*60],0,{s,color:['#8fa3bf','#9db0ca','#7f94b2'][i%3]})}};
B.park=(w,o={})=>{const r=w.r;w.ground('#4fc65a',900);
  // hills
  for(const [x,z,s] of[[-90,-120,70],[110,-170,90],[0,-240,120]])w.add(S.prim('sphere',16,10),[x,-s*.15,z],[s*2.4,s*.9,s*2],'#5ccf5c',{});
  // lines like pitch
  for(let i=-1;i<=1;i+=2)w.box([i*18,.06,-20],[.6,.04,120],'#fff');for(let z=40;z>-80;z-=40)w.box([0,.06,z],[36,.04,.6],'#fff');
  // path
  w.box([0,.05,-30],[7,.06,200],'#f4cf7a');w.box([0,.07,-30],[7.4,.04,2],'#ff9b3a');
  for(let i=0;i<30;i++){const x=(r()-.5)*160,z=-r()*220+30;if(Math.abs(x)<8)continue;if(r()<.5)w.tree(x,z,1+r()*.8);else w.prop('pine',[x,0,z],0,{s:1+r()*.8})}
  for(let i=0;i<40;i++)w.prop('flower',[(r()-.5)*80,0,-r()*100+30],0,{color:['#ff6fa5','#ffd23a','#fff','#a45be8'][i%4]});
  w.prop('bench',[-12,0,10],Math.PI/2,{collide:[2,4.4,3]});w.prop('bench',[12,0,10],-Math.PI/2,{collide:[2,4.4,3]});
  B.mountains(w,{z:-330});w.clouds(14);w.extent=70;w.setSpawn('park',[0,0,35],Math.PI)};
B.school=(w,o={})=>{w.ground('#6bd070',900);w.box([0,.05,24],[12,.1,70],'#e2cf94'); w.box([0,.04,64],[160,.08,16],'#5d6270');
  w.box([0,10,-10],[70,20,24],o.color||'#e8a07a',{collide:'school'});w.box([0,20.5,-10],[72,1,26],'#f2f2f2');
  for(let c=0;c<7;c++)for(let ro=0;ro<2;ro++){w.box([-27+c*9,5+ro*8,2.15],[4,4,.4],'#bfe8ff');w.box([-27+c*9,5+ro*8,2.1],[4.6,4.6,.3],'#fff')}
  w.box([0,4,2.4],[8,8,.6],'#8a4a2a');w.box([0,9,2.2],[22,3.4,.5],'#2f6df6',{});w.sign(o.name||'SCHOOL',[0,9,2.5],0,[20,3],{bg:'#2f6df6',emis:.4});
  w.box([0,.5,6],[14,1,5],'#cfd0d6');w.box([0,1.5,8],[10,1,3],'#bdbec6');
  w.prop('flag',[-18,0,14],0,{color:'#e84a4a'});w.prop('slide',[28,0,20],0,{});w.prop('pullupbar',[-30,0,22],0,{});
  w.fence(-50,40,50,40);for(let i=0;i<8;i++)w.tree(-60+i*17,-30,1.2);
  B.mountains(w,{z:-250});w.clouds(10);w.extent=70;w.setSpawn('yard',[0,0,28],Math.PI)};
B.townhall=(w,o={})=>{w.ground('#cfd5df',900);w.box([0,.05,40],[26,.1,150],'#d9453d');
  w.box([0,1,-12],[46,2,34],'#f2f2f2');w.box([0,2.4,-12],[40,1.4,30],'#e9e9ee');w.box([0,10,-18],[34,16,18],'#f7f7fa',{collide:'townhall'});
  for(let i=-3;i<=3;i++)w.cyl([i*5,9,-5.4],[2,15,2],'#ffffff');w.prism([0,19.5,-8],[38,6,16],'#e8e8ee',{});
  w.box([0,5,-8.8],[7,9,.6],'#7a1f2a');w.box([-1.7,5,-8.4],[.4,.4,.2],'#ffd23a');w.box([1.7,5,-8.4],[.4,.4,.2],'#ffd23a');
  w.sign(o.name||'MAYOR',[0,17,-4.8],0,[10,2.4],{bg:'#f5e6b8',color:'#3a2a1f'});w.cyl([0,28,-18],[7,7,2],'#fff');w.box([0,28,-16.9],[5,5,.2],'#fff');
  w.prop('fountain',[0,0,40],0,{});
  for(const s of[-1,1]){for(let z=30;z>-30;z-=18)w.tree(s*30,z,1.1)}
  B.mountains(w,{z:-200});w.clouds(8);w.extent=60;w.setSpawn('plaza',[0,0,40],Math.PI)};
B.room=(w,o={})=>{const W=o.w||34,D=o.d||30,H=o.h||16,f=o.floor||'#c89a62',wall=o.wall||'#f2dcc0',kind=o.kind||'living';
  w.box([0,-.25,0],[W,.5,D],f);for(let i=-W/2;i<W/2;i+=3)w.box([i,.01,0],[.08,.02,D],shade(f,.85));
  w.box([0,H/2,-D/2],[W,H,.6],wall,{collide:'wall'});w.box([-W/2,H/2,0],[.6,H,D],shade(wall,.96),{collide:'wall'});w.box([W/2,H/2,0],[.6,H,D],shade(wall,.96),{collide:'wall'});
  w.box([0,.5,-D/2+.4],[W,1,.3],'#fff');w.box([-W/2+.4,.5,0],[.3,1,D],'#fff');w.box([W/2-.4,.5,0],[.3,1,D],'#fff');
  w.box([0,H-.2,-D/2+.3],[W,.5,.5],'#fff');
  const win=(x)=>{w.box([x,9,-D/2+.35],[8,7,.3],o.night?'#1a2a58':'#9fd6ff',{emis:o.night?.2:.05});w.box([x,9,-D/2+.3],[8.8,7.8,.2],'#fff');w.box([x,9,-D/2+.45],[.3,7,.2],'#fff');w.box([x,9,-D/2+.45],[8,.3,.2],'#fff')};
  win(-8);win(9);
  if(kind==='living'){w.prop('couch',[0,0,-7],0,{color:o.couch||'#3a4a7a',collide:[7,3,4]});w.prop('tv',[0,.6,-D/2+2],0,{});w.prop('table',[0,0,0],0,{w:6,d:3.4,collide:[6,3.4,2.4]});w.prop('shelf',[-W/2+3,0,-4],Math.PI/2,{});w.prop('lamp',[W/2-3,0,-D/2+3],0,{});w.box([0,.04,-1],[14,.04,9],'#e84a4a')}
  if(kind==='bedroom'){w.prop('bed',[-6,0,-D/2+5],0,{color:o.bed||'#6aa8ff',collide:[5,8,3]});w.prop('shelf',[W/2-3,0,-5],-Math.PI/2,{});w.box([6,.04,0],[12,.04,10],'#ffd23a');w.prop('desk',[W/2-6,0,6],-Math.PI/2,{})}
  if(kind==='classroom'){w.prop('blackboard',[0,8,-D/2+.6],0,{});for(let r=0;r<3;r++)for(let c=-2;c<=2;c++){w.prop('desk',[c*6,0,-3+r*6],0,{collide:[4,2.6,2.2]})}}
  if(kind==='office'){w.prop('desk',[0,0,-9],0,{w:9,d:3.6,collide:[9,3.6,2.4]});w.prop('shelf',[-W/2+3,0,-5],Math.PI/2,{});w.prop('flag',[W/2-4,0,-D/2+3],0,{color:'#2f6df6'});w.prop('trophy',[3,2.3,-9],0,{});w.box([0,.04,-1],[16,.04,10],'#7a1f2a')}
  if(kind==='kitchen'){w.prop('fridge',[-W/2+3,0,-D/2+3],0,{});w.box([5,2,-D/2+3],[16,4,3.5],'#e8e0d0',{collide:'counter'});w.prop('table',[2,0,4],0,{w:7,d:4})}
  w.extent=40;w.setSpawn('room',[0,0,10],Math.PI)};
B.void=(w,o={})=>{w.ground('#241046',600);for(let i=0;i<40;i++)w.box([(w.r()-.5)*200,8+w.r()*50,-w.r()*200],[4+w.r()*6,1+w.r()*20,4+w.r()*6],['#ff4fd8','#2fe0ff','#a45be8'][i%3],{emis:.8});w.extent=60};
B.crowd=(w,o={})=>{const r=w.r,n=o.n||60,[x0,z0,x1,z1]=o.area||[-14,-12,14,10];
  for(let i=0;i<n;i++){const spec=S.randomSpec(r,{scale:.85+r()*.3});const ch=new S.Character('c'+i,spec);const x=x0+(x1-x0)*r(),z=z0+(z1-z0)*r();
    const pose=Object.assign({},S.Anim.ZERO,S.Anim.clips[o.clip||'idle'](r()*6,0,{}),o.poseJitter===false?{}:{headY:(r()-.5)*.8,lArmX:r()<.3?2.8:0,rArmX:r()<.3?2.8:0});
    const yaw=(o.yawDeg!==undefined?o.yawDeg*Math.PI/180:0)+(r()-.5)*(o.spread===undefined?.8:o.spread);
    ch.addToBatch(w.batch,M.chain(M.T(x,o.y||0,z),M.Ry(yaw)),pose)}};
B.plaza=(w,o={})=>{B.city(w,Object.assign({landmark:false},o))};
S.World=World;S.Worlds=B;S.env=env;S.ENV=ENV;
S.buildWorld=function(spec,seed,sky){const list=Array.isArray(spec)?spec:[spec];const w=new World({sky:sky||'day',seed});
  for(const item of list){const it=typeof item==='string'?{type:item}:item;const fn=B[it.type];if(!fn)throw new Error('Unknown world type: '+it.type+' (have: '+Object.keys(B).join(', ')+')');fn(w,it)}
  return w};
})(window.Studio);

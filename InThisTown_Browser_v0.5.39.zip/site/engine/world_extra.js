/* engine/world_extra.js — +14 world builders, +11 interiors, +9 sky/light presets, +6 props (v2 quality pack).
   story.json:  "sky":"nightblue", "world":[{"type":"beach"}]   |   {"type":"interior","kind":"hospital"}
   Worlds follow the engine convention: camera stands at +Z looking toward -Z, street/path along Z, spawn at z≈40. */
(function(S){
const {V,shade}=S;const norm=V.norm;const B=S.Worlds,E=S.ENV,L=S.Props.lib;const PI=Math.PI;
const Bx=(off,size,color,x={})=>Object.assign({p:['box'],off,size,color},x);
const Cy=(off,size,color,x={})=>Object.assign({p:['cyl',14],off,size,color},x);
const Sp=(off,size,color,x={})=>Object.assign({p:['sphere',10,7],off,size,color},x);
const Co=(off,size,color,x={})=>Object.assign({p:['cone',10,false],off,size,color},x);

/* ---------- sky / light presets ---------- */
E.nightblue={skyTop:[.04,.1,.42],skyHor:[.22,.38,.85],sunDir:norm([.35,.75,.5]),sunCol:[.52,.64,1],ambSky:[.5,.58,.98],ambGnd:[.3,.34,.66],fogCol:[.14,.26,.66],fogNear:110,fogFar:460,sat:1.28,expo:1.28,shadows:1,shadowStr:.62,stars:.5,moonDir:norm([-.5,.5,-.7]),sunSize:0,sunDisk:[.5,.6,1]};
E.dawn={skyTop:[.32,.34,.72],skyHor:[1,.78,.62],sunDir:norm([-.8,.2,.45]),sunCol:[1,.72,.5],ambSky:[.56,.55,.74],ambGnd:[.5,.4,.38],fogCol:[1,.78,.7],fogNear:120,fogFar:480,sat:1.18,expo:1.05,shadows:1,shadowStr:.78,sunDisk:[1,.75,.45]};
E.overcast={skyTop:[.62,.68,.76],skyHor:[.82,.86,.9],sunDir:norm([-.3,.8,.4]),sunCol:[.42,.42,.44],ambSky:[.66,.7,.78],ambGnd:[.5,.5,.52],fogCol:[.8,.84,.88],fogNear:90,fogFar:380,sat:.9,expo:1.08,shadows:1,shadowStr:.4,sunSize:0};
E.neon={skyTop:[.06,.02,.2],skyHor:[.5,.1,.55],sunDir:norm([.2,.7,.6]),sunCol:[.9,.4,1],ambSky:[.55,.35,.85],ambGnd:[.3,.15,.5],fogCol:[.28,.06,.4],fogNear:70,fogFar:300,sat:1.35,expo:1.15,shadows:1,shadowStr:.5,stars:.7,sunSize:0,sunDisk:[1,.3,.9]};
E.candy={skyTop:[.55,.8,1],skyHor:[1,.85,.95],sunDir:norm([-.4,.8,.45]),sunCol:[.85,.78,.72],ambSky:[.78,.74,.86],ambGnd:[.62,.5,.55],fogCol:[1,.86,.95],fogNear:160,fogFar:520,sat:1.25,expo:1.12,shadows:1,shadowStr:.6};
E.cave={skyTop:[.04,.03,.08],skyHor:[.1,.08,.16],sunDir:norm([0,.9,.3]),sunCol:[.5,.55,.8],ambSky:[.35,.36,.55],ambGnd:[.2,.18,.3],fogCol:[.06,.05,.12],fogNear:20,fogFar:160,sat:1.1,expo:1.3,shadows:1,shadowStr:.7,sunSize:0};
E.underwater={skyTop:[.05,.35,.7],skyHor:[.2,.7,.85],sunDir:norm([-.2,.9,.3]),sunCol:[.55,.8,.9],ambSky:[.4,.7,.85],ambGnd:[.2,.45,.6],fogCol:[.1,.5,.7],fogNear:15,fogFar:130,sat:1.1,expo:1.1,shadows:1,shadowStr:.45,sunSize:0,tint:[.9,1,1.05]};
E.spooky={skyTop:[.05,.06,.14],skyHor:[.3,.34,.45],sunDir:norm([-.4,.5,-.5]),sunCol:[.5,.55,.75],ambSky:[.34,.38,.52],ambGnd:[.2,.2,.3],fogCol:[.22,.26,.36],fogNear:18,fogFar:150,sat:.85,expo:1.15,shadows:1,shadowStr:.8,stars:.5,moonDir:norm([.4,.5,-.7]),sunSize:0};
E.desert={skyTop:[.28,.58,.95],skyHor:[1,.92,.8],sunDir:norm([-.2,.95,.2]),sunCol:[1,.9,.7],ambSky:[.7,.68,.7],ambGnd:[.65,.5,.35],fogCol:[.98,.9,.78],fogNear:200,fogFar:650,sat:1.15,expo:1.12,shadows:1,shadowStr:.85};
E.space={skyTop:[0,0,.02],skyHor:[.02,.02,.1],sunDir:norm([-.6,.4,.5]),sunCol:[1,.96,.9],ambSky:[.22,.24,.36],ambGnd:[.12,.12,.2],fogCol:[0,0,.03],fogNear:600,fogFar:1500,sat:1.1,expo:1.15,shadows:1,shadowStr:.85,stars:1.2,sunSize:1,moonDir:norm([.5,.4,-.7])};

/* ---------- extra props used only by the worlds below (also usable in scenes) ---------- */
L.snowman=()=>[Sp([0,1.4,0],[3,2.8,3],'#fff'),Sp([0,3.5,0],[2.2,2.2,2.2],'#fff'),Sp([0,5.1,0],[1.6,1.6,1.6],'#fff'),Co([0,5.1,.9],[.3,.3,1.2],'#ff7a1a',{rot:[PI/2,0,0]}),Bx([-.35,5.4,.75],[.2,.2,.1],'#111'),Bx([.35,5.4,.75],[.2,.2,.1],'#111'),Cy([0,6.1,0],[1.4,.8,1.4],'#16161c'),Bx([0,3.5,1.1],[.25,.25,.1],'#111')];
L.igloo=()=>[{p:['sphere',10,6,true],off:[0,0,0],size:[10,8,10],color:'#f4fbff'},Bx([0,1.6,4.6],[2.6,3.2,2.6],'#f4fbff'),Bx([0,1.2,5.9],[1.8,2.4,.2],'#16213a')];
L.barn=(o={})=>[Bx([0,5,0],[16,10,12],o.color||'#c8453c'),{p:['prism'],off:[0,12,0],size:[17,5,13],color:'#7a2a24'},Bx([0,3.4,6.05],[6,6.8,.2],'#f4f4f4'),Bx([0,3.4,6.15],[.4,6.8,.1],'#c8453c',{rot:[0,0,.5]}),Bx([0,3.4,6.15],[.4,6.8,.1],'#c8453c',{rot:[0,0,-.5]}),Bx([0,9,6.1],[2.2,1.6,.2],'#222')];
L.haybale=()=>[Cy([0,1.6,0],[3.2,3,3.2],'#e8c35a',{rot:[0,0,PI/2]}),Cy([0,1.6,0],[3.25,2.9,3.25],'#d9ad3a',{rot:[0,0,PI/2],alpha:.35})];
L.windmill=()=>[Co([0,6,0],[6,12,6],'#f2ead6'),Cy([0,12.5,0],[.8,1,.8],'#8a5a2a'),Bx([0,12.6,1.2],[1,12,.2],'#fff',{rot:[0,0,.3]}),Bx([0,12.6,1.2],[12,1,.2],'#fff',{rot:[0,0,.3]})];
L.silo=()=>[Cy([0,7,0],[5,14,5],'#c8ccd6'),Sp([0,14,0],[5,3,5],'#b0b4bd')];
L.lollipop=(o={})=>[Cy([0,3,0],[.3,6,.3],'#fff'),Cy([0,6.6,0],[3.6,.5,3.6],o.color||'#ff4f9a',{rot:[PI/2,0,0]}),Cy([0,6.6,.2],[2.2,.3,2.2],'#fff',{rot:[PI/2,0,0]})];
L.candycane=()=>[Cy([0,3,0],[.7,6,.7],'#fff'),...Array.from({length:6},(_,i)=>Cy([0,.6+i,0],[.76,.4,.76],'#e83030')),Cy([.9,6.2,0],[.7,2,.7],'#fff',{rot:[0,0,PI/2]})];
L.gumdrop=(o={})=>[{p:['sphere',10,6],off:[0,.9,0],size:[2.4,2.2,2.4],color:o.color||'#ff8fb3',emis:.15}];
L.gravestone=(o={})=>[Bx([0,1.4,0],[2.2,2.8,.6],'#9a9eaa'),Cy([0,2.8,0],[2.2,.6,.6],'#9a9eaa',{rot:[PI/2,0,0]}),Bx([0,1.6,.32],[.9,.15,.05],'#6a6e7a'),Bx([0,1.9,.32],[.15,.9,.05],'#6a6e7a')];
L.deadtree=()=>[Cy([0,3,0],[.9,6,.9],'#3a2a22'),Bx([1.4,5,0],[3,.4,.4],'#3a2a22',{rot:[0,0,.6]}),Bx([-1.4,4.4,0],[2.8,.35,.35],'#3a2a22',{rot:[0,0,-.5]}),Bx([.6,6.6,0],[1.8,.3,.3],'#3a2a22',{rot:[0,0,.9]})];
L.coral=(o={})=>[Co([0,2,0],[1.6,4,1.6],o.color||'#ff6f8f'),Co([1.2,1.2,.3],[1.2,2.4,1.2],o.color||'#ff6f8f',{rot:[0,0,-.3]}),Co([-1,1.4,-.2],[1.2,2.8,1.2],sc(o.color||'#ff6f8f'),{rot:[0,0,.3]})];
const sc=c=>shade(c,.85);
L.stalagmite=()=>[Co([0,2.5,0],[2.4,5,2.4],'#6a6480'),Co([1.6,1.4,.6],[1.4,2.8,1.4],'#7a7490')];
L.sandcastle=()=>[Bx([0,1.2,0],[5,2.4,5],'#e8c97a'),...[[-2.2,-2.2],[2.2,-2.2],[-2.2,2.2],[2.2,2.2]].map(([x,z])=>Cy([x,2.6,z],[1.4,3.2,1.4],'#e8c97a')),Co([0,4.2,0],[1.6,1.8,1.6],'#e8c97a')];
L.beachumbrella=(o={})=>[Cy([0,3.2,0],[.2,6.4,.2],'#f2f2f2',{rot:[0,0,.12]}),Co([0,6.6,0],[7,1.6,7],o.color||'#ff4f6e'),Co([0,6.65,0],[3.6,1.7,3.6],'#fff')];
L.towel=(o={})=>[Bx([0,.08,0],[3,.15,6.4],o.color||'#3bd1ff'),Bx([0,.1,0],[3,.16,.8],'#fff')];
L.surfboard=(o={})=>[{p:['sphere',10,6],off:[0,3.4,0],size:[1.4,7,.3],color:o.color||'#ffd23a'},Bx([0,3.4,.18],[.12,6.4,.05],'#fff')];
L.mesa=(o={})=>[Bx([0,6,0],[20,12,16],o.color||'#d9763a'),Bx([0,13,0],[16,2,12],shade(o.color||'#d9763a',1.08)),Bx([0,8,8.05],[20,.5,.1],shade(o.color||'#d9763a',.85))];
L.sandbox=()=>[Bx([0,.4,0],[9,.8,9],'#8a5a2a'),Bx([0,.62,0],[8.2,.2,8.2],'#f2dfa0')];
L.seesaw=()=>[Co([0,1,0],[1.6,2,1.6],'#555'),Bx([0,2.2,0],[11,.4,1.2],'#e84a4a',{rot:[0,0,.2]})];
L.lollitree=()=>[Cy([0,2.5,0],[.7,5,.7],'#8a5a2a'),Sp([0,6,0],[5,5,5],'#ff8fd0',{emis:.1}),Sp([1.4,7.2,.4],[3,3,3],'#ffd0f0',{emis:.1})];
L.cloudplat=()=>[Sp([0,0,0],[10,3,8],'#fff'),Sp([3.6,.4,0],[7,3,6],'#fff'),Sp([-3.6,.2,0],[7,2.8,6],'#fff')];
L.bleacher=(o={})=>{const a=[];for(let i=0;i<6;i++)a.push(Bx([0,.6+i*1.2,-i*1.4],[(o.w||24),1.2,1.4],i%2?'#d8dbe2':'#c0c4cc'));return a};

/* ---------- world builders ---------- */
const ground=(w,c,s=900)=>w.ground(c,s);
B.studio=(w,o={})=>{ground(w,o.floor||'#cfd5e3');w.box([0,60,-100],[400,120,2],o.wall||'#c4cce0');w.extent=60;w.setSpawn('studio',[0,0,20],Math.PI)};
B.beach=(w,o={})=>{const r=w.r;ground(w,'#f2dfa0');w.box([0,-.2,-170],[900,.5,230],'#42b6f2');w.box([0,.1,-62],[900,.3,8],'#ffffff');w.box([0,.12,-52],[900,.2,6],'#bfe8ff');
  for(let i=0;i<10;i++){const x=(r()-.5)*160,z=20-r()*60;w.prop('palm',[x,0,z],r()*6,{s:.9+r()*.5})}
  for(let i=0;i<6;i++){const x=-40+i*16+r()*6,z=10-r()*18;w.prop('beachumbrella',[x,0,z],0,{color:['#ff4f6e','#ffd23a','#3bd1ff','#a45be8'][i%4]});w.prop('towel',[x+3,0,z+5],r()*.6,{color:['#3bd1ff','#ff8a3d','#6bd86b'][i%3]})}
  w.prop('sandcastle',[18,0,2],0,{});w.prop('surfboard',[-18,0,6],.3,{color:'#ff4f9a'});w.prop('rock',[-50,0,-30],0,{s:2});w.prop('rock',[56,0,-24],0,{s:1.6});
  B.mountains(w,{z:-380});w.clouds(14);w.extent=70;w.setSpawn('beach',[0,0,38],Math.PI)};
B.desert=(w,o={})=>{const r=w.r;ground(w,'#e8c07a');w.road(-7,7,90,-300);
  for(let i=0;i<14;i++)w.prop('cactus',[(r()<.5?-1:1)*(14+r()*60),0,30-r()*240],0,{});
  for(let i=0;i<10;i++)w.prop('rock',[(r()-.5)*180,0,20-r()*220],r()*6,{s:1+r()*2,color:'#c89a6a'});
  for(let i=0;i<8;i++)w.prop('mesa',[(r()<.5?-1:1)*(70+r()*120),0,-120-r()*200],0,{color:['#d9763a','#c8683a','#e08a4a'][i%3]});
  w.prop('skullsign',[12,0,10],-.3,{});w.clouds(5);w.extent=70;w.setSpawn('road',[0,0,45],Math.PI)};
B.snow=(w,o={})=>{const r=w.r;ground(w,'#f4fbff');w.box([0,.05,-60],[14,.1,300],'#dfeaf5');
  for(let i=0;i<26;i++){const x=(r()<.5?-1:1)*(14+r()*70),z=30-r()*230,k=1+r()*.8;w.prop('pine',[x,0,z],0,{s:k});w.cone([x,6.4*k,z],[3.1*k,2.4*k,3.1*k],'#fff')}
  for(let i=0;i<5;i++)w.prop('snowman',[(r()<.5?-1:1)*(10+r()*22),0,24-i*30],r()*6,{});
  w.prop('igloo',[-26,0,-10],.4,{});w.prop('igloo',[30,0,-60],-.5,{});
  for(const s of[-1,1])B.house(w,{x:s*34,z:-30,color:s>0?'#ffe58a':'#a8d8ff',faceX:-s,roof:'#f4fbff'});
  B.mountains(w,{z:-330});w.clouds(8);w.extent=70;w.setSpawn('snow',[0,0,40],Math.PI)};
B.forest=(w,o={})=>{const r=w.r;ground(w,'#3fa856');w.box([0,.05,-40],[6,.08,260],'#d9b07a');
  for(let i=0;i<70;i++){const x=(r()<.5?-1:1)*(8+r()*90),z=40-r()*260;if(r()<.55)w.prop('pine',[x,0,z],0,{s:1.1+r()*1.1});else w.tree(x,z,1.1+r()*.9)}
  for(let i=0;i<10;i++)w.prop('mushroom',[(r()-.5)*40,0,30-r()*120],0,{color:['#e8453c','#ffd23a','#a45be8'][i%3]});
  for(let i=0;i<6;i++){w.prop('log',[(r()<.5?-1:1)*(8+r()*10),0,30-r()*100],r()*3,{});w.prop('rock',[(r()<.5?-1:1)*(7+r()*18),0,25-r()*110],r()*6,{s:1+r()})}
  w.prop('campfire',[10,0,20],0,{});w.prop('tent',[-14,0,18],.3,{});B.mountains(w,{z:-330});w.clouds(8);w.extent=60;w.setSpawn('trail',[0,0,40],Math.PI)};
B.farm=(w,o={})=>{const r=w.r;ground(w,'#6ccf5a');w.box([0,.05,-30],[8,.08,240],'#d9b07a');
  w.prop('barn',[-30,0,-20],.4,{collide:[16,12,10]});w.prop('silo',[-46,0,-30],0,{});w.prop('windmill',[40,0,-50],-.2,{});
  for(let i=0;i<8;i++)w.prop('haybale',[20+r()*20,0,10-i*9],r()*3,{});
  for(let row=0;row<6;row++)for(let i=0;i<14;i++)w.prop('carrot',[30+row*4,0,20-i*3.4],0,{s:.35});
  w.fence(-60,40,60,40);w.fence(-60,-120,60,-120);for(let i=0;i<6;i++)w.tree((r()-.5)*180,-40-r()*80,1.3);
  B.mountains(w,{z:-330});w.clouds(12);w.extent=70;w.setSpawn('farm',[0,0,38],Math.PI)};
B.playground=(w,o={})=>{const r=w.r;ground(w,'#5cc86a');w.box([0,.05,-10],[70,.08,60],'#e2cf94');
  w.prop('slide',[-18,0,-4],.4,{collide:[3,6,6]});w.prop('swing',[0,0,-12],0,{});w.prop('trampoline',[18,0,-2],0,{});w.prop('seesaw',[-8,0,14],0,{});w.prop('sandbox',[14,0,16],0,{});
  w.prop('bench',[-26,0,10],Math.PI/2,{collide:[2,4.4,3]});w.prop('bench',[26,0,10],-Math.PI/2,{collide:[2,4.4,3]});w.prop('basketball',[4,0,6],0,{});w.prop('soccerball',[-4,0,9],0,{});
  w.fence(-40,40,40,40);for(let i=0;i<10;i++)w.tree(-70+i*15,-50-r()*20,1.2);
  B.mountains(w,{z:-300});w.clouds(12);w.extent=60;w.setSpawn('play',[0,0,35],Math.PI)};
B.stadium=(w,o={})=>{const r=w.r;ground(w,'#3fb55a');for(let z=40;z>-80;z-=16)w.box([0,.02,z],[80,.03,8],'#46c25e');
  w.box([0,.06,-4],[70,.04,.5],'#fff');w.box([0,.06,-70],[70,.04,.5],'#fff');w.box([-35,.06,-37],[.5,.04,66],'#fff');w.box([35,.06,-37],[.5,.04,66],'#fff');w.cyl([0,.06,-37],[16,.04,16],'#fff');
  w.prop('goalpost',[0,0,-72],0,{});w.prop('goalpost',[0,0,-2],Math.PI,{});
  for(const s of[-1,1]){w.prop('bleacher',[s*52,0,-37],s>0?-PI/2:PI/2,{w:70});w.box([s*66,10,-37],[2,20,80],'#c0c4cc')}
  B.crowd(w,{n:o.crowd||70,area:[-60,-60,-48,-14],yawDeg:90,y:3});B.crowd(w,{n:o.crowd||70,area:[48,-60,60,-14],yawDeg:-90,y:3});
  w.box([0,22,-120],[160,44,4],'#9aa3b8');for(let i=-3;i<=3;i++){w.box([i*20,36,-117],[3,3,3],'#fff3a0',{emis:1})}
  w.clouds(8);w.extent=70;w.setSpawn('pitch',[0,0,20],Math.PI)};
B.space=(w,o={})=>{w.ground('#2a2f45',500);w.cyl([0,.05,-20],[120,.2,120],'#3a4260',{});w.cyl([0,.1,-20],[100,.1,100],'#4a5578');
  for(let i=0;i<12;i++){const a=i/12*PI*2;w.box([Math.cos(a)*50,.4,-20+Math.sin(a)*50],[3,.6,3],'#3bd1ff',{emis:1})}
  w.prop('planet',[-90,60,-260],0,{r:60,color:'#e8853a'});w.prop('planet',[110,90,-340],0,{r:30,color:'#6aa8ff',ring:'#cfe4ff'});w.prop('moon',[50,120,-300],0,{});
  w.prop('spaceship',[-30,0,-30],.3,{});w.prop('satellite',[40,40,-60],0,{});for(let i=0;i<8;i++)w.prop('rock',[(w.r()-.5)*160,0,-w.r()*100],w.r()*6,{s:1+w.r()*2,color:'#6b7080'});
  w.extent=50;w.setSpawn('deck',[0,0,20],Math.PI)};
B.candy=(w,o={})=>{const r=w.r;ground(w,'#ffc0e0');w.box([0,.05,-40],[10,.08,280],'#fff3a8');for(let z=40;z>-200;z-=6)w.box([0,.09,z],[10,.04,3],'#ffd0f0');
  for(let i=0;i<34;i++){const x=(r()<.5?-1:1)*(10+r()*80),z=40-r()*240,t=r();if(t<.3)w.prop('lollipop',[x,0,z],0,{color:['#ff4f9a','#3bd1ff','#a45be8','#ffd23a'][i%4]});else if(t<.55)w.prop('candycane',[x,0,z],0,{});else if(t<.8)w.prop('lollitree',[x,0,z],0,{});else w.prop('gumdrop',[x,0,z],0,{color:['#ff8fb3','#8fd2ff','#b8ff9f','#ffe14a'][i%4]})}
  w.prop('cake',[-24,0,0],0,{});w.prop('donut',[24,0,-6],0,{});w.prop('icecream',[0,0,-80],0,{});B.mountains(w,{z:-330});w.clouds(14);w.extent=70;w.setSpawn('candy',[0,0,40],Math.PI)};
B.graveyard=(w,o={})=>{const r=w.r;ground(w,'#33513b');w.box([0,.05,-40],[7,.08,260],'#6b6a60');
  for(let i=0;i<40;i++)w.prop('gravestone',[(r()<.5?-1:1)*(8+r()*50),0,30-r()*180],(r()-.5)*.4,{});
  for(let i=0;i<10;i++)w.prop('deadtree',[(r()<.5?-1:1)*(14+r()*60),0,25-r()*170],r()*6,{s:1+r()});
  w.fence(-30,40,30,40,'#2b2f3a');w.prop('moon',[-50,120,-300],0,{});w.extent=60;w.setSpawn('gate',[0,0,40],Math.PI)};
B.underwater=(w,o={})=>{const r=w.r;ground(w,'#e8d28a');
  for(let i=0;i<50;i++)w.prop('coral',[(r()-.5)*160,0,30-r()*200],r()*6,{color:['#ff6f8f','#ffa03a','#a45be8','#ff4fd8'][i%4],collide:false});
  for(let i=0;i<12;i++)w.prop('rock',[(r()-.5)*160,0,30-r()*200],r()*6,{s:1+r()*2,color:'#6b7a8a'});
  w.prop('treasure',[8,0,10],.3,{});w.extent=50;w.setSpawn('sea',[0,0,35],Math.PI)};
B.rooftop=(w,o={})=>{const r=w.r;w.box([0,-1,0],[60,2,50],'#9aa0ad');w.box([0,.3,24],[60,1.2,1],'#cfd4de');w.box([-30,.3,0],[1,1.2,50],'#cfd4de');w.box([30,.3,0],[1,1.2,50],'#cfd4de');
  for(let i=0;i<46;i++){const a=r()*PI*2,d=60+r()*260,h=30+r()*150;w.box([Math.cos(a)*d,h/2-60,Math.sin(a)*d-40],[18+r()*22,h+120,18+r()*22],['#f7c6d9','#bfe3ff','#ffe58a','#c9f0c4','#d7c6f7'][i%5])}
  w.box([-14,3,-14],[8,6,8],'#d6dbe4');w.cyl([16,4,-10],[.6,8,.6],'#ccc');w.prop('billboard',[0,6,-24],0,{});w.clouds(14,[40,140],500);w.extent=40;w.setSpawn('roof',[0,0,12],Math.PI)};
B.cave=(w,o={})=>{const r=w.r;w.ground('#3a3550',500);w.box([0,30,-100],[200,60,2],'#2a2540');w.box([-50,30,0],[2,60,240],'#2a2540');w.box([50,30,0],[2,60,240],'#2a2540');w.box([0,60,-40],[200,2,300],'#221e36');
  for(let i=0;i<30;i++)w.prop('stalagmite',[(r()-.5)*90,0,30-r()*120],r()*6,{s:1+r()*1.6});
  for(let i=0;i<12;i++)w.prop('crystal',[(r()-.5)*80,0,20-r()*100],r()*6,{color:['#5ad8ff','#a45be8','#ff4fd8','#6bd86b'][i%4],s:1});
  w.extent=45;w.setSpawn('cave',[0,0,35],Math.PI)};

/* ---------- interiors (reuse the room shell) ---------- */
B.interior=(w,o={})=>{const W=o.w||34,D=o.d||30,kind=o.kind||'hospital';
  const base={hospital:{floor:'#e8eef4',wall:'#dff0f6'},bathroom:{floor:'#bfe3ff',wall:'#e8f6ff'},restaurant:{floor:'#a87a4a',wall:'#f2c9a0'},gym:{floor:'#3a3f4a',wall:'#e0e4ec'},library:{floor:'#8a5a2a',wall:'#d9c29a'},bakery:{floor:'#f2e2c2',wall:'#ffd9e6'},throne:{floor:'#7a1f2a',wall:'#c9ccd6'},garage:{floor:'#6b6f7a',wall:'#c8ccd6'},studio:{floor:'#2b2f3a',wall:'#3a2a5a'},bank:{floor:'#e8e0d0',wall:'#f2ead6'},shop:{floor:'#f2f2f2',wall:'#ffe58a'}}[kind]||{floor:'#c89a62',wall:'#f2dcc0'};
  B.room(w,Object.assign({},base,o,{kind:'custom'}));
  const g=(n,x,z,yaw,op)=>w.prop(n,[x,0,z],yaw||0,op||{});
  if(kind==='hospital'){g('bed',-8,-D/2+5,0,{color:'#fff'});g('bed',8,-D/2+5,0,{color:'#fff'});g('stool',-14,-4);w.box([0,10,-D/2+.5],[6,3,.2],'#fff');w.box([0,10,-D/2+.55],[1.6,.4,.1],'#e83030');w.box([0,10,-D/2+.55],[.4,1.6,.1],'#e83030');g('plant',W/2-3,-8)}
  if(kind==='bathroom'){g('toilet',-10,-D/2+3);g('sink',2,-D/2+3);g('bathtub',W/2-5,-6,PI/2);g('rug',-4,2,0,{r:6,color:'#a45be8'})}
  if(kind==='restaurant'){for(const [x,z] of[[-10,-4],[0,2],[10,-4],[-8,8],[8,8]]){g('table',x,z,0,{w:5,d:3,collide:[5,3,2.4]});g('chair',x-3.2,z,PI/2);g('chair',x+3.2,z,-PI/2)}g('plant',-W/2+3,-D/2+3);g('burger',-10,-4);w.box([0,2,-D/2+3],[26,4,3],'#8a5a2a')}
  if(kind==='gym'){g('barbell',-10,-6);g('dumbbell',-4,-2);g('pullupbar',10,-4);g('dumbbell',-12,4);w.box([0,6,-D/2+.4],[W-4,8,.2],'#bfe8ff',{alpha:.6})}
  if(kind==='library'){for(const x of[-12,-6,0,6,12])g('shelf',x,-D/2+2.4);g('table',0,4,0,{w:9,d:4,collide:[9,4,2.4]});g('chair',-3,8);g('chair',3,8);g('tablelamp',0,4,0,{});}
  if(kind==='bakery'){w.box([0,2,-6],[22,4,3.4],'#f7e6c8');g('cake',-6,-6);g('donut',0,-6);g('cake',6,-6);g('pizza',3,-6);g('plant',W/2-3,-D/2+3)}
  if(kind==='throne'){g('armchair',0,-D/2+4,0,{color:'#ffd23a'});w.box([0,.3,2],[6,.05,24],'#d8232c');for(const x of[-8,8]){g('statue',x,-8);g('flag',x*1.6,-D/2+2,0,{color:'#a45be8'})}}
  if(kind==='garage'){g('car',-6,-2,.4,{color:'#2f6df6'});g('shelf',W/2-3,-6,-PI/2);g('crate',-W/2+4,-D/2+4);g('hammer',W/2-6,6)}
  if(kind==='studio'){g('stage',0,-D/2+8,0,{});g('speaker',-14,-4);g('speaker',14,-4);g('microphone',0,-4);g('discoball',0,12,0,{})}
  if(kind==='bank'){w.box([0,2,-6],[26,4,2],'#8a5a2a');g('moneystack',-4,-6);g('goldpile',8,-D/2+4,0,{r:5});g('trophy',10,-6)}
  if(kind==='shop'){for(const x of[-12,-4,4,12])g('shelf',x,-D/2+2.4);g('crate',-10,4);g('giftbox',10,6)}
  w.extent=40;w.setSpawn('room',[0,0,10],PI)};
S.Worlds.extraNames=['studio','beach','desert','snow','forest','farm','playground','stadium','space','candy','graveyard','underwater','rooftop','cave','interior'];
})(window.Studio);

/* In This Town — Asset Forge
 * Builds deterministic, reusable low-poly/Roblox-style props from the engine's own primitives.
 * Blueprints are cached in localStorage so a generated prop can be reused in later stories.
 */
(function(S){
'use strict';
if(!S.Props||!S.Props.lib) throw new Error('Asset Forge requires Props to load first.');
const STORE='itt.assetforge.blueprints.v1';
const B=(off,size,color,x={})=>Object.assign({p:['box'],off,size,color},x);
const CY=(off,size,color,x={})=>Object.assign({p:['cyl',14],off,size,color},x);
const SP=(off,size,color,x={})=>Object.assign({p:['sphere',10,7],off,size,color},x);
const CO=(off,size,color,x={})=>Object.assign({p:['cone',10,false],off,size,color},x);
const PALETTES=[
  {base:'#202a3c',edge:'#78d8e8',glow:'#8fffe6',dark:'#101725',accent:'#f1c66d'},
  {base:'#30243e',edge:'#b394ff',glow:'#ff91ce',dark:'#171226',accent:'#78e8dc'},
  {base:'#263a35',edge:'#8dd4a0',glow:'#fff08a',dark:'#14221e',accent:'#78baff'},
  {base:'#403027',edge:'#f2a36f',glow:'#ffe08a',dark:'#201713',accent:'#9be3ff'},
  {base:'#24354a',edge:'#71b9ff',glow:'#a6e7ff',dark:'#101d2a',accent:'#ffd477'},
  {base:'#3e2d30',edge:'#ff8d8d',glow:'#ffd2ba',dark:'#24191e',accent:'#a7f0cc'},
  {base:'#333b24',edge:'#c3e36e',glow:'#f4ff9d',dark:'#1b2415',accent:'#ffb36e'},
  {base:'#2e3142',edge:'#a7a8ff',glow:'#d8c9ff',dark:'#171a29',accent:'#70e8d2'}
];
function hash(s){let h=2166136261;for(let i=0;i<String(s).length;i++){h^=String(s).charCodeAt(i);h=Math.imul(h,16777619)}return h>>>0}
function clone(x){return JSON.parse(JSON.stringify(x))}
function makeBlueprint(kind,variant){
  const p=PALETTES[variant%PALETTES.length],parts=[];
  const add=(...a)=>parts.push(...a);
  // Every design uses a consistent chunky silhouette, a clear focal feature and emissive detail.
  if(kind==='vision'){
    add(B([0,.55,0],[4.8,.7,2.5],p.dark),B([0,3.45,-.25],[4.2,5.6,.45],p.edge),B([0,3.45,.02],[3.35,4.7,.12],p.glow,{emis:.45,alpha:.9}),
      B([0,3.45,.11],[2.65,4.0,.08],'#a8d9ff',{emis:.22,alpha:.45}),CY([0,.95,0],[.18,.8,.18],p.accent),
      SP([-1.85,5.65,.2],[.35,.35,.2],p.accent,{emis:.8}),SP([1.85,5.65,.2],[.35,.35,.2],p.accent,{emis:.8}),
      B([0,6.55,-.2],[1.5,.35,.8],p.base),CY([0,6.95,-.2],[.12,.8,.12],p.accent));
  } else if(kind==='door'){
    add(B([0,2.8,0],[4.8,5.6,.6],p.dark),B([0,2.8,.34],[3.85,5.0,.18],p.base),B([0,2.8,.47],[.14,4.7,.06],p.edge),
      B([-1.8,2.8,.48],[.14,4.7,.06],p.edge),B([1.8,2.8,.48],[.14,4.7,.06],p.edge),
      B([2.55,2.7,.6],[.75,2.1,.45],p.edge),B([2.55,3.45,.85],[.44,.42,.08],p.glow,{emis:.9}),
      SP([2.55,2.65,.9],[.18,.18,.12],p.accent,{emis:.8}),B([0,.25,0],[5.4,.35,1.2],p.dark));
  } else if(kind==='lie'){
    add(B([0,1.1,0],[3.8,2.2,2.5],p.dark),B([0,3.2,-.2],[3.2,2.5,1.9],p.base),
      B([0,3.35,.82],[2.5,1.55,.12],p.edge),B([0,3.35,.91],[2.05,1.08,.06],p.glow,{emis:.5}),
      CY([0,5.15,-.05],[1.65,.28,1.65],p.edge,{rot:[Math.PI/2,0,0]}),CY([0,5.15,.12],[1.18,.3,1.18],p.dark,{rot:[Math.PI/2,0,0]}),
      B([0,5.15,.3],[.15,1.0,.12],p.accent,{rot:[0,0,-.55]}),SP([0,5.15,.42],[.23,.23,.16],p.glow,{emis:.9}));
  } else if(kind==='movement'){
    add(B([0,1.05,0],[5.6,.6,3.0],p.dark),B([0,1.48,0],[4.8,.28,2.4],p.edge),
      B([0,2.0,-.45],[2.6,.9,1.4],p.base),B([0,2.5,-.45],[1.9,.18,1.0],p.glow,{emis:.45}),
      ...[-2.1,2.1].flatMap(x=>[-.95,.95].map(z=>CY([x,.63,z],[.72,.48,.72],p.accent,{rot:[Math.PI/2,0,0]}))),
      SP([0,1.1,1.25],[.42,.28,.18],p.glow,{emis:.8}),B([0,.35,0],[4.3,.2,2.3],p.accent,{emis:.12}));
  } else if(kind==='speech'){
    add(B([0,.8,0],[3.6,1.6,2.2],p.dark),B([0,3.2,0],[3.2,3.0,1.9],p.base),
      B([0,5.2,0],[3.6,1.2,2.2],p.edge),
      CY([0,3.55,1.0],[1.6,.26,1.6],'#151820',{rot:[Math.PI/2,0,0]}),CY([0,3.55,1.16],[1.0,.28,1.0],p.glow,{rot:[Math.PI/2,0,0],emis:.8}),
      CY([0,5.25,1.0],[1.0,.22,1.0],'#151820',{rot:[Math.PI/2,0,0]}),CY([0,5.25,1.14],[.58,.24,.58],p.accent,{rot:[Math.PI/2,0,0],emis:.6}),
      SP([-1.25,6.35,.35],[.22,.22,.22],p.glow,{emis:1}),SP([1.25,6.35,.35],[.22,.22,.22],p.glow,{emis:1}));
  } else if(kind==='night'){
    add(B([0,1.25,0],[4.2,2.5,2.7],p.dark),B([0,3.45,-.1],[3.9,2.5,2.4],p.base),
      CY([0,3.55,1.18],[2.0,.34,2.0],p.edge,{rot:[Math.PI/2,0,0]}),CY([0,3.55,1.38],[1.55,.36,1.55],p.dark,{rot:[Math.PI/2,0,0]}),
      B([0,3.55,1.6],[.16,1.08,.1],p.glow,{emis:.8}),B([.45,3.55,1.62],[.95,.14,.1],p.accent,{emis:.65}),
      SP([0,5.35,-.2],[.9,.9,.9],p.glow,{emis:.65}),CO([0,5.35,.62],[.65,.85,.65],p.accent,{emis:.65}));
  } else if(kind==='body'){
    add(B([0,1.0,0],[5.6,2.0,2.6],p.dark),B([0,3.0,-.1],[5.0,2.0,2.2],p.base),
      B([0,4.25,-.05],[5.4,.35,2.5],p.edge),B([-1.65,2.9,1.14],[1.0,2.4,.18],p.accent),B([1.65,2.9,1.14],[1.0,2.4,.18],p.accent),
      B([0,3.25,1.25],[2.4,1.5,.08],p.glow,{emis:.35}),CY([-1.5,5.1,-.1],[.12,1.4,.12],p.glow),CY([1.5,5.1,-.1],[.12,1.4,.12],p.glow),
      SP([-1.5,5.9,-.1],[.26,.26,.26],p.accent,{emis:.75}),SP([1.5,5.9,-.1],[.26,.26,.26],p.accent,{emis:.75}));
  } else if(kind==='book'){
    add(B([0,.55,0],[4.6,1.1,3.2],p.dark),B([-.12,1.25,0],[3.9,.32,2.8],p.edge),
      B([0,2.6,0],[3.65,2.55,2.65],p.base),B([0,2.6,1.35],[3.38,2.22,.10],'#f1e6c8'),
      B([-.08,2.6,1.42],[.12,1.85,.06],p.accent),B([0,4.0,0],[3.9,.24,2.8],p.edge),
      B([0,2.55,1.52],[1.2,.22,.08],p.glow,{emis:.6}),SP([1.35,3.65,1.52],[.2,.2,.12],p.accent,{emis:.7}));
  } else if(kind==='robot'){
    add(B([0,.55,0],[3.7,1.1,2.8],p.dark),B([0,2.25,0],[2.55,2.4,2.0],p.edge),
      B([0,4.25,.12],[2.8,1.75,2.05],p.base),B([0,4.3,1.18],[2.1,.82,.12],p.dark),
      SP([-.62,4.35,1.3],[.28,.28,.16],p.glow,{emis:1}),SP([.62,4.35,1.3],[.28,.28,.16],p.glow,{emis:1}),
      CY([-1.75,2.25,0],[.42,.65,.42],p.accent),CY([1.75,2.25,0],[.42,.65,.42],p.accent),
      B([-1.15,.0,0],[.55,1.5,.65],p.base),B([1.15,.0,0],[.55,1.5,.65],p.base),
      CY([0,5.45,0],[.12,.75,.12],p.accent),SP([0,5.9,0],[.28,.28,.28],p.glow,{emis:.9}));
  } else if(kind==='puppet'){
    add(B([0,.55,0],[4.4,1.1,2.8],p.dark),B([0,2.15,0],[1.6,1.9,1.2],p.base),
      SP([0,3.75,.05],[1.12,1.12,.95],p.edge),B([0,3.8,.88],[1.3,.36,.12],p.dark),
      SP([-.42,4.0,.95],[.16,.18,.12],p.glow,{emis:.75}),SP([.42,4.0,.95],[.16,.18,.12],p.glow,{emis:.75}),
      CY([-1.25,2.1,0],[.22,1.4,.22],p.accent),CY([1.25,2.1,0],[.22,1.4,.22],p.accent),
      SP([-1.3,1.25,0],[.32,.32,.32],p.edge),SP([1.3,1.25,0],[.32,.32,.32],p.edge),
      B([-1.2,.15,0],[.35,.4,.4],p.dark),B([1.2,.15,0],[.35,.4,.4],p.dark));
  } else if(kind==='chair'){
    add(B([0,1.7,-.75],[3.5,.38,2.5],p.edge),B([0,3.55,-1.7],[3.5,3.5,.45],p.base),
      B([-1.45,2.8,-.72],[.42,2.2,2.35],p.dark),B([1.45,2.8,-.72],[.42,2.2,2.35],p.dark),
      CY([-1.45,.65,-.72],[.55,.32,.55],p.accent,{rot:[Math.PI/2,0,0]}),CY([1.45,.65,-.72],[.55,.32,.55],p.accent,{rot:[Math.PI/2,0,0]}),
      CY([-1.45,.65,.62],[.55,.32,.55],p.accent,{rot:[Math.PI/2,0,0]}),CY([1.45,.65,.62],[.55,.32,.55],p.accent,{rot:[Math.PI/2,0,0]}),
      CY([0,.58,-.05],[.22,1.1,.22],p.edge),B([0,.12,0],[3.8,.22,2.4],p.dark));
  } else {
    add(B([0,.55,0],[4.8,1.1,3.0],p.dark),CY([0,2.3,0],[1.1,2.8,1.1],p.edge),
      B([0,4.2,0],[3.4,2.1,2.3],p.base),B([0,4.25,1.2],[2.5,1.25,.12],p.glow,{emis:.55}),
      SP([0,5.65,0],[.78,.78,.78],p.accent,{emis:.5}),CO([0,6.5,0],[.72,.9,.72],p.edge),
      ...[-1.6,1.6].map(x=>SP([x,2.25,0],[.36,.36,.36],p.glow,{emis:.9})));
  }
  // Distinct reusable silhouettes: each archetype can have eight saved variations.
  if(variant===1) add(CY([0,6.9,.2],[.9,.18,.9],p.glow,{rot:[Math.PI/2,0,0],emis:.42}));
  else if(variant===2) add(B([-2.35,3.0,.2],[.3,1.8,.5],p.accent),B([2.35,3.0,.2],[.3,1.8,.5],p.accent));
  else if(variant===3) add(SP([0,7.35,0],[.42,.42,.42],p.glow,{emis:.8}));
  else if(variant===4) add(CY([-1.9,1.1,1.0],[.26,.42,.26],p.accent),CY([1.9,1.1,1.0],[.26,.42,.26],p.accent));
  else if(variant===5) add(B([0,1.1,-1.7],[1.4,.5,.5],p.edge),B([0,1.1,1.7],[1.4,.5,.5],p.edge));
  else if(variant===6) add(CO([-2.2,4.9,0],[.38,.9,.38],p.accent),CO([2.2,4.9,0],[.38,.9,.38],p.accent));
  else if(variant===7) add(SP([-2.25,5.4,.3],[.3,.3,.3],p.glow,{emis:.9}),SP([2.25,5.4,.3],[.3,.3,.3],p.glow,{emis:.9}));
  // Variant marker: small accent fins make each saved blueprint visually distinct.
  const count=2+(variant%3);
  for(let i=0;i<count;i++) add(B([-1.7+i*1.7, .34, 1.56],[.34,.18,.28],p.accent,{emis:.22}));
  return parts;
}
function ensure(kind,seed=1){
  kind=/^(vision|door|lie|movement|speech|night|body|book|robot|puppet|chair)$/.test(kind)?kind:'general';
  const variant=hash(kind+':'+String(seed))%8;
  const id=`forge_${kind}_${variant}`;
  let saved=null;
  try{saved=JSON.parse(localStorage.getItem(STORE)||'{}')[id]||null;}catch{}
  const parts=saved&&Array.isArray(saved.parts)?saved.parts:makeBlueprint(kind,variant);
  S.Props.lib[id]=()=>clone(parts);
  if(!saved){
    try{const db=JSON.parse(localStorage.getItem(STORE)||'{}');db[id]={kind,variant,parts,createdAt:new Date().toISOString()};localStorage.setItem(STORE,JSON.stringify(db));}catch{}
  }
  return {id,kind,variant,reused:!!saved,partCount:parts.length};
}
function inventory(){try{return Object.values(JSON.parse(localStorage.getItem(STORE)||'{}')).filter(x=>x&&Array.isArray(x.parts)).length;}catch{return 0}}
S.AssetForge={ensure,inventory,makeBlueprint};
})(window.Studio);

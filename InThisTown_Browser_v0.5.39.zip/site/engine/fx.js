/* engine/fx.js — deterministic particle bursts, text sprites, screen overlays */
(function(S){
const {V,M,hex,lerp,clamp,rng,mix}=S;
function softTex(R){return R.canvasTex('soft',(g,w,h)=>{const gr=g.createRadialGradient(w/2,h/2,0,w/2,h/2,w/2);gr.addColorStop(0,'rgba(255,255,255,1)');gr.addColorStop(.45,'rgba(255,255,255,.7)');gr.addColorStop(1,'rgba(255,255,255,0)');g.fillStyle=gr;g.fillRect(0,0,w,h)},128,128,false)}
function starTex(R){return R.canvasTex('star',(g,w,h)=>{g.translate(w/2,h/2);g.fillStyle='#fff';g.beginPath();for(let k=0;k<8;k++){const a=k*Math.PI/4,r=k%2?w*.1:w*.48;g.lineTo(Math.cos(a)*r,Math.sin(a)*r)}g.closePath();g.fill()},128,128,false)}
function ringTex(R){return R.canvasTex('ring',(g,w,h)=>{g.strokeStyle='#fff';g.lineWidth=w*.07;g.beginPath();g.arc(w/2,h/2,w*.42,0,7);g.stroke()},128,128,false)}
function textTex(R,text,o={}){const key='txt|'+text+'|'+(o.color||'#fff')+'|'+(o.stroke||'#000')+'|'+(o.bg||'')+'|'+(o.font||'');
  return R.canvasTex(key,(g,w,h)=>{g.clearRect(0,0,w,h);const fs=o.fs||150;g.font=`900 ${fs}px "Poppins","Arial Black",sans-serif`;g.textAlign='center';g.textBaseline='middle';
    let m=g.measureText(text).width;let f=fs;if(m>w*.92){f=fs*w*.92/m;g.font=`900 ${f}px "Poppins","Arial Black",sans-serif`}
    if(o.bg){g.fillStyle=o.bg;const r=h*.12;g.beginPath();g.roundRect(8,8,w-16,h-16,r);g.fill()}
    g.lineJoin='round';g.lineWidth=f*.16;g.strokeStyle=o.stroke||'#000';if(!o.bg)g.strokeText(text,w/2,h/2+f*.04);g.fillStyle=o.color||'#fff';g.fillText(text,w/2,h/2+f*.04)},o.w||512,o.h||256,true)}
function signTex(R,s){const key='sign|'+s.text+'|'+s.bg+'|'+s.color;return R.canvasTex(key,(g,w,h)=>{g.fillStyle=s.bg;g.fillRect(0,0,w,h);g.strokeStyle='rgba(255,255,255,.85)';g.lineWidth=10;g.strokeRect(10,10,w-20,h-20);
  let f=h*.55;g.font=`900 ${f}px "Poppins","Arial Black",sans-serif`;g.textAlign='center';g.textBaseline='middle';const m=g.measureText(s.text).width;if(m>w*.85){f*=w*.85/m;g.font=`900 ${f}px "Poppins","Arial Black",sans-serif`}
  g.fillStyle=s.color;g.fillText(s.text,w/2,h/2+f*.04)},512,Math.max(64,Math.round(512*s.size[1]/s.size[0])),true)}

const PAL={confetti:['#ff4f6e','#ffd23a','#3bd1ff','#6bd86b','#a45be8','#ff8a3d']};
function P(o){return Object.assign({t0:0,life:1,p0:[0,0,0],v:[0,0,0],g:0,s0:1,s1:1,c0:'#fff',c1:null,shape:'quad',tex:'soft',emis:0,a0:1,a1:0,rot:0,rotv:0,additive:false,size3:null,grav:0},o)}
const GEN={
  poof(a,r){const n=a.n||14,c=a.color||'#ffffff',o=[];for(let i=0;i<n;i++){const th=r()*6.28,sp=3+r()*5;o.push(P({life:.7+r()*.4,v:[Math.cos(th)*sp,1+r()*4,Math.sin(th)*sp],g:-4,s0:1.2,s1:3.6+r()*2,c0:c,c1:'#bfc4d0',a0:.95,a1:0,emis:.2,tex:'soft'}))}return o},
  sparkle(a,r){const n=a.n||18,o=[];const cs=a.colors||['#fff6a8','#ffe14a','#ffffff'];for(let i=0;i<n;i++){const th=r()*6.28,sp=3+r()*8,up=(r()-.2)*7;o.push(P({life:.6+r()*.7,v:[Math.cos(th)*sp,up,Math.sin(th)*sp],g:-6,s0:1.4,s1:.2,c0:cs[i%cs.length],a0:1,a1:0,emis:1,tex:'star',additive:true,rotv:(r()-.5)*8}))}return o},
  teleport(a,r){const col=a.color||'#5ad8ff',o=[];o.push(P({life:.55,s0:1,s1:11,c0:col,shape:'ringflat',tex:'ring',emis:1,a0:1,a1:0,additive:true}));o.push(P({life:.4,s0:3,s1:5,c0:'#ffffff',shape:'cube',size3:[1.6,26,1.6],emis:1,a0:.9,a1:0,p0:[0,13,0]}));
    for(let i=0;i<26;i++){const th=r()*6.28,rr=.5+r()*2.2;o.push(P({life:.7+r()*.5,p0:[Math.cos(th)*rr,r()*2,Math.sin(th)*rr],v:[0,5+r()*10,0],s0:1.2,s1:.1,c0:i%2?col:'#fff',emis:1,tex:'star',additive:true,rotv:5}))}return o},
  explosion(a,r){const o=[];o.push(P({life:.4,s0:4,s1:26,c0:'#ffd36a',c1:'#ff6a1a',shape:'sphere',emis:1,a0:.95,a1:0,additive:true,p0:[0,3,0]}));o.push(P({life:.55,s0:2,s1:30,c0:'#fff',shape:'ringflat',tex:'ring',emis:1,a0:1,a1:0,additive:true}));
    for(let i=0;i<34;i++){const th=r()*6.28,el=r()*1.2,sp=8+r()*22;o.push(P({life:1+r()*.8,v:[Math.cos(th)*sp*Math.cos(el),Math.sin(el)*sp+8,Math.sin(th)*sp*Math.cos(el)],g:-28,s0:1.2+r()*1.6,s1:.8,c0:['#3a2a22','#ff7a2a','#ffd36a','#555'][i%4],shape:'cube',a0:1,a1:1,rotv:(r()-.5)*14,p0:[0,2,0]}))}
    for(let i=0;i<16;i++){const th=r()*6.28,sp=2+r()*8;o.push(P({t0:.1+r()*.2,life:1.6+r(),v:[Math.cos(th)*sp,3+r()*8,Math.sin(th)*sp],g:-1,s0:4,s1:14+r()*8,c0:'#4a4038',c1:'#8a8f98',a0:.8,a1:0,tex:'soft',p0:[0,2,0]}))}return o},
  confetti(a,r){const o=[],n=a.n||70;for(let i=0;i<n;i++){const th=r()*6.28,sp=2+r()*9;o.push(P({life:1.8+r(),p0:[(r()-.5)*(a.spread||6),r()*(a.h||2),(r()-.5)*(a.spread||6)],v:[Math.cos(th)*sp*.4,6+r()*10,Math.sin(th)*sp*.4],g:-14,s0:.45,s1:.45,c0:PAL.confetti[i%6],shape:'cube',size3:[.5,.08,.3],a0:1,a1:1,rotv:(r()-.5)*20,emis:.3}))}return o},
  coins(a,r){const o=[];for(let i=0;i<(a.n||24);i++){const th=r()*6.28,sp=3+r()*7;o.push(P({life:1.6,v:[Math.cos(th)*sp,10+r()*9,Math.sin(th)*sp],g:-30,s0:1,s1:1,c0:'#ffd23a',shape:'cube',size3:[1.1,1.1,.22],emis:.5,rotv:12+r()*8,a0:1,a1:1}))}return o},
  hearts(a,r){const o=[];for(let i=0;i<(a.n||10);i++)o.push(P({t0:i*.07,life:1.4,v:[(r()-.5)*4,4+r()*3,(r()-.5)*2],s0:1.2,s1:2.2,c0:'#ff4f7e',emis:.8,tex:'star',a0:1,a1:0,p0:[(r()-.5)*2,0,0]}));return o},
  smoke(a,r){const o=[];for(let i=0;i<(a.n||20);i++)o.push(P({t0:i*(a.dur||1)/(a.n||20),life:1.8,v:[(r()-.5)*2,4+r()*3,(r()-.5)*2],s0:2,s1:9,c0:a.color||'#6b6b72',a0:.7,a1:0,tex:'soft'}));return o},
  impact(a,r){const o=[];o.push(P({life:.3,s0:1,s1:9,c0:'#fff',shape:'ringflat',tex:'ring',emis:1,a0:1,a1:0,additive:true,p0:[0,3,0]}));for(let i=0;i<10;i++){const th=r()*6.28,sp=8+r()*10;o.push(P({life:.4,v:[Math.cos(th)*sp,(r()-.2)*10,Math.sin(th)*sp],s0:1.6,s1:.2,c0:'#fff3a0',tex:'star',emis:1,additive:true,p0:[0,3,0],rotv:6}))}return o},
  rain(a,r){const o=[],n=a.n||200,dur=a.dur||4;for(let i=0;i<n;i++)o.push(P({follow:true,loop:true,t0:0,life:.55,ph:r(),p0:[(r()-.5)*90,0,(r()-.5)*90-10],v:[0,-70,0],s0:1,s1:1,c0:a.color||'#cfe2ff',shape:'cube',size3:[.07,2.4,.07],a0:.8,a1:.8,y0:35+r()*10}));return o},
  snow(a,r){const o=[],n=a.n||200;for(let i=0;i<n;i++)o.push(P({follow:true,loop:true,life:3,ph:r(),p0:[(r()-.5)*90,0,(r()-.5)*90-10],v:[(r()-.5)*2,-10,0],s0:.4,s1:.4,c0:'#fff',a0:1,a1:1,y0:35,tex:'soft',emis:.8}));return o},
  dust(a,r){const o=[],n=a.n||60;for(let i=0;i<n;i++)o.push(P({follow:true,loop:true,life:5,ph:r(),p0:[(r()-.5)*50,0,(r()-.5)*50-5],v:[(r()-.5)*1.2,.4,0],s0:.25,s1:.25,c0:'#fff',a0:.7,a1:.7,y0:2+r()*14,tex:'soft',emis:.9,yfix:true}));return o},
  speed(a,r){const o=[];for(let i=0;i<(a.n||24);i++){const th=r()*6.28;o.push(P({life:.35,t0:r()*.2,p0:[Math.cos(th)*8,r()*10,(r()-.5)*10],v:[0,0,30],s0:1,s1:1,c0:'#fff',shape:'cube',size3:[.12,.12,5],a0:.7,a1:0,emis:1}))}return o},
};
S.Fx={GEN,softTex,starTex,ringTex,textTex,signTex,make(kind,args,seed){const g=GEN[kind];if(!g)throw new Error('Unknown fx: '+kind+' (have '+Object.keys(GEN).join(', ')+')');return g(args||{},rng(seed|0))}};
})(window.Studio);

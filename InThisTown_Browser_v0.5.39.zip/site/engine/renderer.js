/* engine/renderer.js — WebGL2 renderer: lit/fogged meshes, shadow map, procedural sky, overlays */
(function(S){
const {V,M}=S;
const VS=`#version 300 es
layout(location=0) in vec3 aP; layout(location=1) in vec3 aN; layout(location=2) in vec2 aUV; layout(location=3) in vec3 aC; layout(location=4) in float aE;
uniform mat4 uVP,uModel,uLVP; uniform vec3 uSize;
out vec3 vN; out vec3 vW; out vec2 vUV; out vec3 vC; out float vE; out vec4 vL;
void main(){vec4 w=uModel*vec4(aP*uSize,1.);vW=w.xyz;vN=normalize(mat3(uModel)*(aN/uSize));vUV=aUV;vC=aC;vE=aE;vL=uLVP*w;gl_Position=uVP*w;}`;
const FS=`#version 300 es
precision highp float;
in vec3 vN; in vec3 vW; in vec2 vUV; in vec3 vC; in float vE; in vec4 vL;
uniform sampler2D uShadow; uniform sampler2D uTex;
uniform vec3 uSunDir,uSunCol,uAmbSky,uAmbGnd,uFogCol,uCam,uTint; uniform vec4 uColor,uUV;
uniform float uFogNear,uFogFar,uFogOn,uEmis,uSat,uExpo,uShadowOn,uTexel,uUseTex,uShadowStr,uLit,uAO,uRim,uTone,uSoft;
out vec4 o;
float shadow(vec3 n){vec3 p=vL.xyz/vL.w*.5+.5;if(p.z>1.||p.x<0.||p.x>1.||p.y<0.||p.y>1.)return 1.;
 float bias=max(0.0022*(1.-max(dot(n,uSunDir),0.)),0.0007);float s=0.;
 for(int x=-1;x<=1;x++)for(int y=-1;y<=1;y++){float d=texture(uShadow,p.xy+vec2(float(x),float(y))*uTexel*uSoft).r;s+=(p.z-bias>d)?0.:1.;}
 return mix(1.,s/9.,uShadowStr);}
void main(){
 vec3 n=normalize(vN);if(!gl_FrontFacing&&uUseTex<.5)n=-n;
 vec4 base=vec4(vC,1.)*uColor;float a=base.a;
 if(uUseTex>.5){vec4 t=texture(uTex,vUV*uUV.zw+uUV.xy);base.rgb=t.rgb*uColor.rgb;a=t.a*uColor.a;if(a<.03)discard;}
 float diff=max(dot(n,uSunDir),0.);float sh=uShadowOn>.5?shadow(n):1.;
 vec3 amb=mix(uAmbGnd,uAmbSky,n.y*.5+.5);
 vec3 lit=amb+uSunCol*diff*sh;
 vec3 col=mix(base.rgb*lit,base.rgb*uLit,0.);
 // v2 quality: contact darkening on vertical faces near the ground + soft rim light (grounded, less flat look)
 float vert=1.-smoothstep(.45,.9,n.y);col*=1.-uAO*vert*(1.-smoothstep(0.,2.8,vW.y));
 vec3 Vd=normalize(uCam-vW);float fr=pow(1.-max(dot(n,Vd),0.),3.);col+=uRim*fr*uAmbSky*.7*(.4+.6*sh);
 float em=clamp(uEmis+vE,0.,1.);col=mix(col,base.rgb*1.35,em);
 if(uLit<0.){col=base.rgb;}
 float d=length(vW-uCam);float f=smoothstep(uFogNear,uFogFar,d)*uFogOn;col=mix(col,uFogCol,f);
 col*=uExpo;if(uTone>0.)col=mix(col,col*(1.+col/2.4)/(1.+col),uTone);float g=dot(col,vec3(.299,.587,.114));col=mix(vec3(g),col,uSat)*uTint;
 o=vec4(col,a);}`;
const SHVS=`#version 300 es
layout(location=0) in vec3 aP; uniform mat4 uLVP,uModel; uniform vec3 uSize; void main(){gl_Position=uLVP*uModel*vec4(aP*uSize,1.);}`;
const SHFS=`#version 300 es
precision lowp float; out vec4 o; void main(){o=vec4(1.);}`;
const SKVS=`#version 300 es
out vec2 vP; void main(){vec2 p=vec2(float((gl_VertexID<<1)&2),float(gl_VertexID&2));vP=p*2.-1.;gl_Position=vec4(vP,.9999,1.);}`;
const SKFS=`#version 300 es
precision highp float; in vec2 vP; uniform mat4 uInvVP; uniform vec3 uCam,uTop,uHor,uSunDir,uSunDisk,uMoonDir; uniform float uStars,uSunSize,uTime;
out vec4 o;
float h3(vec3 p){p=fract(p*.3183099+.1);p*=17.;return fract(p.x*p.y*p.z*(p.x+p.y+p.z));}
void main(){vec4 w=uInvVP*vec4(vP,1.,1.);vec3 d=normalize(w.xyz/w.w-uCam);
 float t=clamp(d.y*1.5,0.,1.);vec3 c=mix(uHor,uTop,pow(t,.55));
 float sd=max(dot(d,uSunDir),0.);c+=uSunDisk*(pow(sd,900.)*3.*uSunSize+pow(sd,10.)*.18);
 if(uStars>0.&&d.y>0.02){vec3 q=floor(d*260.);float s=h3(q);if(s>.9965){float tw=.6+.4*sin(uTime*3.+s*80.);c+=vec3(tw)*uStars;}}
 if(uStars>0.){float m=dot(d,uMoonDir);if(m>.9985)c=mix(c,vec3(1.,.98,.9),1.);else if(m>.995)c+=vec3(.25,.28,.4)*(m-.995)*80.*.0+vec3(.05);}
 if(d.y<0.)c=mix(uHor,uHor*.9,clamp(-d.y*3.,0.,1.));
 o=vec4(c,1.);}`;
const OVVS=`#version 300 es
layout(location=0) in vec3 aP; layout(location=2) in vec2 aUV; uniform vec4 uRect; uniform float uRot; out vec2 vUV;
void main(){vUV=aUV;vec2 p=aP.xy;float c=cos(uRot),s=sin(uRot);p=vec2(c*p.x-s*p.y,s*p.x+c*p.y);gl_Position=vec4(uRect.xy+p*uRect.zw,0.,1.);}`;
const OVFS=`#version 300 es
precision mediump float; in vec2 vUV; uniform sampler2D uTex; uniform float uUseTex; uniform vec4 uColor; out vec4 o;
void main(){vec4 c=uColor;if(uUseTex>.5){vec4 t=texture(uTex,vUV);c=vec4(t.rgb*uColor.rgb,t.a*uColor.a);}o=c;}`;

class Renderer{
  constructor(canvas,W,H,opts){opts=opts||{};
    this.canvas=canvas;this.W=W;this.H=H;canvas.width=W;canvas.height=H;
    const gl=this.gl=canvas.getContext('webgl2',{antialias:true,preserveDrawingBuffer:true,alpha:false,powerPreference:'high-performance'});
    if(!gl)throw new Error('WebGL2 unavailable');
    this.main=this.prog(VS,FS);this.shad=this.prog(SHVS,SHFS);this.sky=this.prog(SKVS,SKFS);this.ov=this.prog(OVVS,OVFS);
    this.SM=opts.SM||2048;this.initShadow();this.texCache=new Map();
    this.white=this.makeTex(1,1,new Uint8Array([255,255,255,255]));
    this.quadMesh=this.uploadPrim(S.prim('quad'));this.vaoSky=gl.createVertexArray();
  }
  prog(vs,fs){const gl=this.gl;const mk=(t,s)=>{const x=gl.createShader(t);gl.shaderSource(x,s);gl.compileShader(x);if(!gl.getShaderParameter(x,gl.COMPILE_STATUS))throw new Error(gl.getShaderInfoLog(x));return x};
    const p=gl.createProgram();gl.attachShader(p,mk(gl.VERTEX_SHADER,vs));gl.attachShader(p,mk(gl.FRAGMENT_SHADER,fs));gl.linkProgram(p);
    if(!gl.getProgramParameter(p,gl.LINK_STATUS))throw new Error(gl.getProgramInfoLog(p));
    const u={};const n=gl.getProgramParameter(p,gl.ACTIVE_UNIFORMS);for(let i=0;i<n;i++){const inf=gl.getActiveUniform(p,i);u[inf.name]=gl.getUniformLocation(p,inf.name)}return {p,u}}
  initShadow(){const gl=this.gl,s=this.SM;this.shTex=gl.createTexture();gl.bindTexture(gl.TEXTURE_2D,this.shTex);
    gl.texImage2D(gl.TEXTURE_2D,0,gl.DEPTH_COMPONENT24,s,s,0,gl.DEPTH_COMPONENT,gl.UNSIGNED_INT,null);
    gl.texParameteri(gl.TEXTURE_2D,gl.TEXTURE_MIN_FILTER,gl.NEAREST);gl.texParameteri(gl.TEXTURE_2D,gl.TEXTURE_MAG_FILTER,gl.NEAREST);
    gl.texParameteri(gl.TEXTURE_2D,gl.TEXTURE_WRAP_S,gl.CLAMP_TO_EDGE);gl.texParameteri(gl.TEXTURE_2D,gl.TEXTURE_WRAP_T,gl.CLAMP_TO_EDGE);
    this.shFbo=gl.createFramebuffer();gl.bindFramebuffer(gl.FRAMEBUFFER,this.shFbo);gl.framebufferTexture2D(gl.FRAMEBUFFER,gl.DEPTH_ATTACHMENT,gl.TEXTURE_2D,this.shTex,0);
    gl.drawBuffers([gl.NONE]);gl.readBuffer(gl.NONE);gl.bindFramebuffer(gl.FRAMEBUFFER,null)}
  makeTex(w,h,data,mip=false){const gl=this.gl,t=gl.createTexture();gl.bindTexture(gl.TEXTURE_2D,t);
    if(data instanceof HTMLCanvasElement||data instanceof ImageBitmap){gl.pixelStorei(gl.UNPACK_FLIP_Y_WEBGL,true);gl.texImage2D(gl.TEXTURE_2D,0,gl.RGBA,gl.RGBA,gl.UNSIGNED_BYTE,data);gl.pixelStorei(gl.UNPACK_FLIP_Y_WEBGL,false)}
    else gl.texImage2D(gl.TEXTURE_2D,0,gl.RGBA,w,h,0,gl.RGBA,gl.UNSIGNED_BYTE,data);
    if(mip){gl.generateMipmap(gl.TEXTURE_2D);gl.texParameteri(gl.TEXTURE_2D,gl.TEXTURE_MIN_FILTER,gl.LINEAR_MIPMAP_LINEAR)}else gl.texParameteri(gl.TEXTURE_2D,gl.TEXTURE_MIN_FILTER,gl.LINEAR);
    gl.texParameteri(gl.TEXTURE_2D,gl.TEXTURE_MAG_FILTER,gl.LINEAR);gl.texParameteri(gl.TEXTURE_2D,gl.TEXTURE_WRAP_S,gl.CLAMP_TO_EDGE);gl.texParameteri(gl.TEXTURE_2D,gl.TEXTURE_WRAP_T,gl.CLAMP_TO_EDGE);return t}
  canvasTex(key,drawFn,w=256,h=256,mip=true){let t=this.texCache.get(key);if(t)return t;const c=document.createElement('canvas');c.width=w;c.height=h;drawFn(c.getContext('2d'),w,h);t=this.makeTex(w,h,c,mip);this.texCache.set(key,t);return t}
  _upload(f32,count){const gl=this.gl,vao=gl.createVertexArray();gl.bindVertexArray(vao);const b=gl.createBuffer();gl.bindBuffer(gl.ARRAY_BUFFER,b);gl.bufferData(gl.ARRAY_BUFFER,f32,gl.STATIC_DRAW);
    const st=48;gl.enableVertexAttribArray(0);gl.vertexAttribPointer(0,3,gl.FLOAT,false,st,0);gl.enableVertexAttribArray(1);gl.vertexAttribPointer(1,3,gl.FLOAT,false,st,12);
    gl.enableVertexAttribArray(2);gl.vertexAttribPointer(2,2,gl.FLOAT,false,st,24);gl.enableVertexAttribArray(3);gl.vertexAttribPointer(3,3,gl.FLOAT,false,st,32);gl.enableVertexAttribArray(4);gl.vertexAttribPointer(4,1,gl.FLOAT,false,st,44);
    gl.bindVertexArray(null);return {vao,count,buf:b}}
  uploadBatch(b){return this._upload(new Float32Array(b.d),b.n)}
  uploadPrim(g){const b=new S.Batch();b.add(g,null,[1,1,1],[1,1,1],0);return this.uploadBatch(b)}
  primMesh(name,...a){const k='pm:'+name+a.join(',');if(!this._pm)this._pm={};return this._pm[k]||(this._pm[k]=this.uploadPrim(S.prim(name,...a)))}
  free(mesh){if(!mesh)return;const gl=this.gl;gl.deleteBuffer(mesh.buf);gl.deleteVertexArray(mesh.vao)}
  setCommon(P,F){const gl=this.gl,u=P.u,e=F.env;
    gl.uniform3fv(u.uSunDir,e.sunDir);gl.uniform3fv(u.uSunCol,e.sunCol);gl.uniform3fv(u.uAmbSky,e.ambSky);gl.uniform3fv(u.uAmbGnd,e.ambGnd);
    gl.uniform3fv(u.uFogCol,e.fogCol);gl.uniform1f(u.uFogNear,e.fogNear);gl.uniform1f(u.uFogFar,e.fogFar);gl.uniform3fv(u.uCam,F.camPos);
    gl.uniform1f(u.uSat,e.sat);gl.uniform1f(u.uExpo,e.expo);gl.uniform3fv(u.uTint,e.tint||[1,1,1]);gl.uniform1f(u.uTexel,1/this.SM);gl.uniform1f(u.uShadowStr,e.shadowStr);gl.uniform1f(u.uAO,e.ao===undefined?.2:e.ao);gl.uniform1f(u.uRim,e.rim===undefined?.16:e.rim);gl.uniform1f(u.uTone,e.tone||0);gl.uniform1f(u.uSoft,e.soft===undefined?1.5:e.soft);
    gl.uniformMatrix4fv(u.uVP,false,F.vp);gl.uniformMatrix4fv(u.uLVP,false,F.lvp);gl.uniform1i(u.uShadow,1);gl.uniform1i(u.uTex,0)}
  drawItem(P,it,shadowPass){const gl=this.gl,u=P.u;
    gl.uniformMatrix4fv(u.uModel,false,it.model||this._I||(this._I=M.ident()));
    const s=it.size||[1,1,1];gl.uniform3f(u.uSize,s[0],s[1],s[2]);
    if(!shadowPass){const c=it.color||[1,1,1];gl.uniform4f(u.uColor,c[0],c[1],c[2],it.alpha===undefined?1:it.alpha);gl.uniform1f(u.uEmis,it.emis||0);
      gl.uniform1f(u.uUseTex,it.tex?1:0);if(it.tex){gl.activeTexture(gl.TEXTURE0);gl.bindTexture(gl.TEXTURE_2D,it.tex);const uv=it.uv||[0,0,1,1];gl.uniform4f(u.uUV,uv[0],uv[1],uv[2],uv[3])}
      gl.uniform1f(u.uFogOn,it.nofog?0:1);gl.uniform1f(u.uLit,it.unlit?-1:1)}
    gl.bindVertexArray(it.mesh.vao);gl.drawArrays(gl.TRIANGLES,0,it.mesh.count)}
  render(F){
    const gl=this.gl,e=F.env;
    // --- shadow pass
    if(e.shadows){gl.bindFramebuffer(gl.FRAMEBUFFER,this.shFbo);gl.viewport(0,0,this.SM,this.SM);gl.clear(gl.DEPTH_BUFFER_BIT);
      gl.enable(gl.DEPTH_TEST);gl.depthMask(true);gl.disable(gl.BLEND);gl.enable(gl.CULL_FACE);gl.cullFace(gl.FRONT);gl.colorMask(false,false,false,false);
      gl.useProgram(this.shad.p);gl.uniformMatrix4fv(this.shad.u.uLVP,false,F.lvp);
      for(const m of F.statics)if(!m.noShadow)this.drawItem(this.shad,{mesh:m},true);
      for(const it of F.dyn)if(!it.noShadow&&!it.tex&&(it.alpha===undefined||it.alpha>.5))this.drawItem(this.shad,it,true);
      gl.colorMask(true,true,true,true);gl.cullFace(gl.BACK)}
    // --- main
    gl.bindFramebuffer(gl.FRAMEBUFFER,null);gl.viewport(0,0,this.W,this.H);gl.clearColor(...e.fogCol,1);gl.clear(gl.COLOR_BUFFER_BIT|gl.DEPTH_BUFFER_BIT);
    gl.disable(gl.CULL_FACE);gl.enable(gl.DEPTH_TEST);gl.depthMask(false);gl.disable(gl.BLEND);
    // sky
    gl.useProgram(this.sky.p);const su=this.sky.u;gl.uniformMatrix4fv(su.uInvVP,false,M.inv(F.vp));gl.uniform3fv(su.uCam,F.camPos);gl.uniform3fv(su.uTop,e.skyTop);gl.uniform3fv(su.uHor,e.skyHor);
    gl.uniform3fv(su.uSunDir,e.sunDir);gl.uniform3fv(su.uSunDisk,e.sunDisk||[1,.95,.8]);gl.uniform3fv(su.uMoonDir,e.moonDir||[0,-1,0]);gl.uniform1f(su.uStars,e.stars||0);gl.uniform1f(su.uSunSize,e.sunSize===undefined?1:e.sunSize);gl.uniform1f(su.uTime,F.time);
    gl.bindVertexArray(this.vaoSky);gl.drawArrays(gl.TRIANGLES,0,3);
    gl.depthMask(true);gl.useProgram(this.main.p);this.setCommon(this.main,F);
    gl.activeTexture(gl.TEXTURE1);gl.bindTexture(gl.TEXTURE_2D,this.shTex);gl.activeTexture(gl.TEXTURE0);gl.bindTexture(gl.TEXTURE_2D,this.white);
    gl.uniform1f(this.main.u.uShadowOn,e.shadows?1:0);
    const opaque=[],trans=[];for(const it of F.dyn)((it.alpha!==undefined&&it.alpha<.999)||it.tex?trans:opaque).push(it);
    gl.enable(gl.BLEND);gl.blendFunc(gl.SRC_ALPHA,gl.ONE_MINUS_SRC_ALPHA);
    for(const m of F.statics)this.drawItem(this.main,{mesh:m,color:[1,1,1],tex:null},false);
    for(const it of opaque)this.drawItem(this.main,it,false);
    trans.sort((a,b)=>(b.dist||0)-(a.dist||0));
    for(const it of trans){gl.depthMask(!it.noDepthWrite&&!it.additive&&!it.tex);if(it.additive)gl.blendFunc(gl.SRC_ALPHA,gl.ONE);else gl.blendFunc(gl.SRC_ALPHA,gl.ONE_MINUS_SRC_ALPHA);this.drawItem(this.main,it,false)}
    gl.depthMask(true);gl.blendFunc(gl.SRC_ALPHA,gl.ONE_MINUS_SRC_ALPHA);
    // --- screen overlays
    gl.disable(gl.DEPTH_TEST);gl.useProgram(this.ov.p);const ou=this.ov.u;gl.bindVertexArray(this.quadMesh.vao);
    for(const o of F.overlays||[]){gl.uniform4f(ou.uRect,o.rect[0],o.rect[1],o.rect[2]*2,o.rect[3]*2);gl.uniform1f(ou.uRot,o.rot||0);gl.uniform4f(ou.uColor,...(o.color||[1,1,1,1]));
      gl.uniform1f(ou.uUseTex,o.tex?1:0);if(o.tex){gl.activeTexture(gl.TEXTURE0);gl.bindTexture(gl.TEXTURE_2D,o.tex);gl.uniform1i(ou.uTex,0)}
      gl.drawArrays(gl.TRIANGLES,0,this.quadMesh.count)}
    gl.enable(gl.DEPTH_TEST)}
}
S.Renderer=Renderer;
})(window.Studio);

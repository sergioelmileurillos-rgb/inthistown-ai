/* engine/assets.js — v0.5: registro de assets con etiquetas, alias y fallback con aviso. */
(function(S){
const ALIAS={window:'windowframe',door:'door',lamp:'lamp',light:'lamp',tv:'tv',television:'tv',book:'book_custom',note:'paper_custom',paper:'paper_custom',monster:'shadowbeast',zombie:'skeleton',vampire:'bat',bigfoot:'bigfoot',sasquatch:'bigfoot',goo:'slime',jelly:'slime',pumpkin:'jackolantern',doll:'cursed_doll',eye:'eyeball',octopus:'kraken',tombstone:'gravestone',grave:'gravestone',spirit:'wisp',orb:'wisp',treasurechest:'mimic',web:'spiderweb',spider:'spider_giant',rat:'rat_giant',egg:'creature_egg',lamp_old:'lantern',ghost:'ghost_big',shadow:'shadowfigure',bird:'bird',box:'crate',table:'table',chair:'chair',car:'car',pizza:'pizza',mirror:'mirror'};
const TAGS={city:['calle','ciudad'],home:['casa','hogar'],food:['comida'],nature:['naturaleza'],fantasy:['fantasía'],sport:['deporte'],story:['historia','misterio']};
function tagsFor(n){const t=[];const mt=(S.Props.monsterTags||{})[n];if(mt)return mt.slice();if(/car|bus|taxi|truck|police|ambulance|helicopter|drone|lamp|sign|traffic|hydrant|mailbox|bench|billboard|store|building|tower|skyscraper|clock/.test(n))t.push('city');
  if(/door|window|bed|couch|table|chair|desk|shelf|fridge|tv|lamp|toilet|sink|bath|stove|piano|rug|plant|mirror|curtain|clock/.test(n))t.push('home');
  if(/pizza|burger|cake|donut|icecream|steak|apple|banana|carrot|hotdog|soda|coffee|cheese|popcorn/.test(n))t.push('food');
  if(/tree|pine|bush|flower|palm|cactus|rock|boulder|hill|log|stump|mushroom|pond|mountain|cloud|sun|moon|rainbow/.test(n))t.push('nature');
  if(/dragon|castle|sword|shield|magic|crystal|portal|ghost|alien|robot|ufo|rocket|spaceship|planet|wizard/.test(n))t.push('fantasy');
  if(/ball|hoop|goal|trampoline|swing|dumbbell|barbell|skate|bike|kite|trophy|podium|stage/.test(n))t.push('sport');
  if(/shadow|note|rulebook|gravestone|ghost|stalker|missing|warning|footprint|barrier|chest|gavel|parrot/.test(n))t.push('story');
  return t.length?t:['misc']}
const A=S.Assets={
  alias:ALIAS,
  resolveProp(name){const L=S.Props.lib;if(L[name])return{name};const a=ALIAS[String(name).toLowerCase()];if(a&&L[a])return{name:a,warn:`prop "${name}" → alias "${a}"`};
    const lo=String(name).toLowerCase();const cand=Object.keys(L).find(k=>k===lo)||Object.keys(L).find(k=>k.startsWith(lo)||lo.startsWith(k));
    if(cand)return{name:cand,warn:`prop "${name}" no existe; usando "${cand}"`};return{name:'crate',warn:`prop desconocido "${name}"; usando caja de reserva`}},
  catalog(){const out=[];for(const n of Object.keys(S.Props.lib))out.push({kind:'prop',name:n,tags:tagsFor(n),stateful:(S.Props.stateful||{})[n]||null});
    for(const n of Object.keys(S.Anim.clips))out.push({kind:'anim',name:n,tags:['animación']});for(const n of Object.keys(S.Fx.GEN))out.push({kind:'fx',name:n,tags:['efecto']});
    for(const n of Object.keys(S.PRESETS))out.push({kind:'character',name:n,tags:['personaje']});for(const n of Object.keys(S.Worlds).filter(x=>typeof S.Worlds[x]==='function'))out.push({kind:'world',name:n,tags:['decorado']});
    for(const n of Object.keys(S.AccExtra||{}))out.push({kind:'accessory',name:n,tags:['accesorio']});return out}
};
})(window.Studio);

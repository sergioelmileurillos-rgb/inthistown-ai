/* engine/character_forge.js — seeded block-style character maker and local model library. */
(function(S){
  'use strict';
  const STORE='in-this-town-character-library-v1';
  const SHIRTS=['#2f6df6','#e84a4a','#32b36b','#f5a623','#a45be8','#17b7c8','#e7e8ee','#26334d','#ff75a8','#8f6a42'];
  const PANTS=['#243a73','#3b3f4a','#5a3a26','#2b6a4f','#6a4bc8','#2f6df6','#20232c'];
  const HAIR=['#1b1b22','#2a1a10','#5b3825','#d5aa43','#a6a6ae','#e7e7e7','#743d2a'];
  const HAIR_STYLES=['short','spiky','messy','long','bob','bun','afro','side'];
  const PRESET_ROLE={townie:'hero',citizen:'boy2',detective:'cop',teacher:'teacher',mayor:'mayor',robot:'robot',kid:'kid',creature:'monster'};
  function hash(v){let h=2166136261;for(const c of String(v))h=Math.imul(h^c.charCodeAt(0),16777619);return h>>>0;}
  function pick(r,a){return a[Math.floor(r()*a.length)];}
  function read(){try{const v=JSON.parse(localStorage.getItem(STORE)||'[]');return Array.isArray(v)?v:[]}catch{return[]}}
  function write(list){try{localStorage.setItem(STORE,JSON.stringify(list));return true}catch{return false}}
  function variation(base={},seed='cast'){
    const r=S.rng?S.rng(hash(seed)):(()=>{let x=hash(seed);return()=>((x=Math.imul(x^x>>>15,1|x),x^=x+Math.imul(x^x>>>7,61|x),(x^x>>>14)>>>0)/4294967296)})();
    const generated=S.randomSpec?S.randomSpec(r):{};
    const preset=base.preset||'hero';
    const spec=Object.assign({},generated,base,{preset});
    spec.shirt=pick(r,SHIRTS);spec.pants=pick(r,PANTS);spec.hair=pick(r,HAIR);spec.hairStyle=pick(r,HAIR_STYLES);
    spec.shoes=pick(r,['#f2f2f2','#20232c','#e84a4a','#d8b96a']);
    spec.scale=Number.isFinite(Number(base.scale))?Number(base.scale):(.94+r()*.12);
    if(!base.accessory&&r()<.2)spec.accessory=pick(r,['glasses','sunglasses','headphones','tie','mustache','headband']);
    return spec;
  }
  function create(name,role='townie',custom={}){
    const clean=String(name||'Nuevo personaje').trim().slice(0,32)||'Nuevo personaje';
    // Keep the old shirt-string argument compatible with saved project versions.
    if(typeof custom==='string')custom={shirt:custom};
    custom=custom&&typeof custom==='object'?custom:{};
    const preset=PRESET_ROLE[role]||'hero';const base=Object.assign({preset},S.PRESETS?.[preset]||{});
    const seed=hash(clean+'|'+role+'|'+Date.now());const spec=variation(base,seed);
    for(const key of ['shirt','pants','hair','skin','shoes'])if(/^#[0-9a-f]{6}$/i.test(String(custom[key]||'')))spec[key]=custom[key];
    if(HAIR_STYLES.includes(custom.hairStyle))spec.hairStyle=custom.hairStyle;
    if(custom.accessory==='none')delete spec.accessory;
    else if(['glasses','sunglasses','headphones','tie','mustache','headband','backpack','crown','scarf'].includes(custom.accessory))spec.accessory=[custom.accessory];
    return{id:'model-'+seed.toString(36),name:clean,role,preset,spec,createdAt:Date.now()};
  }
  function save(model){if(!model||!model.id||!model.spec)return false;const list=read().filter(x=>x.id!==model.id);list.unshift(model);return write(list.slice(0,40));}
  function list(){return read();}
  function get(id){return read().find(x=>x.id===id)||null;}
  function activeId(){try{return localStorage.getItem(STORE+':active')||''}catch{return''}}
  function setActive(id){try{if(id)localStorage.setItem(STORE+':active',id);else localStorage.removeItem(STORE+':active');return true}catch{return false}}
  function active(){return get(activeId());}
  function remove(id){const ok=write(read().filter(x=>x.id!==id));if(activeId()===id)setActive('');return ok;}
  S.CharacterForge={version:'0.5.11',variation,create,save,list,get,activeId,setActive,active,remove};
})(window.Studio);

# In This Town Browser v0.5.7

## Compatibilidad de Kokoro en Chromebook
- El cargador detecta ChromeOS, móviles y dispositivos con memoria/CPU limitada.
- En Chromebook y dispositivos limitados, Kokoro comienza con el modelo Q4 en WASM y conserva Q8 como segunda alternativa.
- Se evita intentar reservar primero el modelo FP32 en WebGPU en ChromeOS y otros equipos limitados.
- En equipos de escritorio que informan al menos 8 GB de memoria y ofrecen WebGPU, se mantiene la ruta FP32 acelerada, con alternativas WASM Q8 y Q4.
- Los errores numéricos ahora se muestran también en hexadecimal y el informe conserva la fase y los detalles internos disponibles.
- El worker integrado para copias locales y el worker externo de GitHub Pages usan la misma estrategia.

## Pruebas
- 19 pruebas automatizadas pasan.
- Se prueba la selección Q4 para ChromeOS, la ruta WebGPU para escritorio de alta memoria y los fallbacks.
- Una prueba ejecuta el worker con un fallo simulado Q4 y verifica que continúa con Q8 y llega al estado `ready`.
- Todos los archivos JavaScript pasan `node --check`.

## Límites conocidos
- Esta mejora reduce la memoria necesaria durante la carga en Chromebook, pero la exportación completa aún debe probarse en el Chromebook real.
- La primera carga necesita conexión para descargar el paquete Kokoro y el modelo desde sus distribuidores.
- La alineación de palabras sigue siendo una estimación basada en la forma de onda.
- El generador de historias sigue siendo local y basado en reglas/arquetipos.

# v0.5.20 — integración de los modelos de Claude

- Integra los tres packs procedurales de Claude: monstruos/objetos de historia, pueblo y mundo (146 modelos de utilería, criaturas, animales y elementos de mundo declarados por el paquete de origen (no son avatares humanos editables)).
- Los nuevos modelos se cargan en la aplicación principal y en la vista previa del motor.
- El catálogo de recursos los muestra con sus etiquetas de categoría.
- El Director IA recibe el catálogo real de modelos al crear el prompt y puede utilizar tipos de objeto exactos del motor.
- La validación acepta modelos registrados y comprueba que el nombre del objeto aparezca en la narración antes de mostrarlo.
- Service worker actualizado a `in-this-town-shell-v5-22`; `app.js` versionado a `0.5.20`.

## Verificación
- Pendiente de ejecutar la suite completa y validar una exportación real en Chromebook.

## In This Town — Browser v0.5.22

Release de preparación de uso: incluye los tres packs de modelos integrados, el Director IA externo opcional y el modo local. No requiere API key. La primera generación de voz descarga Kokoro desde internet y puede tardar bastante; el motor está configurado para priorizar WASM Q8/Q4 en Chromebook.

- Versiones de interfaz, app, director IA, paquete y caché alineadas en v0.5.22.
- Guía de inicio rápido incluida en `START_HERE.txt`.
- Suite automatizada verificada: 89 tests; sintaxis JavaScript verificada.
- La exportación real en el Chromebook sigue necesitando una prueba final en el dispositivo.

## v0.5.20 — Claude model pack integration
- Integrates the three procedural prop/creature/world model packs from Claude (146 models as declared by the source package; these are not editable human avatar rigs).
- New props are loaded by the main renderer and the standalone engine preview.
- The asset catalogue exposes their tags, and the external AI director receives the exact installed model names when building a story prompt.
- Imported story validation accepts only registered model keys and requires the object name to be present in that scene's narration.

# In This Town — Browser v0.5.22 (historial de cambios)

Browser-first Roblox-style short-video studio. It creates English narration with Kokoro-82M, builds 3D scenes with the original WebGL2 engine, and exports a vertical video.

## v0.5.19 — Narration-to-animation and continuity guard
- The AI director now identifies the grammatical actor before choosing an animation. A character who is only the object of an action no longer performs it just because they are the only character visible.
- Pronoun references such as “He opened the door” are supported when exactly one actor is visible; ambiguous clauses remain neutral instead of inventing movement.
- The director reports silent location changes without narrated travel or a clear time jump.
- Props no longer follow a story to a different location just because the next line mentions the same noun. Cross-location continuity requires a narrated transfer/possession cue.
- The external story prompt continues to request original premises, non-repeating causal mechanisms, actor-specific actions, grounded objects, word-anchored events and motivated camera direction.
- Position collision checks, path rerouting, camera correction and narration repeat warnings remain active.

## Important: what “AI” means in this build
- **External AI Director:** ChatGPT or Claude invents a free-form story and scene plan from the generated prompt. The JSON is imported and compiled into the actual WebGL 3D story. The app remembers recent completed stories locally and includes them in the next originality prompt.
- **Local story AI:** The browser downloads a compact SmolLM2 instruction model and runs inference locally with Transformers.js / ONNX Runtime. The model is small and can produce weaker scripts than a cloud LLM; generation is validated and rejected rather than silently replaced with a fixed story.
- GitHub Pages is static. This build does not call an LLM API automatically and does not store API keys. The external AI handoff remains copy/paste unless a separate secure backend/API integration is built.

## v0.5.18 — Semantic story director
- Strengthened the free-form prompt so the external model invents a new causal conflict rather than filling a fixed template.
- Added actor-specific action inference, expanded verb coverage, camera alignment, collision checks, and location continuity diagnostics.
- Imported AI scripts are consumed only after a successful export; failed renders keep the imported draft so it can be retried.

## v0.5.17 — Studio interface redesign
- Reorganized the page into a clearer creation flow with quick navigation to story creation, external AI direction, character creation and the asset library.
- Rebuilt the dark studio visual system with stronger hierarchy, clearer labels, larger touch targets, improved responsive layouts and keyboard focus states.
- Kept all existing application control IDs and JavaScript modules to preserve the rendering, narration, AI import and character workflows.
- Added local autosave for the rule, tone, length and variation setting.

## v0.5.16 — Semantic and spatial validation
The external story director validates scene props against the exact narration beat, validates actor starting positions before movement destinations and rejects duplicate prop IDs within a scene.

## v0.5.15 — External AI Story Director
- Optional bridge to ChatGPT/Claude: prepare a prompt from the current premise, tone and length; paste the returned JSON; validate; and use that script in the actual 3D generation pipeline.
- Imported stories specify cast, beat-by-beat narration, locations, actor placements/actions, props, spoken-word cues and camera direction.
- The app validates supported engine assets and timings and warns about mismatched spoken cues and unsupported scene instructions.

## Run locally
Serve the `site/` folder through a local HTTP server. Open `index.html` through HTTPS or localhost for full browser capabilities. WebGL2, Web Audio and MediaRecorder are required for video export.

## Deploy
Upload the versioned `InThisTown_Browser_v*.zip` archive to the repository root. The Pages workflow selects the newest archive, extracts its `site/` directory and deploys it.

## Verification
Run `npm test` and `npm run check` from this directory. These automated tests do not replace a real Kokoro + WebGL2 + MediaRecorder render on the target Chromebook.

## iPhone / iOS 26+
The local story model probes for a real WebGPU adapter on iOS 26+ before trying the Q4 accelerated route. If that is unavailable, it falls back to WASM Q8 and Q4. Older iOS and Android browsers start with WASM. After story generation, the app asks Transformers.js/ONNX to release model resources before voice synthesis and 3D rendering. This reduces memory pressure but cannot guarantee successful long renders on every iPhone; test on the actual device.


### v0.5.29 · iPhone y PC
Incluye un panel de diagnóstico de compatibilidad del navegador y un perfil de voz móvil que intenta Q4 antes de Q8 para reducir el uso máximo de memoria. La selección no garantiza que todos los dispositivos puedan completar la exportación; hay que probar el flujo real en cada equipo.

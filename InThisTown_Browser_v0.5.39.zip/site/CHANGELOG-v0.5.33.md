# In This Town Browser v0.5.34

- Fixed face texture atlas filtering: facial expressions no longer use mipmaps, preventing neighbouring atlas cells from bleeding together at distance.
- Inset face UV coordinates to avoid sampling transparent pixels from adjacent expressions.
- Moved the face plane slightly forward to prevent depth fighting with the head surface.
- Invalid face names now fall back to the explicit neutral expression.
- Added regression tests for the face rendering fixes.

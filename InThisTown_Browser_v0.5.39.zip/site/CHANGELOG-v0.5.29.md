# In This Town Browser v0.5.29

## Ajuste de memoria para la voz en PC
- Kokoro prueba Q8 en WebGPU en lugar de FP32, reduciendo la presión de memoria de vídeo en equipos con GPU dedicada de memoria limitada, como la GTX 1650.
- Si Q8/WebGPU falla, conserva el fallback WASM Q8 y después Q4.
- En iPhone y otros móviles se mantiene WASM Q4 primero y Q8 como alternativa.
- Se ha sincronizado el worker independiente y su copia embebida para que el comportamiento sea idéntico.

La compatibilidad real depende del navegador, los controladores y la memoria disponible. No se ha realizado una prueba física de generación en el iPhone 13 Pro ni en el HP Victus.

# In This Town Browser v0.5.25

## IA local y calidad narrativa
- Selección del backend de inferencia según memoria estimada, núcleos y dispositivo: los equipos de memoria limitada priorizan WASM para evitar asignaciones WebGPU grandes; equipos potentes mantienen WebGPU como primera opción.
- Si el backend preferido falla, se intenta la alternativa disponible.
- Parámetros de generación diferenciados entre reintentos para escapar de respuestas repetitivas: temperatura/top-p/repetition penalty ajustables por intento y bloqueo de trigramas repetidos.
- Revisión narrativa adicional mediante similitud Jaccard entre escenas, detección de repeticiones exactas y advertencias por inicios demasiado uniformes.
- Se amplía moderadamente el presupuesto de tokens para reducir respuestas truncadas.
- Se corrige el texto de interfaz y documentación que todavía describía la IA local como procedural.

## Verificación
- Tests automatizados y comprobación sintáctica ejecutados en el entorno de desarrollo.
- No se ha probado una generación real en el Chromebook físico; la compatibilidad depende de memoria, navegador y WebGPU/WASM disponibles.

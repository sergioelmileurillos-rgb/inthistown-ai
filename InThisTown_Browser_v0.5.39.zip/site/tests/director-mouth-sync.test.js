const test = require('node:test');
const assert = require('node:assert/strict');
global.window = global;
global.Studio = {
  V:{}, M:{}, clamp:(n,a,b)=>Math.max(a,Math.min(b,n)),
  lerp:(a,b,t)=>a+(b-a)*t, ease:(name,t)=>t, hex:x=>x,
  mix:(a,b,t)=>a, rng:()=>()=>.5
};
require('../engine/director.js');

test('mouth pulses follow measured word timings and syllable count',()=>{
  const words=[
    {w:'cat',s:0,e:.3},
    {w:'amazing',s:.4,e:1.0},
    {w:'quiet',s:1.2,e:1.5}
  ];
  const pulses=Studio.Director.speechMouthPulses(words,0,1.1);
  assert.equal(pulses.length,4); // 1 + 3 syllabic mouth pulses; later word is outside the active window
  assert.ok(pulses.every(([a,b])=>a>=0&&b<=1.1&&b>a));
  assert.ok(pulses[0][0]<pulses[1][0]);
  assert.ok(pulses.at(-1)[0]<1.1);
});

test('mouth pulse timing is clipped to the active speech window',()=>{
  const pulses=Studio.Director.speechMouthPulses([
    {w:'hello',s:-.2,e:.4},{w:'world',s:.8,e:1.4}
  ],0,1);
  assert.ok(pulses.length>0);
  assert.ok(pulses.every(([a,b])=>a>=0&&b<=1));
});

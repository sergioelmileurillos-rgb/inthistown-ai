const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const root = path.join(__dirname, '..');
const html = fs.readFileSync(path.join(root, 'index.html'), 'utf8');
const app = fs.readFileSync(path.join(root, 'app.js'), 'utf8');
const ai = fs.readFileSync(path.join(root, 'local-story-ai.js'), 'utf8');
const sw = fs.readFileSync(path.join(root, 'sw.js'), 'utf8');

test('browser-local story AI is loaded by the main page and precached', () => {
  assert.match(html, /src="local-story-ai\.js"/);
  assert.match(sw, /'\.\/local-story-ai\.js'/);
});

test('video creation generates and validates a local AI script before building scenes', () => {
  assert.match(app, /await generateLocalStory\(idea,tone,length,state\.variant\)/);
  assert.match(app, /validateAndCompile\(result\.json,\{tone,length,source:'local-browser-llm'\}\)/);
  assert.match(app, /previousStories:getStoryHistory\(\)\.slice\(0,4\)/);
});

test('local model uses browser inference with a WebGPU and WASM route and browser cache', () => {
  assert.match(ai, /onnx-community\/SmolLM2-360M-Instruct-ONNX/);
  assert.match(ai, /device === 'webgpu'/);
  assert.match(ai, /devicePlan\(\)/);
  assert.match(ai, /device === 'webgpu'/);
  assert.match(ai, /useBrowserCache = true/);
  assert.doesNotMatch(ai, /api[_-]?key|Authorization|Bearer\s/i);
});

test('local model generation extracts and parses a JSON story without an inference API', () => {
  assert.match(ai, /text-generation/);
  assert.match(ai, /extractJSON/);
  assert.match(ai, /JSON\.parse\(json\)/);
  assert.doesNotMatch(ai, /fetch\(['"]https?:\/\/[^'"]*(?:api|inference)/i);
});


test('local AI retries failed drafts and runs narrative quality checks before rendering', () => {
  assert.match(app, /for\(let attempt=0;attempt<3;attempt\+\+\)/);
  assert.match(app, /REVISION OBLIGATORIA/);
  assert.match(app, /inspectLocalStoryQuality/);
  assert.match(app, /No se utilizará una historia fija como sustituto/);
  assert.match(app, /vocabulario variado/);
});

test('local model chooses a conservative backend on low-memory and mobile devices', () => {
  assert.match(ai, /async function devicePlan\(\)/);
  assert.match(ai, /deviceMemory/);
  assert.match(ai, /hardwareConcurrency/);
  assert.match(ai, /ios26Plus/);
  assert.match(ai, /requestAdapter\(\{ powerPreference: mobile \? 'low-power' : 'high-performance' \}\)/);
  assert.match(ai, /if \(mobile\) return ios26Plus && hasAdapter \? \['webgpu', 'wasm'\] : \['wasm'\]/);
  assert.match(ai, /isMobile \? \[\{ device, dtype: 'q4' \}, \{ device, dtype: 'q8' \}\] : \[\{ device, dtype: 'q8' \}, \{ device, dtype: 'q4' \}\]/);
});

test('local generation uses varied retry sampling and suppresses repeated trigrams', () => {
  assert.match(ai, /no_repeat_ngram_size: 3/);
  assert.match(ai, /options\.temperature/);
  assert.match(ai, /options\.topP/);
  assert.match(ai, /options\.repetitionPenalty/);
  assert.match(app, /temperature:attempt===0\?0\.90:attempt===1\?0\.98:0\.82/);
});

test('narrative review detects near-duplicate beats rather than exact duplicates only', () => {
  assert.match(app, /const similarity=\(a,b\)/);
  assert.match(app, /prácticamente lo mismo/);
  assert.match(app, /muchas escenas empiezan con la misma palabra/);
});


test('local model can be released before mobile 3D rendering to reduce memory pressure', () => {
  assert.match(ai, /async function release\(\)/);
  assert.match(ai, /current\.model\?\.dispose/);
  assert.match(app, /await window\.ITT\.LocalAI\.release\?\.\(\)/);
  assert.match(app, /Release ONNX\/WebGPU memory before Kokoro and the 3D renderer start/);
});


test('local AI probes an actual WebGPU adapter before selecting the GPU backend', async () => {
  const vm = require('node:vm');
  const source = ai;
  async function plan(userAgent, memory, cores, adapter) {
    const sandbox = {
      window: { navigator: { userAgent, deviceMemory: memory, hardwareConcurrency: cores, gpu: { async requestAdapter() { return adapter ? {} : null; } } } },
      console, Number, String, Array, Object, Math, Promise, Error, RegExp
    };
    vm.runInNewContext(source, sandbox);
    return JSON.parse(JSON.stringify(await sandbox.window.ITT.LocalAI.devicePlan()));
  }
  assert.deepEqual(await plan('Windows Chrome', 16, 12, true), ['webgpu', 'wasm']);
  assert.deepEqual(await plan('Windows Chrome', 16, 12, false), ['wasm']);
  assert.deepEqual(await plan('iPhone OS 18_0', 6, 6, true), ['wasm']);
  assert.deepEqual(await plan('iPhone OS 26_0', 6, 6, true), ['webgpu', 'wasm']);
});


test('iPhone starts story inference with Q4 to avoid an oversized Q8 allocation', () => {
  assert.match(ai, /isMobile = \/Android\|iPhone\|iPad\|iPod\|Mobile\/i/);
  assert.match(ai, /isMobile \? \[\{ device, dtype: 'q4' \}, \{ device, dtype: 'q8' \}\] : \[\{ device, dtype: 'q8' \}, \{ device, dtype: 'q4' \}\]/);
});

test('manual preload releases the in-memory model on mobile after warming browser cache', () => {
  assert.match(app, /IA descargada y guardada en la caché del navegador/);
  assert.match(app, /await window\.ITT\.LocalAI\.release\?\.\(\)/);
});

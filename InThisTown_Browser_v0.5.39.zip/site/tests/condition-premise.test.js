const test = require('node:test');
const assert = require('node:assert/strict');
const Story = require('../story-engine.js');

test('descriptive premises are not misread as impossible rule verbs', () => {
  const rule = Story.parseRule('In this town, everyone is poor except the mayor');
  assert.equal(rule.kind, 'condition');
  assert.equal(rule.group, 'everyone');
  assert.equal(rule.state, 'poor');
  assert.equal(rule.exception, 'mayor');
  assert.equal(rule.f.verb, 'investigate');
  assert.doesNotMatch(rule.f.ing, /iing/);
});

test('exception premise creates a coherent story about its actual subject', () => {
  for (let seed = 1; seed <= 12; seed++) {
    const story = Story.generate('In this town, everyone is poor except the mayor', 'mystery', 'medium', seed);
    const script = story.beats.map(x => x.vo).join(' ');
    assert.equal(story.arch, 'condition');
    assert.match(script, /poor except the mayor/i);
    assert.match(script, /mayor/i);
    assert.doesNotMatch(script, /stopped iing|loophole|town inspector|rulebook/i);
    assert.ok(story.beats.length >= 12);
    assert.ok(story.beats.every(b => b.vo && Array.isArray(b.plan) && b.plan.length));
  }
});

test('repeated descriptive premise rotates its plot and narration', () => {
  const stories = Array.from({length:24}, (_,i) => Story.generate('In this town, everyone is poor except the mayor', 'mystery', 'medium', i+100));
  const scripts = new Set(stories.map(s => s.beats.map(b => b.vo).join('|')));
  assert.ok(scripts.size >= 2, `expected distinct stories, got ${scripts.size}`);
});

test('loophole endings rotate and no longer force the protagonist into an inspector job', () => {
  const outcomes = new Set();
  for (let seed = 1; seed <= 120; seed++) {
    const story = Story.generate('Nobody is allowed to open a window after midnight', 'mystery', 'medium', seed);
    if (story.arch !== 'loophole') continue;
    const script = story.beats.map(b => b.vo).join(' ');
    assert.doesNotMatch(script, /town inspector|rule inspector|new job/i);
    if (/new rule had the same tiny loophole/i.test(script)) outcomes.add('new-loophole');
    if (/gone too far/i.test(script)) outcomes.add('backfire');
    if (/same trick himself/i.test(script)) outcomes.add('mayor-caught');
  }
  assert.ok(outcomes.size >= 2, `expected different loophole endings, got ${[...outcomes]}`);
});

test('unrecognized descriptive premises fail clearly instead of becoming invented verbs', () => {
  assert.throws(() => Story.generate('In this town, the mayor is secretly a robot', 'mystery', 'medium', 1), /describe una situación/i);
});

const test = require('node:test');
const assert = require('node:assert/strict');
const Story = require('../story-engine.js');

const premises = [
  'Nobody is allowed to open a window after midnight',
  'Every lie makes you shrink by one inch',
  'You can only walk backwards after sunset',
  'Nobody may whistle on Sundays',
  'If you sneeze, the lights go out',
  'No one can look at the moon',
  'Never eat pizza on Tuesdays',
  'Nobody can knock on the red door',
  'Everyone must wear a hat',
  'Nobody is allowed to read books at night',
  'You cannot touch the golden statue',
  'Nobody can turn on a light after dark'
];

test('genera historias completas sin placeholders ni frases vacías', () => {
  for (const premise of premises) {
    for (const tone of ['mystery', 'funny', 'suspense']) {
      const story = Story.generate(premise, tone, 'medium', 1700000000000);
      assert.ok(story.beats.length >= 10, premise + ' / ' + tone);
      assert.ok(story.beats.every(b => typeof b.vo === 'string' && b.vo.trim().length > 0));
      assert.ok(story.beats.every(b => !/\{\w+\}|\bundefined\b|\bNaN\b/.test(b.vo)));
      assert.ok(story.beats.every(b => b.role && b.set && Array.isArray(b.plan)));
    }
  }
});

test('variante cambia reparto o arco manteniendo la misma premisa', () => {
  const a = Story.generate(premises[0], 'mystery', 'medium', 100);
  const b = Story.generate(premises[0], 'mystery', 'medium', 200);
  assert.notEqual(a.seed, b.seed);
  assert.ok(a.beats.length > 0 && b.beats.length > 0);
});

test('versión corta limita la historia y conserva el gancho', () => {
  const story = Story.generate(premises[0], 'mystery', 'short', 42);
  assert.ok(story.beats.length <= 16);
  assert.equal(story.beats[0].role, 'hook');
});


test('story archetypes do not add shadows or monsters to unrelated premises',()=>{
  for(const tone of ['mystery','suspense','funny']){
    const ordinary=Story.generate('Nobody may whistle on Sundays',tone,'medium',12345);
    assert.ok(!['warning'].includes(ordinary.arch));
    assert.ok(!ordinary.beats.some(b=>/shadow|creature|dragon|monster/i.test(b.vo)));
  }
  const shadow=Story.generate('Nobody may walk outside after the lights go out and a shadow appears', 'mystery','medium',12346);
  assert.ok(['warning','investigation','reason','challenge','chain','loophole'].includes(shadow.arch));
  assert.ok(shadow.beats.some(b=>/shadow/i.test(b.vo)));
  const shadowArcs=new Set(Array.from({length:6},(_,i)=>Story.generate('Nobody may walk outside after the lights go out and a shadow appears','mystery','medium',12346+i).arch));
  assert.ok(shadowArcs.size>=3);
});


test('the same premise rotates through genuinely different plot structures',()=>{
  const premise='Nobody is allowed to open a window after midnight';
  const variants=Array.from({length:10},(_,i)=>Story.generate(premise,'mystery','medium',i));
  const arcs=new Set(variants.map(x=>x.arch));
  for(const expected of ['loophole','challenge','investigation','chain','reason'])assert.ok(arcs.has(expected),'missing plot structure '+expected);
  const scripts=new Set(variants.map(x=>x.beats.map(b=>b.vo).join('|')));
  assert.ok(scripts.size>=5,'repeated generations should not reuse the same complete narration');
  for(const story of variants){
    assert.ok(story.beats.every(b=>!/\{\w+\}|\bundefined\b|\bNaN\b/.test(b.vo)));
    assert.ok(story.beats.every(b=>Array.isArray(b.plan)&&b.plan.length>0));
  }
});

test('darkness or lights-out rules do not invent a shadow character',()=>{
  const prompts=[
    'Nobody can turn on a light after dark',
    'Nobody is allowed outside after midnight',
    'When the lights go out, everyone must stay inside'
  ];
  for(const prompt of prompts)for(const tone of ['mystery','funny','suspense']){
    const story=Story.generate(prompt,tone,'medium',12);
    assert.notEqual(story.arch,'warning',prompt+' must not auto-select the shadow plot');
    assert.ok(!story.beats.some(b=>/\bshadow\b|\bghost\b/i.test(b.vo)),prompt+' invented a shadow');
  }
});


test('effect rules rotate through different narrative structures instead of one fixed script',()=>{
  const Story=require('../story-engine.js');
  const arcs=new Set();
  for(let i=0;i<8;i++)arcs.add(Story.generate('Every lie makes you shrink by one inch','mystery','short',1000+i).arch);
  assert.ok(arcs.size>=4,`expected at least four story structures, got ${[...arcs].join(', ')}`);
});

test('local generator avoids recently used plot archetypes when alternatives exist',()=>{
  const avoid=['loophole','challenge','investigation'];
  const story=Story.generate('Nobody may whistle on Sundays','mystery','short',77,{avoidArchetypes:avoid});
  assert.ok(!avoid.includes(story.arch),`recent archetype reused: ${story.arch}`);
});

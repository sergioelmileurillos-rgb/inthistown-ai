const test = require('node:test');
const assert = require('node:assert/strict');
const AIStory = require('../ai-story-director.js');

function sample(){
  const verbs=['lookAround','think','sneak','run','point','inspect','wave_big','shrug','talk','hide','victory','wave_big'];
  return {
    title:'The Sunday Whistle Mystery',
    premise:'Nobody may whistle on Sundays',
    cast:{hero:{name:'Max',preset:'hero'},nbr:{name:'Luna',preset:'boy2'},mayor:{name:'Mayor Bill',preset:'mayor'}},
    beats:Array.from({length:12},(_,i)=>{
      const who=i%3===1?'nbr':'hero';
      const cue=['town','thought','street','ran','pointed','inspected','waved','shrugged','talked','hid','won','waved'][i];
      const line=[
        'In this town, nobody may whistle.',
        'Max heard a strange sound.',
        'He sneaked toward the old park.',
        'Then Luna ran away.',
        'Max pointed at the empty bench.',
        'He inspected the strange footprint.',
        'Luna waved from the fountain.',
        'Max shrugged and checked his watch.',
        'The mayor talked to the crowd.',
        'Max hid behind the statue.',
        'The town finally won its silence.',
        'Everyone waved at the quiet hero.'
      ][i];
      const actor=i===3?'nbr':i===6?'nbr':i===8?'mayor':who;
      const action=verbs[i];
      const spot=['center','left','right','yardL','yardR','street','streetR','plaza','podium','door','far','room'][i];
      return {role:i===0?'hook':i===11?'payoff':i===10?'twist':'build',set:['street','park','city','townhall'][i%4],vo:line,
        actors:[{id:actor,spot,action,cue:i===0?'town':(line.toLowerCase().match(/[a-z']+/g)||[])[1]||'Max',face:'neutral',duration:1}],
        props:[],camera:{shot:i%2?'medium':'wide',focus:[actor],move:'drift',at:'start',amount:.2}};
    })
  };
}

test('external LLM JSON compiles into supported semantic scene plans',()=>{
  const draft=AIStory.validateAndCompile(sample(),{tone:'mystery',length:'short'});
  assert.equal(draft.arch,'ai-original');
  assert.equal(draft.beats.length,12);
  assert.ok(draft.beats.every(b=>b.plan.length>0&&b.cam.length===1));
  assert.ok(draft.beats.every(b=>!b.vo.includes('{')));
});

test('repositions characters that share a requested place and still rejects unsupported cues',()=>{
  const bad=sample();
  bad.beats[0].actors=[
    {id:'hero',spot:'center',action:'lookAround',cue:'Max',face:'neutral'},
    {id:'nbr',spot:'center',action:'think',cue:'Max',face:'neutral'}
  ];
  const spaced=AIStory.validateAndCompile(bad,{length:'short'});
  const castPlan=spaced.beats[0].plan.find(op=>op[0]==='cast')[1];
  assert.notEqual(castPlan.hero,castPlan.nbr);
  assert.ok(spaced.diagnostics.adjustments.some(x=>x.reason==='personajes recolocados para evitar solapamiento'));
  const badCue=sample();badCue.beats[2].actors[0].cue='dragon';
  const fixed=AIStory.validateAndCompile(badCue,{length:'short'});
  assert.ok(fixed.beats[2].plan.some(op=>op[0]==='anim'&&op[3]==='sneaked'));
  assert.ok(fixed.diagnostics.adjustments.length>=0);
});

test('a shadow is rendered when the exact narration names it, even if the premise does not',()=>{
  const draft=sample();draft.beats[4].vo='A shadow appeared behind Max.';
  draft.beats[4].actors=[{id:'hero',spot:'center',action:'think',cue:'Max',face:'neutral'}];
  const out=AIStory.validateAndCompile(draft,{length:'short'});
  assert.ok(out.beats[4].plan.some(op=>op[0]==='obj'&&op[2]==='shadow'));
});

test('accepts markdown fenced JSON and generates a custom prompt for the current premise',()=>{
  const wrapped='```json\n'+JSON.stringify(sample())+'\n```';
  assert.equal(AIStory.validateAndCompile(wrapped,{length:'short'}).beats.length,12);
  const prompt=AIStory.buildPrompt('Every compliment gives you a coin','funny','short');
  assert.match(prompt,/Every compliment gives you a coin/);
  assert.match(prompt,/JSON VÁLIDO/i);
});

test('provides a reusable model when the AI script adds a bot or extra character',()=>{
  const draft=sample();draft.beats[2].actors=[{id:'extra1',spot:'right',action:'lookAround',cue:'sneaked',face:'neutral'}];
  const result=AIStory.validateAndCompile(draft,{length:'short'});
  assert.equal(result.cast.extra1.spec.preset,'grandma');
});

test('normalizes the common In This Town prefix so imported stories match the app rule field',()=>{
  const draft=sample();draft.premise='In This Town, Nobody May Whistle on Sundays.';
  const result=AIStory.validateAndCompile(draft,{length:'short'});
  assert.equal(result.idea,'Nobody May Whistle on Sundays');
});


test('rejects props that are not named in the exact narration beat',()=>{
  const bad=sample();
  bad.beats[4].props=[{id:'book1',type:'book',spot:'right',cue:'start'}];
  assert.throws(()=>AIStory.validateAndCompile(bad,{length:'short'}),/no está mencionado en la narración/);
});

test('reroutes a movement destination occupied by a later actor in the JSON list',()=>{
  const bad=sample();
  bad.beats[0].actors=[{id:'hero',spot:'left',action:'idle',cue:'town',face:'neutral'}];
  bad.beats[1].actors=[{id:'hero',spot:'left',action:'idle',cue:'heard',face:'neutral'}];
  bad.beats[2].vo='Max ran across the old park.';
  bad.beats[2].actors=[
    {id:'hero',spot:'left',destination:'right',action:'walk',cue:'ran',face:'neutral'},
    {id:'nbr',spot:'right',action:'idle',cue:'ran',face:'neutral'}
  ];
  const out=AIStory.validateAndCompile(bad,{length:'short'});
  const movement=out.beats[2].plan.find(op=>op[0]==='walk'&&op[1]==='hero');
  assert.ok(movement);
  assert.notEqual(movement[2],'right');
  assert.ok(out.diagnostics.adjustments.some(x=>x.reason.includes('ruta desviada para evitar colisión')));
});


test('director corrects a mismatched animation and anchors it to the narrated action',()=>{
  const draft=sample();
  draft.beats[3].vo='Luna ran across the empty street.';
  draft.beats[3].actors=[{id:'nbr',spot:'left',action:'think',cue:'Luna',face:'neutral'}];
  const out=AIStory.validateAndCompile(draft,{length:'short'});
  assert.ok(out.beats[3].plan.some(op=>op[0]==='walk'&&op[1]==='nbr'&&op[5]==='run'&&op[3]==='ran'));
  assert.ok(out.diagnostics.adjustments.some(x=>x.from==='think'&&x.to==='run'));
});

test('director automatically adds explicitly narrated props and aligns cameras with the action',()=>{
  const draft=sample();
  draft.beats[4].vo='A shadow appeared behind Max.';
  draft.beats[4].actors=[{id:'hero',spot:'center',action:'lookAround',cue:'Max',face:'neutral'}];
  draft.beats[4].camera={shot:'wide',focus:['hero'],move:'whip',at:'start',amount:.5};
  const out=AIStory.validateAndCompile(draft,{length:'short'});
  assert.ok(out.beats[4].plan.some(op=>op[0]==='obj'&&op[2]==='shadow'));
  assert.equal(out.beats[4].cam[0][0],'close');
  assert.equal(out.beats[4].cam[0][2].move,'push');
  assert.ok(out.diagnostics.autoProps>=1);
});

test('creative prompt rejects fixed plot formulas and does not require a mayor',()=>{
  const prompt=AIStory.buildPrompt('Nobody may whistle on Sundays','mystery','short',{seed:12345});
  assert.match(prompt,/no uses una estructura narrativa prefijada/i);
  assert.match(prompt,/alcalde.*NO son elementos obligatorios/i);
  assert.match(prompt,/SEMILLA DE NOVEDAD/);
  assert.match(prompt,/LA ANIMACIÓN DEBE REPRESENTAR LA FRASE/i);
  assert.match(prompt,/TRES conceptos incompatibles/i);
  assert.match(prompt,/cadena causal/i);
});


test('camera moves into an object interaction and focuses the narrated prop',()=>{
  const draft=sample();
  draft.beats[4].vo='Max opened the red door.';
  draft.beats[4].actors=[{id:'hero',spot:'center',action:'inspect',cue:'opened',face:'neutral'}];
  draft.beats[4].camera={shot:'wide',focus:['hero'],move:'orbit',at:'start',amount:.4};
  const out=AIStory.validateAndCompile(draft,{length:'short'});
  assert.equal(out.beats[4].cam[0][0],'close');
  assert.equal(out.beats[4].cam[0][2].move,'push');
  assert.ok(out.beats[4].cam[0][1].some(id=>String(id).startsWith('auto_door')));
});

test('director flags an exact repeated narration beat before video generation',()=>{
  const draft=sample();
  draft.beats[5].vo=draft.beats[4].vo;
  const out=AIStory.validateAndCompile(draft,{length:'short'});
  assert.ok(out.diagnostics.warnings.some(w=>w.includes('narración repetida')));
});

test('director creates and operates a narrated door at the spoken verb',()=>{
  const draft=sample();
  draft.beats[4].vo='Max opened the red door.';
  draft.beats[4].actors=[{id:'hero',spot:'center',action:'think',cue:'Max',face:'neutral'}];
  draft.beats[4].props=[];
  const out=AIStory.validateAndCompile(draft,{length:'short'});
  const beat=out.beats[4];
  assert.ok(beat.plan.some(op=>op[0]==='obj'&&op[2]==='door'));
  assert.ok(beat.plan.some(op=>op[0]==='do'&&op[2]==='open'&&op[4]==='opened'));
  assert.ok(beat.cam[0][1].some(id=>String(id).startsWith('auto_door')));
});

test('rejects duplicate prop ids within a single scene',()=>{
  const bad=sample();
  bad.beats[4].vo='Max inspected the book beside the book.';
  bad.beats[4].actors=[{id:'hero',spot:'center',action:'inspect',cue:'inspected',face:'neutral'}];
  bad.beats[4].props=[
    {id:'book1',type:'book',spot:'left',cue:'book'},
    {id:'book1',type:'book',spot:'right',cue:'book'}
  ];
  assert.throws(()=>AIStory.validateAndCompile(bad,{length:'short'}),/duplicado en la escena/);
});

test('director corrects exact animation even when proposed and narrated actions share a broad family',()=>{
  const draft=sample();
  draft.beats[3].vo='Luna walked across the empty street.';
  draft.beats[3].actors=[{id:'nbr',spot:'left',action:'run',cue:'walked',face:'neutral'}];
  const out=AIStory.validateAndCompile(draft,{length:'short'});
  assert.ok(out.beats[3].plan.some(op=>op[0]==='walk'&&op[1]==='nbr'&&op[5]==='walk'&&op[3]==='walked'));
  assert.ok(out.diagnostics.adjustments.some(x=>x.from==='run'&&x.to==='walk'));
});

test('object interactions follow the verb in the narration rather than a mismatched AI command',()=>{
  const draft=sample();
  draft.beats[4].vo='Max looked at the red door.';
  draft.beats[4].actors=[{id:'hero',spot:'center',action:'inspect',cue:'looked',face:'neutral'}];
  draft.beats[4].props=[{id:'door1',type:'door',spot:'right',transition:'appear',action:'open',actor:'hero',cue:'door',actionCue:'door'}];
  const out=AIStory.validateAndCompile(draft,{length:'short'});
  assert.ok(!out.beats[4].plan.some(op=>op[0]==='do'&&op[3]==='door1'));
  assert.ok(out.diagnostics.adjustments.some(x=>x.prop==='door1'&&x.fromAction==='open'&&x.toAction==='none'));
});

test('two narrated object actions are assigned to the nearest named object',()=>{
  const draft=sample();
  draft.beats[4].vo='Max opened the door, then closed the window.';
  draft.beats[4].actors=[{id:'hero',spot:'center',action:'useObject',cue:'opened',face:'neutral'}];
  draft.beats[4].props=[];
  const out=AIStory.validateAndCompile(draft,{length:'short'});
  const actions=out.beats[4].plan.filter(op=>op[0]==='do').map(op=>[op[2],op[3],op[4]]);
  assert.ok(actions.some(x=>x[0]==='open'&&x[1]==='auto_door'&&x[2]==='opened'));
  assert.ok(actions.some(x=>x[0]==='close'&&x[1]==='auto_window'&&x[2]==='closed'));
});

test('director does not invent a phone for a verbal call or a clock for vague time wording',()=>{
  const props=AIStory.inferMentionedProps('Max called the mayor at that time.',new Set());
  assert.ok(!props.some(x=>['phone','clock'].includes(x.type)));
});

test('external prompt uses recent story memory to avoid repeating plot mechanisms',()=>{
  const prompt=AIStory.buildPrompt('Nobody may whistle on Sundays','mystery','short',{seed:123,previousStories:[{title:'The Mirror Mayor',archetype:'investigation',hero:'Max',neighbor:'Luna',beats:['Max found a mirror.','The mayor hid a note.'],places:['townhall'],props:['mirror','note'],ending:'The mayor admitted the truth.'}]});
  assert.match(prompt,/HISTORIAL DE ORIGINALIDAD/);
  assert.match(prompt,/mirror/i);
  assert.match(prompt,/No basta con cambiar nombres/);
});

test('each character receives the animation for their own narrated clause',()=>{
  const draft=sample();
  draft.beats[2].vo='Max opened the red door while Luna ran away.';
  draft.beats[2].actors=[
    {id:'hero',spot:'center',action:'run',cue:'Max',face:'neutral'},
    {id:'nbr',spot:'left',action:'useObject',cue:'Luna',face:'neutral'}
  ];
  draft.beats[2].props=[];
  const out=AIStory.validateAndCompile(draft,{length:'short'});
  const ops=out.beats[2].plan;
  assert.ok(ops.some(op=>op[0]==='anim'&&op[1]==='hero'&&op[2]==='useObject'&&op[3]==='opened'));
  assert.ok(ops.some(op=>op[0]==='walk'&&op[1]==='nbr'&&op[5]==='run'&&op[3]==='ran'));
  assert.ok(!ops.some(op=>op[0]==='anim'&&op[1]==='nbr'&&op[2]==='useObject'));
});

test('a character mentioned as the object of an action does not perform that action',()=>{
  const draft=sample();
  draft.beats[4].vo='Max looked at Luna beside the fountain.';
  draft.beats[4].actors=[
    {id:'hero',spot:'center',action:'inspect',cue:'looked',face:'neutral'},
    {id:'nbr',spot:'left',action:'dance',cue:'Luna',face:'neutral'}
  ];
  draft.beats[4].props=[];
  const out=AIStory.validateAndCompile(draft,{length:'short'});
  assert.ok(out.beats[4].plan.some(op=>op[0]==='anim'&&op[1]==='hero'&&op[2]==='inspect'));
  assert.ok(out.beats[4].plan.some(op=>op[0]==='anim'&&op[1]==='nbr'&&op[2]==='listen'));
  assert.ok(out.diagnostics.warnings.some(w=>w.includes('Luna')));
});

test('automatically assigns a prop interaction to the character named as its actor',()=>{
  const draft=sample();
  draft.beats[4].vo='Luna opened the door while Max ran away.';
  draft.beats[4].actors=[
    {id:'hero',spot:'center',action:'run',cue:'ran',face:'neutral'},
    {id:'nbr',spot:'left',action:'useObject',cue:'opened',face:'neutral'}
  ];
  draft.beats[4].props=[];
  const out=AIStory.validateAndCompile(draft,{length:'short'});
  assert.ok(out.beats[4].plan.some(op=>op[0]==='do'&&op[1]==='nbr'&&op[2]==='open'&&op[3]==='auto_door'));
  assert.ok(out.beats[4].plan.some(op=>op[0]==='walk'&&op[1]==='hero'&&op[5]==='run'));
});

test('prop interactions are assigned only to the character who is the narrated subject',()=>{
  const draft=sample();
  draft.beats[4].vo='Luna opened the door while Max ran away.';
  draft.beats[4].actors=[
    {id:'hero',spot:'center',action:'run',cue:'ran',face:'neutral'},
    {id:'nbr',spot:'left',action:'useObject',cue:'opened',face:'neutral'}
  ];
  draft.beats[4].props=[{id:'door1',type:'door',spot:'right',action:'open',actor:'hero',cue:'door'}];
  const out=AIStory.validateAndCompile(draft,{length:'short'});
  assert.ok(!out.beats[4].plan.some(op=>op[0]==='do'&&op[3]==='door1'));
  assert.ok(out.diagnostics.warnings.some(w=>w.includes('interacción')));
});

test('director prompt requires explicit actor names in every beat for reliable blocking',()=>{
  const prompt=AIStory.buildPrompt('Nobody may whistle on Sundays','mystery','short',{seed:123});
  assert.match(prompt,/En CADA beat, nombra explícitamente al personaje/i);
  assert.match(prompt,/props\[\]\.actor debe ser exactamente/i);
});

test('recognizes a wider range of physical actions in narration',()=>{
  assert.equal(AIStory.inferredPerformance('Mia climbed the tower.','climbed').clip,'climb');
  assert.equal(AIStory.inferredPerformance('Leo swam across the river.','swam').clip,'swim');
  assert.equal(AIStory.inferredPerformance('Mia sat beside the door.','sat').clip,'sit');
  assert.equal(AIStory.inferredPerformance('Leo typed a message.','typed').clip,'typing');
});

test('same-beat character routes are adjusted when their paths would cross',()=>{
  const draft=sample();
  draft.beats[0].vo='Max and Luna waited in the square.';
  draft.beats[0].actors=[
    {id:'hero',spot:'left',action:'idle',cue:'start',face:'neutral'},
    {id:'nbr',spot:'right',action:'idle',cue:'start',face:'neutral'}
  ];
  draft.beats[1].vo='Max ran toward the far street while Luna ran toward the other street.';
  draft.beats[1].actors=[
    {id:'hero',spot:'left',destination:'streetR',action:'run',cue:'ran',face:'neutral'},
    {id:'nbr',spot:'right',destination:'street',action:'run',cue:'ran',face:'neutral'}
  ];
  const out=AIStory.validateAndCompile(draft,{length:'short'});
  const routes=out.beats[1].plan.filter(op=>op[0]==='walk');
  assert.equal(routes.length,2);
  assert.ok(out.diagnostics.adjustments.some(x=>x.reason.includes('cruce entre personajes')));
});

test('first narrated action wins when a sentence contains more than one verb',()=>{
  const hit=AIStory.inferredPerformance('Max looked at the door and then opened it.','looked');
  assert.equal(hit.clip,'inspect');
  assert.equal(hit.cue,'looked');
  const second=AIStory.inferredPerformance('Max looked at the door and then opened it.','opened');
  assert.equal(second.clip,'useObject');
  assert.equal(second.cue,'opened');
});

test('character starts at the previous beat destination instead of teleporting',()=>{
  const draft=sample();
  draft.beats[0].actors=[{id:'hero',spot:'center',action:'idle',cue:'town',face:'neutral'}];
  draft.beats[1].vo='Max walked toward the fountain.';
  draft.beats[1].actors=[{id:'hero',spot:'right',destination:'far',action:'walk',cue:'walked',face:'neutral'}];
  draft.beats[2].vo='Max looked at the water.';
  draft.beats[2].actors=[{id:'hero',spot:'left',action:'inspect',cue:'looked',face:'neutral'}];
  const out=AIStory.validateAndCompile(draft,{length:'short'});
  const castAt=(i)=>out.beats[i].plan.find(op=>op[0]==='cast')?.[1]?.hero;
  assert.equal(castAt(0),'center');
  assert.equal(castAt(1),'center');
  assert.equal(castAt(2),'far');
  assert.ok(out.diagnostics.adjustments.some(x=>x.reason.includes('continuidad espacial')));
});

test('original director prompt requires actor-specific actions and position continuity',()=>{
  const prompt=AIStory.buildPrompt('Nobody may whistle on Sundays','mystery','short',{seed:991});
  assert.match(prompt,/su propia cláusula/i);
  assert.match(prompt,/destination de ese beat/i);
  assert.match(prompt,/beats consecutivos/i);
});


test('a sole visible character does not perform an action that happens to them',()=>{
  const cast={hero:{name:'Max'},nbr:{name:'Luna'}};
  assert.equal(AIStory.actorNarration('A door opened in front of Max.','hero',cast,1),'');
  assert.equal(AIStory.actorNarration('He opened the door.','hero',cast,1),'He opened the door.');
  assert.equal(AIStory.actorNarration('The mayor talked to the crowd.','mayor',{mayor:{name:'Mayor Bill'}},1),'The mayor talked to the crowd.');
});

test('a character who changes set without narrated travel receives a continuity warning',()=>{
  const draft=sample();
  draft.beats[0].set='home';
  draft.beats[1].set='park';
  draft.beats[1].vo='Max noticed the old sign.';
  draft.beats[1].actors=[{id:'hero',spot:'left',action:'inspect',cue:'noticed',face:'curious'}];
  const out=AIStory.validateAndCompile(draft,{length:'short'});
  assert.ok(out.diagnostics.warnings.some(x=>x.includes('cambia de localización sin un desplazamiento')));
});

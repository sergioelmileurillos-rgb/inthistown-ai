const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const root = path.resolve(__dirname, '..');
const app = fs.readFileSync(path.join(root, 'app.js'), 'utf8');
const worker = fs.readFileSync(path.join(root, 'kokoro-worker.js'), 'utf8');
const html = fs.readFileSync(path.join(root, 'index.html'), 'utf8');

test('device compatibility panel checks all critical video pipeline APIs', () => {
  assert.match(app, /async function runDeviceDiagnostics\(\)/);
  for (const capability of ['webgl2', 'MediaRecorder', 'captureStream', 'AudioContext', 'isTypeSupported']) {
    assert.ok(app.includes(capability), `missing diagnostic for ${capability}`);
  }
  assert.match(html, /id=\"deviceCheck\"/);
  assert.match(html, /id=\"deviceRecheck\"/);
});

test('mobile Kokoro starts with the lower-memory Q4 model and keeps Q8 fallback', () => {
  assert.match(app, /wasmDtypes:mobile\?\['q4','q8'\]/);
  assert.match(worker, /wasmDtypes:mobile\?\['q4','q8'\]/);
});

test('device diagnostics are available to the app runtime', () => {
  assert.match(app, /runDeviceDiagnostics\(\)\.catch/);
  assert.match(app, /runDeviceDiagnostics,getVideoPipelineCompatibility\};/);
});


test('video preflight checks the complete audio/video recording pipeline before model downloads', () => {
  assert.match(app, /function getVideoPipelineCompatibility\(\)/);
  for (const capability of ['createMediaStreamDestination', 'MediaStream', 'getMime()', 'isSecureContext', 'isContextLost']) {
    assert.ok(app.includes(capability), `missing pipeline check for ${capability}`);
  }
  assert.match(app, /const compatibility=getVideoPipelineCompatibility\(\);/);
  assert.match(app, /if\(!compatibility\.ready\)/);
});

test('diagnostics and recording preflight share the same supported output MIME selection', () => {
  assert.match(app, /const mime=recorder\?getMime\(\):''/);
  assert.match(app, /const mime=getMime\(\);if\(!mime\)/);
  assert.match(app, /getVideoPipelineCompatibility\};/);
});

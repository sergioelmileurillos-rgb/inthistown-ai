const test = require('node:test');
const assert = require('node:assert/strict');
const path = require('node:path');

global.window = global;
global.localStorage = {
  data: new Map(),
  getItem(k){ return this.data.has(k) ? this.data.get(k) : null; },
  setItem(k,v){ this.data.set(k,String(v)); },
  removeItem(k){ this.data.delete(k); }
};
global.Studio = {
  rng(seed){ let x=seed>>>0; return ()=>((x=(Math.imul(x^x>>>15,1|x)+0x6D2B79F5)|0),((x>>>0)/4294967296)); },
  randomSpec(r){ return {skin:'#f4c9a1',hair:'#222222',hairStyle:'short',shirt:'#2f6df6',pants:'#243a73',shoes:'#fff',scale:.95}; },
  PRESETS:{hero:{skin:'#f4c9a1'},cop:{skin:'#f4c9a1',hat:'#1b2a5a'},mayor:{skin:'#c68a5c',accessory:['tophat']},robot:{skin:'#8fa3bf'},monster:{scale:2.6}}
};
require('../engine/character_forge.js');

test('character forge creates saved block-style models and can select, reuse and delete them',()=>{
  const Forge=Studio.CharacterForge;
  const model=Forge.create('Alex','detective',{shirt:'#ff5500',pants:'#112233',hair:'#abcdef',skin:'#fedcba',hairStyle:'long',accessory:'sunglasses'});
  assert.equal(model.name,'Alex');
  assert.equal(model.spec.preset,'cop');
  assert.equal(model.spec.shirt,'#ff5500');
  assert.equal(model.spec.pants,'#112233');
  assert.equal(model.spec.hair,'#abcdef');
  assert.equal(model.spec.skin,'#fedcba');
  assert.equal(model.spec.hairStyle,'long');
  assert.deepEqual(model.spec.accessory,['sunglasses']);
  assert.ok(Forge.save(model));
  assert.equal(Forge.list().length,1);
  Forge.setActive(model.id);
  assert.equal(Forge.active().name,'Alex');
  assert.equal(Forge.get(model.id).spec.hat,'#1b2a5a');
  assert.ok(Forge.remove(model.id));
  assert.equal(Forge.active(),null);
});

test('cast model variations are deterministic for the same seed and distinct across seeds',()=>{
  const base={preset:'hero'};
  const a=Studio.CharacterForge.variation(base,'scene-a');
  const b=Studio.CharacterForge.variation(base,'scene-a');
  const c=Studio.CharacterForge.variation(base,'scene-b');
  assert.deepEqual(a,b);
  assert.notEqual(a.shirt,c.shirt);
});

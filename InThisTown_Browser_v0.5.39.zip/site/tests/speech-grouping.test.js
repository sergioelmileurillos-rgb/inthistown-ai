const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const vm = require('node:vm');
const source = fs.readFileSync(require('node:path').join(__dirname, '..', 'app.js'), 'utf8');

function extractFunction(name) {
  if (name === 'buildSpeechGroups') {
    const start = source.indexOf('function buildSpeechGroups(');
    const end = source.indexOf('\n  function findSpeechBreak', start);
    assert.ok(start >= 0 && end > start, 'missing buildSpeechGroups');
    return source.slice(start, end);
  }
  const match = source.match(new RegExp(`function ${name}\\([^)]*\\)\\s*\\{[\\s\\S]*?\\n  \\}`));
  assert.ok(match, `missing ${name}`);
  return match[0];
}

test('iPhone and Chromebook use smaller Kokoro speech batches', () => {
  const code = `${extractFunction('getSpeechGroupLimits')}\nresult=getSpeechGroupLimits();`;
  for (const userAgent of [
    'Mozilla/5.0 (iPhone; CPU iPhone OS 18_0 like Mac OS X)',
    'Mozilla/5.0 (X11; CrOS x86_64 14541.0.0)'
  ]) {
    const sandbox = { navigator: { userAgent, deviceMemory: 8, hardwareConcurrency: 8 }, result: null };
    vm.runInNewContext(code, sandbox);
    assert.deepEqual(JSON.parse(JSON.stringify(sandbox.result)), { maxLines: 2, maxWords: 18 });
  }
});

test('desktop keeps larger speech batches for throughput', () => {
  const sandbox = { navigator: { userAgent: 'Mozilla/5.0 (Windows NT 10.0; Win64; x64)', deviceMemory: 16, hardwareConcurrency: 16 }, result: null };
  vm.runInNewContext(`${extractFunction('getSpeechGroupLimits')}\nresult=getSpeechGroupLimits();`, sandbox);
  assert.deepEqual(JSON.parse(JSON.stringify(sandbox.result)), { maxLines: 3, maxWords: 25 });
});

test('speech grouping respects per-device limits without dropping or reordering lines', () => {
  const cleanSpokenLine = value => String(value).replace(/[^a-zA-Z0-9' ]/g, ' ').replace(/\\s+/g, ' ').trim();
  const lines = Array.from({ length: 11 }, (_, i) => `Scene ${i + 1} introduces a new event`);
  const sandbox = { cleanSpokenLine, result: null };
  vm.runInNewContext(`${extractFunction('buildSpeechGroups')}\nresult=buildSpeechGroups(${JSON.stringify(lines)}, {maxLines:2,maxWords:18});`, sandbox);
  const groups = JSON.parse(JSON.stringify(sandbox.result));
  assert.ok(groups.every(group => group.count <= 2));
  assert.deepEqual(groups.flatMap(group => group.lines), lines);
  assert.equal(groups[0].start, 0);
  assert.equal(groups.at(-1).start + groups.at(-1).count, lines.length);
});

const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const root = path.join(__dirname, '..');
const character = fs.readFileSync(path.join(root, 'engine/character.js'), 'utf8');
const director = fs.readFileSync(path.join(root, 'engine/director.js'), 'utf8');

test('face atlas includes a dedicated closed-eye blink tile with matching UV layout', () => {
  assert.match(character, /'sob','blink'/);
  assert.match(character, /case'blink':/);
  assert.match(character, /512,1024,false/);
  assert.match(character, /1\/8-2\*padV/);
});

test('blinks are deterministic per actor and do not overwrite sleep or dead expressions', () => {
  assert.match(director, /f!=='sleep'&&f!=='dead'/);
  assert.match(director, /const phase=\(h%4000\)\/1000,period=3\.2/);
  assert.match(director, /if\(blink<\.115\)return 'blink'/);
});

test('talk expression timeline remains intact alongside automatic blinking', () => {
  assert.match(director, /speechMouthPulses\(C\.words\|\|\[\],t,dd\)/);
  assert.match(director, /A\.setExpr\(start,'talk'\)/);
});

const test = require('node:test');
const assert = require('node:assert/strict');
global.window = global;
global.Studio = {
  V:{add:(a,b)=>a.map((v,i)=>v+b[i]),mul:(a,k)=>a.map(v=>v*k),dist:(a,b)=>Math.hypot(...a.map((v,i)=>v-b[i])),norm:a=>{const n=Math.hypot(...a)||1;return a.map(v=>v/n)},sub:(a,b)=>a.map((v,i)=>v-b[i]),cross:(a,b)=>[a[1]*b[2]-a[2]*b[1],a[2]*b[0]-a[0]*b[2]]},
  M:{lookAt:()=>[],persp:()=>[],tp:()=>[],mul:()=>[]},
  clamp:(n,a=0,b=1)=>Math.max(a,Math.min(b,n)),lerp:(a,b,t)=>a+(b-a)*t,ease:(name,t)=>t,hex:x=>x,mix:(a,b,t)=>a,rng:()=>()=>.5
};
require('../engine/director.js');
const gaze=Studio.Director.gazeAngles;
test('gaze points straight ahead when target is in front',()=>{
  const g=gaze([0,0,0],0,[0,4.6,10]);
  assert.ok(Math.abs(g.yaw)<1e-9); assert.ok(Math.abs(g.pitch)<1e-9);
});
test('gaze turns toward targets on either side with bounded head rotation',()=>{
  const left=gaze([0,0,0],0,[-10,4.6,10]);
  const right=gaze([0,0,0],0,[10,4.6,10]);
  assert.ok(left.yaw<0); assert.ok(right.yaw>0);
  assert.ok(Math.abs(left.yaw)<=.82&&Math.abs(right.yaw)<=.82);
});
test('gaze tilts up and down without unbounded neck rotation',()=>{
  const up=gaze([0,0,0],0,[0,100,10]);
  const down=gaze([0,0,0],0,[0,-100,10]);
  assert.ok(up.pitch<0); assert.ok(down.pitch>0);
  assert.ok(Math.abs(up.pitch)<=.38&&Math.abs(down.pitch)<=.38);
});

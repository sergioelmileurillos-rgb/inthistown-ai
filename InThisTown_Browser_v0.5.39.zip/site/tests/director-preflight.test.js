const test = require('node:test');
const assert = require('node:assert/strict');
global.window = global;
global.ITT = {};
global.Studio = {V:{},M:{},clamp:(n,a,b)=>Math.max(a,Math.min(b,n)),lerp:(a,b,t)=>a+(b-a)*t,ease:(n,t)=>t,hex:x=>x,mix:(a,b,t)=>a,rng:()=>()=>.5};
require('../engine/director.js');
require('../shortform-director.js');
require('../episode-preflight.js');

test('short-form director detects an opening hook and creates motivated shot holds', () => {
  const beats = [
    {id:'a',text:'What if nobody could open a window after midnight?',duration:3,locationId:'street',sceneId:'street'},
    {id:'b',text:'But then Max heard a strange sound.',duration:3,locationId:'street',sceneId:'street'},
    {id:'c',text:'The truth was hidden behind the mirror.',duration:3,locationId:'room',sceneId:'room',forceCut:true},
    {id:'d',text:'In the end, the mayor was the shadow.',duration:3,locationId:'room',sceneId:'room'}
  ];
  const score = ITT.Shortform.scoreShortformScript(beats.map(x=>x.text).join(' '),{targetSeconds:12});
  const shots = ITT.Shortform.planShotRhythm(beats,{maxHoldSeconds:6});
  assert.ok(score.score > 0 && score.score <= 100);
  assert.ok(shots.length >= 2);
  assert.ok(shots[0].beatIds.includes('a'));
});

test('episode preflight accepts contiguous shots and flags a missing actor', () => {
  const good = ITT.EpisodePreflight.validateEpisodeTimeline({
    duration:4,
    shots:[{id:'s1',start:0,end:2,actorIds:['hero']},{id:'s2',start:2,end:4,actorIds:['hero']}],
    captions:[{id:'c1',start:0,end:1.8,text:'Nobody knew the rule.'}],
    events:[{id:'e1',time:1,type:'anim',actorId:'hero'}],
    inventory:{actors:['hero'],objects:[]}
  });
  assert.equal(good.blockers,0);
  const bad = ITT.EpisodePreflight.validateEpisodeTimeline({
    duration:2,shots:[{id:'s1',start:0,end:2,actorIds:['ghost']}],inventory:{actors:['hero']}
  });
  assert.ok(bad.blockers > 0);
});


test('renderer separates characters that start or move into the same floor position',()=>{
  const makeActor=(x,z)=>({phase:false,visAt:()=>true,posAt:()=>[x,0,z],scale:{eval:()=>1},char:{spec:{scale:1}}});
  const scene={allowOverlap:false};
  const C={scene,actors:{hero:makeActor(0,10),neighbor:makeActor(0,10)}};
  const first=Studio.Director.resolvedActorPositions(C,1);
  const d=Math.hypot(first.hero[0]-first.neighbor[0],first.hero[2]-first.neighbor[2]);
  assert.ok(d>=2.14,`expected separated actors, got ${d}`);
  const second=Studio.Director.resolvedActorPositions(C,1);
  assert.deepEqual(first,second,'separation should be deterministic at a given frame');
});

const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const vm = require('node:vm');

function loadStudio(){
  const Studio={
    clamp:(n,a=0,b=1)=>Math.max(a,Math.min(b,n)),
    lerp:(a,b,t)=>a+(b-a)*t,
    ease:(name,t)=>t,
    V:{},M:{},hex:x=>x,mix:(a,b,t)=>a,rng:()=>()=>.5,env:()=>({}),
    Character:class Character{constructor(id,spec){this.id=id;this.spec=spec||{};}}
  };
  const sandbox={window:{Studio},console,Math,Set,Map,Object,Array,Number,String,Boolean,RegExp,Float32Array};
  sandbox.window.window=sandbox.window;
  for(const file of ['engine/anim.js','engine/director.js'])
    vm.runInNewContext(fs.readFileSync(path.join(__dirname,'..',file),'utf8'),sandbox,{filename:file});
  return Studio;
}

test('idle characters have subtle deterministic movement with individual phase offsets',()=>{
  const Studio=loadStudio();
  const story={seed:1,characters:{hero:{},friend:{}},defaults:{}};
  const scene={id:'idle',dur:4,actors:{hero:{pos:[-2,0,8]},friend:{pos:[2,0,8]}},cam:[{at:0,shot:'wide'}]};
  const compiled=Studio.Director.compileScene(null,story,scene,{fast:true});
  const hero=compiled.actors.hero.pose(1.37);
  const friend=compiled.actors.friend.pose(1.37);
  assert.ok(Math.abs(hero.torsoX)>0 || Math.abs(hero.headY)>0 || Math.abs(hero.bodyY)>0);
  assert.notEqual(hero.headY,friend.headY,'actors should not sway in sync');
  const again=Studio.Director.compileScene(null,story,scene,{fast:true});
  const repeated=again.actors.hero.pose(1.37);
  for(const key of Object.keys(hero)) assert.equal(hero[key],repeated[key],`pose key ${key} should be deterministic`);
});

test('authored animation still overrides idle motion',()=>{
  const Studio=loadStudio();
  const story={seed:1,characters:{hero:{}},defaults:{}};
  const scene={id:'action',dur:2,actors:{hero:{pos:[0,0,8]}},actions:[{actor:'hero',at:0,do:'anim',clip:'wave',dur:1}],cam:[{at:0,shot:'medium'}]};
  const compiled=Studio.Director.compileScene(null,story,scene,{fast:true});
  const pose=compiled.actors.hero.pose(.4);
  assert.ok(pose.rArmZ>2,'the authored wave pose should remain active');
});

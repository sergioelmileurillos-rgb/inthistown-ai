const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const source = fs.readFileSync(path.join(__dirname, '../engine/character.js'), 'utf8');

test('face atlas disables mipmaps to prevent expressions bleeding into adjacent cells', () => {
  assert.match(source, /canvasTex\('faces-v2',[\s\S]*?512,1024,false\)/);
});

test('face quad is offset beyond the head surface to avoid depth fighting', () => {
  assert.match(source, /off:\[0,\.65,\.705\]/);
});

test('face UVs are inset to avoid sampling neighbouring atlas cells', () => {
  assert.match(source, /padU=4\/512,padV=4\/1024/);
  assert.match(source, /\.25-2\*padU,1\/8-2\*padV/);
});

test('unknown facial expressions fall back to neutral instead of an arbitrary atlas tile', () => {
  assert.match(source, /fi<0\?FACES\.indexOf\('neutral'\):fi/);
});

 test('face texture is rendered unlit so lighting cannot wash out facial features', () => {
  assert.match(source, /o\.color=\[1,1,1\];o\.unlit=true/);
});

 test('face plane has a larger depth gap and slightly smaller footprint', () => {
  assert.match(source, /off:\[0,\.65,\.705\],size:\[\.98,\.98,1\]/);
});

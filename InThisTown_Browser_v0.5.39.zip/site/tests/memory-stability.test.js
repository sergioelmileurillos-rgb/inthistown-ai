const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');

const root = path.join(__dirname, '..');
const app = fs.readFileSync(path.join(root, 'app.js'), 'utf8');
const html = fs.readFileSync(path.join(root, 'index.html'), 'utf8');
const sw = fs.readFileSync(path.join(root, 'sw.js'), 'utf8');

test('Kokoro worker is terminated after narration has been copied into AudioBuffer', () => {
  const synth = app.slice(app.indexOf('async function synthesize'), app.indexOf('function wrapLine'));
  assert.match(app, /function releaseKokoroWorker\(\)/);
  assert.match(synth, /b\.getChannelData\(0\)\.set\(joined\);[\s\S]*?releaseKokoroWorker\(\);/);
  assert.match(synth, /return \{timings,duration:joined\.length\/sampleRate,buffer:b/);
  assert.doesNotMatch(synth, /return \{pcm:joined/);
});

test('3D rendering is throttled to the MediaRecorder FPS, not every display refresh', () => {
  assert.match(app, /const frameInterval=1000\/FPS/);
  assert.match(app, /rafTime-lastFrameAt<frameInterval-1/);
  assert.match(app, /requestAnimationFrame\(tick\)/);
});

test('WebGL context loss is surfaced as a useful status rather than silently continuing', () => {
  assert.match(app, /addEventListener\('webglcontextlost'/);
  assert.match(app, /ha perdido el contexto gráfico durante el render/);
});

test('deployed page and service worker cache use the new app version', () => {
  assert.match(html, /BROWSER v0\.5\.39/);
  assert.match(html, /app\.js\?v=0\.5\.39/);
  assert.match(sw, /in-this-town-shell-v5-41/);
  assert.match(sw, /fetch\(e\.request\)/);
});

test('cancellation checks do not depend on an out-of-scope helper and cancel button updates state', () => {
  assert.doesNotMatch(app, /checkCancel\s*\(/);
  assert.match(app, /if\(state\.cancel\) throw new Error\('Cancelado por el usuario\.'\);/);
  assert.match(app, /\$\('cancel'\)\.addEventListener\('click'/);
});

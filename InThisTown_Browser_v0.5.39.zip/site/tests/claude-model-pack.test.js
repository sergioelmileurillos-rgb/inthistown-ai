const test=require('node:test');
const assert=require('node:assert/strict');
const fs=require('node:fs');
const path=require('node:path');
const AIStory=require('../ai-story-director.js');

const root=path.join(__dirname,'..');
const index=fs.readFileSync(path.join(root,'index.html'),'utf8');
const sw=fs.readFileSync(path.join(root,'sw.js'),'utf8');

test('all three Claude model packs are loaded by the main app and service worker',()=>{
  for(const file of ['props_monsters.js','props_town.js','props_world3.js']){
    assert.ok(fs.existsSync(path.join(root,'engine',file)),`${file} exists`);
    assert.ok(index.includes(`engine/${file}`),`${file} is in index`);
    assert.ok(sw.includes(`engine/${file}`),`${file} is precached`);
  }
});

test('AI prompt receives the exact installed model catalogue',()=>{
  global.Studio={Props:{lib:{church:()=>[],spider_giant:()=>[],icecream_truck:()=>[]}}};
  const prompt=AIStory.buildPrompt('The town closes at noon','mystery','short',{seed:123});
  assert.match(prompt,/CATÁLOGO REAL DE MODELOS DISPONIBLES/);
  assert.match(prompt,/church/);
  assert.match(prompt,/spider_giant/);
  assert.match(prompt,/icecream_truck/);
  delete global.Studio;
});

test('AI story validator accepts exact registered model keys and checks their narration cue',()=>{
  global.Studio={Props:{lib:{church:()=>[]}}};
  const base={
    title:'The Silent Church',premise:'Nobody may speak at noon',
    cast:{hero:{name:'Max',preset:'hero'}},
    beats:Array.from({length:12},(_,i)=>({
      role:i===0?'hook':i===11?'payoff':'build',set:'street',
      vo:i===2?'Max entered the old church.':`Max looked around the quiet street ${i}.`,
      actors:[{id:'hero',spot:['center','left','right','yardL','yardR','street','streetR','plaza','podium','door','far','room'][i],action:i===2?'walk':'lookAround',cue:i===2?'entered':'looked',face:'neutral',duration:1}],
      props:i===2?[{id:'church_1',type:'church',spot:'right',transition:'appear',action:'none',cue:'church'}]:[],
      camera:{shot:'medium',focus:['hero'],move:'drift',at:'start',amount:.1}
    }))
  };
  const compiled=AIStory.validateAndCompile(base,{length:'short'});
  assert.ok(compiled.beats[2].plan.some(op=>op[0]==='obj'&&op[2]==='church'));
  delete global.Studio;
});

const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const vm = require('node:vm');

function loadApp(){
  const elements = new Map();
  const context2d = {drawImage(){},createLinearGradient(){return {addColorStop(){}}},fillRect(){},save(){},restore(){},fillText(){},measureText(t){return {width:String(t).length*12}},beginPath(){},roundRect(){},fill(){},stroke(){}};
  const get = id => {
    if(!elements.has(id))elements.set(id,{id,value:id==='tone'?'mystery':id==='length'?'medium':'',textContent:'',innerHTML:'',style:{},disabled:false,checked:false,open:false,dataset:{},files:[],classList:{add(){},remove(){},contains(){return false}},addEventListener(){},focus(){},getContext(){return context2d}});
    return elements.get(id);
  };
  const document={getElementById:get,querySelectorAll(){return []}};
  const engineText=['engine/anim.js','engine/anim_extra.js'].map(f=>fs.readFileSync(path.join(__dirname,'..',f),'utf8')).join('\n');
  const clips={};for(const match of engineText.matchAll(/C\.([A-Za-z0-9_]+)\s*=/g))clips[match[1]]=true;
  const fxCore=fs.readFileSync(path.join(__dirname,'..','engine/fx.js'),'utf8');
  const fxExtra=fs.readFileSync(path.join(__dirname,'..','engine/fx_extra.js'),'utf8');
  const fxNames=[...fxCore.matchAll(/^\s{2}([A-Za-z0-9_]+)\(a,r\)\{/gm)].map(m=>m[1]);
  const extraNames=fxExtra.match(/S\.Fx\.extraNames=\[([^\]]+)\]/s)?.[1].match(/'([^']+)'/g)?.map(x=>x.slice(1,-1))||[];
  const fxInventory=Object.fromEntries([...new Set([...fxNames,...extraNames])].map(x=>[x,true]));
  const Studio={
    PRESETS:{hero:{},mayor:{},robot:{},nurse:{},catgirl:{},nerd:{},builder:{},farmer:{},athlete:{},chef:{}},
    Anim:{clips},Fx:{GEN:fxInventory},
    V:{},M:{},clamp:(n,a,b)=>Math.max(a,Math.min(b,n)),lerp:(a,b,t)=>a+(b-a)*t,ease:(name,t)=>t,hex:x=>x,mix:(a,b,t)=>a,rng:()=>()=>.5,env:()=>({}),
    Character:class Character{constructor(id,spec){this.id=id;this.spec=spec||{};}},
    AssetForge:{ensure(kind,seed){return{id:'forge_'+kind,kind,variant:0,reused:false,partCount:8}},inventory(){return 1}},
    api:{init(){return{gl:'mock'}},setStory(){},compile(){return{warns:[],sfx:[]}},validate(){return{issues:[],sfx:[]}},frame(){}}
  };
  const store=new Map();const localStorage={getItem(k){return store.get(k)||null;},setItem(k,v){store.set(k,String(v));},removeItem(k){store.delete(k);}};
  const sandbox={console,document,Studio,localStorage,location:{protocol:'file:'},navigator:{},URL,Blob,Map,Set,Float32Array,Math,Date,Number,String,Array,Object,JSON,RegExp,Error,Promise,performance:{now:()=>0},setTimeout,clearTimeout,requestAnimationFrame(){},MediaStream:function(){},window:null};
  sandbox.window=sandbox;sandbox.globalThis=sandbox;sandbox.ITT={};sandbox.addEventListener=()=>{};
  const root=path.join(__dirname,'..');
  for(const file of ['engine/character_forge.js','story-engine.js','ai-story-director.js','story-plan-adapter.js','engine/director.js','shortform-director.js','episode-preflight.js','timing.js','sfx.js','app.js']){
    vm.runInNewContext(fs.readFileSync(path.join(root,file),'utf8'),sandbox,{filename:file});
  }
  return sandbox;
}

test('browser app adapts visual plans across 12 premises and 3 tones',()=>{
  const app=loadApp();
  let reactionTotal=0;
  const premises=[
    'Nobody is allowed to open a window after midnight',
    'Every lie makes you shrink by one inch',
    'You can only walk backwards after sunset',
    'Nobody may whistle on Sundays',
    'If you sneeze, the lights go out',
    'No one can look at the moon',
    'Never eat pizza on Tuesdays',
    'Nobody can knock on the red door',
    'Everyone must wear a hat',
    'Nobody is allowed to read books at night',
    'You cannot touch the golden statue',
    'Nobody can turn on a light after dark'
  ];
  for(let pi=0;pi<premises.length;pi++)for(const tone of ['mystery','funny','suspense']){
    const premise=premises[pi],story=app.ITT.app.buildStory(premise,tone,'medium',1700000000000+pi*17+tone.length);
    assert.ok(story.scenes.length>=10,premise+' / '+tone);
    const timings=story.scenes.map((scene,j)=>{
      const words=(scene.vo.match(/[a-z0-9']+/gi)||[]),n=Math.max(1,words.length),speech=2.8;
      return {duration:3,speechDuration:speech,start:j*3,words:words.map((w,k)=>({w,s:k/n*speech,e:(k+1)/n*speech}))};
    });
    const timing={timings,duration:story.scenes.length*3};
    app.ITT.app.prepareChoreography(story,timing);
    assert.ok(story.editorialShots.length>0,premise+' / '+tone);
    assert.ok(story.scenes.every(s=>s.cam.length>=1),premise+' / '+tone+' needs camera coverage');
    assert.ok(story.scenes.some(s=>s.planDiagnostics?.source==='semantic'),premise+' / '+tone+' should use authored plans');
    assert.ok(story.scenes.every(s=>s.objects.every(o=>o.id!=='storyProp')),premise+' / '+tone+' semantic scenes must not receive a generic story prop');
    reactionTotal+=story.scenes.reduce((sum,s)=>sum+(s.planDiagnostics?.reactions||0),0);
    assert.ok(new Set(story.scenes.map(s=>s.cam[0]?.shot).filter(Boolean)).size>=2,premise+' / '+tone+' should vary its shot language');
    assert.ok(story.scenes.every(s=>s.actions.every(a=>Number.isFinite(a.at)&&a.at>=0&&a.at<s.dur)),premise+' / '+tone+' has invalid action timing');
    assert.ok(story.scenes.every(s=>s.cam.every(c=>Number.isFinite(c.at)&&c.at>=0&&c.at<s.dur)),premise+' / '+tone+' has invalid camera timing');
    assert.ok(story.scenes.every(s=>s.carryAllObjects===false),premise+' / '+tone+' must disable global object carry to prevent props leaking between locations');
    for(let j=0;j<story.scenes.length-1;j++){
      const current=story.scenes[j],next=story.scenes[j+1],nextIds=new Set(next.objects.map(o=>o.id));
      for(const item of current.objects){
        if(['storyPropLeft','storyPropRight','heroTool'].includes(item.id))continue;
        const sameSet=current.world?.[0]?.type===next.world?.[0]?.type;
        const explicitReference=(next.narrativePlan||[]).some(op=>Array.isArray(op)&&op.some(v=>v===item.id));
        if(sameSet||explicitReference)assert.ok(nextIds.has(item.id),premise+' / '+tone+' lost a prop that should persist: '+item.id+' after scene '+(j+1));
      }
    }
    let priorActors={},priorObjects={};
    for(let j=0;j<story.scenes.length;j++){
      const compiled=app.Studio.Director.compileScene(null,story,story.scenes[j],{fast:true,prevEnd:priorActors,prevObjects:priorObjects});
      assert.equal(compiled.warns.length,0,premise+' / '+tone+' / scene '+(j+1)+' engine warnings: '+compiled.warns.join(' | '));
      priorActors=compiled.end;priorObjects=compiled.endObjects;
    }
    const unsupported=story.scenes.flatMap((s,j)=>Object.entries(s.planDiagnostics?.unsupported||{}).map(([op,n])=>`${j+1}:${op}(${n})`));
    assert.equal(unsupported.length,0,premise+' / '+tone+' has unsupported operations: '+unsupported.join(', '));
    const report=app.ITT.app.preflight(story,timing);
    assert.ok(!report.some(x=>x.sev==='error'),premise+' / '+tone+'\n'+report.filter(x=>x.sev==='error').map(x=>x.msg).join('\n'));
  }
  assert.equal(reactionTotal,0,'the adapter must not invent witness reactions absent from the authored beat plan');
});


test('a saved custom protagonist supplies both the 3D model and the spoken character name',()=>{
  const app=loadApp();
  const Forge=app.Studio.CharacterForge;
  const custom=Forge.create('Milo Custom','townie',{shirt:'#123456',pants:'#654321',hair:'#abcdef',skin:'#fedcba',hairStyle:'spiky',accessory:'headphones'});
  assert.ok(Forge.save(custom));Forge.setActive(custom.id);
  const story=app.ITT.app.buildStory('Every lie makes you shrink by one inch','funny','medium',1717171717);
  assert.equal(story.storyArc.hero,'Milo Custom');
  assert.equal(story.characters.hero.shirt,'#123456');
  assert.ok(story.scenes.some(scene=>scene.vo.includes('Milo Custom')));
});

test('an imported AI director script takes priority and becomes the actual 3D scene plan',()=>{
  const app=loadApp();
  const input={
    title:'The Silent Sunday',premise:'Nobody may whistle on Sundays',
    cast:{hero:{name:'Max',preset:'hero'},nbr:{name:'Luna',preset:'boy2'},mayor:{name:'Mayor Bill',preset:'mayor'}},
    beats:Array.from({length:12},(_,i)=>{
      const lines=['In this town, nobody may whistle.','Max heard a strange sound.','He sneaked toward the old park.','Then Luna ran away.','Max pointed at the empty bench.','He inspected a strange footprint.','Luna waved beside the fountain.','Max shrugged and checked his watch.','The mayor talked to the crowd.','Max hid behind the statue.','The town finally won its silence.','Everyone waved at the quiet hero.'];
      const actors=['hero','nbr','hero','nbr','hero','hero','nbr','hero','mayor','hero','hero','nbr'];
      const spots=['center','left','right','yardL','yardR','street','streetR','plaza','podium','door','far','room'];
      const action=['lookAround','think','sneak','run','point','inspect','wave_big','shrug','talk','hide','victory','wave_big'][i];
      const cue=['town','heard','sneaked','ran','pointed','inspected','waved','shrugged','talked','hid','won','waved'][i];
      return {role:i===0?'hook':i===11?'payoff':i===10?'twist':'build',set:['street','park','city','townhall'][i%4],vo:lines[i],actors:[{id:actors[i],spot:spots[i],action,cue,face:'neutral'}],props:[],camera:{shot:'wide',focus:[actors[i]],move:'drift',at:'start'}};
    })
  };
  app.ITT.app.state.aiDraft=app.ITT.AIStory.validateAndCompile(input,{tone:'mystery',length:'short'});
  const story=app.ITT.app.buildStory('Nobody may whistle on Sundays','mystery','short',1234);
  assert.equal(story.storyArc.archetype,'ai-original');
  assert.equal(story.title,'The Silent Sunday');
  assert.equal(story.scenes[1].vo,'Max heard a strange sound.');
  assert.ok(story.scenes.every(scene=>scene.narrativePlan?.length));
});

test('AI-planned props stay hidden until their exact spoken cue and animate at that cue',()=>{
  const app=loadApp();
  const lines=['In this town, nobody may open windows.','Max heard a strange noise outside.','Max opened the window slowly.','A cold breeze entered the room.','Luna noticed the moving curtain.','Max looked toward the empty street.','The mayor arrived with a warning.','Luna pointed toward the open window.','Max closed it before sunset.','The town finally understood the rule.','Nobody touched another window again.','Max locked every window before bedtime.'];
  const actors=lines.map((line,i)=>({id:i===4||i===7?'nbr':i===6?'mayor':'hero',spot:['center','left','right','yardL','yardR','street','streetR','plaza','podium','door','far','room'][i],action:i===2?'inspect':'lookAround',cue:(line.toLowerCase().match(/[a-z']+/g)||[])[1]||'Max',face:'neutral'}));
  const data={premise:'Nobody may open windows after midnight',title:'The Window Test',cast:{hero:{name:'Max'},nbr:{name:'Luna'}},beats:lines.map((vo,i)=>({role:i===0?'hook':i===11?'payoff':'build',set:'home',vo,actors:[actors[i]],props:i===2?[{id:'window1',type:'window',spot:'right',transition:'fadeIn',action:'open',actor:'hero',cue:'window'}]:[],camera:{shot:'medium',focus:[actors[i].id],move:'drift',at:'start'}}))};
  const draft=app.ITT.AIStory.validateAndCompile(data,{length:'short'});
  app.ITT.app.state.aiDraft=draft;
  const story=app.ITT.app.buildStory(data.premise,'mystery','short',7);
  const timings=story.scenes.map(scene=>{const tokens=scene.vo.split(/\\s+/);return{duration:3,speechDuration:2.8,start:0,words:tokens.map((w,i)=>({w,s:i*.2,e:i*.2+.1}))};});
  app.ITT.app.prepareChoreography(story,{timings,duration:story.scenes.length*3});
  const target=story.scenes[2];const object=target.objects.find(o=>o.id==='window1');
  assert.ok(object);assert.equal(object.visible,false);
  assert.ok(target.actions.some(a=>a.obj==='window1'&&a.do==='show'&&a.at>0));
  assert.ok(target.actions.some(a=>a.obj==='window1'&&a.do==='yawTo'&&a.at>0));
});


test('semantic props do not bleed into a different location unless the next beat mentions them',()=>{
  const app=loadApp();
  const data={title:'The travelling door',premise:'Nobody may open windows after midnight',cast:{hero:{name:'Max'}},beats:Array.from({length:12},(_,i)=>({
    role:i===0?'hook':i===11?'payoff':'build',set:i===1?'home':'park',
    vo:i===0?'Nobody may open windows after midnight.':i===1?'Max opened the door.':i===2?'At the park, Max looked at the door again.':`Max walked through the park, scene ${i}.`,
    actors:[{id:'hero',spot:'center',action:i===2?'walk':'idle',cue:i===0?'Nobody':i===2?'walked':'Max',face:'neutral',...(i===2?{destination:'right'}:{})}],
    props:i===1?[{id:'door1',type:'door',spot:'right',transition:'appear',action:'open',actor:'hero',cue:'door',actionCue:'opened'}]:[],camera:{shot:'medium',focus:['hero'],move:'drift',at:'start'}
  }))};
  app.ITT.app.state.aiDraft=app.ITT.AIStory.validateAndCompile(data,{length:'short'});
  const story=app.ITT.app.buildStory(data.premise,'mystery','short',333);
  const timings=story.scenes.map(scene=>({duration:3,speechDuration:2.7,start:0,words:scene.vo.split(/\\s+/).map((w,i)=>({w,s:i*.2,e:i*.2+.1}))}));
  app.ITT.app.prepareChoreography(story,{timings,duration:timings.length*3});
  const first=story.scenes[1],next=story.scenes[2];
  assert.ok(first.objects.some(o=>o.id==='door1'));
  assert.ok(!next.objects.some(o=>o.id==='door1'),'a noun mention in a new set must not teleport the old object');
  assert.equal(next.carryAllObjects,false);
});

test('completed stories are remembered locally as anti-repetition context for future AI prompts',()=>{
  const app=loadApp();
  const story={title:'The Empty Lighthouse',rule:'Nobody can climb the lighthouse',source:'external-llm',storyArc:{archetype:'ai-original',hero:'Milo',neighbor:'Tess'},scenes:[
    {vo:'Nobody can climb the lighthouse.',world:[{type:'coast'}],objects:[]},
    {vo:'Milo found a strange map.',world:[{type:'coast'}],objects:[{type:'map'}]},
    {vo:'Tess turned the old radio on.',world:[{type:'townhall'}],objects:[{type:'radio'}]},
    {vo:'The lighthouse keeper revealed the signal.',world:[{type:'lighthouse'}],objects:[{type:'lamp'}]},
    {vo:'The town followed the signal home.',world:[{type:'plaza'}],objects:[]}
  ]};
  const history=app.ITT.app.rememberStory(story);
  assert.equal(history.length,1);
  assert.equal(history[0].title,'The Empty Lighthouse');
  assert.ok(history[0].beats.some(line=>/map|radio|signal/i.test(line)));
  assert.equal(app.ITT.app.getStoryHistory()[0].archetype,'ai-original');
});

test('descriptive exception premise reaches the real 3D pipeline without corrupt verbs or generic props',()=>{
  const app=loadApp();
  const story=app.ITT.app.buildStory('In this town, everyone is poor except the mayor','mystery','medium',2026111901);
  assert.equal(story.storyArc.archetype,'condition');
  assert.ok(story.scenes.some(s=>/receipt|public money|supplies|wages/i.test(s.vo)));
  assert.ok(story.scenes.every(s=>!/iing poor|stopped iing/i.test(s.vo)));
  const timings=story.scenes.map((scene,i)=>{const words=scene.vo.match(/[a-z0-9']+/gi)||[];return{duration:3,speechDuration:2.8,start:i*3,words:words.map((w,k)=>({w,s:k/Math.max(1,words.length)*2.8,e:(k+1)/Math.max(1,words.length)*2.8}))};});
  app.ITT.app.prepareChoreography(story,{timings,duration:story.scenes.length*3});
  assert.ok(story.scenes.every(s=>s.cam.length>0));
  assert.ok(story.scenes.every(s=>Object.keys(s.planDiagnostics?.unsupported||{}).length===0));
  const report=app.ITT.app.preflight(story,{timings,duration:story.scenes.length*3});
  assert.ok(!report.some(x=>x.sev==='error'),report.filter(x=>x.sev==='error').map(x=>x.msg).join('\n'));
});

test('locally authored lighting is respected and the ending does not turn blue/night without a story cue',()=>{
  const app=loadApp();
  const story=app.ITT.app.buildStory('In this town, everyone is poor except the mayor','mystery','medium',2026111902);
  assert.ok(story.scenes.every(scene=>scene.sky==='day'));
  const warning=app.ITT.app.buildStory('Nobody is allowed to open a window after midnight','suspense','medium',2026111903);
  assert.ok(warning.scenes.some(scene=>scene.sky==='night'));
});

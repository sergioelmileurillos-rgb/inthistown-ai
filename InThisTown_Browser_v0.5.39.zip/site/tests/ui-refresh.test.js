const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const root = path.join(__dirname, '..');
const html = fs.readFileSync(path.join(root, 'index.html'), 'utf8');
const app = fs.readFileSync(path.join(root, 'app.js'), 'utf8');
const sw = fs.readFileSync(path.join(root, 'sw.js'), 'utf8');

test('studio navigation links to the four main work areas', () => {
  for (const id of ['idea', 'aiDirector', 'characterLab', 'gallery']) {
    assert.match(html, new RegExp(`href="#${id}"`), `Missing quick link for ${id}`);
    assert.match(html, new RegExp(`id="${id}"`), `Missing target ${id}`);
  }
});

test('character lab and resource library are separate workspace cards', () => {
  assert.match(html, /class="tools-grid"/);
  assert.match(html, /class="tool-card" id="characterLab"/);
  assert.match(html, /class="tool-card" id="gallery"/);
});

test('external AI director explains the copy-and-paste workflow', () => {
  assert.match(html, /Genera el prompt/);
  assert.match(html, /Pásalo a ChatGPT o Claude/);
  assert.match(html, /Pega el JSON aquí/);
});

test('the refreshed page keeps all IDs referenced by the application', () => {
  const ids = new Set([...html.matchAll(/id="([^"]+)"/g)].map(m => m[1]));
  const used = new Set([...app.matchAll(/\$\('([^']+)'\)/g)].map(m => m[1]));
  for (const id of used) assert.ok(ids.has(id), `Missing application control: ${id}`);
});

test('new interface version and cache are aligned', () => {
  assert.match(html, /BROWSER v0\.5\.39/);
  assert.match(html, /app\.js\?v=0\.5\.39/);
  assert.match(sw, /in-this-town-shell-v5-41/);
});

test('responsive and keyboard accessibility rules are present', () => {
  assert.match(html, /@media\(max-width:720px\)/);
  assert.match(html, /:focus-visible/);
  assert.match(html, /prefers-reduced-motion/);
});


test('small rule and setting drafts are restored and saved locally without network calls', () => {
  const helper = fs.readFileSync(path.join(root, 'studio-ui.js'), 'utf8');
  assert.match(html, /id="draftStatus"/);
  assert.match(html, /src="studio-ui\.js"/);
  assert.match(sw, /\.\/studio-ui\.js/);
  assert.match(helper, /localStorage\.getItem\(KEY\)/);
  assert.match(helper, /localStorage\.setItem\(KEY/);
  assert.doesNotMatch(helper, /fetch\(|XMLHttpRequest|WebSocket/);
});


test('quick navigation automatically opens collapsed workspace details', () => {
  const helper = fs.readFileSync(path.join(root, 'studio-ui.js'), 'utf8');
  assert.match(helper, /querySelectorAll\('\.quicknav a'\)/);
  assert.match(helper, /target\.open = true/);
});

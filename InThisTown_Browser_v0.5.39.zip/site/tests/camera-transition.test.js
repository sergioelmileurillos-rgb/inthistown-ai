const test = require('node:test');
const assert = require('node:assert/strict');
global.window = global;
global.Studio = {
  V:{add:(a,b)=>a.map((v,i)=>v+b[i]),mul:(a,k)=>a.map(v=>v*k),dist:(a,b)=>Math.hypot(...a.map((v,i)=>v-b[i])),norm:a=>{const n=Math.hypot(...a)||1;return a.map(v=>v/n)},sub:(a,b)=>a.map((v,i)=>v-b[i]),cross:(a,b)=>[a[1]*b[2]-a[2]*b[1],a[2]*b[0]-a[0]*b[2],a[0]*b[1]-a[1]*b[0]]},
  M:{lookAt:()=>[],persp:()=>[],tp:()=>[],mul:()=>[]},
  clamp:(n,a=0,b=1)=>Math.max(a,Math.min(b,n)),lerp:(a,b,t)=>a+(b-a)*t,ease:(name,t)=>t,hex:x=>x,mix:(a,b,t)=>a,rng:()=>()=>.5
};
require('../engine/director.js');
const makeTimeline=()=>({actors:{},objects:{},shakes:[],cams:[
  {t0:0,t1:3,pos:[0,3,10],look:[0,2,0],fov:55},
  {t0:3,t1:6,pos:[10,3,0],look:[0,2,0],fov:45,transition:.3}
]});
test('camera cut blends continuously from the previous framing',()=>{
  const C=makeTimeline(),D=Studio.Director;
  const before=D.camEval(C,2.999),at=D.camEval(C,3),after=D.camEval(C,3.001);
  const distance=(a,b)=>Math.hypot(...a.map((v,i)=>v-b[i]));
  assert.ok(distance(before.pos,at.pos)<.02,'no large jump at the cut boundary');
  assert.ok(distance(at.pos,after.pos)<.02,'transition begins smoothly');
  assert.ok(distance(at.pos,D.camEval(C,3.3).pos)>1,'new framing is reached');
});
test('camera transition is deterministic and can be disabled per cut',()=>{
  const C=makeTimeline(),D=Studio.Director;
  assert.deepEqual(D.camEval(C,3.12),D.camEval(C,3.12));
  C.cams[1].transition=0;
  const noBlend=D.camEval(C,3);
  assert.ok(Number.isFinite(noBlend.pos[0]));
});

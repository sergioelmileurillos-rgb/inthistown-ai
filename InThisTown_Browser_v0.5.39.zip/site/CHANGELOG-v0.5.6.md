# In This Town Browser v0.5.6

## Continuidad de props y puesta en escena
- El motor ahora guarda el estado final de cada objeto: posición, rotación, tamaño, transparencia, visibilidad, inclinación y accesorios activos.
- La API de escenas transporta los objetos entre cortes y restaura props aunque no vuelvan a declararse en el siguiente beat.
- La preparación de historia conserva los objetos semánticos creados por el guion; un objeto como una criatura revelada puede aparecer y seguir siendo el mismo objeto en planos posteriores.
- Se mantienen locales las copias de expansión y herramientas de mano para evitar que se acumulen por toda la historia.

## Reacciones y cámaras
- Se añade una reacción de testigo cuando un suceso narrativo importante necesita respuesta visual y existe un personaje disponible que no tenga una actuación propia en ese beat.
- Las reacciones se sincronizan con palabras del diálogo/narración y usan clips y expresiones ya existentes en el motor.
- Se normalizan expresiones equivalentes, por ejemplo `gasp` a `shock`, para evitar caras no incluidas en el atlas.
- Cuando dos escenas consecutivas del mismo decorado usan el mismo primer plano de cámara, se elige un encuadre alternativo compatible.
- Si una escena tiene un único encuadre y un objeto cambia o aparece a mitad del beat, puede añadirse un plano corto motivado por ese evento.

## Pruebas
- 14 pruebas automatizadas pasan.
- Corpus de integración: 12 premisas × 3 tonos.
- Se comprueban continuidad de objetos entre escenas, transformaciones, visibilidad, reacciones de testigos, variedad de encuadres, acciones y cámaras temporizadas.
- Todos los archivos JavaScript pasan la comprobación de sintaxis.

## Límites conocidos
- La alineación de palabra sigue siendo una estimación basada en la forma de onda.
- La exportación final con Kokoro, WebGL2 y MediaRecorder no se ha validado en el dispositivo real del usuario.
- El generador sigue siendo local y basado en reglas/arquetipos; no es un modelo de IA generativa conectado a la nube.

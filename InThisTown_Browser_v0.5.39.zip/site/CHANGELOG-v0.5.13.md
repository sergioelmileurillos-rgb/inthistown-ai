# In This Town Browser v0.5.13

## Corrección de carga y cancelación
- El error `ReferenceError: checkCancel is not defined` ya no depende de una función auxiliar: las comprobaciones de cancelación se realizan directamente en cada fase.
- Se añade una URL versionada `app.js?v=0.5.13` para evitar reutilizar un `app.js` antiguo desde cachés del navegador.
- El service worker usa una caché nueva (`v5-15`) y prioriza la red para la página y el JavaScript principal, conservando una copia local como respaldo sin conexión.
- Se actualizan las pruebas para detectar llamadas a la función antigua y comprobar la estrategia de actualización.

La corrección del código se ha validado con comprobaciones sintácticas y pruebas automatizadas. No se ha realizado una exportación real en el Chromebook del usuario.

# In This Town Browser v0.5.37

## Camera transitions
- Camera changes now blend smoothly across a short, deterministic transition instead of snapping instantly between framings.
- Each camera cut can set `transition` in seconds; `transition: 0` preserves a hard cut. Default transition is 0.28 seconds.
- Position, look target, field of view and roll blend together.
- Existing camera movement, actor tracking and shake remain supported.

## Validation
- Added regression tests for boundary continuity, transition completion, deterministic output and hard-cut opt-out.
- Physical rendering on iPhone and PC remains to be checked by running a generated video.

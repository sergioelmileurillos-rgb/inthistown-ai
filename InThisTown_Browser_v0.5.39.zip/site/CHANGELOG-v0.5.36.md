# In This Town Browser v0.5.36

- Mouth movement during `talk` actions now follows the measured start/end times of the narration words.
- Each word produces a deterministic set of mouth-open pulses based on an approximate syllable count, with pauses between words.
- Pulses are clipped to the speaking action and retain the actor’s base facial expression between openings.
- This is word-timing synchronization, not waveform/phoneme-level lip reading; exact phoneme sync remains a later improvement.

# In This Town Browser v0.5.4

## Fusión de versiones
- Base visual y motor WebGL2: Browser v0.5.2 de Claude.
- Motor narrativo modular: `Story.generate()` del código fuente v0.5.0.
- Registro de assets: `engine/assets.js` del código fuente v0.5.0, compatible con el catálogo ampliado del navegador.
- Director editorial: `shortform-director.js` v0.5.7.
- Validador de episodio: `episode-preflight.js` v0.6.3.
- Sincronización de palabras y efectos de sonido: `timing.js` y `sfx.js` v0.5.0.

## Cambios funcionales
- Las premisas interpretables usan arquetipos narrativos variados, reparto variable y giros; se conserva el generador anterior como fallback.
- Los roles de la historia se convierten en intenciones de escena del coreógrafo v0.5.2.
- El planificador editorial agrupa beats en holds motivados y reduce la coreografía a un movimiento de cámara intencional por escena, en lugar de tres cambios por frase.
- La validación previa revisa frases, tiempos, clips, actores, objetos, cobertura de planos, captions y eventos.
- Se recuperan cancelar generación, generar otra variante, previsualizar el vídeo, consultar el informe y explorar/visualizar assets.
- La grabación usa el reloj de audio como referencia temporal; voz, música, efectos y vídeo se programan sobre el mismo origen temporal.
- La música baja automáticamente durante la narración y se recuperan los efectos de sonido procedurales.
- El resaltado de palabras usa estimaciones de tiempos basadas en la forma de onda dentro de cada bloque de voz. No es alineación fonética exacta.
- El service worker incluye todos los módulos nuevos y cambia de caché para evitar mezclar archivos de versiones anteriores.

## Pruebas
- 6 pruebas automatizadas Node.js pasan.
- 8 familias de premisas se ejecutan a través del generador, coreógrafo, planificación de cámara y preflight sin errores de validación estática.
- Sintaxis comprobada para todos los archivos JavaScript del sitio.
- No se afirma una exportación completa con Kokoro real en iPhone/Chromebook: esa prueba sigue pendiente en dispositivos reales.

In This Town Browser v0.5.10

Corrección crítica del flujo de generación:
1. Se define checkCancel() en el ámbito compartido de la aplicación. La v0.5.9 la invocaba desde create(), validateEngine() y renderPreviews() sin haberla declarado, provocando ReferenceError: checkCancel is not defined.
2. El botón «Cancelar generación» ahora actualiza state.cancel y permite detener el proceso de forma controlada al terminar la operación actual.
3. Se mantiene el motor Kokoro, el motor 3D y el límite de render a 24 FPS de la versión anterior.

Publicación: sube InThisTown_Browser_v0.5.10.zip a la raíz del repositorio. El workflow pages.yml existente seleccionará la versión más alta y publicará site/.

Validación: sintaxis JavaScript comprobada y comprobaciones estáticas de la función de cancelación. No se ha probado una exportación completa en un Chromebook.

# In This Town Browser v0.5.5

This release integrates the story engine's authored per-beat visual plans into the real WebGL2 scene system. See `site/CHANGELOG-v0.5.5.md`, `site/README.md`, and `site/TESTS.md` for implementation and validation details.

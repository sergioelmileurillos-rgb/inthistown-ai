# In This Town Browser v0.5.9

## Estabilidad del render en equipos limitados
- Cuando termina la narración, el audio se copia al `AudioBuffer` y el worker de Kokoro se termina antes de comenzar el render 3D. Así se libera la memoria ocupada por ONNX/WASM durante la grabación.
- Se deja de conservar una segunda copia completa de la narración PCM después de crear el `AudioBuffer`.
- El motor 3D ahora limita los dibujos a 24 FPS, que es la frecuencia de grabación. Antes `requestAnimationFrame` podía dibujar a 60/90/120 Hz aunque MediaRecorder solo guardase 24 FPS.
- Si Chrome pierde el contexto WebGL, la aplicación muestra un mensaje claro y detiene los nuevos intentos de render.
- Se actualiza la caché del service worker para que GitHub Pages no siga sirviendo el JavaScript anterior.

## Verificación
- Pruebas automatizadas de liberación del worker, descarte de PCM duplicado, limitación a 24 FPS y tratamiento de pérdida de contexto WebGL.
- Todos los archivos JavaScript pasan la comprobación sintáctica.
- Estas pruebas no sustituyen una exportación completa en el Chromebook real; no afirmo que se haya probado allí.

# v0.5.10

- Fixed `ReferenceError: checkCancel is not defined` by defining the shared cancellation guard in the application IIFE.
- Wired the Cancel button to `state.cancel`, with a clear status message.
- Kept the v0.5.9 Kokoro/24 FPS/WebGL resource optimizations unchanged.
- Validation: JavaScript syntax and static cancellation-path checks; no full Chromebook export test.

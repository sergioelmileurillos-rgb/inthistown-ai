# In This Town Browser v0.5.8

## Ajuste de inferencia Kokoro en Chromebook
- En ChromeOS, móviles y equipos limitados, el orden de carga WASM cambia a Q8 primero y Q4 como alternativa si Q8 no consigue inicializarse.
- La documentación oficial de kokoro-js muestra Q8 como configuración de ejemplo para WASM; Q4 se mantiene como alternativa de menor tamaño.
- El diagnóstico de errores de generación ahora indica la precisión y el backend que estaban activos (por ejemplo, Q8/WASM), para distinguir fallos de carga de fallos de inferencia.
- Se sincroniza el worker de GitHub Pages con el worker integrado para copias locales.
- Se renueva la caché del service worker para forzar la actualización de los archivos.

## Pruebas
- Se actualizan las pruebas automatizadas para comprobar Q8 primero y Q4 como alternativa.
- Se comprueba que el worker conserva el detalle del backend activo al comunicar errores.

## Límite de verificación
- Las pruebas automatizadas simulan la carga del modelo; no ejecutan una inferencia real en el Chromebook. La prueba definitiva sigue siendo generar una narración en ese dispositivo.

// Prueba extremo a extremo: UI -> historia -> voz (flite como SUSTITUTO de Kokoro) -> render -> vídeo descargable.
const {launch}=require('./lib.js');const fs=require('fs'),path=require('path'),cp=require('child_process');
const [html,out,idea,tone,length]=[process.argv[2],process.argv[3],process.argv[4],process.argv[5]||'mystery',process.argv[6]||'medium'];
fs.mkdirSync(out,{recursive:true});
(async()=>{
 const {b,p,errs}=await launch(html,{log:false});
 await p.exposeFunction('fliteTTS',async text=>{const f=path.join(out,'_t.txt');fs.writeFileSync(f,text);
   const buf=cp.execFileSync('ffmpeg',['-v','error','-f','lavfi','-i',`flite=textfile=${f}:voice=slt`,'-ar','24000','-ac','1','-f','f32le','-'],{maxBuffer:1<<28});return buf.toString('base64')});
 await p.evaluate(()=>{window.__ITT_TTS={generate:async t=>{const b=atob(await window.fliteTTS(t));const u=new Uint8Array(b.length);for(let i=0;i<b.length;i++)u[i]=b.charCodeAt(i);return{audio:new Float32Array(u.buffer),sampling_rate:24000}}}});
 await p.fill('#idea',idea);await p.selectOption('#tone',tone);await p.selectOption('#length',length);
 const t0=Date.now();await p.click('#create');
 // duplicate click must be ignored
 await p.click('#create',{force:true}).catch(()=>{});
 await p.waitForFunction(()=>document.getElementById('result').classList.contains('show')||/No se ha podido|Cancelado/.test(document.getElementById('status').textContent),null,{timeout:900000,polling:1000});
 const res=await p.evaluate(async()=>{const st=document.getElementById('status').textContent;const C=window.ITT.app.state.composed;const S=window.ITT.app.state.story;
   const o={status:st,meta:document.getElementById('resultMeta').textContent,report:window.ITT.app.state.report||[]};
   if(C){o.arch=S.arch;o.beats=S.beats.map(b=>b.vo);o.dur=C.duration;o.scenes=C.engine.scenes.map(s=>({set:s.set,sky:s.sky,t0:s.t0,dur:s.dur,n:s.actions.length}));o.nSfx=C.nSfx;o.caps=C.captions.map(c=>({s:c.start,e:c.end,w:c.words.length}));o.warnings=C.warnings}
   const v=document.getElementById('player');if(v.src){const r=await fetch(v.src);const ab=await r.arrayBuffer();let bin='',u=new Uint8Array(ab);for(let i=0;i<u.length;i+=32768)bin+=String.fromCharCode.apply(null,u.subarray(i,i+32768));o.video=btoa(bin);o.mime=(await (await fetch(v.src)).blob()).type}
   return o});
 if(res.video){fs.writeFileSync(path.join(out,'out.'+(res.mime.includes('mp4')?'mp4':'webm')),Buffer.from(res.video,'base64'));delete res.video}
 fs.writeFileSync(path.join(out,'result.json'),JSON.stringify(res,null,1));
 console.log('wall time s',((Date.now()-t0)/1000).toFixed(0),'| status:',res.status.slice(0,200));console.log('meta',res.meta,'| arch',res.arch,'| scenes',JSON.stringify(res.scenes));
 console.log('report',res.report.length,res.report.slice(0,12).map(r=>r.sev+': '+r.msg));console.log('page errors',errs);
 await b.close();
})();

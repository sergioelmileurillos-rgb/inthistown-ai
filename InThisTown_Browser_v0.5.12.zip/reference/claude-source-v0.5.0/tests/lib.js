const { chromium } = require('playwright');
const fs=require('fs'),path=require('path');
exports.launch=async function(htmlPath,opts={}){
  const b=await chromium.launch({args:['--use-angle=swiftshader','--enable-unsafe-swiftshader','--ignore-gpu-blocklist','--autoplay-policy=no-user-gesture-required']});
  const p=await b.newPage({viewport:{width:760,height:1200}});
  const errs=[];p.on('pageerror',e=>errs.push('pageerror: '+e.message));p.on('console',m=>{if(m.type()==='error')errs.push('console: '+m.text());if(opts.log)console.log('[page]',m.text())});
  await p.goto('file://'+path.resolve(htmlPath));await p.waitForTimeout(600);
  return {b,p,errs};
};
exports.sheet=function(files,out,w=288,h=512){
  const {execFileSync}=require('child_process');
  execFileSync('python3',['-c',`
from PIL import Image
import sys
fs=sys.argv[2:];w,h=${w},${h}
ims=[Image.open(f).resize((w,h)) for f in fs]
W=Image.new('RGB',(w*len(ims),h))
for i,im in enumerate(ims):W.paste(im,(i*w,0))
W.save(sys.argv[1])`,out,...files]);
};

const S=require('../src/app/story.js');
const prem=[
 'Nobody is allowed to open a window after midnight','Every lie makes you shrink by one inch','You can only walk backwards after sunset',
 'No one can look at the moon','Nobody may whistle on Sundays','You must always say hello to the mayor','If you sneeze, the lights go out',
 'In this town, nobody is allowed to laugh','Never eat pizza on Tuesdays','Everyone must wear a hat','Nobody can knock on the red door','Nobody is allowed to turn on a light after dark',
 'No sleeping after sunrise','You cannot touch the golden statue','Nobody is allowed to read books at night','Never say the word banana'];
let bad=0;
for(const p of prem){for(const tone of ['mystery','funny','suspense']){
  const st=S.generate(p,tone,'medium');
  const issues=[];
  for(const b of st.beats){ if(/\{\w+\}/.test(b.vo))issues.push('placeholder: '+b.vo); if(/\bundefined\b|NaN/.test(b.vo))issues.push('undef: '+b.vo); if(b.vo.split(/\s+/).length>16)issues.push('long: '+b.vo);}
  if(issues.length){bad++;console.log('PROBLEMS',p,tone,issues)}
 }}
for(const p of ['Nobody is allowed to open a window after midnight','Every lie makes you shrink by one inch','You can only walk backwards after sunset','Nobody may whistle on Sundays']){
  const st=S.generate(p,'mystery','medium');console.log('\n##',p,'=>',st.arch,'|',JSON.stringify({kind:st.rule.kind,act:st.rule.act,mod:st.rule.mod,past:st.rule.f.past,ing:st.rule.f.ing,home:st.domain.home,vc:st.domain.vc,br:st.domain.breakKind}));
  console.log(st.cast.hero.name,'&',st.cast.nbr.name,st.beats.length,'beats\n'+st.beats.map(b=>`  [${b.set}] ${b.vo}`).join('\n'));
}
console.log('\nproblem cases:',bad);

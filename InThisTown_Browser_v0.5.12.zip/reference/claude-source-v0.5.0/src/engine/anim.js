/* engine/anim.js — procedural animation clips. Each clip(t,d,p) -> partial pose.
   Pose keys (radians unless noted): bodyY, lean, roll, spin, sx sy sz (scale), torsoX/Y/Z, headX/Y/Z,
   lArmX/lArmZ rArmX/rArmZ (X: + = swing FORWARD, Z: + = swing OUTWARD), lLegX/lLegZ rLegX/rLegZ (X + = forward). */
(function(S){
const {clamp,lerp,ease}=S;const PI=Math.PI,sin=Math.sin,cos=Math.cos,abs=Math.abs;
const ZERO={bodyY:0,lean:0,roll:0,spin:0,sx:1,sy:1,sz:1,torsoX:0,torsoY:0,torsoZ:0,headX:0,headY:0,headZ:0,lArmX:0,lArmZ:.08,rArmX:0,rArmZ:.08,lLegX:0,lLegZ:.04,rLegX:0,rLegZ:.04};
const u=(t,d)=>d&&isFinite(d)?clamp(t/d):0;
const C={};
C.idle=(t)=>({torsoX:.02*sin(t*3),headY:.12*sin(t*1.3),lArmX:.06*sin(t*2.6),rArmX:-.06*sin(t*2.6),bodyY:.03*sin(t*3)});
C.walk=(t,d,p)=>{const s=p.speed||1,ph=t*PI*2*1.7*s,a=.75;return{lLegX:a*sin(ph),rLegX:-a*sin(ph),lArmX:-.8*sin(ph),rArmX:.8*sin(ph),bodyY:.14*abs(cos(ph)),torsoY:.1*sin(ph),lean:.05,headY:-.05*sin(ph)}};
C.run=(t,d,p)=>{const s=p.speed||1,ph=t*PI*2*2.6*s,a=1.15;return{lLegX:a*sin(ph),rLegX:-a*sin(ph),lArmX:-1.3*sin(ph),rArmX:1.3*sin(ph),lArmZ:.2,rArmZ:.2,bodyY:.35*abs(sin(ph)),torsoY:.18*sin(ph),lean:.24,headX:-.1}};
C.panic=(t,d,p)=>{const ph=t*PI*2*3;return{...C.run(t,d,{speed:1.15}),lArmX:2.6+.5*sin(ph*2),rArmX:2.6+.5*cos(ph*2),lArmZ:.5+.3*sin(ph),rArmZ:.5-.3*sin(ph),headX:-.2}};
C.jump=(t,d)=>{const k=u(t,d||.8);const air=sin(k*PI);return{bodyY:3.2*air,lArmZ:1.6*air,rArmZ:1.6*air,lArmX:.4*air,rArmX:.4*air,lLegX:.6*air,rLegX:-.2*air,sy:1+.18*(k<.15?-(1-k/.15):air*.15),sx:1-.08*air}};
C.hop=(t,d)=>{const k=u(t,d||.4);return{bodyY:1.2*sin(k*PI),sy:1+.12*sin(k*PI)}};
C.wave=(t)=>({rArmZ:2.75+.35*sin(t*13),rArmX:0,headZ:.1*sin(t*3),headY:.1,bodyY:.04*sin(t*6)});
C.point=(t,d,p)=>({rArmX:1.57,rArmZ:.05,headY:(p.dir||0)*.3,torsoY:(p.dir||0)*-.2});
C.shock=(t)=>({lArmZ:2.2,rArmZ:2.2,lArmX:.5,rArmX:.5,torsoX:-.12,headX:-.25,lLegZ:.25,rLegZ:.25,bodyY:.05*sin(t*40),sy:1.06,sx:.96});
C.scared=(t)=>({lArmX:1.7,rArmX:1.7,lArmZ:-.2,rArmZ:-.2,torsoX:-.2,headX:-.15,lLegZ:.15,rLegZ:.15,bodyY:.04*sin(t*50),torsoZ:.03*sin(t*45)});
C.cheer=(t)=>({lArmX:3.0,rArmX:3.0,lArmZ:.35,rArmZ:.35,bodyY:.9*abs(sin(t*7)),headX:-.2,lLegX:.3*sin(t*7),rLegX:-.3*sin(t*7)});
C.laugh=(t)=>({torsoX:.15+.25*sin(t*18),headX:-.35,bodyY:.2*abs(sin(t*18)),lArmX:1.0,rArmX:1.0,lArmZ:.1,rArmZ:.1});
C.clap=(t)=>({lArmX:1.25,rArmX:1.25,lArmZ:-.05+.28*sin(t*16),rArmZ:-.05+.28*sin(t*16),headX:-.1,bodyY:.1*abs(sin(t*8))});
C.talk=(t,d,p)=>({headX:.05*sin(t*7),headY:.1*sin(t*2.1),lArmX:.35+.3*sin(t*4.5),rArmX:.4+.3*sin(t*4.5+2),lArmZ:.25,rArmZ:.25,torsoX:.03});
C.think=(t)=>({rArmX:2.1,rArmZ:-.5,headX:.18,headZ:.1,lArmX:.1});
C.shrug=(t,d)=>{const k=sin(clamp(t/(d||.8))*PI);return{lArmZ:.7*k+.08,rArmZ:.7*k+.08,lArmX:.5*k,rArmX:.5*k,headZ:.15*k,bodyY:.12*k}};
C.sit=(t,d,p)=>({bodyY:-(p.lower===undefined?.8:p.lower),lLegX:1.57,rLegX:1.57,lArmX:.5,rArmX:.5,torsoX:.03,headY:.05*sin(t*1.5)});
C.sleep=(t)=>({bodyY:-.8,lLegX:1.57,rLegX:1.57,torsoX:.3+.03*sin(t*1.8),headX:.6,lArmX:.3,rArmX:.3});
C.lie=(t,d,p)=>({lean:(p.back?-1:1)*1.5,bodyY:-1.45,lArmZ:.3,rArmZ:.3,headX:p.back?.0:-.5});
C.fall=(t,d)=>{const k=u(t,d||.7);return{lean:ease('in',k)*1.45,bodyY:-1.45*ease('in',k),lArmZ:1.6*(1-k),rArmZ:1.6*(1-k),lArmX:1.2*(1-k)}};
C.fly=(t)=>({lean:1.25,bodyY:.3*sin(t*3),lArmX:3.0,rArmX:3.0,lArmZ:.1,rArmZ:.1,lLegX:-.3,rLegX:-.45,lLegZ:.1,rLegZ:.1,headX:-.8});
C.dance=(t,d,p)=>{const b=p.bpm?p.bpm/60:2.2,ph=t*PI*2*b;return{bodyY:.35*abs(sin(ph)),torsoZ:.18*sin(ph),headZ:-.2*sin(ph),lArmX:2.6*(sin(ph)>0?1:.2),rArmX:2.6*(sin(ph)>0?.2:1),lArmZ:.5+.3*sin(ph*2),rArmZ:.5-.3*sin(ph*2),lLegX:.4*sin(ph),rLegX:-.4*sin(ph),torsoY:.25*sin(ph)}};
C.punch=(t,d)=>{const k=u(t,d||.5);const e=sin(clamp(k*1.6)*PI);return{rArmX:1.57*e,lArmX:-.4*e,torsoY:-.5*e,lean:.1*e,lLegX:.4*e,rLegX:-.3*e}};
C.swing=(t,d,p)=>{const k=u(t,d||.6);const e=k<.4?-ease('out',k/.4)*1:(k<.6?(-1+((k-.4)/.2)*3.2):2.2-((k-.6)/.4)*2.2);return{rArmX:3.0+(k<.4?-0.6*k/.4:-0.6+(k-.4)*5),lArmX:2.4,torsoY:-.5+1*clamp((k-.35)/.25),lean:.1}};
C.sneeze=(t,d)=>{const k=u(t,d||1);if(k<.55){const a=ease('out',k/.55);return{headX:-.45*a,torsoX:-.22*a,lArmX:1.6*a,rArmX:1.6*a,bodyY:.12*a,sy:1+.06*a}}
  if(k<.68){const a=(k-.55)/.13;return{headX:-.45+1.25*a,torsoX:-.22+.8*a,lArmX:1.6-.5*a,rArmX:1.6-.5*a,sy:1.06-.16*a,sx:1+.08*a}}
  const a=ease('out',(k-.68)/.32);return{headX:.8*(1-a),torsoX:.58*(1-a),lArmX:1.1*(1-a),rArmX:1.1*(1-a),sy:.9+.1*a,sx:1.08-.08*a}};
C.warp=(t,d)=>{const k=u(t,d||.6);return{spin:PI*6*ease('in',k),sy:1+1.6*k*k,sx:1-.8*k*k,sz:1-.8*k*k,lArmZ:1.5,rArmZ:1.5}};
C.arrive=(t,d)=>{const k=u(t,d||.5);const e=ease('back',k);return{sy:.15+.85*e,sx:1.6-.6*e,sz:1.6-.6*e,spin:PI*4*(1-k),lArmZ:1.2*(1-k),rArmZ:1.2*(1-k)}};
C.spin=(t,d,p)=>({spin:PI*2*(p.turns||1)*u(t,d||1),lArmZ:1.4,rArmZ:1.4,bodyY:.2*sin(u(t,d||1)*PI)});
C.lookAround=(t)=>({headY:.9*sin(t*2.2),torsoY:.2*sin(t*2.2),lArmX:.05});
C.hang=(t,d,p)=>{const pull=p.pull!==undefined?p.pull:abs(sin(t*PI*.8))*(p.reps?1:0);return{lArmX:3.14,rArmX:3.14,lArmZ:.18,rArmZ:.18,bodyY:-1.6+pull*1.3,lLegX:.15,rLegX:.15,headX:-.3-.1*pull}};
C.pullup=(t,d,p)=>{const k=abs(sin(t*PI*(p.rate||.9)));return{lArmX:3.14,rArmX:3.14,lArmZ:.18,rArmZ:.18,bodyY:-1.9+k*1.5,lLegX:.25,rLegX:.1,headX:-.4+.2*k,torsoX:.03}};
C.kick=(t,d)=>{const k=sin(u(t,d||.5)*PI);return{rLegX:1.5*k,lArmX:.8*k,torsoX:-.2*k,rArmX:-.6*k}};
C.crouch=(t)=>({bodyY:-.9,lLegX:.9,rLegX:.9,torsoX:.4,lArmX:.5,rArmX:.5,headX:-.3});
C.bow=(t,d)=>{const k=sin(u(t,d||1)*PI);return{torsoX:1.1*k,headX:.3*k,lArmX:.1,rArmX:.1}};
C.salute=(t)=>({rArmX:2.3,rArmZ:-.2,headX:-.05});
C.thumbs=(t)=>({rArmX:1.3,rArmZ:.2,headZ:.1,bodyY:.04*sin(t*6)});
C.flail=(t)=>({lArmX:2.4*sin(t*17),rArmX:2.4*sin(t*15+1),lArmZ:1+.8*sin(t*13),rArmZ:1+.8*sin(t*11),lLegX:.8*sin(t*16),rLegX:.8*sin(t*14),torsoZ:.2*sin(t*9),headZ:.3*sin(t*12)});
C.carry=(t)=>({lArmX:1.45,rArmX:1.45,lArmZ:-.1,rArmZ:-.1,torsoX:-.06});
C.hide=(t)=>({bodyY:-1.1,lLegX:1.0,rLegX:1.0,torsoX:.6,lArmX:2.2,rArmX:2.2,lArmZ:-.2,rArmZ:-.2,headX:.4});
C.tpose=()=>({lArmZ:1.57,rArmZ:1.57});
C.slump=(t)=>({torsoX:.45,headX:.55,lArmX:.15,rArmX:.15,bodyY:-.08});
C.angry=(t)=>({torsoX:.12,headX:.1,lArmX:.3,rArmX:.3,lArmZ:.3,rArmZ:.3,bodyY:.04*abs(sin(t*20)),torsoZ:.04*sin(t*20)});
C.cry=(t)=>({headX:.5,torsoX:.3,lArmX:2.3,rArmX:2.3,lArmZ:-.5,rArmZ:-.5,torsoZ:.05*sin(t*12),bodyY:.05*abs(sin(t*12))});
C.slide=(t)=>({lean:-.6,bodyY:-.5,lLegX:1.0,rLegX:1.2,lArmX:1,rArmX:1});
C.climb=(t)=>{const ph=t*PI*2*1.4;return{lArmX:2.8+.6*sin(ph),rArmX:2.8-.6*sin(ph),lLegX:.8*sin(ph+PI),rLegX:.8*sin(ph),lean:-.05}};

function evalPose(name,t,d,p){const f=C[name]||C.idle;const o=Object.assign({},ZERO,f(t,d,p||{}));return o}
function blend(a,b,k){const o={};for(const key in ZERO)o[key]=lerp(a[key],b[key],k);return o}
S.Anim={clips:C,ZERO,evalPose,blend,names:()=>Object.keys(C)};
})(window.Studio);


/* engine/interact.js — v0.5: props con ESTADO (puertas, ventanas, luces, pantallas) + macro de interacción de actores.
   Una parte con {chan:'open',pivot,axis,angle} gira alrededor de un gozne según el canal "open" (0..1) del objeto;
   {chan,slide:[dx,dy,dz]} se desliza; {emisChan:'on'} enciende/apaga su brillo. Los canales se animan con
   {obj:'door1',do:'set',chan:'open',to:1,dur:.5} o con la macro {actor:'max',do:'interact',kind:'open',obj:'door1'}. */
(function(S){
const L=S.Props.lib,PI=Math.PI;
const B=(off,size,color,x={})=>Object.assign({p:['box'],off,size,color},x);
const CY=(off,size,color,x={})=>Object.assign({p:['cyl',14],off,size,color},x);
const sh=S.shade;

/* puerta con marco; hoja con gozne a la izquierda (x=-1.6). Se abre hacia +Z (hacia la cámara habitual). */
L.door_h=(o={})=>{const c=o.color||'#8a4a2a',inside=o.inside||'#17131f';
  return[B([-1.95,3.3,0],[.5,6.6,.7],'#f2ead6'),B([1.95,3.3,0],[.5,6.6,.7],'#f2ead6'),B([0,6.55,0],[4.4,.5,.7],'#f2ead6'),B([0,.06,0],[3.4,.12,.9],'#9a9aa4'),
   B([0,3.15,-.32],[3.4,6.3,.1],inside,{emisChan:'lit',emis:0,emisOn:o.litAmt||.55}),
   B([0,3.15,.1],[3.2,6.3,.3],c,{chan:'open',pivot:[-1.6,0,.1],axis:'y',angle:-1.75}),
   B([.15,3.15,.12],[2.4,5.2,.36],sh(c,1.12),{chan:'open',pivot:[-1.6,0,.1],axis:'y',angle:-1.75}),
   B([1.15,3.1,.34],[.35,.35,.25],'#ffd23a',{chan:'open',pivot:[-1.6,0,.1],axis:'y',angle:-1.75,emis:.15})]};
/* ventana de dos hojas con cristales; se abren hacia fuera (+Z). "lit" enciende el interior. */
L.window_h=(o={})=>{const fr=o.frame||'#ffffff',gl=o.glass||'#9fd6ff';
  return[B([-2.3,2.5,0],[.5,5,.6],fr),B([2.3,2.5,0],[.5,5,.6],fr),B([0,5.05,0],[5.1,.5,.6],fr),B([0,-.05,.1],[5.4,.4,.9],sh(fr,.85)),
   B([0,2.5,-.3],[4.2,4.6,.1],o.inside||'#17131f',{emisChan:'lit',emis:0,emisOn:1,color:o.inside||'#17131f'}),
   B([-1.05,2.5,.05],[2.0,4.4,.14],gl,{alpha:.55,chan:'open',pivot:[-2.05,0,.05],axis:'y',angle:-1.7,emis:.1}),B([1.05,2.5,.05],[2.0,4.4,.14],gl,{alpha:.55,chan:'open',pivot:[2.05,0,.05],axis:'y',angle:1.7,emis:.1}),
   B([-1.05,2.5,.07],[2.1,.16,.2],fr,{chan:'open',pivot:[-2.05,0,.05],axis:'y',angle:-1.7}),B([1.05,2.5,.07],[2.1,.16,.2],fr,{chan:'open',pivot:[2.05,0,.05],axis:'y',angle:1.7}),
   B([-2.05,2.5,.07],[.16,4.5,.2],fr,{chan:'open',pivot:[-2.05,0,.05],axis:'y',angle:-1.7}),B([2.05,2.5,.07],[.16,4.5,.2],fr,{chan:'open',pivot:[2.05,0,.05],axis:'y',angle:1.7}),
   B([-1.05,4.6,-.15],[2.0,.5,.1],o.curtain||'#a33b5a',{chan:'curtain',slide:[-1.2,0,0]}),B([1.05,4.6,-.15],[2.0,.5,.1],o.curtain||'#a33b5a',{chan:'curtain',slide:[1.2,0,0]}),
   B([-1.05,2.3,-.15],[2.0,4.4,.1],o.curtain||'#a33b5a',{chan:'curtain',slide:[-1.25,0,0]}),B([1.05,2.3,-.15],[2.0,4.4,.1],o.curtain||'#a33b5a',{chan:'curtain',slide:[1.25,0,0]})]};
/* farola interruptor */
L.lamp_s=(o={})=>[CY([0,4,0],[.35,8,.35],'#2b2f3a'),B([0,8.1,.9],[.3,.3,2],'#2b2f3a'),B([0,7.9,1.8],[.9,.3,1.3],'#f1f1ea',{emisChan:'on',emis:0,emisOn:1})];
L.tv_s=(o={})=>[B([0,2.2,0],[5,3.4,.6],'#16161c'),B([0,2.2,.32],[4.6,3,.05],o.screen||'#3bd1ff',{emisChan:'on',emis:0,emisOn:.95}),B([0,.3,0],[2.2,.5,1.2],'#16161c')];
L.mirror=(o={})=>[B([0,3,0],[3.2,5.2,.3],'#c9a24a'),B([0,3,.17],[2.7,4.7,.05],'#d8f0ff',{emis:.3}),B([-.5,3.6,.2],[.5,2,.02],'#ffffff',{emis:.8,rot:[0,0,.35]})];
L.chest=(o={})=>[B([0,.9,0],[3.4,1.8,2.2],'#8a5a2a'),B([0,1.9,-.9],[3.4,.4,.4],'#6b4423'),
  B([0,2.0,.0],[3.5,.4,2.3],'#a06a30',{chan:'open',pivot:[0,1.8,-1.1],axis:'x',angle:-1.2}),B([0,1.25,1.12],[.5,.6,.1],'#ffd23a',{emis:.2}),B([0,1.8,0],[2.8,.2,1.8],'#ffd23a',{emisChan:'open',emis:0,emisOn:.9})];
L.fridge_h=(o={})=>[B([0,4,0],[3.4,8,3],'#f2f4f8'),B([-1.6,4,1.55],[.2,7.4,.15],'#d0d4dc',{chan:'open',pivot:[-1.7,4,1.5],axis:'y',angle:-1.6}),B([0,4,1.5],[3.2,7.4,.2],'#e6e9f0',{chan:'open',pivot:[-1.7,4,1.5],axis:'y',angle:-1.6}),B([0,4,1.4],[2.9,7,.1],'#fff8cf',{emisChan:'open',emis:0,emisOn:.9})];
L.curtains=(o={})=>[B([-1.6,3,0],[3,6,.3],o.color||'#a33b5a',{chan:'open',slide:[-1.2,0,0]}),B([1.6,3,0],[3,6,.3],o.color||'#a33b5a',{chan:'open',slide:[1.2,0,0]}),B([0,6.1,.1],[7,.3,.5],'#6b4423')];
L.lightswitch=()=>[B([0,0,0],[.9,1.4,.15],'#f4f4f4'),B([0,0,.1],[.35,.7,.1],'#d8d8d8',{chan:'on',pivot:[0,0,.1],axis:'x',angle:-.5})];
L.footprints=()=>[B([-.5,.03,0],[.7,.04,1.3],'#3a2f28'),B([.5,.03,1.6],[.7,.04,1.3],'#3a2f28'),B([-.5,.03,3.2],[.7,.04,1.3],'#3a2f28'),B([.5,.03,4.8],[.7,.04,1.3],'#3a2f28')];
L.shadowfigure=()=>[B([0,3.4,0],[2.3,6.8,.4],'#05050a',{alpha:.88,emis:0}),B([0,7.2,0],[2,2,.4],'#05050a',{alpha:.88}),B([-.5,7.2,.22],[.35,.22,.05],'#ffffff',{emis:1}),B([.5,7.2,.22],[.35,.22,.05],'#ffffff',{emis:1})];
L.notepaper=()=>[B([0,.05,0],[1.6,.06,2.2],'#fffbe8')];
L.rulebook=()=>[B([0,.35,0],[1.8,.5,2.4],'#7a1f2a'),B([0,.62,0],[1.6,.06,2.2],'#fffbe8'),B([0,.4,1.2],[1.7,.4,.05],'#ffd23a',{emis:.2})];
L.gavel=()=>[CY([0,.8,0],[.22,1.6,.22],'#8a5a2a'),B([0,1.7,0],[1.4,.8,.8],'#6b4423',{rot:[0,0,0]})];
L.ghost=()=>[{p:['sphere',10,7],off:[0,3.4,0],size:[3,3.4,3],color:'#f4f8ff',alpha:.8,emis:.6},B([0,1.6,0],[3,3,3],'#f4f8ff',{alpha:.8,emis:.6}),B([-.6,3.7,1.3],[.5,.7,.1],'#111'),B([.6,3.7,1.3],[.5,.7,.1],'#111'),B([0,2.8,1.4],[.7,.9,.1],'#111')];
L.parrot=(o={})=>[{p:['sphere',10,7],off:[0,1.3,0],size:[1.2,1.7,1.1],color:o.color||'#2fb85a'},{p:['sphere',10,7],off:[0,2.4,.15],size:[.95,.95,.95],color:o.color||'#2fb85a'},B([0,2.35,.7],[.25,.3,.5],'#ffb02a'),B([-.28,2.55,.55],[.18,.18,.1],'#111'),B([.28,2.55,.55],[.18,.18,.1],'#111'),B([0,.7,-.3],[.4,1.6,.2],'#e84a4a',{rot:[.3,0,0]}),B([0,.1,0],[.4,.2,.9],'#8a5a2a')];
L.microphone_stand=()=>[CY([0,2.5,0],[.15,5,.15],'#333'),CY([0,5.2,0],[.5,.9,.5],'#888')];
L.barrier_tape=()=>[B([0,1.6,0],[8,.5,.1],'#ffd23a'),B([0,1.6,.02],[8,.2,.12],'#16161c'),CY([-4,1,0],[.2,2,.2],'#555'),CY([4,1,0],[.2,2,.2],'#555')];
S.Props.stateful={door_h:['open','lit'],window_h:['open','lit','curtain'],lamp_s:['on'],tv_s:['on'],chest:['open'],fridge_h:['open'],curtains:['open'],lightswitch:['on']};
})(window.Studio);

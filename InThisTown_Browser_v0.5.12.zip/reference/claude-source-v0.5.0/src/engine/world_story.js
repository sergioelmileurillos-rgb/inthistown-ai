/* engine/world_story.js — v0.5: decorados diseñados para narrar (puertas/ventanas reales, anclas conocidas). */
(function(S){
const B=S.Worlds,E=S.ENV,shade=S.shade;
/* pared con huecos: holes=[{x0,x1,y0,y1}] ; construye cajas alrededor */
function wall(w,x0,x1,H,z,thick,color,holes,collide){
  const xs=[x0,x1];for(const h of holes){xs.push(h.x0,h.x1)}const u=[...new Set(xs)].sort((a,b)=>a-b);
  for(let i=0;i<u.length-1;i++){const a=u[i],b=u[i+1],mid=(a+b)/2;const hs=holes.filter(h=>mid>h.x0&&mid<h.x1).sort((p,q)=>p.y0-q.y0);let y=0;
    const seg=(ya,yb)=>{if(yb-ya>.01)w.box([mid,(ya+yb)/2,z],[b-a,yb-ya,thick],color,collide?{collide:'wall'}:{})};
    for(const h of hs){seg(y,h.y0);y=h.y1}seg(y,H)}}
B.facade=(w,o={})=>{const r=w.r,H=14,pal=['#f2c9a0','#bfe3ff','#d7c6f7','#c9f0c4','#ffd0a8'];
  w.ground(o.ground||'#4d6b52');
  // calle delante de la casa (a lo largo de X)
  w.box([0,.05,34],[400,.1,16],'#5d6270');for(let x=-190;x<190;x+=14)w.box([x,.11,34],[6,.04,.5],'#f4f4f4');
  w.box([0,.08,22.5],[400,.14,7],'#d9dde6');w.box([0,.1,19],[400,.18,.5],'#cfd4de');
  w.box([0,.06,10],[7,.1,24],'#cfd0d6'); // camino a la puerta
  const holes=[{x0:-1.95,x1:1.95,y0:0,y1:6.6},{x0:-11.3,x1:-6.7,y0:3,y1:8.2},{x0:6.7,x1:11.3,y0:3,y1:8.2}];
  wall(w,-24,24,H,0,.8,o.color||'#f2c9a0',holes,true);
  w.box([0,H+.5,-3],[50,1,10],'#f2f2f2');w.box([0,H+3,-3],[46,5,8],shade(o.color||'#f2c9a0',.85));w.box([14,H+7,-4],[3,5,3],'#b07a5a');
  // interior oscuro tras la fachada
  w.box([0,7,-9],[48,14,.4],'#2a2233');w.box([-24,7,-4.5],[.4,14,9],'#2a2233');w.box([24,7,-4.5],[.4,14,9],'#2a2233');w.box([0,-.05,-4.5],[48,.1,9],'#6b5a48');w.box([0,13.9,-4.5],[48,.2,9],'#2a2233');
  w.box([0,.5,1.4],[5,1,2.4],'#cfd0d6'); // escalón
  // vecinos
  for(const s of[-1,1])for(let k=0;k<3;k++){const x=s*(46+k*34),h=12+r()*8;w.box([x,h/2,-2],[28,h,14],pal[(k+(s>0?2:0))%5],{collide:'house'});w.box([x,h+.4,-2],[29,.8,15],'#f2f2f2');
    for(const wx of[-7,7])w.box([x+wx,h*.5+1,5.1],[4.4,4.6,.3],w.night?(r()<.5?'#ffe48a':'#2a3558'):'#9fd6ff',{emis:w.night&&r()<.5?.8:0})}
  for(const x of[-30,-16,16,30])w.tree(x,10+r()*3,1+r()*.3);
  w.fence(-23,17,-8,17);w.fence(8,17,23,17);w.prop('mailbox',[-14,0,15],0,{});
  w.prop('car',[40,0,34],Math.PI/2,{color:'#2f6df6'});w.prop('car',[-52,0,34],-Math.PI/2,{color:'#e8453c'});
  for(const x of[-34,34])w.lamp(x,22,0);
  for(let i=0;i<10;i++)w.box([(r()-.5)*500,30+r()*40,-120-r()*160],[24,60+r()*80,24],pal[i%5]);
  w.clouds(8);w.extent=64;w.setSpawn('front',[12,0,24],Math.PI)};
S.Worlds.storyNames=['facade'];
})(window.Studio);

/* engine/prims.js — unit primitives + Batch (merge static geometry into one draw call).
   Vertex layout: pos3 nrm3 uv2 col3 emis1 = 12 floats. */
(function(S){
const {V,M,hex}=S;
function mk(){return {pos:[],nrm:[],uv:[]}}
function tri(g,a,b,c,na,nb,nc,ua,ub,uc){g.pos.push(...a,...b,...c);g.nrm.push(...na,...nb,...nc);g.uv.push(...ua,...ub,...uc)}
function quadFace(g,p0,p1,p2,p3,n){tri(g,p0,p1,p2,n,n,n,[0,0],[1,0],[1,1]);tri(g,p0,p2,p3,n,n,n,[0,0],[1,1],[0,1])}
function flatten(g){ // recompute per-face normals
  for(let i=0;i<g.pos.length;i+=9){const a=g.pos.slice(i,i+3),b=g.pos.slice(i+3,i+6),c=g.pos.slice(i+6,i+9);
    const n=V.norm(V.cross(V.sub(b,a),V.sub(c,a)));for(let k=0;k<3;k++){g.nrm[i+k*3]=n[0];g.nrm[i+k*3+1]=n[1];g.nrm[i+k*3+2]=n[2]}}return g}
const P={};
P.box=function(){const g=mk(),h=.5;
  quadFace(g,[-h,-h,h],[h,-h,h],[h,h,h],[-h,h,h],[0,0,1]);
  quadFace(g,[h,-h,-h],[-h,-h,-h],[-h,h,-h],[h,h,-h],[0,0,-1]);
  quadFace(g,[h,-h,h],[h,-h,-h],[h,h,-h],[h,h,h],[1,0,0]);
  quadFace(g,[-h,-h,-h],[-h,-h,h],[-h,h,h],[-h,h,-h],[-1,0,0]);
  quadFace(g,[-h,h,h],[h,h,h],[h,h,-h],[-h,h,-h],[0,1,0]);
  quadFace(g,[-h,-h,-h],[h,-h,-h],[h,-h,h],[-h,-h,h],[0,-1,0]);return g};
P.quad=function(){const g=mk(),h=.5;quadFace(g,[-h,-h,0],[h,-h,0],[h,h,0],[-h,h,0],[0,0,1]);return g};
function grid(g,fn,nu,nv,flat){const pts=[];for(let j=0;j<=nv;j++){pts.push([]);for(let i=0;i<=nu;i++)pts[j].push(fn(i/nu,j/nv))}
  const nr=pts.map(r=>r.map(()=>[0,0,0]));
  const tris=[];for(let j=0;j<nv;j++)for(let i=0;i<nu;i++){tris.push([[i,j],[i+1,j],[i+1,j+1]],[[i,j],[i+1,j+1],[i,j+1]])}
  for(const t of tris){const [a,b,c]=t.map(([i,j])=>pts[j][i]);const n=V.cross(V.sub(b,a),V.sub(c,a));for(const [i,j] of t){nr[j][i]=V.add(nr[j][i],n)}}
  for(const t of tris){for(const [i,j] of t){const n=V.norm(nr[j][i]);g.pos.push(...pts[j][i]);g.nrm.push(...n);g.uv.push(i/nu,j/nv)}}
  if(flat)flatten(g);return g}
P.sphere=function(seg=12,rings=8,flat=false){const g=mk();return grid(g,(u,v)=>{const th=u*Math.PI*2,ph=v*Math.PI;return [.5*Math.sin(ph)*Math.cos(th),-.5*Math.cos(ph),.5*Math.sin(ph)*Math.sin(th)]},seg,rings,flat)};
P.roundbox=function(n=4,seg=20,rings=14){const g=mk(),e=2/n;const sp=(x,p)=>Math.sign(x)*Math.pow(Math.abs(x),p);
  return grid(g,(u,v)=>{const th=u*Math.PI*2,ph=v*Math.PI-Math.PI/2;const ca=Math.cos(ph),sa=Math.sin(ph),ct=Math.cos(th),st=Math.sin(th);
    return [.5*sp(ca,e)*sp(ct,e),.5*sp(sa,e),.5*sp(ca,e)*sp(st,e)]},seg,rings,false)};
P.cyl=function(seg=16,flat=false){const g=mk();
  for(let i=0;i<seg;i++){const a0=i/seg*Math.PI*2,a1=(i+1)/seg*Math.PI*2;const x0=.5*Math.cos(a0),z0=.5*Math.sin(a0),x1=.5*Math.cos(a1),z1=.5*Math.sin(a1);
    const n0=[Math.cos(a0),0,Math.sin(a0)],n1=[Math.cos(a1),0,Math.sin(a1)];
    tri(g,[x0,-.5,z0],[x1,-.5,z1],[x1,.5,z1],n0,n1,n1,[0,0],[1,0],[1,1]);tri(g,[x0,-.5,z0],[x1,.5,z1],[x0,.5,z0],n0,n1,n0,[0,0],[1,1],[0,1]);
    tri(g,[0,.5,0],[x0,.5,z0],[x1,.5,z1],[0,1,0],[0,1,0],[0,1,0],[.5,.5],[0,0],[1,0]);
    tri(g,[0,-.5,0],[x1,-.5,z1],[x0,-.5,z0],[0,-1,0],[0,-1,0],[0,-1,0],[.5,.5],[1,0],[0,0]);}
  return flat?flatten(g):g};
P.cone=function(seg=12,flat=true){const g=mk();
  for(let i=0;i<seg;i++){const a0=i/seg*Math.PI*2,a1=(i+1)/seg*Math.PI*2;const x0=.5*Math.cos(a0),z0=.5*Math.sin(a0),x1=.5*Math.cos(a1),z1=.5*Math.sin(a1);
    tri(g,[x0,-.5,z0],[x1,-.5,z1],[0,.5,0],[0,1,0],[0,1,0],[0,1,0],[0,0],[1,0],[.5,1]);
    tri(g,[0,-.5,0],[x1,-.5,z1],[x0,-.5,z0],[0,-1,0],[0,-1,0],[0,-1,0],[.5,.5],[1,0],[0,0]);}
  return flat?flatten(g):g};
P.prism=function(){ // gable: triangle in XY (base y=-.5, peak y=+.5), extruded along Z
  const g=mk(),h=.5;
  tri(g,[-h,-h,h],[h,-h,h],[0,h,h],[0,0,1],[0,0,1],[0,0,1],[0,0],[1,0],[.5,1]);
  tri(g,[h,-h,-h],[-h,-h,-h],[0,h,-h],[0,0,-1],[0,0,-1],[0,0,-1],[0,0],[1,0],[.5,1]);
  const ns=V.norm([1,1,0]),nw=V.norm([-1,1,0]);
  quadFace(g,[h,-h,h],[h,-h,-h],[0,h,-h],[0,h,h],ns); quadFace(g,[-h,-h,-h],[-h,-h,h],[0,h,h],[0,h,-h],nw);
  quadFace(g,[-h,-h,-h],[h,-h,-h],[h,-h,h],[-h,-h,h],[0,-1,0]);return g};
P.wedge=function(){ // ramp: slope rises toward +Z top
  const g=mk(),h=.5;
  tri(g,[-h,-h,h],[h,-h,h],[h,h,h],[0,0,1],[0,0,1],[0,0,1],[0,0],[1,0],[1,1]);tri(g,[-h,-h,h],[h,h,h],[-h,h,h],[0,0,1],[0,0,1],[0,0,1],[0,0],[1,1],[0,1]);
  quadFace(g,[-h,-h,-h],[h,-h,-h],[h,-h,h],[-h,-h,h],[0,-1,0]);
  const n=V.norm([0,1,-1]);quadFace(g,[-h,-h,-h],[h,-h,-h],[h,h,h],[-h,h,h],V.norm([0,1,-1]));
  tri(g,[h,-h,-h],[h,-h,h],[h,h,h],[1,0,0],[1,0,0],[1,0,0],[0,0],[1,0],[1,1]);tri(g,[-h,-h,h],[-h,-h,-h],[-h,h,h],[-1,0,0],[-1,0,0],[-1,0,0],[0,0],[1,0],[1,1]);return g};
const cache={};
S.prim=function(name,...a){const k=name+':'+a.join(',');return cache[k]||(cache[k]=P[name](...a))};
S.P=P;

/* Batch: accumulate transformed geometry with per-vertex colour into one VBO */
class Batch{
  constructor(){this.d=[];this.n=0}
  add(prim,m,size,color,emis=0){
    m=m||M.ident();size=size||[1,1,1];if(typeof size==='number')size=[size,size,size];
    const c=hex(color),g=prim,N=g.pos.length/3,inv=[1/size[0],1/size[1],1/size[2]];
    for(let i=0;i<N;i++){
      const p=M.tp(m,[g.pos[i*3]*size[0],g.pos[i*3+1]*size[1],g.pos[i*3+2]*size[2]]);
      const n=V.norm(M.tn(m,[g.nrm[i*3]*inv[0],g.nrm[i*3+1]*inv[1],g.nrm[i*3+2]*inv[2]]));
      this.d.push(p[0],p[1],p[2],n[0],n[1],n[2],g.uv[i*2],g.uv[i*2+1],c[0],c[1],c[2],emis);
    }this.n+=N}
}
S.Batch=Batch;
})(window.Studio);


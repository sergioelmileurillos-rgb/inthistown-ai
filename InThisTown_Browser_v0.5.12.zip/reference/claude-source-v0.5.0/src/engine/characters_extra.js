/* engine/characters_extra.js — +30 accessories and +28 character presets (v2 quality pack).
   Accessory parts: head parts use head-centre coordinates (y=0 = middle of the head, front = +z .625);
   torso parts use torso coordinates (y 0 = waist, 2 = shoulders, front = +z .5).
   Use in story.json: "characters": {"chef1": {"preset":"chef"}, "x": {"preset":"hero","spec":{"accessory":["cowboyhat","bowtie"]}}} */
(function(S){
const A=S.AccExtra=S.AccExtra||{};
const P=(p,off,size,color,x={})=>Object.assign({p:Array.isArray(p)?p:[p],off,size,color},x);
const T=.625;
const col=(spec,k,d)=>spec[k]||d;

/* ---- hats / head ---- */
A.chefhat=(h)=>h.push(P('cyl',[0,T+.2,0],[1.3,.5,1.3],'#fff'),P(['sphere',10,7],[0,T+.85,0],[1.7,1.1,1.7],'#fff'));
A.hardhat=(h,t,s)=>h.push(P(['sphere',10,6],[0,T-.05,0],[1.45,.9,1.45],col(s,'hat','#ffd23a')),P('box',[0,T-.18,.9],[1.4,.12,.7],col(s,'hat','#ffd23a')),P('box',[0,T+.35,0],[.3,.15,1.2],sh(col(s,'hat','#ffd23a'),.85)));
A.helmet_space=(h)=>h.push(P(['sphere',12,8],[0,0,0],[1.95,1.95,1.95],'#e8f3ff',{alpha:.38,emis:.1}),P('cyl',[0,-.75,0],[1.9,.35,1.9],'#d8dbe2'),P('box',[0,0,-.9],[.8,.9,.2],'#d8dbe2'));
A.knighthelm=(h)=>h.push(P('box',[0,.15,0],[1.45,1.2,1.45],'#aab4c4'),P('box',[0,.22,T+.1],[1.2,.14,.1],'#16161c'),P('box',[0,-.1,T+.1],[.14,.7,.1],'#16161c'),P('box',[0,T+.2,-.3],[.2,.7,1],'#e84a4a'));
A.ninjamask=(h)=>h.push(P('box',[0,.5,0],[1.38,.5,1.38],'#16161c'),P('box',[0,-.35,0],[1.38,.55,1.38],'#16161c'),P('box',[-.9,.5,-.2],[.3,.15,.4],'#16161c',{rot:[0,0,.3]}));
A.piratehat=(h)=>h.push(P('box',[0,T+.2,0],[1.5,.5,1.5],'#16161c'),P('box',[0,T+.5,0],[2.2,.4,1],'#16161c'),P('box',[0,T+.45,.52],[.5,.3,.1],'#f2f2f2'));
A.eyepatch=(h)=>h.push(P('box',[-.3,.1,T+.03],[.42,.38,.05],'#16161c'),P('box',[0,.38,T+.02],[1.3,.06,.04],'#16161c',{rot:[0,0,-.12]}));
A.bandana=(h,t,s)=>h.push(P('box',[0,.3,0],[1.38,.4,1.38],col(s,'hat','#e84a4a')),P('box',[0,.1,-.8],[.5,.4,.3],col(s,'hat','#e84a4a'),{rot:[0,0,.6]}));
A.beanie=(h,t,s)=>h.push(P(['sphere',10,6],[0,T-.15,0],[1.5,.95,1.5],col(s,'hat','#e84a4a')),P('cyl',[0,T-.35,0],[1.5,.25,1.5],sh(col(s,'hat','#e84a4a'),.85)),P(['sphere',8,6],[0,T+.4,0],[.45,.45,.45],'#fff'));
A.cowboyhat=(h,t,s)=>h.push(P('cyl',[0,T+.2,0],[1.2,.6,1.2],col(s,'hat','#8a5a2a')),P('cyl',[0,T-.02,0],[2.5,.1,2.3],col(s,'hat','#8a5a2a')),P('cyl',[0,T+.12,0],[1.22,.16,1.22],'#3a2010'));
A.strawhat=(h)=>h.push(P('cyl',[0,T+.15,0],[1.2,.5,1.2],'#e8c35a'),P('cyl',[0,T-.02,0],[2.6,.08,2.6],'#e8c35a'),P('cyl',[0,T+.1,0],[1.22,.14,1.22],'#e84a4a'));
A.wizardhat=(h,t,s)=>h.push(P('cyl',[0,T-.02,0],[2.2,.1,2.2],col(s,'hat','#3a2a9a')),P(['cone',8,false],[0,T+1.3,0],[1.4,2.6,1.4],col(s,'hat','#3a2a9a')),P(['sphere',6,4],[0,T+.45,.3],[.3,.3,.3],'#ffd23a',{emis:.8}));
A.santahat=(h)=>h.push(P(['cone',8,false],[0,T+.6,-.1],[1.5,1.4,1.5],'#e83030',{rot:[-.2,0,0]}),P('cyl',[0,T+.1,0],[1.5,.3,1.5],'#fff'),P(['sphere',8,6],[0,T+1.1,-.5],[.4,.4,.4],'#fff'));
A.flowercrown=(h)=>{for(let i=0;i<8;i++){const a=i*.785;h.push(P(['sphere',6,4],[Math.cos(a)*.68,T+.05,Math.sin(a)*.68],[.35,.35,.35],['#ff6fa5','#ffd23a','#fff','#a45be8'][i%4]))}};
A.halo=(h)=>h.push(P('cyl',[0,T+.8,0],[1.2,.08,1.2],'#ffe14a',{emis:1}));
A.horns=(h,t,s)=>h.push(P(['cone',6,false],[-.45,T+.3,0],[.35,.9,.35],col(s,'horn','#f2ead6'),{rot:[0,0,.35]}),P(['cone',6,false],[.45,T+.3,0],[.35,.9,.35],col(s,'horn','#f2ead6'),{rot:[0,0,-.35]}));
A.catears=(h,t,s)=>h.push(P(['cone',4,false],[-.42,T+.3,0],[.45,.6,.3],col(s,'hair','#9a9aa8')),P(['cone',4,false],[.42,T+.3,0],[.45,.6,.3],col(s,'hair','#9a9aa8')));
A.bunnyears=(h,t,s)=>h.push(P('box',[-.3,T+.8,0],[.3,1.5,.15],col(s,'hair','#fff'),{rot:[0,0,.12]}),P('box',[.3,T+.8,0],[.3,1.5,.15],col(s,'hair','#fff'),{rot:[0,0,-.12]}),P('box',[-.3,T+.8,.09],[.14,1.2,.05],'#ffb8cc',{rot:[0,0,.12]}),P('box',[.3,T+.8,.09],[.14,1.2,.05],'#ffb8cc',{rot:[0,0,-.12]}));
A.antenna=(h)=>h.push(P('cyl',[0,T+.45,0],[.08,.9,.08],'#888'),P(['sphere',6,4],[0,T+.95,0],[.35,.35,.35],'#ff3030',{emis:1}));
A.goggles=(h,t,s)=>h.push(P('box',[0,.12,0],[1.38,.12,1.38],'#16161c'),P('cyl',[-.3,.12,T+.1],[.5,.2,.5],'#8fd2ff',{rot:[PI2,0,0],emis:.2}),P('cyl',[.3,.12,T+.1],[.5,.2,.5],'#8fd2ff',{rot:[PI2,0,0],emis:.2}));
A.headset=(h)=>h.push(P('box',[0,T+.05,0],[1.5,.1,.2],'#222'),P('box',[-.76,0,0],[.25,.55,.5],'#222'),P('box',[.76,0,0],[.25,.55,.5],'#222'),P('box',[.55,-.35,T-.1],[.12,.12,.9],'#222',{rot:[0,.5,0]}),P(['sphere',6,4],[.7,-.45,T+.3],[.22,.22,.22],'#ff3030',{emis:.6}));
A.monocle=(h)=>h.push(P('cyl',[.3,.05,T+.05],[.5,.06,.5],'#ffd23a',{rot:[PI2,0,0]}),P('box',[.3,-.4,T+.06],[.03,.6,.02],'#ffd23a'));
A.eyebrows_big=(h)=>h.push(P('box',[-.3,.4,T+.04],[.45,.12,.05],'#2a1a10'),P('box',[.3,.4,T+.04],[.45,.12,.05],'#2a1a10'));
A.bigsmile_teeth=(h)=>h.push(P('box',[0,-.22,T+.04],[.7,.14,.04],'#fff'));
A.blush=(h)=>h.push(P('box',[-.42,-.08,T+.02],[.22,.12,.03],'#ff7a98'),P('box',[.42,-.08,T+.02],[.22,.12,.03],'#ff7a98'));
A.bandaid=(h)=>h.push(P('box',[.25,.05,T+.03],[.38,.14,.03],'#f6c9a0',{rot:[0,0,.4]}));
A.mask_hero=(h,t,s)=>h.push(P('box',[0,.3,T+.02],[1.28,.12,.05],col(s,'hat','#16161c')),P('box',[0,-.06,T+.02],[1.28,.1,.05],col(s,'hat','#16161c')),P('box',[-.6,.12,T+.02],[.1,.5,.05],col(s,'hat','#16161c')),P('box',[.6,.12,T+.02],[.1,.5,.05],col(s,'hat','#16161c')));
A.mask_lower=(h,t,s)=>h.push(P('box',[0,-.3,T+.03],[1.1,.5,.06],col(s,'hat','#16161c')));
A.mask_surgical=(h)=>h.push(P('box',[0,-.3,T+.03],[1.1,.5,.06],'#8fd2ff'));

/* ---- torso ---- */
A.labcoat=(h,t)=>t.push(P('box',[0,1,0],[2.14,2.04,1.14],'#f4f6fa'),P('box',[0,1,.58],[.1,2,.04],'#c8ccd6'),P('box',[-.6,.4,.6],[.5,.5,.04],'#dfe3ea'));
A.apron=(h,t,s)=>t.push(P('box',[0,.9,.54],[1.6,1.6,.06],col(s,'apron','#fff')),P('box',[0,1.9,.52],[1.6,.1,.05],col(s,'apron','#fff')));
A.stethoscope=(h,t)=>t.push(P('box',[-.4,1.6,.55],[.1,.9,.06],'#222',{rot:[0,0,.2]}),P('box',[.4,1.6,.55],[.1,.9,.06],'#222',{rot:[0,0,-.2]}),P('cyl',[0,1.1,.56],[.3,.1,.3],'#aaa',{rot:[PI2,0,0]}));
A.medcross=(h,t)=>t.push(P('box',[0,1.1,.54],[.9,.28,.04],'#e83030'),P('box',[0,1.1,.54],[.28,.9,.04],'#e83030'));
A.armor=(h,t)=>t.push(P('box',[0,1,0],[2.2,2.1,1.2],'#aab4c4'),P('box',[0,1,.62],[1.2,1.4,.06],'#c8d0de'),P('box',[-1.35,2,0],[1,.5,1.2],'#aab4c4'),P('box',[1.35,2,0],[1,.5,1.2],'#aab4c4'));
A.vest=(h,t,s)=>t.push(P('box',[0,1,.54],[1.9,1.9,.06],col(s,'vest','#ff7a1a')),P('box',[-.55,1,.58],[.28,1.9,.04],'#f4f4f4'),P('box',[.55,1,.58],[.28,1.9,.04],'#f4f4f4'));
A.wings=(h,t,s)=>t.push(P('box',[-1.9,1.8,-.6],[2.6,.2,1.6],col(s,'wing','#fff'),{rot:[0,.3,.4]}),P('box',[1.9,1.8,-.6],[2.6,.2,1.6],col(s,'wing','#fff'),{rot:[0,-.3,-.4]}));
A.tail=(h,t,s)=>t.push(P('box',[0,.2,-.9],[.3,.3,1.4],col(s,'tail','#c28a4a'),{rot:[.5,0,0]}));
A.bowtie=(h,t,s)=>t.push(P('box',[-.3,1.95,.52],[.5,.35,.08],col(s,'tie','#e84a4a'),{rot:[0,0,.2]}),P('box',[.3,1.95,.52],[.5,.35,.08],col(s,'tie','#e84a4a'),{rot:[0,0,-.2]}),P('box',[0,1.95,.54],[.2,.2,.1],sh(col(s,'tie','#e84a4a'),.7)));
A.badge=(h,t)=>t.push(P('box',[.55,1.5,.54],[.45,.5,.05],'#ffd23a',{emis:.2}));
A.necklace=(h,t)=>t.push(P('box',[0,1.9,.52],[1,.08,.05],'#ffd23a'),P(['sphere',6,4],[0,1.65,.55],[.35,.35,.2],'#ffd23a',{emis:.3}));
A.lanyard=(h,t)=>t.push(P('box',[-.3,1.5,.53],[.08,1.2,.04],'#2f6df6',{rot:[0,0,.2]}),P('box',[.3,1.5,.53],[.08,1.2,.04],'#2f6df6',{rot:[0,0,-.2]}),P('box',[0,.85,.55],[.6,.8,.05],'#fff'));
A.rags=(h,t)=>t.push(P('box',[-.6,.2,.52],[.5,.5,.04],'#3a2a22'),P('box',[.5,1.5,.52],[.6,.4,.04],'#3a2a22'),P('box',[.1,.6,.52],[.3,.6,.04],'#4a3a2e'));
A.jetpack=(h,t)=>t.push(P('cyl',[-.5,1.1,-.8],[.7,1.7,.7],'#aab4c4'),P('cyl',[.5,1.1,-.8],[.7,1.7,.7],'#aab4c4'),P(['cone',8,false],[-.5,.1,-.8],[.6,.6,.6],'#ffb02a',{emis:1,rot:[PI,0,0]}),P(['cone',8,false],[.5,.1,-.8],[.6,.6,.6],'#ffb02a',{emis:1,rot:[PI,0,0]}));
A.cape_super=(h,t,s)=>t.push(P('box',[0,.9,-.62],[1.9,2.5,.1],col(s,'cape','#e83030'),{rot:[.15,0,0]}),P('box',[0,2.05,-.4],[2.1,.3,.3],col(s,'cape','#e83030')));
A.sash_gold=(h,t)=>t.push(P('box',[0,1,.52],[.45,2.5,.06],'#ffd23a',{rot:[0,0,.65],emis:.2}));
A.scarf_long=(h,t,s)=>t.push(P('box',[0,1.95,0],[2.1,.35,1.1],col(s,'scarf','#e84a4a')),P('box',[.5,1,.55],[.4,1.8,.08],col(s,'scarf','#e84a4a')));
const PI=Math.PI, PI2=Math.PI/2; const sh=S.shade;

/* ---- presets ---- */
const R=S.PRESETS;
const add=(k,v)=>{R[k]=Object.assign({decal:'none',face:'smile',sleeves:'short',shoes:'#f2f2f2'},v)};
add('robber',{skin:'#f4c9a1',hair:'#16161c',hairStyle:'short',shirt:'#f2f2f2',decal:'stripes3',pants:'#16161c',shoes:'#16161c',face:'smirk',accessory:['mask_lower','beanie'],hat:'#16161c',sleeves:'long'});
add('chef',{skin:'#e8b48a',hair:'#2a1a10',hairStyle:'short',shirt:'#ffffff',pants:'#3b3f4a',shoes:'#222',face:'grin',accessory:['chefhat','apron','mustache'],sleeves:'long'});
add('doctor',{skin:'#c68a5c',hair:'#16161c',hairStyle:'short',shirt:'#3fb8d8',pants:'#2b6a8a',shoes:'#fff',face:'neutral',accessory:['labcoat','stethoscope','glasses'],sleeves:'long'});
add('nurse',{skin:'#f6d7b7',hair:'#c6702f',hairStyle:'bun',shirt:'#8fd2ff',pants:'#8fd2ff',shoes:'#fff',face:'smile',accessory:['medcross','mask_surgical'],sleeves:'short'});
add('astronaut',{skin:'#f4c9a1',hair:'#2a1a10',hairStyle:'short',shirt:'#f2f4f8',pants:'#e0e4ec',shoes:'#aab4c4',face:'shock',accessory:['helmet_space','jetpack','badge'],sleeves:'long'});
add('king',{skin:'#f4c9a1',hair:'#d9d9de',hairStyle:'bald',shirt:'#8a1f3a',pants:'#8a1f3a',shoes:'#ffd23a',face:'smug',beard:'#d9d9de',accessory:['crown','sash_gold','mustache'],sleeves:'long',scale:1.05});
add('queen',{skin:'#f6d7b7',hair:'#7a4a22',hairStyle:'long',shirt:'#a45be8',pants:'#a45be8',shoes:'#ffd23a',face:'cute',accessory:['crown','necklace'],sleeves:'long'});
add('knight',{skin:'#e8b48a',hair:'#2a1a10',hairStyle:'bald',shirt:'#aab4c4',pants:'#8a94a6',shoes:'#6b7488',face:'neutral',accessory:['knighthelm','armor'],sleeves:'long'});
add('ninja',{skin:'#f4c9a1',hair:'#16161c',hairStyle:'bald',shirt:'#16161c',pants:'#16161c',shoes:'#16161c',face:'angry',accessory:['ninjamask'],sleeves:'long'});
add('farmer',{skin:'#e8b48a',hair:'#7a4a22',hairStyle:'short',shirt:'#c8453c',pants:'#3a5bd6',shoes:'#6b3b1d',face:'grin',accessory:['strawhat'],sleeves:'long'});
add('cowboy',{skin:'#d9a070',hair:'#4b2d14',hairStyle:'short',shirt:'#e8c35a',pants:'#3a5bd6',shoes:'#6b3b1d',face:'smirk',accessory:['cowboyhat','bandana','badge'],sleeves:'long'});
add('zombie',{skin:'#8fbf7a',hair:'#3a2a22',hairStyle:'messy',shirt:'#5a6c85',pants:'#3a3a4a',shoes:'#444',face:'dead',accessory:['rags'],sleeves:'long'});
add('robot',{skin:'#aab4c4',hair:'#aab4c4',hairStyle:'bald',shirt:'#8a94a6',pants:'#6b7488',shoes:'#555',face:'neutral',accessory:['antenna','headphones'],decal:'bolt',sleeves:'long'});
add('alien',{skin:'#6bd86b',hair:'#6bd86b',hairStyle:'bald',shirt:'#a45be8',pants:'#5a3a9a',shoes:'#16161c',face:'cute',accessory:['antenna'],sleeves:'short'});
add('pirate',{skin:'#d9a070',hair:'#16161c',hairStyle:'long',shirt:'#f2f2f2',pants:'#6b3b1d',shoes:'#3a2010',face:'smirk',accessory:['piratehat','eyepatch','sash'],beard:'#16161c',sleeves:'long'});
add('scientist',{skin:'#f4c9a1',hair:'#d9d9de',hairStyle:'messy',shirt:'#f2f2f2',pants:'#3b3f4a',shoes:'#222',face:'worried',accessory:['labcoat','goggles'],sleeves:'long'});
add('baby',{skin:'#f6d7b7',hair:'#c6702f',hairStyle:'messy',shirt:'#ffe0ec',pants:'#ffe0ec',shoes:'#fff',face:'cute',accessory:['blush'],sleeves:'short',scale:.55});
add('athlete',{skin:'#8d5a3a',hair:'#16161c',hairStyle:'short',shirt:'#e84a4a',pants:'#fff',shoes:'#fff',face:'grin',accessory:['headband'],decal:'bolt',sleeves:'short',scale:1.08});
add('wizard',{skin:'#e8b48a',hair:'#d9d9de',hairStyle:'bald',shirt:'#3a2a9a',pants:'#3a2a9a',shoes:'#16161c',face:'smile',beard:'#d9d9de',accessory:['wizardhat','glasses'],hat:'#3a2a9a',sleeves:'long'});
add('princess',{skin:'#f6d7b7',hair:'#e8c35a',hairStyle:'long',shirt:'#ff8fb3',pants:'#ff8fb3',shoes:'#ffd23a',face:'cute',accessory:['crown','blush'],decal:'heart',sleeves:'short'});
add('firefighter',{skin:'#d9a070',hair:'#2a1a10',hairStyle:'short',shirt:'#e8453c',pants:'#3a3a4a',shoes:'#222',face:'grin',accessory:['hardhat','vest'],hat:'#ffd23a',sleeves:'long'});
add('builder',{skin:'#e8b48a',hair:'#4b2d14',hairStyle:'short',shirt:'#ff7a1a',pants:'#3a5bd6',shoes:'#6b3b1d',face:'grin',accessory:['hardhat','vest'],hat:'#ffd23a',sleeves:'short'});
add('mailman',{skin:'#c68a5c',hair:'#16161c',hairStyle:'cap',hat:'#2a4fa8',shirt:'#5a8ad8',pants:'#2a4fa8',shoes:'#222',face:'smile',accessory:['backpack','badge'],sleeves:'short'});
add('bully',{skin:'#e8b48a',hair:'#a33b20',hairStyle:'spiky',shirt:'#16161c',pants:'#3b3f4a',shoes:'#e84a4a',face:'evil',accessory:['bandaid'],decal:'skull',sleeves:'short',scale:1.2});
add('nerd',{skin:'#f4c9a1',hair:'#4b2d14',hairStyle:'bob',shirt:'#e8f3ff',pants:'#3b3f4a',shoes:'#fff',face:'worried',accessory:['glasses','bowtie','backpack'],sleeves:'short',scale:.92});
add('rich',{skin:'#f4c9a1',hair:'#16161c',hairStyle:'short',shirt:'#16161c',pants:'#16161c',shoes:'#111',face:'smug',accessory:['tophat','monocle','mustache','bowtie'],sleeves:'long'});
add('gamer',{skin:'#f4c9a1',hair:'#2f6df6',hairStyle:'messy',shirt:'#6a2fd8',pants:'#2b2f3a',shoes:'#16161c',face:'grin',accessory:['headset'],decal:'bolt',sleeves:'long'});
add('reporter',{skin:'#d9a070',hair:'#2a1a10',hairStyle:'short',shirt:'#e84a4a',pants:'#2b2f3a',shoes:'#222',face:'talk',accessory:['tie','lanyard'],sleeves:'long'});
add('hero2',{skin:'#8d5a3a',hair:'#16161c',hairStyle:'spiky',shirt:'#e83030',pants:'#2f6df6',shoes:'#ffd23a',face:'grin',accessory:['cape_super','mask_hero'],decal:'bolt',sleeves:'short'});
add('villain',{skin:'#d9d9e8',hair:'#16161c',hairStyle:'spiky',shirt:'#3a1a5a',pants:'#16161c',shoes:'#16161c',face:'evil',accessory:['cape_super','horns'],cape:'#7a1f9a',sleeves:'long',scale:1.1});
add('stalker',{skin:'#8c93a3',hair:'#8c93a3',hairStyle:'bald',shirt:'#7a8294',pants:'#7a8294',shoes:'#7a8294',face:'neutral',scale:3.4,sleeves:'long'});
add('angel',{skin:'#fff0dc',hair:'#ffe9a0',hairStyle:'bob',shirt:'#ffffff',pants:'#ffffff',shoes:'#fff',face:'cute',accessory:['halo','wings'],sleeves:'long'});
add('bunny',{skin:'#fff',hair:'#fff',hairStyle:'bald',shirt:'#ffb8cc',pants:'#fff',shoes:'#fff',face:'cute',accessory:['bunnyears','tail'],tail:'#fff',sleeves:'short',scale:.9});
add('catgirl',{skin:'#f6d7b7',hair:'#9a9aa8',hairStyle:'bob',shirt:'#6a4bc8',pants:'#3b3f4a',shoes:'#fff',face:'cute',accessory:['catears','tail'],sleeves:'short'});
S.PRESET_NAMES=()=>Object.keys(R);
})(window.Studio);


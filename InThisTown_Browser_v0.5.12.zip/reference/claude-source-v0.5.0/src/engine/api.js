/* engine/api.js — page-level API driven by scripts/render.js (Playwright) */
(function(S){
let R=null,W=576,H=1024,story=null,cur=null,startStates=[{}],all_=[];
const api={
  init(w,h,opts){W=w;H=h;const c=document.getElementById('gl')||document.getElementById('c');if(!c)throw new Error('No se encontró el canvas de renderizado 3D (#gl).');R=new S.Renderer(c,w,h,opts||{});R.quadMesh=R.uploadPrim(S.prim('quad'));return {gl:R.gl.getParameter(R.gl.VERSION)}},
  setStory(s){for(const c of all_)if(c&&c.mesh)R.free(c.mesh);all_=[];story=s;cur=null;startStates=[{}];return true},
  use(i){if(!all_[i])throw new Error('Escena '+i+' sin compilar');cur=all_[i];return true},
  compileAll(){const out=[];for(let i=0;i<story.scenes.length;i++){out.push(this.compile(i,{fast:false}))}return out},
  frameAt(i,t){cur=all_[i];S.Director.renderFrame(cur,t,W,H);return true},
  validateAll(){const o=[];for(let i=0;i<all_.length;i++)o.push(S.Director.validate(all_[i]));return o},
  /* compile scene idx (carrying actor state from earlier scenes). Returns metadata only. */
  compile(idx,opts={}){
    if(!story||!Array.isArray(story.scenes)||!story.scenes[idx])throw new Error('Índice de escena no válido: '+idx);
    cur=null;const all=story.scenes;if(all_[idx]&&all_[idx].mesh){R.free(all_[idx].mesh);all_[idx]=null}
    // Cache the actor end-state as scenes are compiled in order. The previous
    // implementation rebuilt every earlier scene for each new scene (O(n²)).
    while(startStates.length<=idx){
      const prevIndex=startStates.length-1;
      const previous=S.Director.compileScene(R,story,all[prevIndex],{fast:true,prevEnd:startStates[prevIndex]||{}});
      startStates.push(Object.assign({},previous.end));
    }
    const prev=startStates[idx]||{};
    cur=S.Director.compileScene(R,story,all[idx],{fast:!!opts.fast,prevEnd:prev});
    all_[idx]=cur;const end=Object.assign({},cur.end);
    if(startStates.length===idx+1)startStates.push(end);else startStates[idx+1]=end;
    return {id:all[idx].id,dur:cur.dur,warns:cur.warns,sfx:cur.sfx,end:cur.end,startState:prev}},
  validate(idx){const r=this.compile(idx);const issues=S.Director.validate(cur);return {issues,sfx:r.sfx,dur:r.dur,startState:r.startState}},
  cam(t){const c=S.Director.camEval(cur,t);const r=a=>a.map(v=>+v.toFixed(2));return {pos:r(c.pos),look:r(c.look),fov:c.fov,actors:Object.fromEntries(Object.entries(cur.actors).map(([k,A])=>[k,r(A.posAt(t))]))}},
  frame(t){S.Director.renderFrame(cur,t,W,H);return true},
  jpeg(q=.93){return R.canvas.toDataURL('image/jpeg',q).split(',')[1]},
  png(){return R.canvas.toDataURL('image/png').split(',')[1]},
  assets(){return {extras:{props:S.Props.extraNames,anims:S.Anim.extraNames,fx:S.Fx.extraNames,worlds:S.Worlds.extraNames},clips:S.Anim.names(),faces:S.FACES,presets:Object.keys(S.PRESETS),worlds:Object.keys(S.Worlds),props:S.Props.names(),skies:Object.keys(S.ENV),fx:Object.keys(S.Fx.GEN),shots:Object.keys({close:1,medium:1,wide:1,low:1,high:1,over:1,follow:1,profile:1,front:1,top:1,pov:1,extreme:1,dutch:1,hero:1,long:1})}},
};
S.api=api;window.api=api;
})(window.Studio);


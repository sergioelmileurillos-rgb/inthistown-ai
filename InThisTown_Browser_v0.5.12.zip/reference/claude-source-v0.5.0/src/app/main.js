/* In This Town v0.5 — motor 3D procedural WebGL2 + motor de historias + Kokoro-82M + render sincronizado al reloj de audio. */
(() => {
  'use strict';
  const $ = id => document.getElementById(id);
  const FPS = 24, W = 576, H = 1024;
  const KOKORO_VOICE = 'am_adam';
  const {Story,Compose,Timing,Sfx} = window.ITT;
  const state = {busy:false,cancel:false,mode:'unavailable',engine:null,worker:null,workerReady:null,workerPending:new Map(),workerSeq:0,story:null,composed:null,musicFile:null,stage:'inicio',variant:0,lastIdea:''};
  const glCanvas = $('gl'), outCanvas = $('out'), outCtx = outCanvas.getContext('2d',{alpha:false});
  let jobUrl = null;
  const setStatus = (text, progress) => {$('status').textContent = text; if (progress !== undefined) $('bar').style.width = Math.max(0,Math.min(100,progress))+'%';};
  const setBusy = value => {state.busy=value; $('create').disabled=value || state.mode!=='webgl'; $('create').textContent=value?'CREANDO TU VÍDEO…':'✦ CREAR MI VÍDEO'; $('cancel').style.display=value?'block':'none';};
  const escapeText = s => String(s).replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
  const sleep = ms => new Promise(r=>setTimeout(r,ms));
  const checkCancel = () => {if(state.cancel) throw new Error('Cancelado por el usuario.');};
  $('idea').addEventListener('input',()=>{$('count').textContent=$('idea').value.length+' / 300';});
  document.querySelectorAll('.example[data-idea]').forEach(b=>b.addEventListener('click',()=>{$('idea').value=b.dataset.idea;$('count').textContent=$('idea').value.length+' / 300';$('idea').focus();}));
  $('musicFile')?.addEventListener('change',e=>{const f=e.target.files?.[0]||null;state.musicFile=f;$('musicName').textContent=f?`Pista seleccionada: ${f.name}`:'Sin pista propia · música ambiental original';});
  $('clearMusic')?.addEventListener('click',()=>{state.musicFile=null;if($('musicFile'))$('musicFile').value='';$('musicName').textContent='Sin pista propia · música ambiental original';});
  $('cancel').addEventListener('click',()=>{state.cancel=true;setStatus('Cancelando…');});

  function initRenderer(){
    try {
      if (!window.Studio?.api) throw new Error('No se han cargado los módulos del motor 3D.');
      const info=Studio.api.init(W,H,{SM:1024});
      state.mode='webgl';$('engineBadge').textContent='Motor 3D activo';$('engineBadge').style.color='var(--green)';$('create').disabled=false;return info;
    } catch(e) {
      state.mode='unavailable';$('engineBadge').textContent='WebGL 2 no disponible';$('engineBadge').style.color='var(--amber)';$('create').disabled=true;
      console.error('No se pudo iniciar el motor 3D:',e);
      setStatus('Este navegador no ha podido iniciar WebGL 2. Actualiza Chrome/Safari (iOS 15+) y activa la aceleración gráfica. No se generará un vídeo 2D de sustitución.');return null;
    }
  }

  // Embedded copy for extracted file:// copies. This avoids fetching a sibling
  // worker file from the ZIP/local-file origin. WASM inference stays off the UI thread.
  function inlineKokoroWorker(){
    const KOKORO_MODULE_URL='https://cdn.jsdelivr.net/npm/kokoro-js@1.2.1/dist/kokoro.web.js';
    const MODEL_ID='onnx-community/Kokoro-82M-v1.0-ONNX';
    let tts=null,loading=null;
    function postError(id,phase,error){
      const message=error&&typeof error==='object'?(error.message||error.name||JSON.stringify(error)):String(error);
      self.postMessage({type:'error',id:id??null,phase,message,stack:error?.stack||''});
    }
    async function loadModel(){
      if(tts)return tts;if(loading)return loading;
      loading=(async()=>{
        self.postMessage({type:'progress',message:'Cargando Kokoro en segundo plano…',progress:8});
        const mod=await import(KOKORO_MODULE_URL);
        if(!mod.KokoroTTS)throw new Error('La compilación de Kokoro no expone KokoroTTS.');
        tts=await mod.KokoroTTS.from_pretrained(MODEL_ID,{
          dtype:'q8',device:'wasm',
          progress_callback:event=>{
            const loaded=Number(event?.loaded||0),total=Number(event?.total||0),file=event?.file||event?.name||event?.path||'modelo';
            if(total>0)self.postMessage({type:'progress',message:`Descargando Kokoro (${file}) · ${Math.round(loaded/1048576)} / ${Math.round(total/1048576)} MB…`,progress:Math.round(10+Math.min(1,loaded/total)*14)});
            else if(event?.status)self.postMessage({type:'progress',message:`Preparando Kokoro (${file}) · ${event.status}…`,progress:12});
          }
        });
        if(typeof tts.generate!=='function')throw new Error('Kokoro se ha cargado, pero no ofrece generate().');
        self.postMessage({type:'ready',message:'Kokoro está listo en segundo plano.'});return tts;
      })();
      try{return await loading;}catch(error){tts=null;loading=null;throw error;}
    }
    self.addEventListener('message',async event=>{
      const data=event.data||{};
      if(data.type==='load'){try{await loadModel();}catch(error){postError(null,'carga de Kokoro',error);}return;}
      if(data.type==='generate'){
        try{
          const model=await loadModel();
          const result=await model.generate(String(data.text||''),{voice:data.voice||'am_adam',speed:Number(data.speed||1)});
          const audio=result?.audio instanceof Float32Array?result.audio:(result?.audio?.audio instanceof Float32Array?result.audio.audio:null);
          if(!audio||!audio.length)throw new Error('Kokoro no ha devuelto muestras de audio.');
          const sampleRate=result?.sampling_rate||result?.sample_rate||result?.audio?.sampling_rate||24000;
          self.postMessage({type:'audio',id:data.id,audio,sampleRate},[audio.buffer]);
        }catch(error){postError(data.id,'generación de voz',error);}
      }
    });
  }


  function workerFailure(e){
    const msg=e?.message||'No se ha podido iniciar el proceso de voz en segundo plano.';
    for(const [id,p] of state.workerPending){p.reject(new Error(msg));state.workerPending.delete(id);}
    if(state.workerReadyReject){state.workerReadyReject(new Error(msg));state.workerReadyReject=null;}
    try{state.worker?.terminate();}catch{}
    state.worker=null;state.workerReady=null;state.engine=null;
    if(state.workerBlobUrl){try{URL.revokeObjectURL(state.workerBlobUrl);}catch{}state.workerBlobUrl=null;}
  }

  function generateInWorker(text,opts={}){
    if(!state.worker) return Promise.reject(new Error('El proceso de Kokoro no está activo.'));
    const id=++state.workerSeq;
    return new Promise((resolve,reject)=>{
      state.workerPending.set(id,{resolve,reject});
      try{state.worker.postMessage({type:'generate',id,text,voice:opts.voice||KOKORO_VOICE,speed:opts.speed||.96});}
      catch(error){state.workerPending.delete(id);reject(error);}
    });
  }


  async function loadKokoro(progress){
    if(state.engine) return state.engine;
    if(state.workerReady) return state.workerReady;
    state.stage='carga de Kokoro';
    // HTTPS uses the separate worker file. Extracted file:// copies use an
    // embedded Blob module worker, so the app can be opened without publishing.
    if(!window.Worker) throw new Error('Este navegador no admite Web Workers. Actualiza Chrome para ejecutar Kokoro sin bloquear la página.');
    progress(location.protocol==='file:'
      ? 'Iniciando Kokoro en segundo plano desde la copia local…'
      : 'Iniciando Kokoro en segundo plano para no bloquear Chrome…',8);
    state.workerReady=new Promise((resolve,reject)=>{
      state.workerReadyReject=reject;
      let worker;
      try{
        const source=`(${inlineKokoroWorker.toString()})();`;
        const blobUrl=URL.createObjectURL(new Blob([source],{type:'text/javascript'}));
        state.workerBlobUrl=blobUrl;
        worker=new Worker(blobUrl,{type:'module',name:'in-this-town-kokoro'});
      }catch(error){
        state.workerReady=null;state.workerReadyReject=null;
        reject(new Error('No se pudo iniciar Kokoro en segundo plano. Detalle: '+errorText(error)));
        return;
      }
      state.worker=worker;
      worker.addEventListener('message',(event)=>{
        const msg=event.data||{};
        if(msg.type==='progress'){
          progress(msg.message||'Preparando Kokoro…',msg.progress??12);
          return;
        }
        if(msg.type==='ready'){
          state.engine={generate:generateInWorker};
          if(state.workerBlobUrl){try{URL.revokeObjectURL(state.workerBlobUrl);}catch{}state.workerBlobUrl=null;}
          state.workerReadyReject=null;
          progress('Kokoro-82M listo · voz am_adam · cálculo en segundo plano.',25);
          resolve(state.engine);
          return;
        }
        if(msg.type==='audio'){
          const pending=state.workerPending.get(msg.id);
          if(pending){state.workerPending.delete(msg.id);pending.resolve({audio:msg.audio,sampling_rate:msg.sampleRate});}
          return;
        }
        if(msg.type==='error'){
          const detail=msg.message||'Error desconocido del proceso Kokoro.';
          if(msg.id!=null){const pending=state.workerPending.get(msg.id);if(pending){state.workerPending.delete(msg.id);pending.reject(new Error(detail));}}
          else {
            workerFailure(new Error(`Kokoro no ha podido iniciarse: ${detail}`));
          }
        }
      });
      worker.addEventListener('error',(event)=>{
        const detail=event.message||'Error en el proceso de voz';
        workerFailure(new Error(detail));
      });
      worker.addEventListener('messageerror',()=>workerFailure(new Error('Chrome no pudo recibir los datos de audio del proceso Kokoro.')));
      worker.postMessage({type:'load'});
    });
    try{return await state.workerReady;}
    catch(error){state.workerReady=null;state.engine=null;throw error;}
  }


  function errorText(e){
    if(typeof e==='number') return `Valor numérico: ${e} (0x${(e>>>0).toString(16).toUpperCase()})`;
    if(typeof e==='string') return e;
    if(e===null) return 'El navegador devolvió null.';
    if(e===undefined) return 'El navegador devolvió un error vacío (undefined).';
    if(e instanceof Error) {
      const parts=[`${e.name}: ${e.message}`];
      if(e.code!==undefined) parts.push(`code=${e.code}`);
      if(e.cause!==undefined && e.cause!==e) parts.push(`cause=${errorText(e.cause)}`);
      if(e.stack) parts.push(e.stack.split('\n').slice(0,4).join(' | '));
      return parts.join(' · ');
    }
    if(typeof e==='object') {
      const parts=[];
      for(const k of ['name','message','code','status','url','type','cause']) {
        if(e[k]!==undefined && e[k]!==e) parts.push(`${k}=${typeof e[k]==='object'?errorText(e[k]):String(e[k])}`);
      }
      if(parts.length) return parts.join(' · ');
      try { return JSON.stringify(e)||Object.prototype.toString.call(e); } catch { return Object.prototype.toString.call(e); }
    }
    return String(e);
  }



  /* ---------- voz: proveedor Kokoro (o sustituto inyectado en pruebas) ---------- */
  async function getTTS(progress){ if(window.__ITT_TTS) return window.__ITT_TTS; return loadKokoro(progress); }
  async function synthesize(story,progress){
    const engine=await getTTS(progress);const infos=[];let sr=24000;
    for(let i=0;i<story.beats.length;i++){
      checkCancel();
      progress(`Narrando con Kokoro am_adam · frase ${i+1}/${story.beats.length}…`,12+(i/story.beats.length)*22);
      const text=Timing.normalizeForTTS(story.beats[i].vo);
      const result=await engine.generate(text,{voice:KOKORO_VOICE,speed:1});
      const pcm=result?.audio instanceof Float32Array ? result.audio : (result?.audio?.audio instanceof Float32Array ? result.audio.audio : null);
      sr=result?.sampling_rate||result?.sample_rate||sr;
      if(!pcm||!pcm.length) throw new Error('Kokoro no ha generado audio válido para la frase '+(i+1)+'.');
      infos.push(Object.assign({vo:story.beats[i].vo},Timing.analyze(story.beats[i].vo,pcm,sr)));
    }
    return {infos,sr};
  }

  /* ---------- validación previa al render ---------- */
  function preflight(composed){
    const report=[];const add=(sev,msg)=>report.push({sev,msg});
    composed.warnings.forEach(w=>add('warn',w));
    if(!composed.engine.scenes.length) add('error','No hay escenas.');
    for(const b of composed.captions){ if(!b.vo.trim()) add('error','Frase vacía en la posición '+(b.i+1)); if(b.end-b.start>9) add('warn',`La frase ${b.i+1} dura ${(b.end-b.start).toFixed(1)} s (muy larga).`); }
    return report;
  }
  function engineValidation(composed,report){
    const res=Studio.api.validateAll();
    res.forEach((issues,si)=>issues.forEach(is=>{ if(is.type==='actor-overlap')return; report.push({sev:is.sev==='error'?'error':'warn',msg:`[decorado ${si+1}] ${is.msg}`}); }));
  }
  function renderReport(report){
    const body=$('reportBody');
    if(!report.length){body.innerHTML='<p>Sin avisos: referencias, tiempos, cámara y colisiones correctos.</p>';}
    else body.innerHTML=report.slice(0,60).map(r=>`<p class="${r.sev==='error'?'error':''}">${r.sev==='error'?'✖':'⚠'} ${escapeText(r.msg)}</p>`).join('')+(report.length>60?`<p>… y ${report.length-60} más</p>`:'');
    $('report').open=report.some(r=>r.sev==='error');
  }

  function getMime(){
    const candidates=['video/mp4;codecs=avc1.42E01E,mp4a.40.2','video/mp4','video/webm;codecs=vp9,opus','video/webm;codecs=vp8,opus','video/webm'];
    for(const t of candidates){try{if(MediaRecorder.isTypeSupported(t))return t;}catch{}}
    return '';
  }

  async function loadMusic(ctx,mood){
    // Optional user-selected soundtrack. The file stays on-device and is never uploaded.
    if(state.musicFile){
      const bytes=await state.musicFile.arrayBuffer();
      try { return await ctx.decodeAudioData(bytes.slice(0)); }
      catch(e){ throw new Error('No se ha podido leer el archivo de música. Prueba con MP3, WAV, M4A u OGG.'); }
    }
    // Original ambient bed generated locally as a fallback; no copyrighted recording bundled.
    const patterns={
      quirky:[{b:82,p:165,m:247},{b:98,p:196,m:294},{b:110,p:220,m:330},{b:98,p:196,m:294}],
      suspense:[{b:55,p:110,m:165},{b:62,p:124,m:185},{b:58,p:116,m:174},{b:65,p:130,m:196}],
      tense:[{b:49,p:98,m:147},{b:55,p:110,m:165},{b:52,p:104,m:156},{b:58,p:116,m:174}],
      chill:[{b:73,p:146,m:220},{b:82,p:165,m:247},{b:87,p:174,m:262},{b:82,p:165,m:247}],
      spooky:[{b:55,p:110,m:165},{b:65,p:130,m:196},{b:58,p:116,m:174},{b:73,p:146,m:220}]
    };
    const pattern=patterns[mood]||patterns.spooky, seconds=8, length=ctx.sampleRate*seconds;
    const buffer=ctx.createBuffer(2,length,ctx.sampleRate), left=buffer.getChannelData(0), right=buffer.getChannelData(1);
    for(let i=0;i<length;i++){
      const t=i/ctx.sampleRate, beat=t%2, bar=Math.floor(t/2)%4, n=pattern[bar];
      const fade=Math.min(1,t/.7,(seconds-t)/.7);
      const bass=Math.sin(2*Math.PI*n.b*t)*.025;
      const pad=(Math.sin(2*Math.PI*n.p*t)+.25*Math.sin(2*Math.PI*n.p*2*t)+.12*Math.sin(2*Math.PI*n.p*3*t))*.012;
      const shimmer=Math.sin(2*Math.PI*n.m*t+Math.sin(t*1.7)*.18)*.006;
      const pluck=Math.exp(-beat*4.5)*Math.sin(2*Math.PI*n.m*t)*.012;
      const pulse=Math.exp(-beat*13)*Math.sin(2*Math.PI*48*beat)*.009;
      const sample=(bass+pad+shimmer+pluck+pulse)*Math.max(0,fade);
      left[i]=sample;right[i]=(bass+pad+Math.sin(2*Math.PI*n.m*(t+.003))*.006+pluck+pulse)*Math.max(0,fade);
    }
    return buffer;
  }



  /* ---------- composición 2D: subtítulos palabra a palabra + títulos ---------- */
  function wrapWords(ctx,words,maxW){const lines=[[]];let cw=0;const sp=ctx.measureText(' ').width;
    for(let i=0;i<words.length;i++){const w=ctx.measureText(words[i].w.toUpperCase()).width;if(cw+w>maxW&&lines[lines.length-1].length){lines.push([]);cw=0}lines[lines.length-1].push(i);cw+=w+sp}return lines;}
  function drawCaption(ctx,cap,t){
    if(!cap) return;
    const words=cap.words;let cur=-1;for(let i=0;i<words.length;i++)if(t>=words[i].s)cur=i;
    ctx.save();ctx.textAlign='left';ctx.textBaseline='middle';const fs=50;ctx.font=`900 ${fs}px "Arial Black",Impact,system-ui,sans-serif`;ctx.lineJoin='round';
    const lines=wrapWords(ctx,words,W-70);const lh=fs*1.18;const y0=H*.665-(lines.length-1)*lh/2;const sp=ctx.measureText(' ').width;
    lines.forEach((ln,li)=>{const ws=ln.map(i=>ctx.measureText(words[i].w.toUpperCase()).width);const total=ws.reduce((a,b)=>a+b,0)+sp*(ln.length-1);let x=(W-total)/2;const y=y0+li*lh;
      ln.forEach((i,k)=>{const txt=words[i].w.toUpperCase();const isCur=i===cur;const age=isCur?Math.min(1,(t-words[i].s)/.12):1;const pop=isCur?1+.14*Math.sin(Math.PI*age):1;const cx=x+ws[k]/2;
        ctx.save();ctx.translate(cx,y);ctx.scale(pop,pop);ctx.lineWidth=11;ctx.strokeStyle='#000';ctx.strokeText(txt,-ws[k]/2,0);ctx.fillStyle=isCur?'#ffe14a':'#ffffff';ctx.fillText(txt,-ws[k]/2,0);ctx.restore();x+=ws[k]+sp})});
    ctx.restore();
  }
  function drawTitle(ctx,tt,t){
    const u=t-tt.t0;if(u<0||u>tt.dur)return;const k=Math.min(1,u/.22),out=Math.min(1,(tt.dur-u)/.2);const pop=(1+.25*Math.pow(1-k,2)*Math.cos(k*9))*Math.min(k*1.4,1)*Math.min(out*1.3,1);
    ctx.save();ctx.translate(W/2,tt.kind==='hook'?H*.2:H*.26);ctx.rotate(-.045);ctx.scale(pop,pop);ctx.textAlign='center';ctx.textBaseline='middle';ctx.lineJoin='round';
    const fs=tt.kind==='hook'?66:60;ctx.font=`900 ${fs}px "Arial Black",Impact,system-ui,sans-serif`;
    const lines=[];let line='';for(const w of tt.text.split(' ')){const test=line?line+' '+w:w;if(ctx.measureText(test).width>W-90&&line){lines.push(line);line=w}else line=test}lines.push(line);
    lines.forEach((l,i)=>{const y=(i-(lines.length-1)/2)*fs*1.1;ctx.lineWidth=14;ctx.strokeStyle='#000';ctx.strokeText(l,0,y);ctx.fillStyle=tt.kind==='hook'?'#ff4f6e':'#ffe14a';ctx.fillText(l,0,y)});ctx.restore();
  }
  function drawFrame(t){
    const C=state.composed;const sc=C.engine.scenes;let si=0;for(let i=0;i<sc.length;i++)if(t>=sc[i].t0)si=i;
    Studio.api.frameAt(si,Math.max(0,Math.min(t-sc[si].t0,sc[si].dur-.001)));
    outCtx.drawImage(glCanvas,0,0,W,H);
    const g=outCtx.createLinearGradient(0,H*.5,0,H);g.addColorStop(0,'#07091400');g.addColorStop(1,'#070914aa');outCtx.fillStyle=g;outCtx.fillRect(0,H*.5,W,H*.5);
    outCtx.save();outCtx.textAlign='center';outCtx.fillStyle='#ffffffaa';outCtx.font='800 16px system-ui';outCtx.fillText('IN THIS TOWN',W/2,H-36);outCtx.restore();
    let cap=null;for(const c of C.captions)if(t>=c.start&&t<c.end){cap=c;break}
    drawCaption(outCtx,cap,t);for(const tt of C.titles)drawTitle(outCtx,tt,t);
  }

  /* ---------- audio: narración colocada en línea de tiempo + música con ducking + SFX ---------- */
  function buildVoiceBuffer(ctx,composed,voice){
    const sr=voice.sr,total=Math.ceil((composed.duration+.5)*sr),out=new Float32Array(total);
    voice.infos.forEach((inf,i)=>{const start=Math.round((composed.beatTimes[i].start+inf.lead)*sr);out.set(inf.pcm.subarray(0,Math.max(0,Math.min(inf.pcm.length,total-start))),start)});
    const b=ctx.createBuffer(1,total,sr);b.getChannelData(0).set(out);return b;
  }
  async function recordVideo(composed,voice,audioCtx,progress){
    const total=composed.duration+.35;
    const voiceSource=audioCtx.createBufferSource();voiceSource.buffer=buildVoiceBuffer(audioCtx,composed,voice);
    const voiceGain=audioCtx.createGain();voiceGain.gain.value=1.15;voiceSource.connect(voiceGain);
    const musicBuf=await loadMusic(audioCtx,composed.engine.mood||'spooky');
    const musicSource=audioCtx.createBufferSource();musicSource.buffer=musicBuf;musicSource.loop=true;
    const musicGain=audioCtx.createGain();const base=state.musicFile?.18:.2;const duck=base*.42;musicSource.connect(musicGain);
    const compressor=audioCtx.createDynamicsCompressor();compressor.threshold.value=-16;compressor.knee.value=12;compressor.ratio.value=3.5;compressor.attack.value=.01;compressor.release.value=.2;
    const sfxGain=audioCtx.createGain();sfxGain.gain.value=.5;
    const mix=audioCtx.createMediaStreamDestination();voiceGain.connect(compressor);musicGain.connect(compressor);sfxGain.connect(compressor);compressor.connect(mix);
    const T0=audioCtx.currentTime+.4;
    musicGain.gain.setValueAtTime(base,T0);
    voice.infos.forEach((inf,i)=>{const s=T0+composed.beatTimes[i].start+inf.lead,e=s+inf.speech;musicGain.gain.setTargetAtTime(duck,Math.max(T0,s-.08),.05);musicGain.gain.setTargetAtTime(base,e+.05,.18)});
    let nSfx=0;const seen=new Set();
    composed.engine.scenes.forEach((sc,i)=>{const r=composed.sceneSfx[i]||[];for(const f of r){const key=f.name+'|'+Math.round((sc.t0+f.t)*20);if(seen.has(key))continue;seen.add(key);const w=T0+sc.t0+f.t;if(sc.t0+f.t<0||sc.t0+f.t>total)continue;
      const src=audioCtx.createBufferSource();src.buffer=Sfx.get(audioCtx,f.name);const g=audioCtx.createGain();g.gain.value=Math.min(1,f.vol===undefined?.8:f.vol);src.connect(g);g.connect(sfxGain);src.start(w);nSfx++}});
    composed.nSfx=nSfx;
    const videoStream=outCanvas.captureStream(FPS);
    const stream=new MediaStream([...videoStream.getVideoTracks(),...mix.stream.getAudioTracks()]);
    const mime=getMime();if(!mime)throw new Error('Este navegador no puede exportar vídeo con MediaRecorder. Usa Chrome, Edge o Safari 14.1+ recientes.');
    let recorder;try{recorder=new MediaRecorder(stream,{mimeType:mime,videoBitsPerSecond:4_000_000,audioBitsPerSecond:128_000});}catch{recorder=new MediaRecorder(stream,{mimeType:mime});}
    const chunks=[];recorder.ondataavailable=e=>{if(e.data?.size)chunks.push(e.data);};
    const stopped=new Promise((resolve,reject)=>{recorder.onstop=resolve;recorder.onerror=e=>reject(e.error||new Error('Falló la grabación de vídeo.'));});
    drawFrame(0);recorder.start(500);await audioCtx.resume();voiceSource.start(T0);musicSource.start(T0);
    $('placeholder').style.display='none';
    let renderError=null,frames=0;
    await new Promise(resolve=>{
      const stop=()=>{try{if(recorder.state!=='inactive')recorder.stop();}catch{}resolve();};
      const tick=()=>{
        try{
          if(state.cancel){renderError=new Error('Cancelado por el usuario.');stop();return;}
          const t=audioCtx.currentTime-T0;           // el RELOJ DE AUDIO manda: el vídeo no puede desincronizarse
          if(t>=total){stop();return;}
          drawFrame(Math.max(0,t));frames++;
          if(frames%12===0)progress(`Renderizando · ${Math.max(0,t).toFixed(0)} / ${composed.duration.toFixed(0)} s`,48+Math.max(0,t)/total*50);
          requestAnimationFrame(tick);
        }catch(e){renderError=e;stop();}
      };requestAnimationFrame(tick);
    });
    await stopped;
    try{videoStream.getTracks().forEach(t=>t.stop());mix.stream.getTracks().forEach(t=>t.stop());voiceSource.stop();musicSource.stop();}catch{}
    if(renderError)throw renderError;
    const blob=new Blob(chunks,{type:mime.split(';')[0]||'video/webm'});
    if(blob.size<30000)throw new Error('El archivo de vídeo es demasiado pequeño; este navegador puede no soportar la grabación del lienzo.');
    return {blob,mime,totalDuration:composed.duration,frames};
  }

  async function create(){
    if(state.busy)return;
    if(state.mode!=='webgl'){setStatus('El motor 3D necesita WebGL 2. Actualiza el navegador y activa la aceleración gráfica.');return;}
    const idea=$('idea').value.trim(),tone=$('tone').value,length=$('length').value;
    if(idea.length<8){setStatus('Escribe una regla más concreta (mínimo 8 caracteres).');return;}
    if(!window.MediaRecorder||!outCanvas.captureStream){setStatus('Tu navegador no permite exportar vídeo. Prueba una versión reciente de Chrome, Edge o Safari.',0);return;}
    setBusy(true);state.cancel=false;$('result').classList.remove('show');$('player').style.display='none';
    if(jobUrl){URL.revokeObjectURL(jobUrl);jobUrl=null;}
    $('placeholder').style.display='grid';
    let audioCtx;
    try{
      state.stage='preparación';
      const AudioCtor=window.AudioContext||window.webkitAudioContext;
      if(!AudioCtor) throw new Error('Este navegador no ofrece Web Audio y no puede mezclar la narración.');
      audioCtx=new AudioCtor();await audioCtx.resume();
      if(idea!==state.lastIdea){state.variant=0;state.lastIdea=idea}else if($('regen').checked)state.variant++;
      state.stage='historia';setStatus('Creando la historia a partir de tu regla…',3);await sleep(0);
      const story=Story.generate(idea,tone,length,state.variant);state.story=story;
      state.stage='generación de voz';
      const voice=await synthesize(story,setStatus);checkCancel();
      state.stage='composición de escenas';setStatus('Coreografiando acciones y cámaras sobre la voz…',36);await sleep(0);
      const composed=Compose.compose(story,voice.infos);composed.engine.mood=tone==='funny'?'quirky':tone==='suspense'?'suspense':'spooky';state.composed=composed;
      const report=preflight(composed);
      state.stage='preparación 3D';Studio.api.setStory(composed.engine);
      const metas=[];for(let i=0;i<composed.engine.scenes.length;i++){checkCancel();setStatus(`Construyendo decorado ${i+1}/${composed.engine.scenes.length}…`,38+i/composed.engine.scenes.length*9);await sleep(0);
        try{metas.push(Studio.api.compile(i,{fast:false}));}catch(e){throw new Error(`Error al preparar el decorado ${i+1}: ${errorText(e)}`);}}
      metas.forEach(m=>m.warns.forEach(w=>report.push({sev:'warn',msg:w})));composed.sceneSfx=metas.map(m=>m.sfx);
      engineValidation(composed,report);renderReport(report);state.report=report;
      const fatal=report.filter(r=>r.sev==='error'&&!/intersects|camera inside/.test(r.msg));
      if(fatal.length)throw new Error('Validación fallida: '+fatal.slice(0,3).map(r=>r.msg).join(' · '));
      state.stage='grabación y render 3D';
      drawFrame(0);
      const result=await recordVideo(composed,voice,audioCtx,setStatus);
      const ext=result.mime.includes('mp4')?'mp4':'webm';jobUrl=URL.createObjectURL(result.blob);
      $('download').href=jobUrl;$('download').download='in-this-town-'+story.slug+'.'+ext;$('download').textContent='↓ DESCARGAR '+ext.toUpperCase();
      $('player').src=jobUrl;$('player').style.display='block';
      $('resultTitle').textContent=story.title;$('resultMeta').textContent=`${Math.round(result.totalDuration)} s · ${story.beats.length} frases · ${composed.engine.scenes.length} decorados · ${ext.toUpperCase()} · ${(result.blob.size/1024/1024).toFixed(1)} MB · ${report.length} avisos`;
      $('script').innerHTML=story.beats.map((b,i)=>`<p><b>${String(i+1).padStart(2,'0')}.</b> ${escapeText(b.vo)}</p>`).join('');
      $('result').classList.add('show');$('placeholder').style.display='none';
      setStatus('¡Terminado! Tu vídeo está listo para descargar.',100);
    } catch(e){
      const detail=errorText(e);console.error('In This Town create failed at '+state.stage+':',e);
      $('placeholder').style.display='grid';
      setStatus(/Cancelado/.test(detail)?'Cancelado. Puedes intentarlo de nuevo.':`No se ha podido crear el vídeo · Fase: ${state.stage}\n${detail}`,0);
    } finally {try{await audioCtx?.close();}catch{};setBusy(false);state.cancel=false;state.stage='listo';}
  }

  /* ---------- biblioteca de assets ---------- */
  function renderGallery(){
    const q=($('galQ').value||'').toLowerCase().trim();const cat=Studio.Assets.catalog().filter(a=>!q||a.name.includes(q)||a.kind.includes(q)||a.tags.some(t=>t.includes(q)));
    const groups={};cat.forEach(a=>(groups[a.kind]=groups[a.kind]||[]).push(a));
    $('galBody').innerHTML=Object.entries(groups).map(([k,arr])=>`<p><b>${k}</b> (${arr.length})</p><div class="gal">${arr.map(a=>k==='prop'?`<div class="gi" data-n="${a.name}"><canvas width="84" height="104"></canvas>${a.name}${a.stateful?' ⚙':''}</div>`:`<span class="tag" title="${a.tags.join(', ')}">${a.name}</span>`).join('')}</div>`).join('');
  }
  async function renderPreviews(){
    if(state.busy)return;setBusy(true);const items=[...document.querySelectorAll('#galBody .gi')].slice(0,60);
    try{for(const el of items){const n=el.dataset.n;const parts=Studio.Props.parts(n,{});const mn=[1e9,1e9,1e9],mx=[-1e9,-1e9,-1e9];for(const p of parts)for(let k=0;k<3;k++){mn[k]=Math.min(mn[k],p.off[k]-p.size[k]/2);mx[k]=Math.max(mx[k],p.off[k]+p.size[k]/2)}
      const sz=Math.max(mx[0]-mn[0],mx[1]-mn[1],mx[2]-mn[2],1),sc=8/sz,cx=(mn[0]+mx[0])/2,cz=(mn[2]+mx[2])/2;
      const st={characters:{},defaults:{sky:'day'},scenes:[{id:'p',sky:'day',world:[{type:'studio'}],dur:1,actors:{},objects:{p:{type:n,pos:[-cx*sc,-mn[1]*sc,-cz*sc],scale:sc}},actions:[],cam:[{at:0,pos:[9,6.5,16],look:[0,3.6,0],fov:36}]}]};
      Studio.api.setStory(st);Studio.api.compile(0,{fast:false});Studio.api.frame(0);el.querySelector('canvas').getContext('2d').drawImage(glCanvas,0,0,W,H,0,0,84,104);await sleep(0)}}catch(e){console.error(e)}
    finally{setBusy(false)}
  }
  $('gallery').addEventListener('toggle',()=>{if($('gallery').open&&!$('galBody').innerHTML)renderGallery()});
  $('galQ').addEventListener('input',renderGallery);$('galPrev').addEventListener('click',renderPreviews);

  $('create').addEventListener('click',create);
  window.addEventListener('beforeunload',()=>{if(jobUrl)URL.revokeObjectURL(jobUrl);});
  window.ITT.app={state,create,preflight};
  initRenderer();
  if(location.protocol==='file:'){setStatus('Modo local: abre este HTML directamente. Kokoro necesita internet la primera vez para descargar el modelo (≈90 MB, queda en caché).');}
})();

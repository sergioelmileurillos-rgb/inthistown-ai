/* app/compose.js — v0.5 compositor: beats (+ tiempos reales de voz) -> JSON de escenas del motor.
   - Las frases consecutivas de un mismo decorado se compilan como UNA secuencia continua (sin teletransportes,
     las puertas abiertas siguen abiertas, los actores conservan posición).
   - Cada acción se ancla a la PALABRA hablada ("opened" -> la puerta gira justo entonces). */
(function(G){
'use strict';
const ITT=G.ITT=G.ITT||{};
const clamp=(x,a,b)=>Math.max(a,Math.min(b,x));
const norm=w=>String(w).toLowerCase().replace(/[^a-z0-9']/g,'');

/* ---- decorados con ranuras de posición y objetos ancla ---- */
const COMMON={front:[12,24],yardL:[-10,17],yardR:[10,17],street:[-20,30],streetR:[22,30],door:[0,8],center:[0,16],far:[-26,22],plaza:[0,14],plaza2:[-14,16],podium:[0,14],left:[-8,18],right:[8,18]};
const ROOM={front:[6,8],yardL:[-9,6],yardR:[10,5],street:[-12,10],streetR:[12,10],door:[10,-7.5],center:[0,3],far:[-12,3],plaza:[0,3],plaza2:[-6,5],podium:[0,2],left:[-6,4],right:[6,4]};
const HALL={front:[0,32],yardL:[-11,28],yardR:[11,28],street:[-16,34],streetR:[16,34],door:[0,24],center:[0,24],far:[-20,28],plaza:[0,28],plaza2:[-12,32],podium:[0,19],left:[-9,24],right:[9,24]};
const PARK={front:[0,28],yardL:[-8,22],yardR:[8,22],street:[-14,26],streetR:[14,26],door:[0,12],center:[0,16],far:[-18,14],plaza:[0,18],plaza2:[-10,20],podium:[0,12],left:[-7,16],right:[7,16]};
const SETS={
  facade:{world:[{type:'facade'}],slots:COMMON,maxDist:34,bounds:[-70,70,2,80],
    objects:{door:{type:'door_h',pos:[0,0,0]},winL:{type:'window_h',pos:[-9,3,0]},winR:{type:'window_h',pos:[9,3,0]},lampL:{type:'lamp_s',pos:[-34,0,22]},lampR:{type:'lamp_s',pos:[34,0,22]},item:{type:'chest',pos:[-4,0,13],yawDeg:20},note:{type:'notepaper',pos:[0,1.06,1.5],scale:1.4},rulebook:{type:'rulebook',pos:[-4,0,12],scale:1.6},mirror:{type:'mirror',pos:[-6,0,12]},pizza:{type:'pizza',pos:[-4,0,12],scale:1.6}}},
  bedroom:{world:[{type:'room',kind:'bedroom',nowin:true}],slots:ROOM,maxDist:15,bounds:[-15,15,-10,14],
    objects:{door:{type:'door_h',pos:[11,0,-14.3]},winL:{type:'window_h',pos:[3,6.2,-14.3]},winR:{type:'window_h',pos:[-1,6.2,-14.3],yawDeg:0},lampL:{type:'lamp_s',pos:[14,0,-11]},lampR:{type:'lamp_s',pos:[-14,0,8]},item:{type:'chest',pos:[-2,0,6]},note:{type:'notepaper',pos:[6,0,4],scale:1.4},rulebook:{type:'rulebook',pos:[5,0,4],scale:1.6},mirror:{type:'mirror',pos:[-3,0,-13.8]},pizza:{type:'pizza',pos:[5,0,4],scale:1.6}}},
  townhall:{world:[{type:'townhall'}],slots:HALL,maxDist:36,bounds:[-60,60,6,80],
    objects:{door:{type:'door_h',pos:[0,0,-8.5],scale:1.3},rulebook:{type:'rulebook',pos:[3,0,19],scale:1.8},note:{type:'notepaper',pos:[3,0,19],scale:1.6},item:{type:'chest',pos:[4,0,22]},lampL:{type:'lamp_s',pos:[-30,0,34]},lampR:{type:'lamp_s',pos:[30,0,34]},winL:{type:'window_h',pos:[-26,0,30]}}},
  park:{world:[{type:'park'}],slots:PARK,maxDist:36,bounds:[-70,70,2,90],
    objects:{rulebook:{type:'rulebook',pos:[3,0,14],scale:1.6},item:{type:'chest',pos:[3,0,14]},note:{type:'notepaper',pos:[3,0,14],scale:1.4},door:{type:'door_h',pos:[0,0,4]},winL:{type:'window_h',pos:[-9,3,4]},lampL:{type:'lamp_s',pos:[-14,0,12]},lampR:{type:'lamp_s',pos:[14,0,12]},mirror:{type:'mirror',pos:[3,0,14]},pizza:{type:'pizza',pos:[3,0,14],scale:1.6}}}
};
function interiorSet(kind){return{world:[{type:'interior',kind,nowin:false}],slots:ROOM,maxDist:15,bounds:[-15,15,-10,14],objects:{door:{type:'door_h',pos:[11,0,-14.3]},item:{type:'chest',pos:[4,0,2]},rulebook:{type:'rulebook',pos:[4,0,3],scale:1.6},pizza:{type:'pizza',pos:[4,0,3],scale:1.6},note:{type:'notepaper',pos:[4,0,3],scale:1.4},lampL:{type:'lamp_s',pos:[14,0,-11]},lampR:{type:'lamp_s',pos:[-14,0,8]},winL:{type:'window_h',pos:[-8,6.2,-14.3]},mirror:{type:'mirror',pos:[3,0,-13.8]}}}}
function setOf(name){if(SETS[name])return SETS[name];if(name&&name.startsWith('interior:'))return interiorSet(name.split(':')[1]);return SETS.facade}
const DYN={shadow:{type:'shadowfigure',scale:1,fade:true},beast:{type:'dragon',scale:.1,rise:true},stalker:{type:'gray_stalker',scale:.2}};

/* respuesta de cámara: shots permitidos en encuadre de mundo (la cámara nunca pasa al lado -Z) */
const SHOTMAP={over:'medium',pov:'close',top:'wide',profile:'medium',follow:'medium',front:'medium',dutch:'medium',long:'wide'};
const MOVEMAP={follow:'drift',whip:'drift',rise:'rise',orbit:'orbit'};

function wordTime(info,anchor,warn,fb){
  if(anchor===null||anchor===undefined||anchor==='')return fb;
  if(typeof anchor==='number')return anchor;
  const key=norm(anchor);const w=info.words.find(x=>norm(x.w).startsWith(key))||info.words.find(x=>norm(x.w).includes(key));
  if(!w){warn(`ancla "${anchor}" no encontrada en «${info.vo}»`);return fb}return w.s}

function compose(story,infos){
  const warnings=[],warn=m=>warnings.push(m);
  const beats=story.beats;if(infos.length!==beats.length)throw new Error('compose: faltan tiempos de voz para algunas frases');
  // línea de tiempo global
  let cur=0;const gb=beats.map((b,i)=>{const s=cur;cur+=infos[i].dur;return{start:s,end:cur,dur:infos[i].dur}});
  const total=cur;
  // agrupar secuencias (set + sky + dim)
  const skyOf=b=>b.sky==='void'?'night':(b.sky||(story.arch==='loophole'?'day':'night'));
  const seqs=[];let lastKey=null;
  beats.forEach((b,i)=>{const key=b.set+'|'+skyOf(b);if(key!==lastKey){seqs.push({set:b.set,sky:skyOf(b),from:i,to:i,idx:seqs.length});lastKey=key}else seqs[seqs.length-1].to=i});
  const scenes=[],titles=[],pred={},objState={};let prevSet=null;
  seqs.forEach((sq,si)=>{
    const S=setOf(sq.set),t0=gb[sq.from].start,dur=gb[sq.to].end-t0;const slot=n=>{const v=S.slots[n]||S.slots.center;return v};
    const sameSet=prevSet===sq.set&&si>0;prevSet=sq.set;
    const actorDefs={},objDefs={},actions=[],cams=[],sfx=[],texts=[];const present=new Set(sameSet?Object.keys(pred):[]);
    const L=(b)=>gb[b].start-t0;
    // objetos fijos del decorado
    for(const [id,d] of Object.entries(S.objects))objDefs[id]=Object.assign({},d,{state:objState[sq.set+'|'+id]||undefined});
    // objetos dinámicos usados en esta secuencia
    for(let i=sq.from;i<=sq.to;i++)for(const p of beats[i].plan)if(p[0]==='obj'){const [,id,type,,mode]=p;const base=DYN[id]||{type,scale:1};
      const where=S.slots.far;objDefs[id]={type:base.type||type,pos:[where[0]+(id==='beast'?8:0),0,id==='beast'?-30:where[1]],yawDeg:0,scale:mode==='rise'?.05:1,alpha:mode==='fadeIn'?0:1,visible:mode!=='rise'&&mode!=='fadeIn'?true:false,state:{wave:0}}}
    const ensure=(id,tAt)=>{ // actor existe en la secuencia
      if(actorDefs[id])return;const spec=story.cast[id];if(!spec){warn(`actor desconocido "${id}"`);return}
      const prev=sameSet&&pred[id];const p=prev?prev.pos:slot(id==='hero'?'front':id==='nbr'?'yardL':id==='mayor'?'podium':id==='shadow'?'far':'street');
      actorDefs[id]=sameSet&&prev?{ref:id,visible:prev.visible}:{ref:id,pos:[p[0],0,p[1]],yawDeg:0,face:spec.spec.face||'smile',visible:false};
      if(!sameSet||!prev)pred[id]={pos:p.slice(),visible:false}};
    const show0=null;
    const show=(id,tAt)=>{ensure(id,tAt);if(!pred[id])pred[id]={pos:slot('front'),visible:false};if(!pred[id].visible||actorDefs[id].visible===false&&tAt>0){actions.push({actor:id,at:Math.max(0,tAt),do:'show'});pred[id].visible=true}};
    if(sameSet)for(const id of Object.keys(pred))ensure(id,0);
    for(let i=sq.from;i<=sq.to;i++){
      const b=beats[i],info=infos[i],bt=L(i),bend=bt+info.dur;const at=(a,fb)=>bt+wordTime(info,a,warn,fb===undefined?.18:fb);
      const resolvePos=k=>Array.isArray(k)?k:slot(k);
      const targetOf=k=>{if(k==='camera')return null;if(story.cast[k])return k;return k};
      for(const p of b.plan){const k=p[0];
        if(k==='cast'){for(const [id,sl] of Object.entries(p[1])){const pos=slot(sl);ensure(id,bt);
            if(!pred[id].visible){pred[id].pos=pos.slice();actorDefs[id].pos=[pos[0],0,pos[1]];show(id,Math.max(0,bt-.05))}
            else if(Math.hypot(pred[id].pos[0]-pos[0],pred[id].pos[1]-pos[1])>1.5){actions.push({actor:id,at:bt+.1,do:'walkTo',to:pos,dur:clamp(Math.hypot(pred[id].pos[0]-pos[0],pred[id].pos[1]-pos[1])/5.5,.5,1.8),path:'straight'});pred[id].pos=pos.slice()}}}
        else if(k==='anim'){const [,a,clip,w,d,ex]=p;show(a,bt);const o={actor:a,at:at(w),do:'anim',clip};if(d)o.dur=d;if(ex)o.expr=ex;actions.push(o)}
        else if(k==='walk'){const [,a,sl,w,d,mode]=p;show(a,bt);const pos=resolvePos(sl);const t=at(w,.1);actions.push({actor:a,at:t,do:mode==='run'?'runTo':'walkTo',to:pos,dur:d||undefined,path:'straight'});pred[a].pos=pos.slice()}
        else if(k==='walkOff'){const [,a,sl]=p;show(a,bt);const pos=slot(sl);actions.push({actor:a,at:bt+.1,do:'walkTo',to:pos,dur:Math.max(1,info.dur-.3),path:'straight'});pred[a].pos=pos.slice()}
        else if(k==='do'){const [,a,kind,obj,w]=p;show(a,bt);const hit=bt+wordTime(info,w,warn,.9);
          if(!objDefs[obj])warn(`el decorado ${sq.set} no tiene el objeto "${obj}"`);
          actions.push({actor:a,at:bt,do:'interact',kind,obj,hit,path:'straight'});
          const od=S.objects[obj];if(od){const st=kind==='open'?1:kind==='close'?0:null;if(st!==null)objState[sq.set+'|'+obj]=Object.assign({},objState[sq.set+'|'+obj],{open:st,lit:st});
            if(kind==='switchOn'||kind==='switchOff')objState[sq.set+'|'+obj]=Object.assign({},objState[sq.set+'|'+obj],{on:kind==='switchOn'?1:0});
            const so=pred[a];if(od.pos)pred[a].pos=[od.pos[0],od.pos[2]+3.4]}}
        else if(k==='face'){const [,a,tg,w]=p;show(a,bt);if(tg==='camera')actions.push({actor:a,at:at(w),do:'turn',yawDeg:0,dur:.3});else{const tp=story.cast[tg]?tg:(objDefs[tg]?tg:null);if(tp)actions.push({actor:a,at:at(w),do:'turn',to:tp,dur:.3});else warn(`face: destino "${tg}" desconocido`)}}
        else if(k==='turnTo'){const [,a,tg,w]=p;show(a,bt);actions.push({actor:a,at:at(w),do:'turn',to:tg,dur:.35})}
        else if(k==='expr'){const [,a,f,w]=p;show(a,bt);actions.push({actor:a,at:at(w),do:'expr',face:f})}
        else if(k==='fx'){const [,kind,on,w,o]=p;if(story.cast[on])show(on,bt);actions.push(Object.assign({do:'fx',kind,on,at:at(w)},o||{}))}
        else if(k==='state'){const [,obj,chan,to,w,d]=p;if(!objDefs[obj]){warn(`state: objeto "${obj}" inexistente en ${sq.set}`);continue}actions.push({obj,do:'set',chan,to,at:at(w),dur:d===undefined?.4:d});
          objState[sq.set+'|'+obj]=Object.assign({},objState[sq.set+'|'+obj],{[chan]:to})}
        else if(k==='obj'){const [,id,type,w,mode]=p;const t=at(w);const O=objDefs[id];
          if(mode==='fadeIn'){// colocar detrás del actor protagonista del beat
            const foc=(b.focus&&pred[b.focus])||pred.nbr||pred.hero;const fp=foc&&foc.pos?foc.pos:slot('center');O.pos=[fp[0]+2.6,0,fp[1]-3.4];
            actions.push({obj:id,do:'show',at:t});actions.push({obj:id,do:'fadeTo',to:.9,at:t,dur:.7})}
          else if(mode==='rise'){actions.push({obj:id,do:'show',at:t});actions.push({obj:id,do:'scaleTo',to:2.4,at:t,dur:1.4,ease:'out'});actions.push({obj:id,do:'moveTo',to:[O.pos[0],0,O.pos[2]+12],at:t,dur:2.2,ease:'out'})}
          sfx.push({at:t,name:mode==='rise'?'rumble':'whoosh',vol:.8})}
        else if(k==='hide'){const [,a,w]=p;const t=at(w,.3);if(story.cast[a])actions.push({actor:a,at:t,do:'hide'});else actions.push({obj:a,do:'hide',at:t});if(pred[a])pred[a].visible=false}
        else if(k==='show'){const [,a,w]=p;ensure(a,bt);actions.push({actor:a,at:at(w),do:'show'});pred[a].visible=true}
        else if(k==='scale'){const [,a,to,w,d]=p;show(a,bt);actions.push({actor:a,at:at(w),do:'scaleTo',to,dur:d||.6,ease:'back'})}
        else if(k==='hover'){const [,a,h,w]=p;show(a,bt);actions.push({actor:a,at:at(w),do:'hover',to:h,dur:.6})}
        else if(k==='text'){const [,txt,w,d,style]=p;const t=at(w,.2);if(style==='title')titles.push({t0:t0+t,dur:d||1.5,text:txt,kind:'key'});else if(story.cast[w])texts.push({text:txt,at:t,dur:d||1,on:w})}
        else if(k==='hook'){titles.push({t0:t0+bt+.05,dur:Math.min(2.4,info.dur),text:story.hookText,kind:'hook'})}
        else if(k==='shake'){const [,w,d,amp]=p;actions.push({do:'shake',at:at(w),dur:d,amp,sfx:false});sfx.push({at:at(w),name:'rumble',vol:.7})}
        else if(k==='flash'){const [,w,amt]=p;actions.push({do:'flash',at:at(w),dur:.4,amount:amt||.8})}
        else if(k==='sfx'){const [,name,w]=p;sfx.push({at:at(w),name,vol:.9})}
        else warn(`directiva desconocida "${k}"`)
      }
      if(b.sky==='void')actions.push({do:'dim',at:bt,dur:.5,amount:.55,color:'#1a0a40',until:bend});
      // cámara
      const cs=b.cam&&b.cam.length?b.cam:[['medium',['hero'],{}]];
      cs.forEach(([shot,on,o],ci)=>{o=o||{};const ids=on.filter(x=>story.cast[x]||objDefs[x]);ids.forEach(x=>{if(story.cast[x])show(x,Math.max(0,bt-.05))});
        const sh=SHOTMAP[shot]||shot;const az=clamp((o.az||0),-52,52);const mv=MOVEMAP[o.move]||o.move;
        cams.push({at:ci===0?bt:at(o.at,bt+info.dur*.5),shot:sh,on:ids.length?ids:['hero'],fixed:true,refYaw:0,az,move:mv,amount:o.amount,deg:Math.min(o.deg||24,Math.max(0,58-Math.abs(az))),maxDist:S.maxDist,bounds:S.bounds,noRoll:true})});
      // parpadeo + expresión base (vida)
      for(const id of Object.keys(actorDefs)){let tt=bt+.7+((i*37+id.length*11)%10)/10*1.2;while(tt<bend-.2){actions.push({actor:id,at:tt,do:'blink'});tt+=2.6+((i+Math.floor(tt*7))%4)*.5}}
    }
    // escena
    const actors={};for(const [id,d] of Object.entries(actorDefs))actors[id]=d;
    scenes.push({id:'seq'+si,set:sq.set,t0,beatFrom:sq.from,beatTo:sq.to,sky:sq.sky,world:S.world,actors,objects:objDefs,actions,texts,cam:cams,dur,__dur:dur,seed:17+si*31,sfx,ignoreColliders:['wall','house','building','school','townhall'],allowOverlap:true})
  });
  // tracks de subtítulos
  const captions=beats.map((b,i)=>({i,start:gb[i].start,end:gb[i].end,vo:b.vo,words:infos[i].words.map(w=>({w:w.w,s:gb[i].start+w.s,e:gb[i].start+w.e}))}));
  return{engine:{title:story.title,characters:Object.fromEntries(Object.entries(story.cast).map(([k,v])=>[k,{spec:v.spec}])),defaults:{sky:'night',world:[{type:'facade'}]},scenes,seed:story.seed},captions,titles,duration:total,warnings,beatTimes:gb}}

ITT.Compose={compose,SETS,setOf,wordTime};
if(typeof module!=='undefined'&&module.exports)module.exports=ITT.Compose;
})(typeof window!=='undefined'?window:globalThis);

/* app/story.js — v0.5 motor de historias (100 % local, sin APIs).
   premisa -> parseRule -> contexto (reparto, verbo, dominio) -> arquetipo -> beats.
   Cada beat = una frase narrada + un PLAN VISUAL explícito (actores, objeto destino, estado, animación, cámara, FX),
   anclado a palabras concretas de la frase ("opened" -> la puerta se abre justo ahí). */
(function(G){
'use strict';
const ITT=G.ITT=G.ITT||{};

/* ------------------------------------------------------------ utilidades */
function hash(str){let h=2166136261;for(let i=0;i<str.length;i++){h^=str.charCodeAt(i);h=Math.imul(h,16777619)}return h>>>0}
function rng(seed){let a=seed>>>0;return()=>{a|=0;a=a+0x6D2B79F5|0;let t=Math.imul(a^a>>>15,1|a);t=t+Math.imul(t^t>>>7,61|t)^t;return((t^t>>>14)>>>0)/4294967296}}
const cap=s=>s.charAt(0).toUpperCase()+s.slice(1);

/* ------------------------------------------------------------ morfología mínima de verbos */
const IRR={go:['went','going'],see:['saw','seeing'],run:['ran','running'],sit:['sat','sitting'],swim:['swam','swimming'],eat:['ate','eating'],speak:['spoke','speaking'],say:['said','saying'],make:['made','making'],take:['took','taking'],sleep:['slept','sleeping'],tell:['told','telling'],sing:['sang','singing'],write:['wrote','writing'],give:['gave','giving'],get:['got','getting'],come:['came','coming'],leave:['left','leaving'],hear:['heard','hearing'],drink:['drank','drinking'],stand:['stood','standing'],look:['looked','looking'],break:['broke','breaking'],keep:['kept','keeping'],find:['found','finding'],wear:['wore','wearing'],buy:['bought','buying'],hold:['held','holding'],lie:['lied','lying'],stay:['stayed','staying'],play:['played','playing'],pay:['paid','paying'],spend:['spent','spending'],throw:['threw','throwing'],ring:['rang','ringing'],read:['read','reading'],hide:['hid','hiding'],lose:['lost','losing'],fall:['fell','falling'],drive:['drove','driving'],ride:['rode','riding'],dance:['danced','dancing'],cry:['cried','crying'],win:['won','winning'],set:['set','setting'],put:['put','putting'],cut:['cut','cutting'],hit:['hit','hitting'],shut:['shut','shutting'],begin:['began','beginning'],meet:['met','meeting'],forget:['forgot','forgetting'],wake:['woke','waking'],touch:['touched','touching'],knock:['knocked','knocking']};
const DBL=new Set(['stop','step','hop','shop','plan','jog','tap','clap','chat','drop','skip','trip','whip','grab','nod','pop','sip','hug','jam','dip','rub','zip','wrap','slip','spin','swap','pat','pet','tag','beg','pin']);
function verbForms(v){v=v.toLowerCase();if(IRR[v])return{past:IRR[v][0],ing:IRR[v][1]};
  let past,ing;
  if(/e$/.test(v)){past=v+'d';ing=v.slice(0,-1)+'ing'}
  else if(/[^aeiou]y$/.test(v)){past=v.slice(0,-1)+'ied';ing=v+'ing'}
  else if(DBL.has(v)){past=v+v.slice(-1)+'ed';ing=v+v.slice(-1)+'ing'}
  else{past=v+'ed';ing=v+'ing'}
  return{past,ing}}
const PARTICLES=new Set(['up','down','out','in','on','off','over','away','back','around','outside','inside','forward','backward','backwards','along','through']);
/* "open a window" -> {verb:'open',rest:'a window'} ; "walk forward" ; "look out of a window" */
function splitAct(act){const w=act.trim().split(/\s+/);const verb=w.shift();return{verb,rest:w.join(' ')}}
function actForms(act){const {verb,rest}=splitAct(act);const f=verbForms(verb);return{base:act,verb,rest,past:f.past+(rest?' '+rest:''),ing:f.ing+(rest?' '+rest:''),pastV:f.past,ingV:f.ing}}

/* ------------------------------------------------------------ parseRule */
const MODAL='(?:is\\s+|are\\s+)?(?:allowed\\s+to|permitted\\s+to|able\\s+to|supposed\\s+to|can|may|could|should|dares?\\s+to|dared\\s+to|will|would|ever|ever\\s+dares?\\s+to)?';
function cleanRule(raw){let t=String(raw||'').replace(/\s+/g,' ').trim().replace(/^["“]|["”]$/g,'');
  t=t.replace(/^in\s+this\s+town\s*[,:\-–—]?\s*/i,'').replace(/[.!?…]+$/,'').trim();return t}
function splitMod(act){// "open a window after midnight" -> act + mod
  const m=act.match(/^(.*?)\s+((?:after|before|during|past|until|at|when|while|once|every|each)\s+(?:the\s+)?(?:midnight|night|sunset|sunrise|dawn|dusk|noon|dark(?:ness)?|school|class|dinner|lunch|breakfast|church|bedtime|[0-9]+(?::[0-9]+)?\s*(?:am|pm|a\.m\.|p\.m\.)?|[a-z]+\s+(?:o'clock|time)|\w+\s+(?:falls|rises|comes|ends|starts)))\s*$/i);
  if(m)return{act:m[1].trim(),mod:m[2].trim()};
  const m2=act.match(/^(.*?)\s+(after dark|at night|at midnight|in public|in the dark|on sundays?|on mondays?|in the morning|in the evening|in the street|indoors|outside)\s*$/i);
  if(m2)return{act:m2[1].trim(),mod:m2[2].trim()};
  return{act:act.trim(),mod:''}}
function parseRule(raw){
  const text=cleanRule(raw);const low=text.toLowerCase();let m;
  const out={raw:String(raw).trim(),text:low,kind:'prohibit',act:'',mod:'',effect:'',trigger:''};
  // "Every lie makes you shrink by one inch"
  if(m=low.match(/^(?:every|each)\s+(.+?)\s+(?:makes?|will make|causes?)\s+(?:you|them|everyone|people|anyone)\s+(.+)$/)){out.kind='effect';out.trigger=m[1];out.effect=m[2];out.act=m[1];return finish(out)}
  if(m=low.match(/^if\s+(?:you|anyone|someone|somebody|people|they)\s+(.+?)\s*,?\s+(?:then\s+)?(?:you|they|it|everyone|something|the)\s*(.+)$/)){const sp=splitMod(m[1]);out.kind='effect';out.act=sp.act;out.mod=sp.mod;out.trigger=sp.act;out.effect=m[2];return finish(out)}
  if(m=low.match(new RegExp('^(?:nobody|no\\s?one|no\\s+person|nobody\\s+in\\s+town|no\\s+resident)\\s+'+MODAL+'\\s*(.+)$'))){const sp=splitMod(m[1]);out.act=sp.act;out.mod=sp.mod;out.kind='prohibit';return finish(out)}
  if(m=low.match(/^(?:you|everyone|people|residents|citizens|kids|children|all\s+\w+)\s+(?:can(?:not|'t)|cannot|must\s+not|mustn't|may\s+not|are\s+not\s+allowed\s+to|aren't\s+allowed\s+to|should\s+never|can\s+never|must\s+never|never|do\s+not|don't|are\s+forbidden\s+to|are\s+never\s+allowed\s+to)\s+(.+)$/)){const sp=splitMod(m[1]);out.act=sp.act;out.mod=sp.mod;out.kind='prohibit';return finish(out)}
  if(m=low.match(/^(?:you|everyone|people|residents|citizens)\s+(?:can|may|must)\s+only\s+(.+)$/)){const sp=splitMod(m[1]);out.act=sp.act;out.mod=sp.mod;out.kind='only';return finish(out)}
  if(m=low.match(/^(?:you|everyone|people|residents|citizens)\s+(?:must|have\s+to|need\s+to|are\s+required\s+to|should\s+always|always\s+have\s+to)\s+(.+)$/)){const sp=splitMod(m[1]);out.act=sp.act;out.mod=sp.mod;out.kind='must';return finish(out)}
  if(m=low.match(/^(?:it\s+is|it's)\s+(?:illegal|forbidden|against\s+the\s+law)\s+to\s+(.+)$/)){const sp=splitMod(m[1]);out.act=sp.act;out.mod=sp.mod;return finish(out)}
  if(m=low.match(/^(?:no|never)\s+(\w+ing)\s*(.*)$/)){const sp=splitMod((m[1]+' '+m[2]).trim());out.act=ingToBase(sp.act);out.mod=sp.mod;return finish(out)}
  if(m=low.match(/^(?:everyone|everybody|all\s+\w+)\s+(?:has|have)\s+to\s+(.+)$/)){const sp=splitMod(m[1]);out.act=sp.act;out.kind='must';out.mod=sp.mod;return finish(out)}
  if(m=low.match(/^(?:everyone|everybody|people|residents)\s+(\w+)\s*(.*)$/)){// "everyone whispers"
    out.kind='must';const v=m[1].replace(/ies$/,'y').replace(/(s|es)$/,'');const sp=splitMod((v+' '+m[2]).trim());out.act=sp.act;out.mod=sp.mod;return finish(out)}
  // sin patrón: toda la frase como acto genérico
  const sp=splitMod(low);out.act=sp.act;out.mod=sp.mod;out.kind='prohibit';out.generic=true;return finish(out)}
function ingToBase(s){const {verb,rest}=splitAct(s);let b=verb.replace(/ing$/,'');if(/(.)\1$/.test(b))b=b.slice(0,-1);else if(IRR[b+'e']||/[^aeiou][aeiou][^aeiouwxy]$/.test(b)&&b.length<5)b=b+'e';return (b+' '+rest).trim()}
function finish(o){
  o.act=o.act.replace(/^(?:ever\s+|to\s+)/,'').replace(/\s+/g,' ').trim();
  if(!o.act)o.act='break the rule';
  o.f=actForms(o.act);return o}

/* ------------------------------------------------------------ dominios: qué significa romper la regla visualmente */
/* gesture: {k:'interact',kind,prop} | {k:'anim',clip,expr,fx} */
const NOUN_PROP=[[/window|curtain|blind|shutter/,'window_h'],[/door|gate|entrance/,'door_h'],[/light|lamp|switch|bulb|candle|lantern|flashlight/,'lamp_s'],[/\btv\b|television|screen|channel|video/,'tv_s'],[/mirror|reflection/,'mirror'],[/phone|call|text|message/,'phone'],[/clock|watch|time/,'clock_wall'],[/chest|box|crate|gift|present|package|parcel|treasure/,'chest'],[/fridge|refrigerator/,'fridge_h'],[/book|page|rule|newspaper|letter|note/,'rulebook'],[/pizza|cake|cookie|food|dinner|lunch|snack|burger|bread|pie|candy|ice cream|donut/,'pizza'],[/bird|parrot|crow|owl/,'parrot'],[/ball|toy/,'ball'],[/umbrella|rain/,'umbrella'],[/balloon/,'balloon']];
const VERB_CLASS=[
  [/^(open|unlock|unseal|crack|unlatch|pull)$/,'open'],[/^(close|shut|lock|seal|slam)$/,'close'],[/^(look|watch|stare|peek|peep|gaze|spy|glance|see|observe|check)$/,'look'],
  [/^(knock|ring|tap)$/,'knock'],[/^(turn|switch|flip|light|ignite|press|push|click|flick)$/,'switch'],
  [/^(run|jog|sprint|race|rush|hurry)$/,'run'],[/^(walk|step|stroll|wander|move|go|travel|cross|leave|exit|enter|come)$/,'walk'],[/^(jump|hop|leap|skip|bounce)$/,'jump'],
  [/^(sing|hum|whistle|chant)$/,'sing'],[/^(dance|twirl|boogie)$/,'dance'],[/^(laugh|giggle|smile|grin|chuckle|joke)$/,'laugh'],[/^(cry|weep|sob)$/,'cry'],[/^(sneeze|cough|yawn)$/,'sneeze'],
  [/^(speak|talk|say|shout|yell|scream|whisper|tell|lie|answer|ask|call|argue|complain|mention|name)$/,'speak'],
  [/^(sleep|dream|nap|snore|rest|lie\s*down)$/,'sleep'],[/^(eat|drink|chew|taste|bite|cook|bake|swallow|sip)$/,'eat'],
  [/^(read|write|draw|type|study|text)$/,'read'],[/^(touch|grab|take|pick|steal|hold|carry|borrow|bring|keep|collect)$/,'touch'],
  [/^(clap|wave|point|salute|bow|hug|kiss|shake|nod)$/,'gesture'],[/^(swim|dive|fly|climb|float|surf|ride|drive|slide|swing)$/,'move2'],[/^(stand|sit|stay|wait|stop|freeze|hide|kneel)$/,'still'],
  [/^(wear|put)$/,'touch'],[/^(forget|remember|think|wonder|ignore|trust|believe)$/,'think']];
function classifyVerb(v){for(const [re,c] of VERB_CLASS)if(re.test(v))return c;return 'other'}
function nounProp(txt){for(const [re,p] of NOUN_PROP)if(re.test(txt))return p;return null}
function nounPhrase(f){// "the window" a partir de "open a window"
  const r=f.rest.replace(/^(?:a|an|the|any|your|their|his|her|its|our|my)\s+/,'').replace(/\s+(?:outside|out|away|up|down|again|twice|once|alone|aloud|loudly|quietly)$/,'');
  return r?'the '+r:'it'}

function domainOf(rule,rnd){
  const f=rule.f,vc=classifyVerb(f.verb.toLowerCase()),txt=(f.rest+' '+rule.mod+' '+rule.text).toLowerCase();
  const prop=nounProp(f.rest.toLowerCase())||nounProp(f.verb+' '+f.rest);
  const d={vc,prop,home:'facade',breakKind:'anim',clip:'shrug',fx:null,expr:'smirk',sfx:'pop'};
  const isInteract=(prop==='window_h'||prop==='door_h'||prop==='chest'||prop==='fridge_h')&&(vc==='open'||vc==='close'||vc==='knock'||vc==='look'||vc==='touch'||vc==='other'||vc==='switch');
  if(vc==='look'&&(/window|outside|street|out of/.test(txt))){d.breakKind='interact';d.ikind='peek';d.prop='window_h';d.obj='winL';d.home='facade';return d}
  if(isInteract){d.breakKind='interact';d.ikind=vc==='knock'?'knock':vc==='close'?'close':(vc==='look'?'peek':'open');d.obj=prop==='window_h'?'winL':prop==='door_h'?'door':'item';d.home=prop==='fridge_h'?'interior:restaurant':prop==='chest'?'facade':'facade';return d}
  if(vc==='switch'||prop==='lamp_s'||/\b(lights?|lamp|dark)\b/.test(f.rest)){d.breakKind='interact';d.ikind=(/off|out/.test(txt)?'switchOff':'switchOn');d.prop='lamp_s';d.obj='lampL';d.home='facade';return d}
  if(vc==='sleep'||/\b(bed|sleep|dream|awake|midnight|night)\b/.test(txt)&&vc!=='look'&&vc!=='walk'&&vc!=='run'&&vc!=='speak'){d.home='bedroom';d.clip=vc==='sleep'?'sleep':'yawn';d.expr='sleep';d.fx='zzz';d.sfx='yawn';return d}
  switch(vc){
    case'run':d.clip='run';d.home='park';d.expr='grin';d.fx='speed';d.sfx='swish';d.travel=true;break;
    case'walk':d.clip=/back/.test(txt)?'moonwalk':'walk';d.home='park';d.expr=/back/.test(txt)?'dizzy':'neutral';d.travel=true;break;
    case'jump':d.clip='jump';d.home='park';d.expr='grin';d.fx='poof';d.sfx='boing';break;
    case'sing':d.clip='dance';d.home='park';d.expr='grin';d.fx='sparkle';d.sfx='sparkle';break;
    case'dance':d.clip='dance';d.home='park';d.expr='grin';d.fx='sparkle';break;
    case'laugh':d.clip='laugh';d.home='park';d.expr='laugh';d.fx='sparkle';d.sfx='giggle';break;
    case'cry':d.clip='cry';d.home='park';d.expr='cry';d.fx='tears';break;
    case'sneeze':d.clip='sneeze';d.home='park';d.expr='worried';d.fx='poof';break;
    case'speak':d.clip='talk';d.home='townhall';d.expr='talk';d.speech=true;d.fx=null;d.sfx='pop';break;
    case'eat':d.clip='eat';d.home='interior:restaurant';d.expr='grin';d.fx='sparkle';d.prop=d.prop||'pizza';break;
    case'read':d.clip='phone';d.home='interior:library';d.expr='neutral';d.prop=d.prop||'rulebook';break;
    case'touch':d.clip='pickup';d.home='facade';d.expr='sus';d.prop=d.prop||'chest';d.fx='sparkle';break;
    case'gesture':d.clip=/clap/.test(f.verb)?'clap':/wave/.test(f.verb)?'wave':/point/.test(f.verb)?'point':/bow/.test(f.verb)?'bow':/salute/.test(f.verb)?'salute':/hug/.test(f.verb)?'hug':'wave';d.home='park';d.expr='grin';d.fx='sparkle';break;
    case'move2':d.clip=/swim/.test(f.verb)?'swim':/fly/.test(f.verb)?'fly':/climb/.test(f.verb)?'climb':/slide/.test(f.verb)?'slide':'ride';d.home='park';d.expr='grin';d.fx='bubbles';break;
    case'still':d.clip=/sit/.test(f.verb)?'sit':/hide/.test(f.verb)?'hide':'kneel';d.home='park';d.expr='worried';break;
    case'think':d.clip='think';d.home='facade';d.expr='worried';break;
    case'close':d.clip='reach';d.home='facade';break;
    case'look':d.clip='lookAround';d.home='facade';d.expr='sus';d.prop=d.prop||'mirror';break;
    default:d.clip=rnd()<.5?'shrug':'point';d.home='facade';d.expr='smirk';d.fx='sparkle';
  }
  return d}

/* ------------------------------------------------------------ reparto */
const HEROES=[{preset:'hero',g:'m',names:['Max','Leo','Jack','Finn','Noah']},{preset:'girl',g:'f',names:['Lily','Mia','Zoe','Ruby','Nina']},{preset:'boy2',g:'m',names:['Sam','Eli','Theo','Kai','Omar']},{preset:'student',g:'m',names:['Ben','Alex','Hugo','Dan','Ethan']},{preset:'catgirl',g:'f',names:['Luna','Ivy','Maya','Cleo','Tess']}];
const NEIGHBORS=[{preset:'kid',g:'m',names:['Timmy','Oscar','Jojo']},{preset:'nerd',g:'m',names:['Gus','Walter','Percy']},{preset:'builder',g:'m',names:['Rex','Moe','Bruno']},{preset:'nurse',g:'f',names:['Daisy','Rosa','Pearl']},{preset:'farmer',g:'m',names:['Earl','Clyde','Hank']},{preset:'athlete',g:'f',names:['Skye','Jade','Tara']},{preset:'chef',g:'m',names:['Luigi','Marco','Gordo']}];
function pronouns(g){return g==='f'?{he:'she',He:'She',him:'her',his:'her',His:'Her',hims:'herself'}:{he:'he',He:'He',him:'him',his:'his',His:'His',hims:'himself'}}
function makeCast(r){
  const hero=HEROES[Math.floor(r()*HEROES.length)];let nb=NEIGHBORS[Math.floor(r()*NEIGHBORS.length)];
  const hn=hero.names[Math.floor(r()*hero.names.length)],nn=nb.names[Math.floor(r()*nb.names.length)];
  const tintShirt=['#2f6df6','#e84a4a','#32b36b','#f5a623','#a45be8','#17b7c8'][Math.floor(r()*6)];
  return{
    hero:{id:'hero',name:hn,g:hero.g,p:pronouns(hero.g),spec:{preset:hero.preset,shirt:tintShirt}},
    nbr:{id:'nbr',name:nn,g:nb.g,p:pronouns(nb.g),spec:{preset:nb.preset}},
    mayor:{id:'mayor',name:'the mayor',g:'m',p:pronouns('m'),spec:{preset:'mayor'}},
    shadow:{id:'shadow',name:'the shadow',g:'m',p:pronouns('m'),spec:{preset:'ninja',shirt:'#07070c',pants:'#07070c',face:'evil'}},
    extra1:{id:'extra1',name:'a neighbor',g:'f',p:pronouns('f'),spec:{preset:'grandma'}},
    extra2:{id:'extra2',name:'a neighbor',g:'m',p:pronouns('m'),spec:{preset:'oldman'}},
    extra3:{id:'extra3',name:'a neighbor',g:'f',p:pronouns('f'),spec:{preset:'teacher'}}}}

/* ------------------------------------------------------------ contexto de plantillas */
function makeCtx(rule,dom,cast,tone,rnd){
  const f=rule.f,H=cast.hero,N=cast.nbr,np=nounPhrase(f);
  const eff=rule.effect?rule.effect.replace(/\s+/g,' '):'';
  const c={rule,dom,cast,tone,rnd,H:H.name,N:N.name,he:H.p.he,He:H.p.He,him:H.p.him,his:H.p.his,His:H.p.His,hims:H.p.hims,nhe:N.p.he,nHe:N.p.He,nhim:N.p.him,nhis:N.p.his,nHis:N.p.His,
    act:f.base,ing:f.ing,past:f.past,thing:np,mod:rule.mod,effect:eff,
    modc:rule.mod?', '+rule.mod:'',modp:rule.mod?' '+rule.mod:'',
    ruleSent:'In this town, '+rule.text.replace(/\b(monday|tuesday|wednesday|thursday|friday|saturday|sunday)s?\b/g,m=>cap(m))+'.',
    when:rule.mod||'at night',
    forbid:rule.kind==='prohibit'?f.base:'',
    breakline:null};
  // frase "romper la regla" según tipo
  if(rule.kind==='prohibit'||rule.kind==='effect')c.breakI=c.past;       // H opened a window
  else c.breakI='stopped '+f.ing;                                         // H stopped opening a window
  c.breakN=c.breakI;
  c.doing=rule.kind==='prohibit'||rule.kind==='effect'?c.ing:c.ing;
  c.itPron=/^(?:the|a|an)\s/.test(np)||np==='it'?'it':'it';
  return c}
function fill(t,c){return t.replace(/\{(\w+)\}/g,(m,k)=>c[k]!==undefined?c[k]:m).replace(/\s+([,.!?])/g,'$1').replace(/\s{2,}/g,' ').replace(/,\s*,/g,',').trim()}

/* ------------------------------------------------------------ arquetipos */
const wk=(c,k)=>c.dom.breakKind;// helper
/* helper de plan: gesto de romper la regla para un actor */
function breakPlan(c,actor,word){
  const d=c.dom,A=actor;
  if(c.rule.kind!=='prohibit'&&c.rule.kind!=='effect')return[['anim',A,'headshake',word,1.1,'worried'],['anim',A,'idle',null]];
  if(d.breakKind==='interact'){const o=[['do',A,d.ikind,d.obj,word]];if(d.ikind==='open'||d.ikind==='peek')o.push(['fx','sparkle',d.obj,word]);return o}
  const o=[['anim',A,d.clip,word,1.6,d.expr]];if(d.fx)o.push(['fx',d.fx,A,word]);return o}
function copyPlan(c,actor,word){return breakPlan(c,actor,word)}

const ARCH={};
/* --- L: la LAGUNA (divertida) --- */
ARCH.loophole=c=>{const H='hero',N='nbr',M='mayor';const V=a=>a[Math.floor(c.rnd()*a.length)];const home=c.dom.home;const P=breakPlan;const only=c.rule.kind!=='prohibit'&&c.rule.kind!=='effect';
 const B=[];const T=(role,set,vo,plan,cam,extra)=>B.push(Object.assign({role,set,vo,plan:plan||[],cam},extra||{}));
 T('hook',home,'{ruleSent}',[['cast',{hero:'front'}],['anim',H,'lookAround','In',2],['hook']],[['wide',[H],{az:12,move:'crane',amount:.3}]]);
 T('setup',home,V(['Everyone obeyed it.','And everyone obeyed it.','Nobody ever questioned it.']),[['cast',{hero:'front',nbr:'yardL',extra1:'street',extra2:'streetR'}],['anim','extra1','walk',null,0,'smile'],['anim','extra2','walk',null,0,'neutral'],['walkOff','extra1','streetR'],['walkOff','extra2','street'],['anim',N,'idle']],[['wide',[H,N],{az:-18,move:'drift'}]]);
 T('setup',home,'Everyone, except {H}.',[['anim',H,'idle'],['expr',H,'smirk','except'],['face',H,'camera','except']],[['close',[H],{az:10,move:'push',amount:.25}]]);
 T('setup',home,only?'{H} was tired of it.':'{H} had a plan.',[['anim',H,'think',null,1.6,'smirk'],['fx','sparkle',H,'plan']],[['medium',[H],{az:-20,move:'dolly'}]]);
 T('build',home,V(['{He} waited until nobody was looking.','{He} checked the street. Twice.','{He} made sure the coast was clear.']),[['anim',H,'sneak',null,0,'sus'],['expr',H,'sus','nobody'],['sfx','swish','waited']],[['medium',[H,N],{az:24,move:'push',amount:.2}]]);
 T('build',home,only?'Then {he} {breakI}.':'Then {he} {past}.',P(c,H,only?'stopped':c.rule.f.pastV),[['medium',[H],{az:-28,move:'push',amount:.18}]],{focus:H,key:'break'});
 T('build',home,V(['Nothing happened.','And nothing bad happened.','Not a single thing went wrong.']),[['anim',H,'shrug','Nothing',.9,'neutral'],['sfx','ding','happened']],[['close',[H],{az:14}]]);
 T('build',home,'But {N} had seen everything.',[['walk',N,'yardL',null],['anim',N,'shock','seen',1.2,'gasp'],['fx','stars_burst',N,'everything']],[['over',[N],{az:160}],['close',[N],{az:-12,at:'seen'}]]);
 T('build',home,'{N} tried it too.',P(c,N,'tried'),[['medium',[N],{az:22,move:'push',amount:.2}]],{focus:N});
 T('turn',home,'Soon, the whole street joined in.',[['cast',{extra1:'street',extra2:'streetR',nbr:'yardL'}],...[['extra1','Soon'],['extra2','joined'],[N,'whole']].map(([a,w])=>['anim',a,c.dom.clip==='walk'||c.dom.clip==='run'?'cheer':c.dom.clip==='sleep'?'cheer':c.dom.clip,w,0,c.dom.expr]),['fx','confetti',H,'joined']],[['wide',[H,N,'extra1','extra2'],{az:-24,move:'orbit',deg:30}]]);
 T('turn','townhall','Then the mayor arrived.',[['cast',{mayor:'podium',hero:'left'}],['walk',M,'plaza','arrived',2.4],['anim',M,'angry','arrived',2,'angry'],['shake','arrived',.5,.6]],[['low',[M],{az:10,move:'pull',amount:.2}]]);
 T('turn','townhall','He opened the old rulebook.',[['do',M,'pickup','rulebook','opened'],['expr',M,'smirk','old']],[['medium',[M],{az:-16,move:'push',amount:.22}]]);
 T('turn','townhall','It said: loopholes are not allowed.',[['text','NO LOOPHOLES','loopholes',1.6,'title'],['shake','loopholes',.4,.8],['sfx','boom','loopholes']],[['close',[M],{az:8,move:'zoom'}]]);
 T('turn','townhall','{H} tried to run.',[['cast',{hero:'left'}],['anim',H,'run','run',0,'scared'],['walk',H,'plaza2','run',2.2,'run']],[['medium',[H],{az:-22,move:'follow'}]],{focus:H});
 T('reveal','townhall','But the mayor was faster.',[['walk',M,'left','faster',.8,'run'],['fx','speedlines2',M,'faster']],[['wide',[H,M],{az:18,move:'whip'}]]);
 T('twist','townhall','{He} got a new job.',[['anim',H,'shock',null,1.1,'shock'],['anim',M,'point','job',1.4,'evil']],[['close',[H],{az:14}]]);
 T('twist','townhall',only?'{H} became the town inspector.':'{H} became the official rule inspector.',[['anim',H,'proud','became',0,'smug'],['fx','sparkle',H,'inspector'],['text','INSPECTOR','inspector',1.6,'title']],[['hero',[H],{az:10,move:'rise'}]]);
 T('payoff','townhall',only?'Now {he} watches everyone.':'Now {he} watches everyone who tries to {act}.',[['anim',H,'lookAround','watches',0,'sus']],[['medium',[H],{az:-22,move:'drift'}]]);
 T('payoff','townhall','And {he} loves it.',[['anim',H,'victory','loves',0,'grin'],['fx','confetti',H,'loves']],[['low',[H],{az:12,move:'rise'}]]);
 return B};

/* --- W: el AVISO (misterio/suspense) --- */
ARCH.warning=c=>{const H='hero',N='nbr';const only=c.rule.kind!=='prohibit'&&c.rule.kind!=='effect';const home=c.dom.home==='bedroom'?'bedroom':'facade';const P=breakPlan;const V=a=>a[Math.floor(c.rnd()*a.length)];
 const B=[];const T=(role,set,vo,plan,cam,extra)=>B.push(Object.assign({role,set,vo,plan:plan||[],cam},extra||{}));const night={sky:'night'};
 T('hook',home,'{ruleSent}',[['cast',{hero:'front'}],['anim',H,'lookAround','town',2,'worried'],['hook'],['fx','dust',H,'In']],[['wide',[H],{az:10,move:'crane',amount:.3}]],night);
 T('setup',home,V(['Everyone followed it. Without question.','For years, nobody dared to break it.','Everyone followed it, even the dogs.']),[['cast',{hero:'front',nbr:'yardL',extra1:'street'}],['walkOff','extra1','streetR'],['anim','extra1','tiredwalk',null,0,'worried'],['anim',N,'idle']],[['wide',[H,N],{az:-18,move:'drift'}]],night);
 T('setup',home,'Except {N}.',[['expr',N,'smirk','Except'],['anim',N,'lookAround',null,1.4,'sus'],['sfx','swish','Except']],[['close',[N],{az:12,move:'push',amount:.2}]],night);
 T('setup',home,V(['{N} was the curious type.','{N} never liked being told what to do.','{N} just had to know why.']),[['anim',N,'scratchhead',null,0,'sus'],['fx','sparkle',N,null]],[['medium',[N],{az:-20,move:'dolly'}]],night);
 T('build',home,V(['One night, {nhe} decided to test it.','One night, {nhe} snuck out alone.','Late one night, {nhe} gave in.']),[['walk',N,'door','test',1.6],['anim',N,'sneak','night',0,'sus']],[['medium',[N],{az:26,move:'follow'}]],night);
 T('build',home,'{nHe} {past}.',P(c,N,c.rule.f.pastV),[['medium',[N],{az:-26,move:'push',amount:.2}]],Object.assign({focus:N,key:'break'},night));
 T('build',home,V(['Nothing happened. At first.','Silence. Too much silence.','At first, everything seemed fine.']),[['anim',N,'shrug',null,.9,'neutral'],['expr',N,'worried',null],['fx','heartbeat',N,null]],[['close',[N],{az:10,move:'zoom',amount:.5}]],night);
 T('turn',home,V(['Then every light went out.','Then the whole street went dark.','Then the lights began to flicker.']),[['state','lampL','on',0,'light'],['state','lampR','on',0,'light'],['flash','light',.5],['sfx','rumble','out'],['expr',N,'scared','light']],[['wide',[N],{az:-14,move:'pull',amount:.3}]],{sky:'void'});
 T('turn',home,'A shadow appeared behind {nhim}.',[['obj','shadow','shadowfigure','behind','fadeIn'],['fx','pulse','shadow','shadow'],['expr',N,'terrified','behind']],[['low',['nbr'],{az:6,move:'push',amount:.4}]],{sky:'void'});
 T('turn',home,'{N} never came back.',[['anim',N,'jumpscare','never',.6,'terrified'],['hide',N,'back'],['fx','poof',N,'never'],['hide','shadow','back'],['sfx','thud','never']],[['wide',['shadow'],{az:0}],['medium',[H],{az:20,at:'back'}]],{sky:'void'});
 T('reveal',home,V(['By morning, the house was empty.','The next day, {nhis} house was silent.','By sunrise, {nhe} was gone.']),[['cast',{hero:'front'}],['anim',H,'worried',null,0,'worried'],['state','door','open',.55,'morning',.6]],[['wide',[H],{az:-22,move:'push',amount:.18}]],{sky:'day'});
 T('reveal',home,'{H} found a note on the door.',[['do',H,'pickup','note','found'],['expr',H,'worried','note']],[['medium',[H],{az:24,move:'push',amount:.2}]],{sky:'day'});
 T('reveal',home,'It said: you saw nothing.',[['text','YOU SAW NOTHING','saw',1.7,'title'],['sfx','boom','nothing']],[['close',[H],{az:8,move:'zoom',amount:.45}]],{sky:'day'});
 T('build',home,V(['{H} wanted answers.','{H} refused to let it go.','{H} had to find the truth.']),[['anim',H,'angry',null,0,'angry'],['expr',H,'sus','answers']],[['medium',[H],{az:-16,move:'dolly'}]],{sky:'sunset'});
 T('build',home,'So {he} waited for night.',[['anim',H,'sneak','waited',0,'sus']],[['wide',[H],{az:20,move:'drift'}]],night);
 T('build',home,only?'And {he} {breakI}, too.':'And {he} {past}, too.',P(c,H,only?'too':c.rule.f.pastV),[['medium',[H],{az:-24,move:'push',amount:.2}]],Object.assign({focus:H,key:'break'},night));
 T('turn',home,'The shadow came back.',[['obj','shadow','shadowfigure','shadow','fadeIn'],['anim',H,'scared','shadow',0,'scared'],['fx','pulse','shadow','shadow']],[['low',[H,'shadow'],{az:10,move:'push',amount:.3}]],{sky:'void'});
 T('twist',home,'But this time, {H} turned around.',[['anim',H,'idle'],['turnTo',H,'shadow','turned'],['expr',H,'angry','around']],[['close',[H],{az:-12}]],{sky:'void'});
 T('twist',home,'It was {N}. {nHe} had been the shadow all along.',[['hide','shadow','It'],['cast',{nbr:'door'}],['show',N,'It'],['expr',N,'evil','It'],['fx','explosion',N,'shadow'],['shake','shadow',.6,.8]],[['hero',[N],{az:8,move:'pull'}]],{sky:'void'});
 T('payoff',home,'Now {H} is the new shadow.',[['anim',H,'proud','Now',0,'evil'],['fx','pulse',H,'shadow']],[['low',[H],{az:10,move:'rise'}]],{sky:'void'});
 return B};

/* --- E: el EFECTO ("cada X te hace Y") --- */
ARCH.effect=c=>{const H='hero',N='nbr',P=breakPlan;const home='park';const B=[];const T=(role,set,vo,plan,cam,extra)=>B.push(Object.assign({role,set,vo,plan:plan||[],cam},extra||{}));
 const eff=c.effect,e=/shrink|small|tiny/.test(eff)?'shrink':/grow|big|tall|giant/.test(eff)?'grow':/float|fly|rise/.test(eff)?'float':/dance/.test(eff)?'dance':/sneez/.test(eff)?'sneeze':/laugh/.test(eff)?'laugh':/glow|shine|light/.test(eff)?'glow':'poof';
 const fxOf={shrink:'poof',grow:'shockwave',float:'sparkle',dance:'sparkle',sneeze:'poof',laugh:'sparkle',glow:'sparkle',poof:'poof'}[e];
 const doEff=(a,w)=>{const o=[];if(e==='shrink')o.push(['scale',a,.55,w,.6]);else if(e==='grow')o.push(['scale',a,1.5,w,.6]);else if(e==='float')o.push(['hover',a,4,w]);else if(e==='dance')o.push(['anim',a,'dance',w,2.2,'grin']);else if(e==='sneeze')o.push(['anim',a,'sneeze',w,1.2,'worried']);else if(e==='laugh')o.push(['anim',a,'laugh',w,2,'laugh']);else o.push(['anim',a,'shock',w,1,'shock']);o.push(['fx',fxOf,a,w]);return o};
 T('hook',home,'{ruleSent}',[['cast',{hero:'front'}],['anim',H,'lookAround','In',2],['hook']],[['wide',[H],{az:12,move:'crane',amount:.3}]]);
 T('setup',home,'Nobody believed it.',[['cast',{hero:'front',nbr:'yardL'}],['anim',N,'laugh','believed',1.6,'laugh'],['anim',H,'shrug','Nobody',1,'smirk']],[['wide',[H,N],{az:-18,move:'drift'}]]);
 T('setup',home,'So {H} decided to test it.',[['anim',H,'think','test',1.6,'smirk'],['fx','sparkle',H,'decided']],[['medium',[H],{az:20,move:'push',amount:.2}]]);
 T('build',home,'{He} took a deep breath.',[['anim',H,'stretch','deep',1.4,'worried'],['sfx','swish','breath']],[['close',[H],{az:-12,move:'push',amount:.25}]]);
 T('build',home,'And {he} did it.',P(c,H,'did'),[['medium',[H],{az:24}]],{focus:H,key:'break'});
 T('turn',home,'Instantly, {H} changed.',[...doEff(H,'Instantly'),['shake','Instantly',.4,.5]],[['medium',[H],{az:-18,move:'zoom',amount:.4}]],{focus:H});
 T('turn',home,'{N} screamed.',[['anim',N,'panic','screamed',1.4,'terrified'],['fx','sweat',N,'screamed']],[['medium',[N],{az:16,move:'push',amount:.2}]]);
 T('build',home,'{H} tried to hide it.',[['anim',H,'hide','hide',1.5,'worried'],['walk',H,'far','tried',1.6]],[['medium',[H],{az:-24,move:'follow'}]]);
 T('build',home,'But {N} told everyone.',[['anim',N,'point','told',1.4,'gasp'],['cast',{extra1:'street',extra2:'streetR',extra3:'yardR'}],['anim','extra1','shock','told',1.4,'gasp'],['anim','extra2','shock','everyone',1.4,'gasp']],[['wide',[N,'extra1','extra2'],{az:20,move:'orbit',deg:25}]]);
 T('turn',home,'Soon, the whole town wanted to try.',[...['extra1','extra2','extra3',N].flatMap((a,i)=>doEff(a,i<2?'Soon':'try')),['fx','confetti',H,'town']],[['wide',[H,N,'extra1','extra2','extra3'],{az:-20,move:'pull',amount:.3}]]);
 T('turn',home,'Then the mayor made a new rule.',[['cast',{mayor:'plaza'}],['walk','mayor','center','mayor',1.8],['anim','mayor','angry','rule',1.6,'angry'],['text','NEW RULE','rule',1.4,'title'],['sfx','boom','rule']],[['low',['mayor'],{az:8,move:'pull',amount:.2}]]);
 T('twist',home,'It said: everyone must {act}, forever.',[['text',c.act.toUpperCase(),'act',1.6,'title']],[['close',['mayor'],{az:-8}]]);
 T('twist',home,'Now, the whole town is {ing} all day.',[...['extra1','extra2','extra3',N,H].flatMap((a)=>doEff(a,'Now')),['fx','confetti',H,'day']],[['wide',[H,N,'extra1','extra2','extra3','mayor'],{az:14,move:'crane',amount:.5}]]);
 T('payoff',home,'And nobody was allowed to stop.',[['anim',H,'flail','stop',0,'worried']],[['hero',[H],{az:10,move:'rise'}]]);
 return B};


/* --- R: la RAZÓN (el alcalde esconde el motivo) --- */
ARCH.reason=c=>{const H='hero',M='mayor';const V=a=>a[Math.floor(c.rnd()*a.length)];const P=breakPlan;const only=c.rule.kind!=='prohibit'&&c.rule.kind!=='effect';
 const B=[];const T=(role,set,vo,plan,cam,extra)=>B.push(Object.assign({role,set,vo,plan:plan||[],cam},extra||{}));const night={sky:'night'};
 T('hook','facade','{ruleSent}',[['cast',{hero:'front'}],['anim',H,'lookAround','In',2,'worried'],['hook']],[['wide',[H],{az:12,move:'crane',amount:.3}]]);
 T('setup','facade',V(['Nobody knew why.','Nobody remembered why.','Nobody ever asked why.']),[['cast',{hero:'front',nbr:'yardL'}],['anim','nbr','shrug','knew',1,'neutral'],['anim',H,'think','why',1.4,'worried']],[['medium',[H,'nbr'],{az:-20,move:'drift'}]]);
 T('setup','townhall','So {H} asked the mayor.',[['cast',{hero:'left',mayor:'podium'}],['walk',H,'plaza','asked',1.8],['anim',H,'point','asked',1.2,'sus'],['text','?','mayor',1,'pop']],[['medium',[H,M],{az:18,move:'push',amount:.2}]]);
 T('setup','townhall','The mayor just smiled.',[['anim',M,'proud','smiled',0,'smug'],['anim',H,'idle',null]],[['close',[M],{az:-10,move:'push',amount:.3}]]);
 T('build','facade','That night, {H} followed {nhim}.'.replace('{nhim}','him'),[['cast',{hero:'streetR',mayor:'center'}],['walk','mayor','door','followed',2.8],['anim',H,'sneak','followed',0,'sus'],['walk',H,'yardR','night',2.4]],[['wide',[H,M],{az:22,move:'follow'}]],Object.assign({},night));
 T('build','facade','The mayor looked around nervously.',[['anim',M,'lookAround','nervously',2,'worried'],['anim',H,'hide','looked',1.6,'sus']],[['medium',[M],{az:-24,move:'push',amount:.2}]],night);
 T('turn','facade',only?'Then he {breakI}!':'Then he {past}!',[...P(c,M,only?'stopped':c.rule.f.pastV),['expr',H,'gasp','Then']],[['medium',[M],{az:26,move:'push',amount:.22}]],Object.assign({focus:M,key:'break'},night));
 T('turn','facade','Suddenly, the ground shook.',[['shake','Suddenly',1.4,1],['sfx','rumble','ground'],['anim',H,'scared','shook',1.4,'terrified']],[['low',[H],{az:12,move:'pull',amount:.3}]],night);
 T('turn','facade','A giant creature rose behind the houses.',[['obj','beast','dragon','rose','rise'],['fx','smoke','beast','creature'],['fx','pulse','beast','rose']],[['wide',[H,M,'beast'],{az:-8,move:'crane',amount:.5}]],night);
 T('turn','facade','{H} froze.',[['anim',H,'tremble','froze',0,'terrified']],[['close',[H],{az:10,move:'zoom',amount:.5}]],night);
 T('reveal','facade','But the creature just waved.',[['state','beast','wave',1,'waved',.4],['expr',H,'shock','waved']],[['wide',[H,'beast'],{az:-14,move:'push',amount:.2}]],night);
 T('reveal','facade','It was the mayor\'s best friend.',[['anim',M,'wave','friend',1.6,'grin'],['fx','hearts',M,'friend']],[['medium',[M,H],{az:18}]],night);
 T('twist','facade','The rule was only there to keep the secret.',[['anim',H,'facepalm','secret',0,'worried'],['text','TOP SECRET','secret',1.6,'title']],[['close',[H],{az:-10}]],night);
 T('payoff','facade','So {H} promised to never tell.',[['anim',H,'salute','promised',1.4,'smirk'],['fx','sparkle',H,'promised']],[['hero',[H],{az:12,move:'rise'}]],night);
 T('payoff','facade',only?'And every night, {he} visits the creature.':'And every night, {he} {past}, just to say hello.',[['anim',H,'wave','hello',0,'grin'],['fx','hearts','beast','hello']],[['wide',[H,'beast'],{az:-16,move:'pull',amount:.3}]],night);
 return B};

function pickArchetype(rule,tone,rnd){
  if(rule.kind==='effect')return 'effect';
  const w=tone==='funny'?[['loophole',.45],['reason',.35],['warning',.2]]:tone==='suspense'?[['warning',.4],['reason',.4],['loophole',.2]]:[['warning',.45],['reason',.35],['loophole',.2]];
  let x=rnd();for(const [n,p] of w){if(x<p)return n;x-=p}return w[0][0]}

/* ------------------------------------------------------------ API pública */
function generate(idea,tone,length,variant){
  const raw=String(idea||'').trim();if(raw.length<4)throw new Error('Escribe primero una regla para el pueblo.');
  const rule=parseRule(raw);const seed=hash(raw.toLowerCase()+'|'+tone+'|'+(variant||0));const rnd=rng(seed);
  const cast=makeCast(rnd);const dom=domainOf(rule,rnd);const c=makeCtx(rule,dom,cast,tone,rnd);
  const name=pickArchetype(rule,tone,rnd);let beats=ARCH[name](c);
  // longitud: short ~ 16 beats; medium ~ todos (≈55–65 s)
  const keepShort=beats.length>16&&length==='short';
  if(keepShort){const drop=new Set();const mid=beats.filter(b=>b.role==='build'&&!b.key);for(let i=0;i<beats.length-16&&i<mid.length;i++)drop.add(mid[i]);beats=beats.filter(b=>!drop.has(b))}
  beats=beats.map((b,i)=>Object.assign({},b,{i,vo:fill(b.vo,c)}));
  const title='The town where '+rule.text.replace(/^(nobody|no one)\s+/,'').slice(0,60);
  const hookText=(rule.kind==='prohibit'&&rule.act.length<=26)?('NEVER '+rule.act.toUpperCase()):'ONE RULE. NO EXCEPTIONS.';
  return{hookText,title:cap(title),slug:'town-'+seed.toString(36),idea:raw,rule,arch:name,tone,seed,cast,domain:dom,beats}}

ITT.Story={generate,parseRule,verbForms,actForms,domainOf,classifyVerb,hash,rng,fill};
if(typeof module!=='undefined'&&module.exports)module.exports=ITT.Story;
})(typeof window!=='undefined'?window:globalThis);

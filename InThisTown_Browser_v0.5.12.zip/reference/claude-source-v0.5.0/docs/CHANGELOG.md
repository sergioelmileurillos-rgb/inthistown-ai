# Changelog v0.5.0 (sobre v0.4.8)
- Código modularizado (src/*) con build a un único index.html (`node tools/build.js dist/index.html`). Partición sin pérdidas del original.
- Corregido: atlas de caras (4 expresiones nunca se dibujaban), dependencia de kokoro-worker.js y sw.js inexistentes (worker ahora inline), límite de tiempo de 3.9 s, SFX y anclas de palabra sin uso.
- Nuevo: props con estado (puerta, ventana, lámpara, TV, espejo, cofre, nevera…) y macro `interact` (andar, girar, gesto, cambio de estado en la palabra hablada, SFX).
- Nuevo: cámara con encuadre fijo al mundo, auto-encuadre, límites; parpadeo; overlay `dim`.
- Nuevo: motor de historias (reglas → arquetipos loophole/warning/reason/effect → beats con plan visual).
- Nuevo: timing de TTS (recorte de silencios, tiempos de palabra refinados con la envolvente, pausas por puntuación), subtítulos sincronizados con el reloj de audio.
- Nuevo: catálogo/galería de assets con tags y fallbacks, informe de validación previo, cancelar, anti-doble-clic, previsualización.
## Sin probar / no implementado
Ver AUDIT.md.

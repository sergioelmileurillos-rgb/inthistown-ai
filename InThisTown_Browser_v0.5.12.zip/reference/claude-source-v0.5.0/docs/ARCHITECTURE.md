# Arquitectura
Pipeline: premisa → story.js (parseRule, domainOf, archetype, beats) → TTS por beat (Kokoro am_adam en worker inline) → timing.js (analyze) → compose.js (escenas, acciones ancladas a palabras, captions) → director.js (compile + validate) → render en tiempo real sincronizado con audioCtx.currentTime → MediaRecorder.
Módulos (orden en src/manifest.json): engine (math, prims, renderer, anim, props, interact, character, world, fx, assets, director, api) y app (story, compose, timing, sfx, main).
Nuevo asset: añadir definición en props_extra/interact y alias/tags en assets.js; aparece en la galería.

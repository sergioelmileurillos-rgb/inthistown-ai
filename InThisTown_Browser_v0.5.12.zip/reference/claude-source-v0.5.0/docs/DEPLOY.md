# Despliegue en GitHub Pages
1. En el repo, sustituye el contenido por esta carpeta (o solo dist/index.html y .github/workflows/pages.yml). El zip original con pages.yml no venía en el handoff; este workflow publica dist/index.html como index.html.
2. Settings → Pages → Source: "GitHub Actions".
3. Commit y push a main; el workflow publica en https://sergioelmileurillos-rgb.github.io/inthistown-ai/
4. kokoro-worker.js y sw.js ya no hacen falta.
Regenerar: `node tools/build.js dist/index.html`. Tests: `node tests/story.test.js`, `node tests/e2e.js dist/index.html OUT "premisa" mystery|funny|suspense short|medium`.

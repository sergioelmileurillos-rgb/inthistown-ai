# Auditoría — qué se probó realmente
PROBADO (Chromium headless con SwiftShader, Playwright, TTS sustituto flite de ffmpeg):
- Build, sintaxis, 0 problemas en barrido de premisas (tests/story.test.js).
- Generación E2E completa por la UI de 2 premisas distintas (ventana/medianoche, mentir): vídeo 576×1024, VP9+Opus en contenedor MP4/WebM reproducible por ffprobe; fotogramas inspeccionados (gancho, subtítulos con palabra resaltada, puerta/ventana abriéndose).
NO PROBADO:
- Kokoro-82M real (red bloqueada en el entorno): la sincronización con su audio real no está verificada.
- iPhone Safari, Chrome de escritorio con GPU real, GitHub Pages en HTTPS.
- Cancelación, recuperación de errores, doble clic y galería: implementados, sin prueba automatizada.
- Rendimiento: con SwiftShader el renderizado en tiempo real va a muy pocos fps (el primer vídeo tenía ~70 fotogramas en 40 s); con GPU real debería ir fluido, pero NO está verificado. Si falla, la sincronización de audio se mantiene pero el vídeo sería entrecortado.
- Pendiente: exportación determinista con WebCodecs; avisos de anclas no encontradas ("out", "morning") y un sujeto fuera de plano en un plano concreto (el validador los reporta).
- Música "Numbers": solo con archivo subido por el usuario.

/**
 * In This Town — Episode Preflight v0.6.3
 * Deterministic quality gate for a complete short-form episode timeline.
 * Renderer-neutral: validates supplied data and never invents assets or timings.
 */
const finite = n => Number.isFinite(Number(n));
const round = n => Math.round(n * 1000) / 1000;
const asArray = x => Array.isArray(x) ? x : [];

function issue(severity, code, details = {}) { return { severity, code, ...details }; }

/**
 * Validate shot coverage, caption readability, event references and timeline bounds.
 * Expected shapes:
 * shots: [{id,start,end,sceneId?,actorIds?}]
 * captions: [{id,start,end,text}]
 * events: [{id,time,type,actorId?,objectId?}]
 * inventory: {actors: string[], objects: string[]}
 */
export function validateEpisodeTimeline({ duration, shots = [], captions = [], events = [], inventory = {}, options = {} } = {}) {
  const issues = [];
  const total = Number(duration);
  const tolerance = finite(options.tolerance) ? Math.max(0, Number(options.tolerance)) : 0.08;
  const minCaptionCps = finite(options.minCaptionCps) ? Number(options.minCaptionCps) : 2;
  const maxCaptionCps = finite(options.maxCaptionCps) ? Number(options.maxCaptionCps) : 22;
  const maxCaptionChars = finite(options.maxCaptionChars) ? Number(options.maxCaptionChars) : 42;
  const maxGap = finite(options.maxShotGap) ? Number(options.maxShotGap) : 0.12;

  if (!finite(total) || total <= 0) issues.push(issue('blocker', 'invalid_episode_duration'));
  const validDuration = finite(total) && total > 0 ? total : 0;
  const actorSet = new Set(asArray(inventory.actors).map(x => typeof x === 'string' ? x : x?.id).filter(Boolean));
  const objectSet = new Set(asArray(inventory.objects || inventory.props).map(x => typeof x === 'string' ? x : x?.id).filter(Boolean));

  const normalizedShots = asArray(shots).map((s, index) => ({...s, _index:index, _start:Number(s?.start), _end:Number(s?.end)}));
  if (!normalizedShots.length) issues.push(issue('blocker', 'no_shots'));
  normalizedShots.forEach((s, i) => {
    if (!s.id) issues.push(issue('blocker', 'shot_missing_id', { index:i }));
    if (!finite(s._start) || !finite(s._end) || s._start < 0 || s._end <= s._start) {
      issues.push(issue('blocker', 'invalid_shot_interval', { shotId:s.id || null, index:i }));
      return;
    }
    if (validDuration && s._end > validDuration + tolerance) issues.push(issue('blocker', 'shot_exceeds_episode', { shotId:s.id, end:s._end, duration:validDuration }));
    for (const actorId of asArray(s.actorIds)) if (actorSet.size && !actorSet.has(actorId)) issues.push(issue('blocker', 'shot_actor_missing', { shotId:s.id, actorId }));
  });
  const ordered = normalizedShots.filter(s => finite(s._start) && finite(s._end) && s._end > s._start).sort((a,b)=>a._start-b._start || a._end-b._end);
  if (ordered.length && validDuration) {
    if (ordered[0]._start > tolerance) issues.push(issue('blocker', 'opening_coverage_gap', { from:0, to:round(ordered[0]._start) }));
    for (let i=1;i<ordered.length;i++) {
      const prev=ordered[i-1], cur=ordered[i], delta=round(cur._start-prev._end);
      if (delta > maxGap) issues.push(issue('blocker', 'shot_coverage_gap', { after:prev.id, before:cur.id, seconds:delta }));
      if (delta < -tolerance) issues.push(issue('blocker', 'shot_overlap', { first:prev.id, second:cur.id, seconds:round(-delta) }));
    }
    const last=ordered.at(-1);
    if (validDuration-last._end > tolerance) issues.push(issue('blocker', 'ending_coverage_gap', { from:round(last._end), to:round(validDuration) }));
  }

  const captionIds = new Set();
  asArray(captions).forEach((c,index)=>{
    const id=c?.id || `caption-${index+1}`;
    const start=Number(c?.start), end=Number(c?.end), text=String(c?.text ?? '').trim();
    if (captionIds.has(id)) issues.push(issue('blocker','duplicate_caption_id',{captionId:id}));
    captionIds.add(id);
    if (!finite(start)||!finite(end)||start<0||end<=start|| (validDuration && end>validDuration+tolerance)) {
      issues.push(issue('blocker','invalid_caption_interval',{captionId:id})); return;
    }
    if (!text) issues.push(issue('warning','empty_caption',{captionId:id}));
    const charsPerSecond=text.length/Math.max(.001,end-start);
    if (text.length>maxCaptionChars) issues.push(issue('warning','caption_too_long',{captionId:id,characters:text.length,limit:maxCaptionChars}));
    if (text && charsPerSecond>maxCaptionCps) issues.push(issue('warning','caption_too_fast',{captionId:id,charactersPerSecond:round(charsPerSecond)}));
    if (text && charsPerSecond<minCaptionCps && end-start>2.5) issues.push(issue('warning','caption_hold_too_long',{captionId:id,charactersPerSecond:round(charsPerSecond)}));
  });
  const sortedCaptions=asArray(captions).map(c=>({...c,_start:Number(c.start),_end:Number(c.end)})).filter(c=>finite(c._start)&&finite(c._end)&&c._end>c._start).sort((a,b)=>a._start-b._start);
  for(let i=1;i<sortedCaptions.length;i++) if(sortedCaptions[i]._start<sortedCaptions[i-1]._end-tolerance) issues.push(issue('warning','caption_overlap',{first:sortedCaptions[i-1].id||null,second:sortedCaptions[i].id||null}));

  asArray(events).forEach((e,index)=>{
    const time=Number(e?.time);
    if (!finite(time)||time<0||(validDuration&&time>validDuration+tolerance)) issues.push(issue('blocker','event_out_of_bounds',{eventId:e?.id||null,index,time:e?.time}));
    if (e?.actorId && actorSet.size && !actorSet.has(e.actorId)) issues.push(issue('blocker','event_actor_missing',{eventId:e.id||null,actorId:e.actorId}));
    if (e?.objectId && objectSet.size && !objectSet.has(e.objectId)) issues.push(issue('blocker','event_object_missing',{eventId:e.id||null,objectId:e.objectId}));
    if (!e?.type) issues.push(issue('warning','event_type_missing',{eventId:e?.id||null,index}));
  });

  const blockers=issues.filter(x=>x.severity==='blocker').length;
  const warnings=issues.filter(x=>x.severity==='warning').length;
  return {
    schema:'inthistown.episode-preflight.v1', version:'0.6.3',
    readyForRender:blockers===0 && warnings===0,
    blockers,warnings,issues,
    stats:{duration:validDuration,shots:normalizedShots.length,captions:asArray(captions).length,events:asArray(events).length}
  };
}

/** Return a concise, stable summary suitable for a UI status panel. */
export function summarizePreflight(report) {
  const issues=asArray(report?.issues);
  return {
    ready:report?.readyForRender===true,
    status:report?.readyForRender===true?'ready':issues.some(x=>x.severity==='blocker')?'blocked':'review',
    blockerCodes:issues.filter(x=>x.severity==='blocker').map(x=>x.code),
    warningCodes:issues.filter(x=>x.severity==='warning').map(x=>x.code),
    counts:{blockers:Number(report?.blockers)||0,warnings:Number(report?.warnings)||0}
  };
}

/** Keep captions aligned to video frames instead of relying only on low-frequency timeupdate. */
export function connectCaptionClock(video,captions) {
  if(!video?.addEventListener||typeof captions?.update!=='function') {
    throw new TypeError('connectCaptionClock expects a video element and a captions instance.');
  }
  let active=false;
  let rafId=null;
  let videoFrameId=null;
  const sync=()=>captions.update(video.currentTime);
  const stop=()=>{
    active=false;
    if(rafId!=null && typeof cancelAnimationFrame==='function') cancelAnimationFrame(rafId);
    if(videoFrameId!=null && typeof video.cancelVideoFrameCallback==='function') video.cancelVideoFrameCallback(videoFrameId);
    rafId=null; videoFrameId=null;
  };
  const tick=()=>{
    if(!active||video.paused||video.ended) return;
    sync();
    if(typeof video.requestVideoFrameCallback==='function') {
      videoFrameId=video.requestVideoFrameCallback(()=>tick());
    } else if(typeof requestAnimationFrame==='function') {
      rafId=requestAnimationFrame(()=>tick());
    }
  };
  const start=()=>{ if(active) return; active=true; sync(); tick(); };
  const onPause=()=>{ stop(); sync(); };
  const onSeek=()=>sync();
  video.addEventListener('play',start);
  video.addEventListener('playing',start);
  video.addEventListener('pause',onPause);
  video.addEventListener('ended',onPause);
  for(const event of ['timeupdate','seeking','seeked','loadedmetadata','ratechange']) video.addEventListener(event,onSeek);
  sync();
  if(!video.paused&&!video.ended) start();
  return ()=>{
    stop();
    video.removeEventListener('play',start);
    video.removeEventListener('playing',start);
    video.removeEventListener('pause',onPause);
    video.removeEventListener('ended',onPause);
    for(const event of ['timeupdate','seeking','seeked','loadedmetadata','ratechange']) video.removeEventListener(event,onSeek);
  };
}

/**
 * In This Town — TikTok-style subtitle overlay.
 * All unqualified time values are seconds. Milliseconds require an explicit *Ms field
 * or { timeUnit: 'ms' } option; long audio is never guessed to be milliseconds.
 */

const finite = value => value !== null && value !== undefined && value !== '' && Number.isFinite(Number(value));
const toSeconds = (value, explicitMs = false) => {
  const number = Number(value);
  if (!Number.isFinite(number)) return NaN;
  return explicitMs ? number / 1000 : number;
};

function readTiming(item, key, options = {}) {
  const aliases = key === 'start'
    ? ['startMs','start_ms','startMilliseconds','start','startTime']
    : ['endMs','end_ms','endMilliseconds','end','endTime'];
  const field = aliases.find(name => item?.[name] != null);
  if (!field) return NaN;
  const explicitMs = /ms|milliseconds/i.test(field) || options.timeUnit === 'ms';
  return toSeconds(item[field], explicitMs);
}

function tokenText(item) {
  return String(item?.word ?? item?.text ?? item?.token ?? '').trim();
}

/** Normalize word timings, sort them, clamp negative start times and remove overlaps. */
export function normalizeWordTimings(items = [], options = {}) {
  const source = Array.isArray(items) ? items : Array.isArray(items?.words) ? items.words : [];
  const normalized = source.map((item,index) => {
    const start = readTiming(item,'start',options);
    let end = readTiming(item,'end',options);
    if (!Number.isFinite(end) && finite(item?.durationMs ?? item?.duration_ms ?? item?.duration)) {
      const durationIsMs = item.durationMs != null || item.duration_ms != null || options.durationUnit === 'ms';
      end = start + toSeconds(item.durationMs ?? item.duration_ms ?? item.duration,durationIsMs);
    }
    return { text:tokenText(item), start:Math.max(0,start), end, sourceIndex:index };
  }).filter(cue => cue.text && Number.isFinite(cue.start) && Number.isFinite(cue.end) && cue.end > cue.start)
    .sort((a,b) => a.start-b.start || a.sourceIndex-b.sourceIndex);

  const clean = [];
  for (const cue of normalized) {
    const previous = clean[clean.length-1];
    if (previous && cue.start < previous.end) cue.start = previous.end;
    if (cue.end > cue.start) clean.push(cue);
  }
  return clean.map(({text,start,end}) => ({text,start,end}));
}

function joinCaptionTokens(tokens) {
  let result = '';
  for (const raw of tokens) {
    const token = String(raw ?? '').trim();
    if (!token) continue;
    const punctuationOnly = /^[,.;:!?%)}\]]/.test(token) || /^['’](?:s|re|ve|d|ll|m|t)\b/i.test(token);
    const opensAfter = /[(\[{“‘]$/.test(result);
    result += result && !punctuationOnly && !opensAfter ? ` ${token}` : token;
  }
  return result;
}

/** Combine adjacent word timings into short, readable caption phrases. */
export function groupWordTimings(words = [], options = {}) {
  const maxWords = Math.max(1,Math.min(6,Number(options.maxWords)||4));
  const maxChars = Math.max(8,Math.min(48,Number(options.maxChars)||28));
  const maxDuration = Math.max(0.4,Number(options.maxDuration)||1.35);
  const maxGap = Math.max(0,Number(options.maxGap ?? 0.28));
  const clean = normalizeWordTimings(words,options);
  const groups = [];
  let current = [];
  const flush = () => {
    if (!current.length) return;
    groups.push({
      text:joinCaptionTokens(current.map(word=>word.text)),
      start:current[0].start,
      end:current[current.length-1].end,
      words:current.map(word=>({...word}))
    });
    current=[];
  };
  for (const word of clean) {
    const previous=current[current.length-1];
    const candidateText=joinCaptionTokens([...current.map(w=>w.text),word.text]);
    const punctuationOnly=/^[,.;:!?%)}\]]+$/.test(word.text);
    const tooLarge=previous && !punctuationOnly && (
      current.length>=maxWords ||
      word.end-current[0].start>maxDuration ||
      word.start-previous.end>maxGap ||
      candidateText.length>maxChars
    );
    if (tooLarge) flush();
    current.push(word);
    if (/[.!?]$/.test(word.text)) flush();
  }
  flush();
  return groups;
}

const DEFAULT_HUD_SELECTORS = [
  '.itt-corner-label','.itt-debug-hud','.stage-note','.corner-label','.debug-label',
  '[data-itt-overlay="corner-label"]','[data-itt-overlay="debug"]','[data-itt-overlay="brand"]'
];

export function removeKnownStageHud(stage, selectors = DEFAULT_HUD_SELECTORS) {
  if (!stage?.querySelectorAll) return 0;
  let removed=0;
  for (const selector of selectors) {
    try {
      for (const node of stage.querySelectorAll(selector)) {
        if (node.closest('.itt-subtitles')) continue;
        node.remove(); removed++;
      }
    } catch { /* Ignore invalid host-provided selectors instead of breaking subtitle setup. */ }
  }
  return removed;
}

export class TikTokCaptions {
  constructor(stage, options = {}) {
    if (!stage?.appendChild) throw new TypeError('TikTokCaptions needs a valid video stage element.');
    this.stage=stage;
    this.options={
      bottom:options.bottom ?? '8.5%',
      maxWords:options.maxWords ?? 4,
      maxChars:options.maxChars ?? 28,
      maxDuration:options.maxDuration ?? 1.35,
      maxGap:options.maxGap ?? 0.28,
      timeUnit:options.timeUnit,
      durationUnit:options.durationUnit,
      offsetSeconds:Number.isFinite(Number(options.offsetSeconds))?Number(options.offsetSeconds):0
    };
    if (options.hideHud !== false) removeKnownStageHud(stage,options.hudSelectors || DEFAULT_HUD_SELECTORS);
    this.node=document.createElement('div');
    this.node.className='itt-subtitles';
    this.node.setAttribute('aria-hidden','true');
    this.node.dataset.ittOverlay='captions';
    this.node.style.bottom=this.options.bottom;
    this.stage.classList.add('itt-video-stage');
    this.stage.appendChild(this.node);
    this.cues=[];
    this.lastCue=-1;
  }

  setCues(input = []) {
    const items=Array.isArray(input)?input:(input?.words||input?.cues||[]);
    const hasWordTimings=items.some?.(item=>item&&(item.word!=null||item.token!=null));
    this.cues=hasWordTimings?groupWordTimings(items,this.options):normalizeWordTimings(items,this.options);
    this.lastCue=-1;
    this.node.replaceChildren();
  }

  setWordTimings(words,options={}) {
    this.cues=groupWordTimings(words,{...this.options,...options});
    this.lastCue=-1;
    this.node.replaceChildren();
  }

  _findCue(time) {
    let low=0,high=this.cues.length-1;
    while(low<=high){
      const mid=(low+high)>>1;
      const cue=this.cues[mid];
      if(time<cue.start) high=mid-1;
      else if(time>=cue.end) low=mid+1;
      else return mid;
    }
    return -1;
  }

  update(timeSeconds) {
    const rawTime=Number(timeSeconds);
    if(!Number.isFinite(rawTime)) return;
    const time=rawTime-this.options.offsetSeconds;
    const index=this._findCue(time);
    if(index===this.lastCue) return;
    this.lastCue=index;
    this.node.replaceChildren();
    if(index<0) return;
    const span=document.createElement('span');
    span.className='itt-subtitles__line';
    span.textContent=this.cues[index].text; // Never inject narration as HTML.
    this.node.appendChild(span);
  }

  clear(){this.node.replaceChildren();this.lastCue=-1;}
  destroy(){this.node.remove();this.cues=[];this.lastCue=-1;}
}

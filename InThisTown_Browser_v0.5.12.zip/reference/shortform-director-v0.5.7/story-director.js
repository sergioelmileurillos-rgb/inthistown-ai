/**
 * In This Town — Semantic Story Director v0.5.6
 * Deterministic narration-to-blocking planner. It never assumes a renderer clip exists.
 * The host app must bind the returned semantic plans to its own scene graph/animation API.
 */

const OBJECTS = [
  ['front door', ['front door', 'door']], ['window', ['window']], ['gate', ['gate']],
  ['drawer', ['drawer']], ['box', ['box']], ['lid', ['lid']], ['key', ['key']],
  ['phone', ['phone', 'mobile', 'cellphone']], ['backpack', ['backpack', 'bag']],
  ['book', ['book']], ['letter', ['letter', 'note', 'envelope']], ['table', ['table', 'desk']],
  ['chair', ['chair', 'sofa']], ['car', ['car', 'vehicle']], ['light', ['light', 'lamp']],
  ['switch', ['switch', 'button']], ['wallet', ['wallet', 'purse']], ['cup', ['cup', 'mug', 'glass']],
  ['food', ['food', 'sandwich', 'pizza', 'apple']], ['ball', ['ball']], ['suitcase', ['suitcase', 'luggage']],
  ['mirror', ['mirror']], ['stairs', ['stairs', 'staircase']], ['computer', ['computer', 'laptop']],
  ['remote', ['remote', 'controller']], ['helmet', ['helmet']], ['flashlight', ['flashlight', 'torch']],
  ['photo', ['photo', 'picture', 'photograph']], ['gift', ['gift', 'present']],
  ['shadow', ['shadow', 'silhouette', 'figure']], ['person', ['stranger', 'man', 'woman', 'person', 'someone']]
];

// Rules are searched by textual position, not by the order of this array.
const ACTIONS = [
  { type:'open', re:/\b(opens?|opened|opening|unlocks?|unlocked|push(?:es|ed)? open)\b/i, object:true, clips:['interact_open','action_open','open'] },
  { type:'close', re:/\b(closes?|closed|closing|shuts?|shut)\b/i, object:true, clips:['interact_close','action_close','close'] },
  { type:'pick_up', re:/\b(picks? up|picked up|takes?|took|grabs?|grabbed|holds?|held|lifts?|lifted)\b/i, object:true, clips:['interact_pickup','action_pickup','pickup','pick_up'] },
  { type:'give', re:/\b(gives?|gave|hands?|handed|passes?|passed|hands? over)\b/i, object:true, clips:['interact_give','action_give','give','handoff'] },
  { type:'put_down', re:/\b(puts? down|put down|placed|places?|drops?|dropped|sets? down|set down)\b/i, object:true, clips:['interact_putdown','action_putdown','putdown','put_down'] },
  { type:'throw', re:/\b(throws?|threw|thrown|tosses?|tossed)\b/i, object:true, clips:['action_throw','throw'] },
  { type:'catch', re:/\b(catch(?:es)?|caught|grabs? from the air)\b/i, object:true, clips:['action_catch','catch'] },
  { type:'push', re:/\b(pushes?|pushed|shoves?|shoved)\b/i, object:false, clips:['action_push','push'] },
  { type:'pull', re:/\b(pulls?|pulled|drags?|dragged)\b/i, object:false, clips:['action_pull','pull'] },
  { type:'touch', re:/\b(touches?|touched|presses?|pressed|knocks?|knocked|taps?|tapped)\b/i, object:true, clips:['interact_touch','action_touch','touch'] },
  { type:'enter', re:/\b(enter(?:s|ed|ing)?|goes? inside|went inside|steps? inside|stepped inside|comes? in|came in)\b/i, object:false, clips:['locomotion_enter','enter','walk'] },
  { type:'appear', re:/\b(appears?|appeared|emerges?|emerged|comes? into view|came into view)\b/i, object:false, clips:['appearance_enter','enter','walk'] },
  { type:'exit', re:/\b(exits?|exited|leaves?|left|walks? out|walked out|runs? out|ran out|steps? outside|stepped outside)\b/i, object:false, clips:['locomotion_exit','exit','walk'] },
  { type:'run_to', re:/\b(runs?|ran|rushes?|rushed|sprints?|sprinted|dashes?|dashed)\b/i, object:false, clips:['locomotion_run','run'] },
  { type:'walk_to', re:/\b(walks?|walked|approaches?|approached|moves? toward|moved toward|heads? toward|headed toward|steps? toward|stepped toward)\b/i, object:false, clips:['locomotion_walk','walk'] },
  { type:'jump', re:/\b(jumps?|jumped|leaps?|leaped|leapt)\b/i, object:false, clips:['locomotion_jump','jump'] },
  { type:'fall', re:/\b(falls?|fell|fallen|trips?|tripped|stumbles?|stumbled)\b/i, object:false, clips:['reaction_fall','fall'] },
  { type:'get_up', re:/\b(gets? up|got up|stands? back up|stood back up|rises?|rose)\b/i, object:false, clips:['pose_getup','get_up','stand'] },
  { type:'crouch', re:/\b(crouches?|crouched|ducks?|ducked|kneels?|knelt)\b/i, object:false, clips:['pose_crouch','crouch','kneel'] },
  { type:'sit', re:/\b(sits? down|sat down|sits?|sat)\b/i, object:false, clips:['pose_sit','sit'] },
  { type:'stand', re:/\b(stands? up|stood up|stands?|stood)\b/i, object:false, clips:['pose_stand','stand'] },
  { type:'look_at', re:/\b(looks? at|looked at|stares? at|stared at|notices?|noticed|spots?|spotted|sees?|saw)\b/i, object:false, clips:['reaction_look','look'] },
  { type:'turn', re:/\b(turns? around|turned around|turns? toward|turned toward|turns? to face|turned to face)\b/i, object:false, clips:['reaction_turn','turn'] },
  { type:'listen', re:/\b(hears?|heard|listens?|listened|listening)\b/i, object:false, clips:['reaction_listen','listen'] },
  { type:'freeze', re:/\b(freezes?|froze|freezing|stands? frozen|stood frozen|stops? dead|stopped dead)\b/i, object:false, clips:['reaction_freeze','freeze'] },
  { type:'hide', re:/\b(hides?|hid|hiding|hides? behind|hid behind)\b/i, object:false, clips:['action_hide','hide','crouch'] },
  { type:'wave', re:/\b(waves?|waved|waving)\b/i, object:false, clips:['gesture_wave','wave'] },
  { type:'nod', re:/\b(nods?|nodded|nodding)\b/i, object:false, clips:['gesture_nod','nod'] },
  { type:'shake_head', re:/\b(shakes? (?:his|her|their) head|shook (?:his|her|their) head)\b/i, object:false, clips:['gesture_shake_head','shake_head'] },
  { type:'point', re:/\b(points?|pointed|gestures? toward|gestured toward)\b/i, object:false, clips:['gesture_point','action_point','point'] },
  { type:'hug', re:/\b(hugs?|hugged|embraces?|embraced)\b/i, object:false, clips:['gesture_hug','hug'] },
  { type:'flinch', re:/\b(flinches?|flinched|recoils?|recoiled|jerks? back|jerked back)\b/i, object:false, clips:['reaction_flinch','flinch'] },
  { type:'smile', re:/\b(smiles?|smiled|grins?|grinned)\b/i, object:false, clips:['emotion_happy','gesture_smile','smile'] },
  { type:'laugh', re:/\b(laughs?|laughed|chuckles?|chuckled)\b/i, object:false, clips:['emotion_happy','gesture_laugh','laugh'] },
  { type:'gasp', re:/\b(gasps?|gasped|pants?|gasped for air)\b/i, object:false, clips:['reaction_gasp','gasp'] },
  { type:'scream', re:/\b(screams?|screamed|shriek(?:s|ed)?)\b/i, object:false, clips:['reaction_scream','scream'] },
  { type:'cry', re:/\b(cries?|cried|sobs?|sobbed|weeps?|wept)\b/i, object:false, clips:['emotion_sad','reaction_cry','cry'] },
  { type:'talk', re:/\b(says?|said|whispers?|whispered|shouts?|shouted|yells?|yelled|replies?|replied|asks?|asked)\b/i, object:false, clips:['talk','talking','idle_talk'] }
];

const EMOTIONS = [
  { type:'fear', re:/\b(scared|terrified|afraid|frightened|panicked|panic|nervous(?:ly)?|worried)\b/i, clips:['emotion_fear','reaction_fear'] },
  { type:'surprised', re:/\b(shocked|surprised|astonished|couldn.t believe|in disbelief|amazed)\b/i, clips:['emotion_surprised','reaction_surprised'] },
  { type:'angry', re:/\b(angry|furious|annoyed|mad|frustrated)\b/i, clips:['emotion_angry','reaction_angry'] },
  { type:'happy', re:/\b(happy|excited|smile(?:s|d|ing)?|grin(?:s|ned|ning)?|laugh(?:s|ed|ing)?|celebrated)\b/i, clips:['emotion_happy','reaction_happy'] },
  { type:'sad', re:/\b(sad|upset|heartbroken|disappointed|cri(?:es|ed|ing)|sob(?:s|bed|bing)|weeps?|wept|tearful)\b/i, clips:['emotion_sad','reaction_sad'] }
];

const NEGATION = /(?:\b(?:did\s+not|didn't|does\s+not|doesn't|do\s+not|don't|never|not|cannot|can't|won't|wouldn't|isn't|is\s+not|wasn't|was\s+not|refused\s+to|failed\s+to|tried\s+to|attempted\s+to|wanted\s+to|without)\s+(?:\w+\s+){0,2})$/i;
const WORD = value => new RegExp(`\\b${String(value).replace(/[.*+?^${}()|[\]\\]/g, '\\$&')}\\b`, 'i');
const clamp = (n, min, max) => Math.max(min, Math.min(max, n));

function normalizeActors(actors = []) {
  const source = Array.isArray(actors) ? actors : [];
  const normalized = source.map(actor => {
    const value = typeof actor === 'string' ? { id:actor, name:actor } : (actor || {});
    const id = String(value.id ?? value.name ?? '').trim();
    const name = String(value.name ?? value.id ?? '').trim();
    const aliases = [name, id, ...(Array.isArray(value.aliases) ? value.aliases : [])]
      .filter(Boolean).map(alias => String(alias).trim()).filter(Boolean);
    return { id, name, aliases:[...new Set(aliases)] };
  }).filter(actor => actor.id && actor.name);
  return normalized;
}

function findObject(text) {
  const lower = String(text).toLowerCase();
  // Longer phrases are considered first so "front door" is not reduced prematurely.
  for (const [canonical, aliases] of [...OBJECTS].sort((a,b) => Math.max(...b[1].map(x=>x.length)) - Math.max(...a[1].map(x=>x.length)))) {
    if (aliases.some(alias => WORD(alias).test(lower))) return canonical;
  }
  return null;
}

function findActorMention(text, actors, exceptId = null) {
  const ids = new Map();
  for (const actor of actors) {
    if (actor.id === exceptId) continue;
    if (actor.aliases.some(alias => WORD(alias).test(text))) ids.set(actor.id, actor);
  }
  return ids.size === 1 ? [...ids.values()][0] : null;
}

function actorMentionBeforeVerb(text, actors, verbIndex) {
  const matches = [];
  for (const actor of actors) for (const alias of actor.aliases) {
    const expression = new RegExp(WORD(alias).source, 'gi');
    for (const match of text.matchAll(expression)) {
      if (match.index <= verbIndex) matches.push({ actor, index:match.index });
    }
  }
  const distinct = [...new Map(matches.map(match => [match.actor.id,match.actor])).values()];
  if (distinct.length > 1 && /\b(?:and|&|both)\b/i.test(text.slice(0,verbIndex))) return null;
  matches.sort((a,b) => b.index - a.index);
  return matches[0]?.actor || null;
}

function resolveActor(beat, text, actors, previousActor, verbIndex = text.length, continueActor = false) {
  if (beat?.actor) {
    const id = typeof beat.actor === 'string' ? beat.actor : String(beat.actor.id ?? beat.actor.name ?? '');
    return actors.find(actor => actor.id === id || actor.name === id || actor.aliases.includes(id)) || { id, name:id, aliases:[id] };
  }
  const beforeVerb = actorMentionBeforeVerb(text, actors, verbIndex);
  if (beforeVerb) return beforeVerb;
  if (continueActor && previousActor) return previousActor;
  if (verbIndex >= text.length) {
    const explicit = findActorMention(text,actors);
    if (explicit) return explicit;
  }
  if (/^\s*(he|she|they|him|her|them|his|their)\b/i.test(text) && previousActor) return previousActor;
  return actors.length === 1 ? actors[0] : null;
}

function findTargetActor(text, actors, currentActor, previousActor = null, actorHistory = []) {
  const explicit = findActorMention(text, actors, currentActor?.id);
  if (explicit) return explicit;
  if (/\b(him|her|them)\b/i.test(text)) {
    if (previousActor && previousActor.id !== currentActor?.id) return previousActor;
    for (let index=actorHistory.length-1; index>=0; index--) {
      const candidate=actorHistory[index];
      if (candidate?.id && candidate.id!==currentActor?.id) return candidate;
    }
  }
  return null;
}

function isNegatedAt(text, index) {
  const prefix = text.slice(Math.max(0, index - 48), index).split(/[.!?;,]/).at(-1) || '';
  return NEGATION.test(prefix);
}

function collectActionMatches(text) {
  const matches = [];
  for (const rule of ACTIONS) {
    const expression = new RegExp(rule.re.source, 'gi');
    for (const match of text.matchAll(expression)) {
      if (!isNegatedAt(text, match.index)) {
        matches.push({ rule, index:match.index, end:match.index + match[0].length, value:match[0] });
      }
    }
  }
  matches.sort((a,b) => a.index - b.index || (b.end - b.index) - (a.end - a.index));
  const distinct = [];
  for (const match of matches) {
    const previous = distinct[distinct.length - 1];
    if (!previous || match.index >= previous.end) distinct.push(match);
  }
  return distinct;
}

function emotionFor(text) {
  return EMOTIONS.find(item => item.re.test(text)) || { type:'neutral', clips:[] };
}

function suggestedDuration(type) {
  return ({ open:1.4, close:1.1, pick_up:1.2, give:1.25, put_down:1.1, throw:0.85, catch:0.85,
    push:0.95, pull:0.95, touch:0.9, enter:1.7, exit:1.6, run_to:1.5, walk_to:1.8, jump:0.8,
    fall:1.0, get_up:1.2, crouch:0.9, sit:1.3, stand:1.0, look_at:0.8, turn:0.8, listen:1.0,
    freeze:0.8, hide:1.1, wave:0.9, nod:0.6, shake_head:0.7, point:0.8, hug:1.5, flinch:0.6, smile:0.75, laugh:1.0, gasp:0.55, scream:1.2, cry:1.1, talk:1.2, react:1.0 })[type] || 1;
}

function cameraFor(beat, previousBeat) {
  const explicitCut = beat?.camera?.cut === true || beat?.forceCut === true;
  const sceneChanged = !!previousBeat && (
    (beat.sceneId != null && previousBeat.sceneId != null && beat.sceneId !== previousBeat.sceneId) ||
    (beat.locationId != null && previousBeat.locationId != null && beat.locationId !== previousBeat.locationId)
  );
  const transitionCue = previousBeat && /\b(later that (?:day|night)|the next (?:morning|day)|hours later|meanwhile|back at|across town|at the same time)\b/i.test(String(beat?.text || ''));
  const cut = explicitCut || !!sceneChanged || !!transitionCue;
  const allowedMovement = new Set(['static','slow_push','slow_pull','pan_to_target']);
  const requested = beat?.camera?.movement;
  const movement = allowedMovement.has(requested) ? requested : 'static';
  return { cut, movement, reason:explicitCut ? 'explicit_story_direction' : sceneChanged ? 'location_or_scene_changed' : transitionCue ? 'narrative_transition' : 'preserve_continuity' };
}

function targetFromText(text, object, targetActor) {
  if (object) return object;
  if (targetActor) return targetActor.id;
  const match = text.match(/\b(?:to|toward|towards|at|into|through|behind|inside|onto|under|over|outside|away|home|upstairs|downstairs)\s+(?:the|a|an)?\s*([a-z][\w-]*)/i);
  if (match) return match[1];
  if (/\b(outside|inside|away|home|upstairs|downstairs)\b/i.test(text)) return text.match(/\b(outside|inside|away|home|upstairs|downstairs)\b/i)?.[1] || null;
  return null;
}

function objectForAction(text, match, lastObject) {
  if (!match) return findObject(text);
  const after = text.slice(match.end);
  const clauseAfter = after.split(/[,;.!?]|\b(?:and|then|but|while)\b/i,1)[0] || after;
  const localObject = findObject(clauseAfter);
  if (localObject) return localObject;
  if (/\b(it|that|the same one|the door|the box|the key)\b/i.test(clauseAfter) && lastObject) return lastObject;
  const before = text.slice(Math.max(0,match.index-42),match.index);
  return findObject(before) || null;
}

export function planBeat(beat, context = {}) {
  const text = String(beat?.text ?? beat ?? '').trim();
  const actors = normalizeActors(Array.isArray(beat?.actors) ? beat.actors : (context.actors || []));
  const previousActor = context.previousActor || null;
  const firstMatch = collectActionMatches(text)[0] || null;
  const actionRule = firstMatch?.rule || null;
  const actor = resolveActor(beat, text, actors, previousActor, firstMatch?.index ?? text.length, context.continueActor === true);
  const emotionRule = emotionFor(text);
  const object = objectForAction(text,firstMatch,context.lastObject);
  const targetActor = findTargetActor(text,actors,actor,previousActor,context.actorHistory || []);
  const target = targetFromText(text, object, targetActor);

  let action;
  if (actionRule) {
    action = {
      type:actionRule.type,
      target:actionRule.object ? object : target,
      targetActor:['give','hug','push','pull'].includes(actionRule.type) ? targetActor?.id ?? null : null,
      clipCandidates:[...actionRule.clips]
    };
  } else if (emotionRule.type !== 'neutral') {
    action = { type:'react', target:null, emotion:emotionRule.type, clipCandidates:[...emotionRule.clips] };
  } else {
    action = { type:'none', target:null, clipCandidates:[] };
  }

  const warnings = [];
  if (!actor) warnings.push(actors.length > 1 ? 'Actor is ambiguous; specify which character acts.' : 'No actor was assigned to this beat.');
  if (actionRule?.object && !object) warnings.push(`The ${actionRule.type} action has no recognised object.`);
  if (['give','hug'].includes(actionRule?.type) && !targetActor) warnings.push(`The other participant for ${actionRule.type} is unclear.`);
  if (['walk_to','run_to'].includes(action.type) && !target) warnings.push('The movement has no clear destination.');
  if (action.type === 'none') warnings.push('No supported physical action or clear emotion was found; use a neutral hold instead of inventing movement.');

  const rawDuration = beat?.duration ?? ((Number(beat?.end) - Number(beat?.start)) || suggestedDuration(action.type));
  const duration = Number(rawDuration);
  const gesture = action.type === 'none' ? 'neutral_hold' : action.type === 'react' ? `express_${emotionRule.type}` : action.type;
  const gazeTarget = action.targetActor || action.target || (['listen','freeze','react','flinch','gasp','scream'].includes(action.type) ? 'story_focus' : null);
  const propActions = new Set(['open','close','pick_up','give','put_down','throw','catch','push','pull','touch']);
  let blocking;
  if (action.type === 'give') blocking = { type:'handoff', participants:[actor?.id ?? null, targetActor?.id ?? null], object:action.target, needsSceneAnchor:true };
  else if (['hug','push','pull'].includes(action.type) && targetActor) blocking = { type:'two_character_interaction', participants:[actor?.id ?? null, targetActor?.id ?? null], needsSceneAnchor:true };
  else if (propActions.has(action.type)) blocking = { type:'prop_interaction', actor:actor?.id ?? null, object:action.target, formation:'within_reach', needsSceneAnchor:true };
  else if (['walk_to','run_to'].includes(action.type)) blocking = { type:'approach_target', actor:actor?.id ?? null, destination:action.target, needsSceneAnchor:true };
  else if (['enter','exit'].includes(action.type)) blocking = { type:action.type === 'enter' ? 'enter_scene_space' : 'exit_scene_space', actor:actor?.id ?? null, requiresDoorOrBoundaryAnchor:true };
  else if (action.type==='appear') blocking = action.target ? { type:'appear_near_target', actor:actor?.id ?? null, target:action.target, needsSceneAnchor:true } : { type:'enter_scene_space', actor:actor?.id ?? null, requiresDoorOrBoundaryAnchor:true };
  else if (['look_at','wave','point','turn'].includes(action.type)) blocking = { type:'face_target', actor:actor?.id ?? null, target:action.target || 'story_focus', needsSceneAnchor:false };
  else if (action.type === 'hide') blocking = { type:'hide_behind_anchor', actor:actor?.id ?? null, target:action.target, needsSceneAnchor:true };
  else blocking = { type:'hold_position', actor:actor?.id ?? null };

  const hasActor = !!actor?.id;
  const semanticConfidence = action.type === 'none' ? 0.25 : actionRule ? (actionRule.object && !object ? 0.52 : 0.84) : 0.68;
  const confidence = clamp(semanticConfidence - (warnings.some(w => /ambiguous|unclear|no recognised|no clear/.test(w)) ? 0.25 : 0) - (!hasActor ? 0.25 : 0), 0.05, 0.98);

  return {
    beatId:beat?.id ?? null,
    text,
    actor:actor?.id ?? null,
    action,
    acting:{ gesture, emotion:emotionRule.type, gazeTarget, intensity:beat?.intensity ?? (action.type === 'react' || action.type === 'freeze' ? 0.8 : 0.55) },
    blocking,
    timing:{ start:Number.isFinite(Number(beat?.start)) ? Number(beat.start) : null, end:Number.isFinite(Number(beat?.end)) ? Number(beat.end) : null, suggestedDuration:clamp(Number.isFinite(duration) ? duration : suggestedDuration(action.type),0.35,6), approximate:beat?.approximateTiming === true },
    camera:null,
    confidence,
    requiresReview:warnings.length > 0,
    warnings
  };
}

/** Split a narration beat containing multiple non-negated physical verbs into ordered sub-beats. */
export function expandBeatActions(beat) {
  const text = String(beat?.text ?? beat ?? '').trim();
  const matches = collectActionMatches(text);
  if (matches.length <= 1) return [{ ...((typeof beat === 'object' && beat) ? beat : { text }), text, continueActor:false, approximateTiming:false }];

  const starts = [0];
  const ends = [];
  for (let index = 1; index < matches.length; index++) {
    const previousEnd = matches[index - 1].end;
    const currentStart = matches[index].index;
    const bridge = text.slice(previousEnd, currentStart);
    const separators = [...bridge.matchAll(/(?:[.!?]\s*|,\s*(?:(?:and|then|but)\s*)?|\b(?:and(?:\s+then)?|then|but|after that|before that)\b\s*)/gi)];
    if (separators.length) {
      const separator = separators[separators.length - 1];
      ends.push(previousEnd + separator.index);
      starts.push(previousEnd + separator.index + separator[0].length);
    } else {
      ends.push(currentStart);
      starts.push(currentStart);
    }
  }
  ends.push(text.length);
  const ranges = starts.map((start,index) => ({ start, end:ends[index] })).filter(range => range.end > range.start);
  const weights = ranges.map(range => Math.max(1, text.slice(range.start,range.end).trim().length));
  const totalWeight = weights.reduce((sum,weight) => sum + weight,0);
  const hasClock = Number.isFinite(Number(beat?.start)) && Number.isFinite(Number(beat?.end)) && Number(beat.end) > Number(beat.start);
  let cursor = hasClock ? Number(beat.start) : null;
  const totalDuration = hasClock ? Number(beat.end) - Number(beat.start) : null;

  return ranges.map((range,index) => {
    const part = text.slice(range.start,range.end).trim()
      .replace(/^(and then|then|and|but|before|after that)\s+/i,'')
      .replace(/\s+(?:when|while|as|because|after|before)\s+(?:he|she|they|it|him|her|them)\s*$/i,'').trim();
    const piece = { ...((typeof beat === 'object' && beat) ? beat : {}), text:part,
      id:beat?.id == null ? null : `${beat.id}:${index+1}`,
      parentBeatId:beat?.id ?? null,
      continueActor:index > 0,
      approximateTiming:hasClock };
    if (hasClock) {
      const duration = totalDuration * weights[index] / totalWeight;
      piece.start = cursor;
      piece.end = index === ranges.length-1 ? Number(beat.end) : cursor + duration;
      cursor = piece.end;
    }
    delete piece.actor;
    if (index === 0 && beat?.actor) piece.actor = beat.actor;
    return piece;
  });
}

export function splitNarrationIntoBeats(script = '') {
  const text=String(script ?? '').replace(/\s+/g,' ').trim();
  if (!text) return [];
  const parts=text.match(/[^.!?]+[.!?]+|[^.!?]+$/g) || [text];
  return parts.map((part,index)=>({ id:`narration-${index+1}`, text:part.trim() })).filter(beat=>beat.text);
}

export function planNarration(script = '', context = {}) {
  return planStory(splitNarrationIntoBeats(script),context);
}

export function planStory(beats = [], context = {}) {
  if (typeof beats === 'string') beats=splitNarrationIntoBeats(beats);
  const actors = normalizeActors(context.actors || []);
  const plans = [];
  let previousActor = null;
  const actorHistory = [];
  let previousBeat = null;
  let lastObject = null;
  const objectOwners = {};
  const objectStates = {};
  let sequence = 0;
  for (let sourceIndex = 0; sourceIndex < beats.length; sourceIndex++) {
    const sourceBeat = beats[sourceIndex];
    const expanded = expandBeatActions(sourceBeat);
    for (const beat of expanded) {
      sequence += 1;
      const plan = planBeat(beat,{ ...context, actors, previousActor, actorHistory, lastObject, continueActor:beat.continueActor });
      plan.sequence = sequence;
      plan.sourceBeatIndex = sourceIndex;
      if (beat.parentBeatId != null) plan.parentBeatId = beat.parentBeatId;
      // Catch continuity contradictions before they reach the renderer.
      const semanticProp = plan.action.target && OBJECTS.some(([canonical]) => canonical === plan.action.target) ? plan.action.target : null;
      if (semanticProp && plan.actor) {
        const owner = objectOwners[semanticProp];
        const state = objectStates[semanticProp];
        if (plan.action.type === 'give' && owner && owner !== plan.actor) {
          plan.warnings.push(`Possession conflict: ${plan.actor} gives the ${semanticProp}, but the tracked owner is ${owner}.`);
        }
        if (plan.action.type === 'throw' && owner && owner !== plan.actor) {
          plan.warnings.push(`Possession conflict: ${plan.actor} throws the ${semanticProp}, but the tracked owner is ${owner}.`);
        }
        if (plan.action.type === 'open' && state === 'open') {
          plan.warnings.push(`Continuity conflict: ${semanticProp} is already marked open.`);
        }
        if (plan.action.type === 'close' && state === 'closed') {
          plan.warnings.push(`Continuity conflict: ${semanticProp} is already marked closed.`);
        }
        if (plan.warnings.length) plan.requiresReview = true;
      }
      if (beat.approximateTiming) {
        plan.warnings.push('Sub-action timing was proportionally split from its parent beat; align it to word timestamps before rendering.');
        plan.requiresReview = true;
      }
      plan.camera = cameraFor(beat,previousBeat);
      if (plan.actor) {
        previousActor = actors.find(actor => actor.id === plan.actor) || { id:plan.actor, name:plan.actor, aliases:[plan.actor] };
        actorHistory.push(previousActor);
      }
      const prop = plan.action.target && OBJECTS.some(([canonical]) => canonical === plan.action.target) ? plan.action.target : null;
      if (prop) lastObject = prop;
      if (prop && ['pick_up','catch'].includes(plan.action.type) && plan.actor) objectOwners[prop]=plan.actor;
      if (prop && plan.action.type==='give' && plan.action.targetActor) objectOwners[prop]=plan.action.targetActor;
      if (prop && ['put_down','throw'].includes(plan.action.type)) objectOwners[prop]=null;
      if (prop && plan.action.type==='open') objectStates[prop]='open';
      if (prop && plan.action.type==='close') objectStates[prop]='closed';
      plan.worldState={ lastObject, objectOwners:{...objectOwners}, objectStates:{...objectStates} };
      plans.push(plan);
      previousBeat = beat;
    }
  }
  const warnings = plans.flatMap((plan,index) => plan.warnings.map(message => `Beat ${index+1}: ${message}`));
  return { version:'0.5.7', plans, warnings, stats:{ sourceBeats:beats.length, beats:plans.length, needsReview:plans.filter(plan=>plan.requiresReview).length, explicitCuts:plans.filter(plan=>plan.camera.cut).length, averageConfidence:plans.length ? Number((plans.reduce((s,p)=>s+p.confidence,0)/plans.length).toFixed(2)) : 0 } };
}

function timingToken(value) {
  return String(value ?? '').toLowerCase().replace(/[^a-z0-9']/g,'').replace(/^'+|'+$/g,'');
}

/** Align planned sub-actions against actual word timestamps, in order. */
export function alignPlansToWordTimings(plans = [], wordTimings = []) {
  const words = (Array.isArray(wordTimings) ? wordTimings : wordTimings?.words || [])
    .map(item => ({ token:timingToken(item.word ?? item.text ?? item.token), start:item.startMs!=null?Number(item.startMs)/1000:Number(item.start), end:item.endMs!=null?Number(item.endMs)/1000:Number(item.end) }))
    .filter(item => item.token && Number.isFinite(item.start) && Number.isFinite(item.end) && item.end > item.start)
    .sort((a,b)=>a.start-b.start);
  let cursor = 0;
  const aligned = plans.map(plan => {
    const tokens = String(plan.text || '').split(/\s+/).map(timingToken).filter(token => token.length > 1);
    if (!tokens.length || !words.length) return { ...plan, timing:{ ...plan.timing, aligned:false, alignment:'unavailable' } };
    let foundStart = -1;
    let foundEnd = -1;
    for (let start = cursor; start < words.length; start++) {
      let scan = start;
      let matched = 0;
      for (const token of tokens) {
        let found = -1;
        for (let j = scan; j < Math.min(words.length,scan+5); j++) {
          if (words[j].token === token || words[j].token.startsWith(token) || token.startsWith(words[j].token)) { found=j; break; }
        }
        if (found < 0) break;
        scan = found + 1;
        matched += 1;
      }
      if (matched >= Math.max(1,Math.ceil(tokens.length*0.6))) { foundStart=start; foundEnd=scan-1; break; }
    }
    if (foundStart >= 0 && foundEnd >= foundStart) {
      cursor = foundEnd+1;
      return { ...plan, timing:{ ...plan.timing, start:words[foundStart].start, end:words[foundEnd].end, aligned:true, alignment:'word_timestamps', approximate:false } };
    }
    return { ...plan, timing:{ ...plan.timing, aligned:false, alignment:'not_found', approximate:true }, requiresReview:true, warnings:[...plan.warnings,'Could not align this action to the supplied narration word timings.'] };
  });
  return { plans:aligned, aligned:aligned.filter(p=>p.timing.aligned).length, unmatched:aligned.filter(p=>!p.timing.aligned).length };
}

/** Group sequential action plans into shots without introducing extra cuts. */
export function groupPlansIntoShots(plans = []) {
  const shots = [];
  for (const plan of plans) {
    const previous = shots[shots.length-1];
    if (!previous || plan.camera?.cut) {
      shots.push({ id:`shot-${shots.length+1}`, start:plan.timing?.start ?? null, end:plan.timing?.end ?? null, camera:plan.camera, plans:[plan] });
    } else {
      previous.plans.push(plan);
      if (Number.isFinite(plan.timing?.end)) previous.end = plan.timing.end;
    }
  }
  return shots;
}

/** Check references against the real scene inventory before rendering. */
export function validateStoryPlan(plans = [], inventory = {}) {
  const hasActorInventory = Array.isArray(inventory.actors);
  const propInventory = Array.isArray(inventory.objects) ? inventory.objects : inventory.props;
  const hasPropInventory = Array.isArray(propInventory);
  const hasAnchorInventory = Array.isArray(inventory.sceneAnchors);
  const actorIds = new Set((inventory.actors || []).map(item => typeof item === 'string' ? item : String(item.id ?? item.name ?? '')));
  const propIds = new Set((propInventory || []).map(item => typeof item === 'string' ? item : String(item.id ?? item.name ?? '')));
  const issues = [];
  for (const plan of plans) {
    if (plan.actor && hasActorInventory && !actorIds.has(plan.actor)) issues.push({ sequence:plan.sequence, type:'missing_actor', ref:plan.actor });
    const target = plan.action?.target;
    if (target && plan.blocking?.type === 'prop_interaction' && hasPropInventory && !propIds.has(target)) issues.push({ sequence:plan.sequence, type:'missing_prop', ref:target });
    if (plan.blocking?.needsSceneAnchor && hasAnchorInventory && inventory.sceneAnchors.length===0) issues.push({ sequence:plan.sequence, type:'missing_scene_anchor', ref:target || null });
  }
  return { valid:issues.length===0, issues, checked:plans.length };
}

function hasClip(registry, id) {
  if (!id || !registry) return false;
  if (registry instanceof Set) return registry.has(id);
  if (Array.isArray(registry)) return registry.some(item => (typeof item === 'string' ? item : item?.id) === id);
  if (registry instanceof Map) return registry.has(id);
  return Object.prototype.hasOwnProperty.call(registry,id) && registry[id] !== false && registry[id] != null;
}

/** Resolve a semantic action to a clip that genuinely exists in the host engine. */
export function bindAvailableClips(plan, availableClips = {}, options = {}) {
  const clipMap = options.clipMap || {};
  const mapped = clipMap[plan.action.type];
  const candidates = [mapped,...(plan.action.clipCandidates || [])].filter(Boolean);
  const clip = candidates.find(candidate => hasClip(availableClips,candidate)) || null;
  const fallback = !clip && options.neutralIdleClip && hasClip(availableClips,options.neutralIdleClip) ? options.neutralIdleClip : null;
  const warnings = clip ? [...plan.warnings] : [...plan.warnings,`No compatible animation clip for action "${plan.action.type}"${fallback ? '; neutral hold will be used' : ''}.`];
  return { ...plan, action:{ ...plan.action, clip:clip || fallback, fallbackUsed:!!fallback, unsupported:!clip }, requiresReview:plan.requiresReview || !clip, warnings };
}

export function createDirectorReport(result, clipRegistry = null) {
  const unresolved = clipRegistry ? result.plans.filter(plan => bindAvailableClips(plan,clipRegistry).action.unsupported) : [];
  return {
    version:'0.5.7', stats:result.stats,
    shots:groupPlansIntoShots(result.plans).length,
    warnings:result.warnings,
    unresolvedClips:unresolved.map(plan=>({ sequence:plan.sequence, action:plan.action.type, actor:plan.actor })),
    clipVerification:clipRegistry==null?'not_checked':'checked',
    readyForRender:clipRegistry!=null && result.plans.length>0 && result.plans.every(plan=>plan.actor && !plan.requiresReview) && unresolved.length===0
  };
}


/**
 * Produce a renderer-neutral command list. The host must map these command types
 * to its own real engine methods; this function never calls or invents engine APIs.
 */
export function buildRendererCommands(plan, inventory = {}, clipRegistry = {}) {
  const commands=[];
  const issues=[];
  const hasActorInventory=Array.isArray(inventory.actors);
  const hasObjectInventory=Array.isArray(inventory.objects)||Array.isArray(inventory.props);
  const actorList=Array.isArray(inventory.actors)?inventory.actors:[];
  const objectList=Array.isArray(inventory.objects)?inventory.objects:(Array.isArray(inventory.props)?inventory.props:[]);
  const getId=item=>typeof item==='string'?item:String(item?.id??item?.name??'');
  const findActorRef=ref=>actorList.find(item=>getId(item)===ref || item?.name===ref || (Array.isArray(item?.aliases)&&item.aliases.includes(ref)));
  const actorItem=findActorRef(plan.actor);
  const actorExists=!!plan.actor && (!hasActorInventory || !!actorItem);
  const actorId=actorItem?getId(actorItem):plan.actor;
  if (!plan.actor || !actorExists) issues.push({type:'actor_unavailable',ref:plan.actor||null});
  const semanticTarget=plan.action?.target;
  const targetObject=objectList.find(item=>getId(item)===semanticTarget || item?.semanticId===semanticTarget || item?.name?.toLowerCase()===String(semanticTarget||'').toLowerCase());
  const resolvedTarget=targetObject ? getId(targetObject) : (hasObjectInventory ? null : semanticTarget);
  if (semanticTarget && plan.blocking?.type==='prop_interaction' && !resolvedTarget) issues.push({type:'prop_unavailable',ref:semanticTarget});

  if (plan.camera?.cut || (plan.camera?.movement && plan.camera.movement!=='static')) {
    commands.push({type:'camera_directive',cut:!!plan.camera.cut,movement:plan.camera.movement||'static',reason:plan.camera.reason});
  }
  if (plan.blocking?.type==='prop_interaction' && resolvedTarget && actorExists) {
    commands.push({type:'position_actor_within_reach',actorId,targetId:resolvedTarget,formation:'within_reach'});
    commands.push({type:'interact_with_prop',actorId,targetId:resolvedTarget,action:plan.action.type});
  } else if (plan.blocking?.type==='approach_target' && actorExists && plan.action.target) {
    const destination=targetObject ? getId(targetObject) : (actorList.find(item=>getId(item)===plan.action.target)?.id || plan.action.target);
    commands.push({type:'move_actor_to_target',actorId,targetId:destination,pace:plan.action.type==='run_to'?'run':'walk'});
  } else if (plan.blocking?.type==='handoff') {
    const recipient=findActorRef(plan.action.targetActor);
    const recipientId=recipient?getId(recipient):(!hasActorInventory?plan.action.targetActor:null);
    if (!actorExists || !recipientId || !resolvedTarget) issues.push({type:'handoff_references_unavailable',actor:plan.actor,recipient:plan.action.targetActor,object:semanticTarget});
    else commands.push({type:'stage_handoff',giverId:actorId,recipientId,objectId:resolvedTarget,formation:'face_each_other_within_reach'});
  } else if (plan.blocking?.type==='two_character_interaction') {
    const recipient=findActorRef(plan.action.targetActor);
    const recipientId=recipient?getId(recipient):(!hasActorInventory?plan.action.targetActor:null);
    if (!actorExists || !recipientId) issues.push({type:'interaction_partner_unavailable',actor:plan.actor,partner:plan.action.targetActor});
    else commands.push({type:'stage_two_character_interaction',actorId,partnerId:recipientId,interaction:plan.action.type});
  } else if (plan.blocking?.type==='face_target' && actorExists) {
    commands.push({type:'face_target',actorId,targetId:resolvedTarget || plan.action.target || 'story_focus'});
  } else if (['enter_scene_space','exit_scene_space','hide_behind_anchor','appear_near_target'].includes(plan.blocking?.type) && actorExists) {
    const anchors=Array.isArray(inventory.sceneAnchors)?inventory.sceneAnchors:[];
    if (!anchors.length) issues.push({type:'scene_anchor_unavailable',action:plan.blocking.type});
    else commands.push({type:plan.blocking.type,actorId,anchorId:getId(anchors[0]),targetId:plan.blocking.type==='appear_near_target'?(resolvedTarget||plan.action.target||null):undefined});
  } else if (actorExists) {
    commands.push({type:'hold_actor',actorId,pose:'neutral'});
  }

  const clipBinding=bindAvailableClips(plan,clipRegistry,inventory.clipOptions||{});
  if (clipBinding.action.clip && actorExists) commands.push({type:'play_animation',actorId,clipId:clipBinding.action.clip,loop:false});
  else if (plan.action?.type!=='none') issues.push({type:'animation_clip_unavailable',action:plan.action.type});
  if (plan.acting?.emotion && plan.acting.emotion!=='neutral' && actorExists) {
    commands.push({type:'set_emotion',actorId,emotion:plan.acting.emotion,intensity:plan.acting.intensity});
  }
  if (plan.acting?.gazeTarget && actorExists) commands.push({type:'set_gaze_target',actorId,targetId:plan.acting.gazeTarget});
  return {sequence:plan.sequence??null,commands,issues,ready:issues.length===0};
}


/** Build a reusable asset/anchor manifest for a scene generator. No coordinates are guessed. */
export function collectSceneRequirements(plans = []) {
  const characters=new Map();
  const props=new Map();
  const anchorIntents=[];
  const animationIntents=new Set();
  for(const plan of plans){
    if(plan.actor) characters.set(plan.actor,{id:plan.actor,roles:[...(characters.get(plan.actor)?.roles||[]),'actor']});
    if(plan.action?.targetActor) characters.set(plan.action.targetActor,{id:plan.action.targetActor,roles:[...(characters.get(plan.action.targetActor)?.roles||[]),'interaction_partner']});
    if(plan.blocking?.object) props.set(plan.blocking.object,{semanticId:plan.blocking.object,kind:'prop'});
    if(plan.action?.target && OBJECTS.some(([key])=>key===plan.action.target)) props.set(plan.action.target,{semanticId:plan.action.target,kind:'prop'});
    if(plan.blocking?.needsSceneAnchor || plan.blocking?.requiresDoorOrBoundaryAnchor){
      anchorIntents.push({sequence:plan.sequence??null,actor:plan.actor,type:plan.blocking.type,target:plan.action?.target||null});
    }
    for(const candidate of plan.action?.clipCandidates||[]) animationIntents.add(candidate);
  }
  return {characters:[...characters.values()],props:[...props.values()],anchorIntents,animationCandidates:[...animationIntents]};
}

const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const vm = require('node:vm');

const root = path.join(__dirname, '..');
const worker = fs.readFileSync(path.join(root, 'kokoro-worker.js'), 'utf8');
const app = fs.readFileSync(path.join(root, 'app.js'), 'utf8');

function profileFor(navigatorValue) {
  const match = worker.match(/function getKokoroLoadProfile\(\)\s*\{[\s\S]*?\n\}/);
  assert.ok(match, 'worker must define the device-aware Kokoro profile');
  const sandbox = { navigator: navigatorValue, result: null };
  vm.runInNewContext(`${match[0]}\nresult = getKokoroLoadProfile();`, sandbox);
  return JSON.parse(JSON.stringify(sandbox.result));
}

test('Chromebooks use documented WASM Q8 first and never allocate WebGPU FP32 first', () => {
  const profile = profileFor({
    userAgent: 'Mozilla/5.0 (X11; CrOS x86_64 14541.0.0) AppleWebKit/537.36 Chrome/156.0.0.0 Safari/537.36',
    deviceMemory: 8,
    hardwareConcurrency: 8,
    gpu: {}
  });
  assert.equal(profile.chromebook, true);
  assert.equal(profile.constrained, true);
  assert.equal(profile.useWebGPU, false);
  assert.deepEqual(profile.wasmDtypes, ['q8', 'q4']);
});

test('high-memory desktop can keep the faster WebGPU route with Q8 WASM fallback', () => {
  const profile = profileFor({
    userAgent: 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) Chrome/156.0.0.0 Safari/537.36',
    deviceMemory: 16,
    hardwareConcurrency: 16,
    gpu: {}
  });
  assert.equal(profile.constrained, false);
  assert.equal(profile.useWebGPU, true);
  assert.deepEqual(profile.wasmDtypes, ['q8', 'q4']);
});

test('mobile and low-memory browsers avoid the large WebGPU allocation', () => {
  const mobile = profileFor({ userAgent: 'Mozilla/5.0 (iPhone; CPU iPhone OS 18_0 like Mac OS X)', deviceMemory: 8, hardwareConcurrency: 8, gpu: {} });
  const lowRam = profileFor({ userAgent: 'Mozilla/5.0 (X11; Linux x86_64) Chrome/156.0.0.0', deviceMemory: 4, hardwareConcurrency: 8, gpu: {} });
  assert.equal(mobile.useWebGPU, false);
  assert.deepEqual(mobile.wasmDtypes, ['q8', 'q4']);
  assert.equal(lowRam.useWebGPU, false);
  assert.deepEqual(lowRam.wasmDtypes, ['q8', 'q4']);
});

test('embedded file worker and hosted worker share the Q8-first strategy and preserve worker diagnostics', () => {
  assert.match(app, /function getKokoroLoadProfile\(\)/);
  assert.match(app, /wasmDtypes:constrained\?\['q8','q4'\]:\['q8','q4'\]/);
  assert.match(worker, /wasmDtypes:constrained\?\['q8','q4'\]:\['q8','q4'\]/);
  assert.match(worker, /generación de voz · \$\{activeDtype\}/);
  assert.match(worker, /código numérico \$\{error\} \(0x/);
  assert.match(app, /const phase=msg\.phase\?/);
  assert.match(app, /Detalle interno:/);
});

test('Chromebook worker retries Q4 if Q8 fails, and reaches ready without using WebGPU', async () => {
  const calls = [];
  const messages = [];
  let messageHandler;
  const workerSelf = {
    addEventListener(type, handler) { if (type === 'message') messageHandler = handler; },
    postMessage(message) { messages.push(message); }
  };
  const sandbox = {
    self: workerSelf,
    navigator: {
      userAgent: 'Mozilla/5.0 (X11; CrOS x86_64 14541.0.0) Chrome/156.0.0.0',
      deviceMemory: 4,
      hardwareConcurrency: 4,
      gpu: {}
    },
    __mockImport: async () => ({
      KokoroTTS: {
        async from_pretrained(_model, options) {
          calls.push({ dtype: options.dtype, device: options.device });
          if (options.dtype === 'q8') throw 438170696;
          return { generate() {} };
        }
      }
    })
  };
  const executable = worker.replace('await import(KOKORO_MODULE_URL)', 'await __mockImport(KOKORO_MODULE_URL)');
  vm.runInNewContext(executable, sandbox);
  await messageHandler({ data: { type: 'load' } });
  assert.deepEqual(calls, [
    { dtype: 'q8', device: 'wasm' },
    { dtype: 'q4', device: 'wasm' }
  ]);
  assert.ok(messages.some(message => message.type === 'ready'));
  assert.ok(messages.some(message => /alternativa/.test(message.message || '')));
});

# v0.5.12 test report

- [x] Fixed and tested the shared `checkCancel()` guard used by creation, scene validation and asset previews.
- [x] Cancel button now sets the shared cancellation state.
- [x] Kokoro loading strategy tests cover Chromebook Q8-first with Q4 fallback and desktop WebGPU selection.
- [x] Story generation and visual-plan adapter tests cover multiple premises and tones.
- [x] Scene compilation and object continuity tests cover actor/object state across cuts.
- [x] Memory-stability tests verify worker termination and 24 fps render throttling.
- [x] WebGL context loss is reported to the user.
- [x] All application JavaScript files pass `node --check`.
- [ ] Full Kokoro inference + WebGL2 + MediaRecorder export still needs a real browser/device run on the Chromebook.

Automated tests validate code structure and simulated paths; they do not claim a complete final video has been rendered on the actual Chromebook.


La suite de v0.5.12 incluye 32 pruebas automatizadas, entre ellas: aparición de la sombra sincronizada con la palabra narrada, cámara que encuadra actor y sombra, farolas separadas y cambio real de iluminación, continuidad entre escenas y taller de modelos personalizados.

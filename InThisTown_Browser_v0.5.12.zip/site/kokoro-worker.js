/* In This Town — Kokoro-82M worker. WebGPU first when available; WASM q8 fallback. */
'use strict';
const KOKORO_MODULE_URL='https://cdn.jsdelivr.net/npm/kokoro-js@1.2.1/dist/kokoro.web.js';
const MODEL_ID='onnx-community/Kokoro-82M-v1.0-ONNX';
const VOICE_SPEED=1.14;
let tts=null,loading=null,activeDtype='unknown';
function getKokoroLoadProfile(){
  const ua=typeof navigator!=='undefined'?(navigator.userAgent||''):'';
  const memory=typeof navigator!=='undefined'?Number(navigator.deviceMemory||0):0;
  const cores=typeof navigator!=='undefined'?Number(navigator.hardwareConcurrency||0):0;
  const chromebook=/\bCrOS\b/i.test(ua);
  const mobile=/Android|iPhone|iPad|iPod/i.test(ua);
  const constrained=chromebook||mobile||(memory>0&&memory<=4)||(cores>0&&cores<=4);
  return {
    chromebook, constrained,
    useWebGPU:!constrained&&memory>=8&&typeof navigator!=='undefined'&&!!navigator.gpu,
    wasmDtypes:constrained?['q8','q4']:['q8','q4'],
    memory, cores
  };
}
function describeKokoroError(error){
  if(typeof error==='number')return `código numérico ${error} (0x${(error>>>0).toString(16).toUpperCase()})`;
  if(typeof error==='string')return error;
  if(error&&typeof error==='object')return error.message||error.name||JSON.stringify(error);
  return String(error);
}
function postError(id,phase,error){
  self.postMessage({type:'error',id:id??null,phase,message:describeKokoroError(error),stack:error?.stack||''});
}
async function loadModel(){
  if(tts)return tts;if(loading)return loading;
  loading=(async()=>{
    self.postMessage({type:'progress',message:'Preparando el motor de voz…',progress:8});
    const mod=await import(KOKORO_MODULE_URL);if(!mod.KokoroTTS)throw new Error('La compilación de Kokoro no expone KokoroTTS.');
    const onProgress=event=>{const loaded=Number(event?.loaded||0),total=Number(event?.total||0),file=event?.file||event?.name||event?.path||'modelo';if(total>0)self.postMessage({type:'progress',message:`Descargando Kokoro (${file}) · ${Math.round(loaded/1048576)} / ${Math.round(total/1048576)} MB…`,progress:Math.round(10+Math.min(1,loaded/total)*14)});else if(event?.status)self.postMessage({type:'progress',message:`Preparando Kokoro (${file}) · ${event.status}…`,progress:12});};
    const profile=getKokoroLoadProfile();
    const failures=[];
    if(profile.chromebook)self.postMessage({type:'progress',message:'Chromebook detectado · activando carga de memoria reducida…',progress:9});
    // Avoid a large FP32 WebGPU allocation on Chromebooks and constrained devices.
    if(profile.useWebGPU){
      try{
        self.postMessage({type:'progress',message:'Probando Kokoro acelerado por GPU…',progress:10});
        tts=await mod.KokoroTTS.from_pretrained(MODEL_ID,{dtype:'fp32',device:'webgpu',progress_callback:onProgress});activeDtype='fp32/webgpu';
      }catch(gpuError){
        failures.push(`WebGPU/FP32: ${describeKokoroError(gpuError)}`);
        self.postMessage({type:'progress',message:'La GPU no está disponible; cambiando al modo compatible…',progress:13});
        tts=null;
      }
    }
    for(const dtype of profile.wasmDtypes){
      if(tts)break;
      try{
        self.postMessage({type:'progress',message:`Cargando voz Kokoro · modo WASM ${dtype.toUpperCase()}…`,progress:dtype==='q4'?14:16});
        tts=await mod.KokoroTTS.from_pretrained(MODEL_ID,{dtype,device:'wasm',progress_callback:onProgress});activeDtype=`${dtype}/wasm`;
      }catch(wasmError){
        failures.push(`WASM/${dtype.toUpperCase()}: ${describeKokoroError(wasmError)}`);
        tts=null;
        if(profile.wasmDtypes.indexOf(dtype)<profile.wasmDtypes.length-1){
          self.postMessage({type:'progress',message:`El modo ${dtype.toUpperCase()} no ha arrancado; probando una alternativa…`,progress:17});
        }
      }
    }
    if(!tts)throw new Error(`No se ha podido inicializar Kokoro. Intentos: ${failures.join(' · ')||'ninguno'}. Comprueba la conexión y vuelve a intentarlo.`);
    if(typeof tts.generate!=='function')throw new Error('Kokoro se ha cargado, pero no ofrece generate().');
    self.postMessage({type:'ready',message:profile.constrained?'Kokoro listo · modo de memoria reducida.':'Kokoro listo.'});return tts;
  })();
  try{return await loading;}catch(error){tts=null;loading=null;throw error;}
}
self.addEventListener('message',async event=>{const data=event.data||{};if(data.type==='load'){try{await loadModel();}catch(error){postError(null,'carga de Kokoro',error);}return;}if(data.type==='generate'){try{const model=await loadModel();const result=await model.generate(String(data.text||''),{voice:data.voice||'am_adam',speed:Number(data.speed||VOICE_SPEED)});const audio=result?.audio instanceof Float32Array?result.audio:(result?.audio?.audio instanceof Float32Array?result.audio.audio:null);if(!audio||!audio.length)throw new Error('Kokoro no ha devuelto muestras de audio.');const sampleRate=result?.sampling_rate||result?.sample_rate||result?.audio?.sampling_rate||24000;self.postMessage({type:'audio',id:data.id,audio,sampleRate},[audio.buffer]);}catch(error){postError(data.id,`generación de voz · ${activeDtype}`,error);}}});

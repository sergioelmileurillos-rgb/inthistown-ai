/* engine/character.js — Roblox-style R6 characters built from boxes (head/torso/arms/legs), fully parametric. */
(function(S){
const {M,hex,shade,rng}=S;
const FACES=['smile','neutral','shock','angry','sad','laugh','sleep','wink','smirk','scared','dead','cute','talk','grin','worried','cry','tongue','love','dizzy','evil','sus','blush','bored','terrified','pout','star','smug','sob'];
const SKINS=['#f4c9a1','#e8b48a','#c68a5c','#8d5a3a','#5a3a26','#ffdfc4','#f6d7b7','#b57c52'];
const HAIRC=['#2a1a10','#4b2d14','#7a4a22','#c6702f','#e8c35a','#1b1b22','#a33b20','#d9d9de','#6b3b1d'];
const CLOTH=['#2f6df6','#e84a4a','#32b36b','#f5c542','#a45be8','#ff8a3d','#2fb8d6','#ec5fa5','#ffffff','#3b3f4a'];
const PRESETS={
  hero:{skin:'#f4c9a1',hair:'#6b3b1d',hairStyle:'spiky',shirt:'#2f6df6',pants:'#243a73',shoes:'#f2f2f2',decal:'star',face:'smile',sleeves:'short'},
  girl:{skin:'#f6d7b7',hair:'#c6702f',hairStyle:'long',shirt:'#ec5fa5',pants:'#6a4bc8',shoes:'#ffffff',decal:'heart',face:'cute',sleeves:'short'},
  boy2:{skin:'#8d5a3a',hair:'#1b1b22',hairStyle:'short',shirt:'#32b36b',pants:'#2b2f3a',shoes:'#ffffff',decal:'none',face:'smile',sleeves:'short'},
  oldman:{skin:'#e8b48a',hair:'#d9d9de',hairStyle:'bald',shirt:'#7a4a22',pants:'#4a3a2e',shoes:'#3a2a1f',decal:'none',face:'neutral',beard:'#d9d9de',accessory:['glasses'],sleeves:'long',scale:.96},
  grandma:{skin:'#f6d7b7',hair:'#d9d9de',hairStyle:'bun',shirt:'#d8689c',pants:'#7a4ca0',shoes:'#3a2a1f',decal:'none',face:'smile',accessory:['glasses'],sleeves:'long'},
  mayor:{skin:'#f4c9a1',hair:'#d9d9de',hairStyle:'bald',shirt:'#4b2d9a',pants:'#4b2d9a',shoes:'#1b1b22',decal:'none',face:'smirk',beard:'#d9d9de',accessory:['tophat','mustache','sash'],sleeves:'long'},
  kid:{skin:'#e8b48a',hair:'#2a1a10',hairStyle:'messy',shirt:'#f5c542',pants:'#3a5bd6',shoes:'#e84a4a',decal:'none',face:'grin',sleeves:'short',scale:.78},
  teacher:{skin:'#c68a5c',hair:'#1b1b22',hairStyle:'bun',shirt:'#ffffff',pants:'#3b3f4a',shoes:'#1b1b22',decal:'none',face:'neutral',accessory:['glasses','tie'],sleeves:'long'},
  cop:{skin:'#f4c9a1',hair:'#1b1b22',hairStyle:'cap',hat:'#1b2a5a',shirt:'#2a4fa8',pants:'#1b2a5a',shoes:'#111',decal:'none',face:'neutral',sleeves:'long'},
  student:{skin:'#f4c9a1',hair:'#1b1b22',hairStyle:'messy',shirt:'#1f3a73',pants:'#243a73',shoes:'#eee',decal:'none',face:'neutral',accessory:['glasses'],sleeves:'long',jacket:true},
  monster:{skin:'#7a8da6',hair:'#7a8da6',hairStyle:'bald',shirt:'#5a6c85',pants:'#5a6c85',shoes:'#5a6c85',decal:'none',face:'angry',scale:2.6,sleeves:'long'},
};
function faceTex(R){return R.canvasTex('faces',(g,w,h)=>{const c=w/4;g.clearRect(0,0,w,h);
  FACES.forEach((f,i)=>{const cx=(i%4)*c+c/2,cy=Math.floor(i/4)*c+c/2,s=c/128;g.save();g.translate(cx-64*s,cy-64*s);g.scale(s,s);drawFace(g,f);g.restore()})},512,768,true)}
function drawFace(g,f){g.fillStyle='#17110f';g.strokeStyle='#17110f';g.lineCap='round';g.lineWidth=7;
  const eye=(x,y,rx,ry)=>{g.beginPath();g.ellipse(x,y,rx,ry,0,0,7);g.fill()};
  const arc=(x,y,r,a0,a1)=>{g.beginPath();g.arc(x,y,r,a0,a1);g.stroke()};
  const L=44,R=84,EY=54,MY=88;
  switch(f){
  case'smile':eye(L,EY,6,9);eye(R,EY,6,9);arc(64,MY-14,20,.15*Math.PI,.85*Math.PI);break;
  case'grin':eye(L,EY,6,9);eye(R,EY,6,9);g.beginPath();g.moveTo(40,82);g.quadraticCurveTo(64,118,88,82);g.closePath();g.fill();g.fillStyle='#fff';g.fillRect(48,82,32,7);break;
  case'neutral':eye(L,EY,6,9);eye(R,EY,6,9);g.beginPath();g.moveTo(52,MY);g.lineTo(76,MY);g.stroke();break;
  case'shock':g.fillStyle='#fff';g.beginPath();g.ellipse(L,EY,12,15,0,0,7);g.ellipse(R,EY,12,15,0,0,7);g.fill();g.stroke();g.fillStyle='#17110f';eye(L,EY+1,4,5);eye(R,EY+1,4,5);g.beginPath();g.ellipse(64,MY+4,8,12,0,0,7);g.fill();break;
  case'angry':eye(L,EY+3,6,8);eye(R,EY+3,6,8);g.lineWidth=9;g.beginPath();g.moveTo(30,EY-12);g.lineTo(54,EY-2);g.moveTo(98,EY-12);g.lineTo(74,EY-2);g.stroke();g.lineWidth=7;arc(64,MY+14,18,1.15*Math.PI,1.85*Math.PI);break;
  case'sad':eye(L,EY+2,6,9);eye(R,EY+2,6,9);g.beginPath();g.moveTo(30,EY-6);g.lineTo(54,EY-14);g.moveTo(98,EY-6);g.lineTo(74,EY-14);g.stroke();arc(64,MY+14,16,1.2*Math.PI,1.8*Math.PI);break;
  case'laugh':arc(L,EY+4,10,1.1*Math.PI,1.9*Math.PI);arc(R,EY+4,10,1.1*Math.PI,1.9*Math.PI);g.beginPath();g.moveTo(36,80);g.quadraticCurveTo(64,128,92,80);g.closePath();g.fill();g.fillStyle='#e8556b';g.beginPath();g.ellipse(64,100,13,7,0,0,7);g.fill();break;
  case'sleep':g.lineWidth=6;g.beginPath();g.moveTo(34,EY+4);g.lineTo(54,EY+4);g.moveTo(74,EY+4);g.lineTo(94,EY+4);g.stroke();g.beginPath();g.ellipse(64,MY+2,6,5,0,0,7);g.stroke();break;
  case'wink':eye(L,EY,6,9);g.lineWidth=6;g.beginPath();g.moveTo(74,EY+2);g.lineTo(94,EY-3);g.stroke();arc(64,MY-14,20,.15*Math.PI,.85*Math.PI);break;
  case'smirk':eye(L,EY,6,9);eye(R,EY,6,9);g.beginPath();g.moveTo(50,MY);g.quadraticCurveTo(70,MY+2,84,MY-10);g.stroke();g.lineWidth=6;g.beginPath();g.moveTo(32,EY-14);g.lineTo(54,EY-10);g.stroke();break;
  case'scared':g.fillStyle='#fff';g.beginPath();g.ellipse(L,EY,11,13,0,0,7);g.ellipse(R,EY,11,13,0,0,7);g.fill();g.stroke();g.fillStyle='#17110f';eye(L,EY,3,3);eye(R,EY,3,3);g.beginPath();g.moveTo(40,MY+4);for(let i=1;i<=6;i++)g.lineTo(40+i*8,MY+4+(i%2?-7:7));g.stroke();break;
  case'dead':g.lineWidth=6;for(const x of[L,R]){g.beginPath();g.moveTo(x-9,EY-9);g.lineTo(x+9,EY+9);g.moveTo(x+9,EY-9);g.lineTo(x-9,EY+9);g.stroke()}arc(64,MY+10,14,1.15*Math.PI,1.85*Math.PI);break;
  case'cute':eye(L,EY,7,10);eye(R,EY,7,10);g.fillStyle='#fff';eye(L-2,EY-3,2.5,3);eye(R-2,EY-3,2.5,3);g.fillStyle='rgba(255,90,120,.55)';eye(28,72,10,6);eye(100,72,10,6);g.fillStyle='#17110f';arc(64,MY-8,9,.15*Math.PI,.85*Math.PI);break;
  case'talk':eye(L,EY,6,9);eye(R,EY,6,9);g.beginPath();g.ellipse(64,MY+2,12,9,0,0,7);g.fill();break;
  case'worried':eye(L,EY+2,6,9);eye(R,EY+2,6,9);g.beginPath();g.moveTo(30,EY-6);g.lineTo(54,EY-14);g.moveTo(98,EY-6);g.lineTo(74,EY-14);g.stroke();g.beginPath();g.moveTo(48,MY+2);g.quadraticCurveTo(64,MY-6,80,MY+2);g.stroke();break;
  case'cry':eye(L,EY,6,9);eye(R,EY,6,9);g.fillStyle='#5ab8ff';g.beginPath();g.ellipse(L,EY+22,5,14,0,0,7);g.ellipse(R,EY+22,5,14,0,0,7);g.fill();g.fillStyle='#17110f';arc(64,MY+14,16,1.2*Math.PI,1.8*Math.PI);break;
  case'tongue':eye(L,EY,6,9);eye(R,EY,6,9);arc(64,MY-14,20,.15*Math.PI,.85*Math.PI);g.fillStyle='#ff6f8f';g.beginPath();g.ellipse(70,MY+8,8,11,0,0,7);g.fill();break;
  case'love':g.fillStyle='#ff3f6e';for(const x of[L,R]){g.beginPath();g.moveTo(x,EY+12);g.bezierCurveTo(x-22,EY-6,x-8,EY-24,x,EY-8);g.bezierCurveTo(x+8,EY-24,x+22,EY-6,x,EY+12);g.fill()}g.fillStyle='#17110f';arc(64,MY-12,20,.15*Math.PI,.85*Math.PI);break;
  case'dizzy':g.lineWidth=5;for(const x of[L,R]){g.beginPath();for(let i=0;i<40;i++){const a=i*.45,r=i*.4;g.lineTo(x+Math.cos(a)*r,EY+Math.sin(a)*r)}g.stroke()}g.beginPath();g.moveTo(44,MY+4);g.quadraticCurveTo(54,MY-4,64,MY+4);g.quadraticCurveTo(74,MY+12,84,MY+4);g.stroke();break;
  case'evil':eye(L,EY+3,6,8);eye(R,EY+3,6,8);g.lineWidth=9;g.beginPath();g.moveTo(28,EY-14);g.lineTo(56,EY-2);g.moveTo(100,EY-14);g.lineTo(72,EY-2);g.stroke();g.beginPath();g.moveTo(34,MY-4);g.quadraticCurveTo(64,MY+30,94,MY-4);g.closePath();g.fill();g.fillStyle='#fff';g.fillRect(44,MY+2,40,6);break;
  case'sus':g.fillStyle='#fff';g.beginPath();g.ellipse(L,EY+4,11,7,0,0,7);g.ellipse(R,EY+4,11,7,0,0,7);g.fill();g.stroke();g.fillStyle='#17110f';eye(L+5,EY+4,4,5);eye(R+5,EY+4,4,5);g.lineWidth=7;g.beginPath();g.moveTo(30,EY-6);g.lineTo(56,EY-6);g.moveTo(74,EY-6);g.lineTo(100,EY-6);g.stroke();g.beginPath();g.moveTo(52,MY+2);g.lineTo(78,MY+2);g.stroke();break;
  case'blush':eye(L,EY,6,9);eye(R,EY,6,9);g.fillStyle='rgba(255,90,120,.65)';eye(26,72,12,7);eye(102,72,12,7);g.fillStyle='#17110f';arc(64,MY-10,12,.2*Math.PI,.8*Math.PI);break;
  case'bored':g.lineWidth=6;g.beginPath();g.moveTo(34,EY+2);g.lineTo(56,EY+2);g.moveTo(72,EY+2);g.lineTo(94,EY+2);g.stroke();eye(45,EY+9,5,5);eye(83,EY+9,5,5);g.beginPath();g.moveTo(52,MY+2);g.lineTo(76,MY+2);g.stroke();break;
  case'terrified':g.fillStyle='#fff';g.beginPath();g.ellipse(L,EY,14,18,0,0,7);g.ellipse(R,EY,14,18,0,0,7);g.fill();g.stroke();g.fillStyle='#17110f';eye(L,EY,2.5,2.5);eye(R,EY,2.5,2.5);g.beginPath();g.ellipse(64,MY+8,16,20,0,0,7);g.fill();break;
  case'pout':eye(L,EY,6,9);eye(R,EY,6,9);g.beginPath();g.moveTo(34,EY-8);g.lineTo(56,EY-12);g.moveTo(94,EY-8);g.lineTo(72,EY-12);g.stroke();arc(64,MY+12,14,1.15*Math.PI,1.85*Math.PI);break;
  case'star':g.fillStyle='#ffd23a';for(const x of[L,R]){g.beginPath();for(let k=0;k<10;k++){const a=-Math.PI/2+k*Math.PI/5,rr=k%2?6:16;g.lineTo(x+Math.cos(a)*rr,EY+Math.sin(a)*rr)}g.closePath();g.fill()}g.fillStyle='#17110f';g.beginPath();g.moveTo(40,82);g.quadraticCurveTo(64,116,88,82);g.closePath();g.fill();break;
  case'smug':g.lineWidth=6;g.beginPath();g.moveTo(32,EY+2);g.lineTo(56,EY+2);g.moveTo(72,EY+2);g.lineTo(96,EY+2);g.stroke();g.beginPath();g.moveTo(50,MY-2);g.quadraticCurveTo(72,MY+10,88,MY-14);g.stroke();g.beginPath();g.moveTo(34,EY-14);g.lineTo(56,EY-18);g.stroke();break;
  case'sob':g.lineWidth=6;arc(L,EY+4,9,1.1*Math.PI,1.9*Math.PI);arc(R,EY+4,9,1.1*Math.PI,1.9*Math.PI);g.fillStyle='#5ab8ff';g.beginPath();g.ellipse(L,EY+26,6,18,0,0,7);g.ellipse(R,EY+26,6,18,0,0,7);g.fill();g.fillStyle='#17110f';g.beginPath();g.ellipse(64,MY+10,16,14,0,0,7);g.fill();break;
  }}
const DECALS=['star','heart','bolt','smiley','stripe','skull','dot','cross','flame','crown','ring','arrow','check','peace','bear','stripes3'];
function decalTex(R){return R.canvasTex('decals',(g,w,h)=>{g.clearRect(0,0,w,h);const c=w/4;
  DECALS.forEach((d,i)=>{const cx=(i%4)*c+c/2,cy=Math.floor(i/4)*c+c/2,r=c*.36;g.save();g.translate(cx,cy);
   if(d==='star'){g.fillStyle='#ffd23a';g.strokeStyle='#c99a10';g.lineWidth=5;g.beginPath();for(let k=0;k<10;k++){const a=-Math.PI/2+k*Math.PI/5,rr=k%2?r*.45:r;g.lineTo(Math.cos(a)*rr,Math.sin(a)*rr)}g.closePath();g.fill();g.stroke()}
   if(d==='heart'){g.fillStyle='#ff4f7e';g.beginPath();g.moveTo(0,r*.9);g.bezierCurveTo(-r*1.5,-r*.2,-r*.6,-r*1.1,0,-r*.35);g.bezierCurveTo(r*.6,-r*1.1,r*1.5,-r*.2,0,r*.9);g.fill()}
   if(d==='bolt'){g.fillStyle='#ffe14a';g.beginPath();g.moveTo(r*.2,-r);g.lineTo(-r*.6,r*.1);g.lineTo(0,r*.1);g.lineTo(-r*.2,r);g.lineTo(r*.6,-r*.15);g.lineTo(0,-r*.15);g.closePath();g.fill()}
   if(d==='smiley'){g.fillStyle='#ffd23a';g.beginPath();g.arc(0,0,r,0,7);g.fill();g.fillStyle='#222';g.beginPath();g.arc(-r*.35,-r*.2,r*.12,0,7);g.arc(r*.35,-r*.2,r*.12,0,7);g.fill();g.strokeStyle='#222';g.lineWidth=5;g.beginPath();g.arc(0,r*.05,r*.5,.2,Math.PI-.2);g.stroke()}
   if(d==='stripe'){g.fillStyle='#fff';g.fillRect(-r*1.3,-r*.35,r*2.6,r*.25);g.fillRect(-r*1.3,r*.1,r*2.6,r*.25)}
   if(d==='skull'){g.fillStyle='#f5f5f5';g.beginPath();g.arc(0,-r*.1,r*.8,0,7);g.fill();g.fillRect(-r*.4,r*.3,r*.8,r*.5);g.fillStyle='#222';g.beginPath();g.arc(-r*.3,-r*.1,r*.2,0,7);g.arc(r*.3,-r*.1,r*.2,0,7);g.fill()}
   if(d==='dot'){g.fillStyle='#fff';g.beginPath();g.arc(0,0,r*.6,0,7);g.fill()}
   if(d==='cross'){g.fillStyle='#e84a4a';g.fillRect(-r*.2,-r*.7,r*.4,r*1.4);g.fillRect(-r*.7,-r*.2,r*1.4,r*.4)}
   if(d==='flame'){g.fillStyle='#ff7a1a';g.beginPath();g.moveTo(0,-r);g.bezierCurveTo(r*.9,-r*.2,r*.9,r*.8,0,r);g.bezierCurveTo(-r*.9,r*.8,-r*.9,-r*.2,0,-r);g.fill();g.fillStyle='#ffd23a';g.beginPath();g.moveTo(0,-r*.2);g.bezierCurveTo(r*.5,r*.2,r*.4,r*.8,0,r*.85);g.bezierCurveTo(-r*.4,r*.8,-r*.5,r*.2,0,-r*.2);g.fill()}
   if(d==='crown'){g.fillStyle='#ffd23a';g.beginPath();g.moveTo(-r,r*.6);g.lineTo(-r,-r*.5);g.lineTo(-r*.5,0);g.lineTo(0,-r*.7);g.lineTo(r*.5,0);g.lineTo(r,-r*.5);g.lineTo(r,r*.6);g.closePath();g.fill()}
   if(d==='ring'){g.strokeStyle='#fff';g.lineWidth=r*.28;g.beginPath();g.arc(0,0,r*.7,0,7);g.stroke()}
   if(d==='arrow'){g.fillStyle='#fff';g.beginPath();g.moveTo(0,-r);g.lineTo(r*.8,0);g.lineTo(r*.3,0);g.lineTo(r*.3,r);g.lineTo(-r*.3,r);g.lineTo(-r*.3,0);g.lineTo(-r*.8,0);g.closePath();g.fill()}
   if(d==='check'){g.strokeStyle='#32b36b';g.lineWidth=r*.3;g.lineCap='round';g.beginPath();g.moveTo(-r*.7,0);g.lineTo(-r*.2,r*.6);g.lineTo(r*.8,-r*.6);g.stroke()}
   if(d==='peace'){g.strokeStyle='#fff';g.lineWidth=r*.16;g.beginPath();g.arc(0,0,r*.8,0,7);g.moveTo(0,-r*.8);g.lineTo(0,r*.8);g.moveTo(0,0);g.lineTo(-r*.55,r*.55);g.moveTo(0,0);g.lineTo(r*.55,r*.55);g.stroke()}
   if(d==='bear'){g.fillStyle='#8a5a2a';g.beginPath();g.arc(0,0,r*.7,0,7);g.arc(-r*.6,-r*.6,r*.3,0,7);g.arc(r*.6,-r*.6,r*.3,0,7);g.fill();g.fillStyle='#222';g.beginPath();g.arc(-r*.25,-r*.1,r*.08,0,7);g.arc(r*.25,-r*.1,r*.08,0,7);g.arc(0,r*.15,r*.12,0,7);g.fill()}
   if(d==='stripes3'){g.fillStyle='#fff';for(let k=-1;k<=1;k++)g.fillRect(-r*1.3,k*r*.45-r*.1,r*2.6,r*.22)}
   g.restore()})},512,512,true)}

function hairParts(spec){const c=spec.hair,hs=1.25,t=hs/2,out=[];
  const B=(off,size,col,rot)=>out.push({p:['box'],off,size,color:col||c,rot});
  switch(spec.hairStyle){
  case'bald':break;
  case'short':B([0,t-.02,0],[hs+.1,.34,hs+.1]);B([0,.05,-t+.05],[hs+.1,hs*.9,.3]);B([0,t-.17,t-.02],[hs+.06,.16,.16]);break;
  case'spiky':B([0,t-.02,0],[hs+.1,.3,hs+.1]);for(let i=-2;i<=2;i++)B([i*.26,t+.3+(i%2?0:.08),.05],[.22,.5,.3+(Math.abs(i)<2?.5:0)],c,[0,0,i*.1]);B([0,.05,-t+.05],[hs+.1,hs*.85,.3]);B([0,t-.16,t-.03],[hs+.06,.14,.14]);break;
  case'messy':B([0,t-.02,0],[hs+.12,.36,hs+.12]);B([-.45,t+.2,.1],[.4,.4,.5],c,[0,0,.3]);B([.4,t+.25,-.1],[.4,.45,.5],c,[0,0,-.35]);B([0,.05,-t+.05],[hs+.1,hs*.9,.3]);break;
  case'long':B([0,t-.02,0],[hs+.12,.36,hs+.12]);B([0,-.45,-t-.02],[hs+.12,2.1,.34]);B([-t-.06,-.35,0],[.22,1.9,hs*.7]);B([t+.06,-.35,0],[.22,1.9,hs*.7]);B([0,t-.4,t],[hs+.1,.25,.2]);break;
  case'bob':B([0,t-.02,0],[hs+.12,.36,hs+.12]);B([0,-.2,-t-.02],[hs+.12,1.2,.34]);B([-t-.06,-.1,0],[.22,1.0,hs*.8]);B([t+.06,-.1,0],[.22,1.0,hs*.8]);B([0,t-.4,t],[hs+.1,.25,.2]);break;
  case'bun':B([0,t-.02,0],[hs+.1,.32,hs+.1]);B([0,.05,-t+.05],[hs+.1,hs*.9,.3]);out.push({p:['sphere'],off:[0,t+.45,-.25],size:[.7,.7,.7],color:c});break;
  case'afro':out.push({p:['sphere'],off:[0,.3,-.1],size:[2.0,1.9,2.0],color:c});break;
  case'side':B([0,t-.02,0],[hs+.1,.3,hs+.1]);B([-.35,.12,t-.02],[.48,.52,.38],c,[0,0,.28]);B([0,.05,-t+.05],[hs+.1,hs*.9,.3]);break;
  case'cap':B([0,t,0],[hs+.12,.45,hs+.12],spec.hat||'#e84a4a');B([0,t-.12,t+.4],[hs-.1,.12,.8],spec.hat||'#e84a4a');B([0,.05,-t+.05],[hs+.08,.45,.25],c);break;
  }return out}
function accParts(spec){const out=[],hs=1.25,t=hs/2;const acc=spec.accessory||[];
  const B=(off,size,col,extra)=>out.push(Object.assign({p:['box'],off,size,color:col},extra||{}));
  const head=[],torso=[];
  for(const a of acc){
    if(S.AccExtra&&S.AccExtra[a]){S.AccExtra[a](head,torso,spec);continue}
    if(a==='glasses'){head.push({p:['box'],off:[0,.05,t+.03],size:[.42,.05,.04],color:'#15151a'},{p:['box'],off:[-.3,.05,t+.04],size:[.46,.4,.04],color:'#2a2f3a',alpha:.55},{p:['box'],off:[.3,.05,t+.04],size:[.46,.4,.04],color:'#2a2f3a',alpha:.55},{p:['box'],off:[-.3,.27,t+.05],size:[.52,.05,.05],color:'#15151a'},{p:['box'],off:[.3,.27,t+.05],size:[.52,.05,.05],color:'#15151a'},{p:['box'],off:[-.3,-.15,t+.05],size:[.52,.05,.05],color:'#15151a'},{p:['box'],off:[.3,-.15,t+.05],size:[.52,.05,.05],color:'#15151a'})}
    if(a==='sunglasses')head.push({p:['box'],off:[0,.1,t+.04],size:[1.05,.3,.08],color:'#0b0b10'});
    if(a==='tophat'){head.push({p:['cyl'],off:[0,t+.45,0],size:[1.1,.9,1.1],color:'#151520'},{p:['cyl'],off:[0,t+.02,0],size:[1.7,.1,1.7],color:'#151520'},{p:['cyl'],off:[0,t+.2,0],size:[1.12,.18,1.12],color:'#c8232c'})}
    if(a==='crown')head.push({p:['cyl'],off:[0,t+.2,0],size:[1.0,.4,1.0],color:'#ffd23a',emis:.2},{p:['cone',6],off:[0,t+.5,0],size:[.3,.3,.3],color:'#ffd23a',emis:.2});
    if(a==='headband')head.push({p:['box'],off:[0,.25,0],size:[hs+.12,.2,hs+.12],color:'#e84a4a'});
    if(a==='mustache')head.push({p:['box'],off:[0,-.1,t+.05],size:[.6,.1,.08],color:spec.beard||'#2a1a10'});
    if(a==='headphones'){head.push({p:['box'],off:[0,t+.05,0],size:[hs+.3,.12,.18],color:'#222'},{p:['box'],off:[-t-.12,0,0],size:[.25,.6,.55],color:'#e84a4a'},{p:['box'],off:[t+.12,0,0],size:[.25,.6,.55],color:'#e84a4a'})}
    if(a==='tie')torso.push({p:['box'],off:[0,1.25,.52],size:[.28,1.2,.05],color:'#c8232c'});
    if(a==='sash')torso.push({p:['box'],off:[0,1,.52],size:[.5,2.5,.06],color:'#d8232c',rot:[0,0,.65]});
    if(a==='backpack')torso.push({p:['box'],off:[0,1.1,-.75],size:[1.4,1.6,.5],color:'#e8553a'});
    if(a==='cape')torso.push({p:['box'],off:[0,.9,-.6],size:[1.9,2.3,.1],color:'#d8232c',rot:[.12,0,0]});
    if(a==='scarf')torso.push({p:['box'],off:[0,1.95,0],size:[2.1,.35,1.1],color:'#e84a4a'});
  }
  if(spec.beard)head.push({p:['box'],off:[0,-.5,t-.15],size:[hs-.2,.3,.4],color:spec.beard},{p:['box'],off:[-t+.05,-.2,t-.3],size:[.12,.7,.3],color:spec.beard},{p:['box'],off:[t-.05,-.2,t-.3],size:[.12,.7,.3],color:spec.beard});
  return {head,torso}}

class Character{
  constructor(id,spec){this.id=id;this.setSpec(spec)}
  setSpec(spec){const base=spec&&spec.preset?PRESETS[spec.preset]:{};this.spec=Object.assign({skin:'#f4c9a1',hair:'#4b2d14',hairStyle:'short',shirt:'#2f6df6',pants:'#243a73',shoes:'#f2f2f2',decal:'none',face:'smile',sleeves:'short',scale:1,jacket:false},base,spec||{});this.build()}
  build(){const s=this.spec,sk=s.skin,P=[];
    const torso=[{p:['box'],off:[0,1,0],size:[2,2,1],color:s.shirt}];
    if(s.jacket){torso.push({p:['box'],off:[0,1,.505],size:[.7,1.95,.02],color:'#f2f2f2'},{p:['box'],off:[0,.0,0],size:[2.04,.3,1.04],color:'#c9a24a'});}
    if(s.decal&&s.decal!=='none')torso.push({decal:s.decal,p:['quad'],off:[0,1.15,.512],size:[1.1,1.1,1],color:'#ffffff',noShadow:true});
    const acc=accParts(s);torso.push(...acc.torso);
    const head=[{p:['roundbox',4],off:[0,.65,0],size:[1.25,1.25,1.25],color:sk},{face:true,p:['quad'],off:[0,.65,.629],size:[1.0,1.0,1],color:'#fff',noShadow:true}];
    for(const h of hairParts(s))head.push(Object.assign({},h,{off:[h.off[0],h.off[1]+.65,h.off[2]]}));
    for(const h of acc.head)head.push(Object.assign({},h,{off:[h.off[0],h.off[1]+.65,h.off[2]]}));
    const sl=s.sleeves==='long'?1.35:.75;
    const mkArm=()=>[{p:['box'],off:[0,-sl/2+.05,0],size:[1,sl,1],color:s.shirt},{p:['box'],off:[0,-sl-(2-sl-.05)/2+.05,0],size:[.96,2-sl-.05+.0,.96],color:sk}];
    const leg=()=>[{p:['box'],off:[0,-.8,0],size:[1,1.6,1],color:s.pants},{p:['box'],off:[0,-1.8,.04],size:[1.04,.4,1.1],color:s.shoes}];
    this.parts={torso,head,armL:mkArm(),armR:mkArm(),legL:leg(),legR:leg()};
  }
  /* iterate parts with transforms; emit(item, matrix) */
  walk(rootM,pose,emit){const p=pose,P=this.parts,sc=this.spec.scale||1;
    const root=M.chain(rootM,M.S(sc),M.T(0,2,0),M.Rx(p.lean||0),M.Rz(p.roll||0),M.T(0,-2,0),M.T(0,p.bodyY||0,0),M.S(p.sx,p.sy,p.sz));
    const hip=M.chain(root,M.T(0,2,0),M.Rx(p.torsoX),M.Ry(p.torsoY),M.Rz(p.torsoZ));
    const grp=(items,m)=>{for(const it of items)emit(it,m)};
    grp(P.torso,hip);
    const neck=M.chain(hip,M.T(0,2,0),M.Rx(p.headX),M.Ry(p.headY),M.Rz(p.headZ));grp(P.head,neck);
    const armLM=M.chain(hip,M.T(1.5,1.9,0),M.Rx(-p.lArmX),M.Rz(p.lArmZ)),armRM=M.chain(hip,M.T(-1.5,1.9,0),M.Rx(-p.rArmX),M.Rz(-p.rArmZ));
    grp(P.armL,armLM);grp(P.armR,armRM);
    grp(P.legL,M.chain(root,M.T(.5,2,0),M.Rx(-p.lLegX),M.Rz(p.lLegZ)));
    grp(P.legR,M.chain(root,M.T(-.5,2,0),M.Rx(-p.rLegX),M.Rz(-p.rLegZ)));
    return {root,hip,neck,armLM,armRM}}
  /* dynamic draw: push items to out.dyn */
  draw(R,rootM,pose,face,out,alpha=1,tint=null,dist=0){
    const ft=faceTex(R),dt=decalTex(R),fi=FACES.indexOf(face||this.spec.face),f=fi<0?0:fi;
    const frames=this.walk(rootM,pose,(it,m)=>{
      const mm=it.off?M.chain(m,M.T(...it.off),it.rot?M.chain(M.Rx(it.rot[0]),M.Ry(it.rot[1]),M.Rz(it.rot[2])):M.ident()):m;
      const o={mesh:R.primMesh(...it.p),model:mm,size:it.size,color:tint?S.mix(it.color,tint[0],tint[1]):hex(it.color),emis:it.emis||0,noShadow:it.noShadow,dist};
      if(it.face){o.tex=ft;o.uv=[(f%4)/4,1-(Math.floor(f/4)+1)/6,.25,1/6];o.color=[1,1,1];o.unlit=false}
      else if(it.decal){const di=DECALS.indexOf(it.decal);o.tex=dt;o.uv=[(di%4)/4,1-(Math.floor(di/4)+1)/4,.25,.25];o.color=[1,1,1]}
      if(it.alpha!==undefined||alpha<1)o.alpha=(it.alpha===undefined?1:it.alpha)*alpha;
      out.push(o)});return frames}
  addToBatch(batch,rootM,pose){this.walk(rootM,pose,(it,m)=>{if(it.face||it.decal)return;
    const mm=it.off?M.chain(m,M.T(...it.off),it.rot?M.chain(M.Rx(it.rot[0]),M.Ry(it.rot[1]),M.Rz(it.rot[2])):M.ident()):m;
    batch.add(S.prim(...it.p),mm,it.size,it.color,it.emis||0)})}
}
function randomSpec(r,o={}){const pick=a=>a[Math.floor(r()*a.length)];
  return Object.assign({skin:pick(SKINS),hair:pick(HAIRC),hairStyle:pick(['short','spiky','messy','long','bob','bun','short','afro']),shirt:pick(CLOTH),pants:pick(['#243a73','#3b3f4a','#5a3a26','#2b6a4f','#6a4bc8','#2f6df6']),shoes:pick(['#fff','#222','#e84a4a']),face:pick(['smile','grin','laugh','cute','neutral']),sleeves:r()<.7?'short':'long',decal:r()<.2?pick(DECALS):'none',scale:.9+r()*.2},o)}
S.Character=Character;S.PRESETS=PRESETS;S.randomSpec=randomSpec;S.FACES=FACES;
})(window.Studio);

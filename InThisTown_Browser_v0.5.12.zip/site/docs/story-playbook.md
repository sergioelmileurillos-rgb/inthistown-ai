# Story playbook — "weird rule in a town"

**Formula (every episode):**
1. **RULE (0–3 s)** – one absurd, visual, rule-like sentence. "In this town, every sneeze teleports you." Show it happening *immediately* to a bystander (demo > explanation).
2. **PROTAGONIST sees the loophole (3–8 s)** – a motivation + a trick. Give him a name, a want (hates walking to school), a prop (pepper).
3. **ESCALATION (8–35 s)** – 3–5 situations, each bigger than the last, each a new location/set + new side character reacting. Comedy engines: abuse (free things), consequences for others, authority notices, over-use.
4. **TWIST (last 8 s)** – flip the rule on the hero: rule bites back / authority uses it better / the rule's origin is revealed / everyone arrives at his place / a new rule cancels the loophole. The last line is a short punchline and shows the irony visually.

**Rules of thumb**
- 55–110 spoken words total. One sentence per scene, ≤ 9 words; mix 2-word punches ("Zero minutes.") with 7-word lines.
- Concrete verbs and numbers; "But", "Until", "Then", "Soon", "Turns out" are momentum words.
- Each scene = new picture: change set, shot size, or character. Reaction close-up after each surprise.
- Visual gags beat explanation: put titles on screen (`NO PEPPER!`, `FREE!`, `1 WEEK LATER`, counters).
- Keep rules consistent: once the rule is established, the twist must use *the same rule* (fair surprise).
- Safe: no real people/brands, no gore; fear = comedic.

**Rule ideas**: sneezing teleports · you must say "sorry" to doors or they lock · the mayor changes gravity every Monday · whoever tells the first lie of the day becomes tiny · every compliment gives you a coin · you can only walk backwards after 8 pm · cats are legally mayors · the loudest person owns the street · yawning is contagious *physically* (people fall asleep) · ...

**Scene checklist (per scene):** vo line · world+sky · who is in it (pos, yaw) · 1–3 actions anchored to words · fx/title if it is a gag · 1–3 camera cuts (≈ one per 1.9 s) · twist scene gets `sky:"red"|"fog"` or music change.

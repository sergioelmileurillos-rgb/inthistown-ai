# In This Town — integration notes

## Base and architecture

- Browser build and procedural WebGL2 engine from the user-supplied Claude v0.5.2/v0.5.4 line.
- Local story generator and word-timing support from the supplied v0.5.0 source.
- `story-plan-adapter.js` converts the authored beat plans into supported actions, object operations, FX, captions and camera cuts.
- `shortform-director.js` and `episode-preflight.js` remain in the browser pipeline.
- Kokoro-82M browser worker remains configured for `am_adam`.

## v0.5.6 changes

The previous version connected authored beat plans to the renderer, but each scene still constructed its objects independently. This meant that a creature or named prop could appear in one scene and be recreated from a default transform in the next.

The scene compiler now exports object end-state alongside actor end-state. The API carries it across scene compilation and restores object position, orientation, scale, alpha, pitch, roll, visibility, spin/bob settings and active attachments. The story preparation stage also keeps semantic object IDs available to later beat plans. Decorative duplicates and temporary hand tools stay local to avoid clutter.

The semantic plan adapter can add one witness reaction when a significant event occurs and a present character has no authored action in that beat. It uses a real clip and supported face from the engine inventory and anchors the reaction to the event word. Face aliases such as `gasp` are mapped to supported atlas entries.

Camera direction authored by the story plan is retained. When the first shot repeats across adjacent scenes in the same set, the browser app chooses a compatible alternate framing. A scene with one authored setup can receive one short object close-up at a meaningful reveal or interaction time.

## Verification and limitations

- 14 automated tests pass.
- Integration corpus: 12 premises × 3 tones.
- The corpus is compiled through the original scene director in fast mode; no missing actor or object references are reported.
- JavaScript syntax checks pass throughout `site/`.
- Word timing remains waveform-informed rather than phoneme-level forced alignment.
- No complete Kokoro + WebGL2 + MediaRecorder export has been verified on the user's actual device.
- The story generator remains local, deterministic and based on rules/archetypes; it is not a cloud LLM or arbitrary 3D asset generator.

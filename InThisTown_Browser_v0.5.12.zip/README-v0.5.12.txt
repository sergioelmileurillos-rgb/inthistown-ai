In This Town Browser v0.5.12

New in this build:
- More reliable visual continuity between narration, props, actors, actions and camera framing.
- Shadow reveals are timed to the spoken word and framed together with the character.
- Separate lamp placements and real on/off illumination changes.
- Custom block-style character workshop with reusable local models.

See site/CHANGELOG-v0.5.12.md for details.

Automated tests pass, but a complete export still needs testing on the target Chromebook.

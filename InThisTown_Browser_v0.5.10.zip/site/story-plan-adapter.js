/* In This Town — semantic story-plan adapter v0.5.5
 * Translates Claude's narrative beat plans into the original WebGL scene schema.
 * Unknown operations are counted and safely ignored; no fictional engine commands are emitted.
 */
(function (G) {
  'use strict';
  const ITT = G.ITT = G.ITT || {};
  const ACTOR_ALIASES = { H:'hero', hero:'hero', N:'neighbor', nbr:'neighbor', neighbor:'neighbor', M:'mayor', mayor:'mayor',
    bot:'bot', robot:'bot', extra1:'extra1', extra2:'extra2', extra3:'extra3' };
  const SETS = {
    facade:{type:'suburb'}, home:{type:'room',kind:'living'}, bedroom:{type:'room',kind:'bedroom'},
    townhall:{type:'townhall'}, park:{type:'park'}, school:{type:'school'}, city:{type:'city'},
    street:{type:'city'}, plaza:{type:'townhall'}, void:{type:'void'}
  };
  const POS = {
    front:[0,0,16], center:[0,0,13], left:[-4.4,0,17], right:[4.4,0,17],
    yardL:[-6.6,0,21], yardR:[6.6,0,21], street:[-10,0,23], streetR:[10,0,23],
    plaza:[0,0,8], plaza2:[-4,0,10], podium:[0,0,2], door:[6,0,12], far:[0,0,27],
    room:[0,0,8], centerRoom:[0,0,8]
  };
  const PROP_ALIASES = {
    door:'door_h', gate:'door_h', winL:'window_h', winR:'window_h', window:'window_h',
    lampL:'lamp_s', lampR:'lamp_s', light:'lamp_s', rulebook:'rulebook', book:'rulebook',
    note:'notepaper', paper:'notepaper', shadow:'shadowfigure', beast:'dragon',
    phone:'phone', speaker:'speaker', mirror:'mirror', box:'chest'
  };
  const SHOTS = new Set(['close','extreme','medium','wide','low','high','over','follow','profile','front','top','pov','dutch','hero','long']);
  const clamp = (n,a,b)=>Math.max(a,Math.min(b,n));
  const FACE_ALIASES={gasp:'shock',surprised:'shock',terrified:'scared',nervous:'worried',happy:'smile',grinning:'grin',laughing:'laugh',suspicious:'sus'};
  function actorId(id) { return ACTOR_ALIASES[String(id||'')] || String(id||''); }
  function faceName(value) {
    const faces=G.Studio?.FACES||['neutral','smile','grin','worried','shock','angry','sad','scared','talk','smirk','evil','terrified','laugh','cry','sleep','blush','sus','proud','cute','dead','dizzy','bored','pout','tongue','love','wink','star','smug','sob'];
    const name=FACE_ALIASES[String(value||'').toLowerCase()]||String(value||'');
    return faces.includes(name)?name:null;
  }
  function anchor(word) {
    if (word === undefined || word === null || word === '') return 0;
    if (typeof word === 'number' && Number.isFinite(word)) return word;
    const s=String(word).trim();
    if (!s) return 0;
    if (/^(?:null|undefined|start|beginning)$/i.test(s)) return 0;
    if (/^(?:back|end)$/i.test(s)) return 'end-0.55';
    if (/^(?:middle|mid)$/i.test(s)) return '50%';
    if (/^\d+(?:\.\d+)?%$/.test(s) || /^end(?:[+-]\d+(?:\.\d+)?)?$/.test(s) || /^w\d+e?(?:[+-]\d+(?:\.\d+)?)?$/.test(s)) return s;
    return '@'+s.replace(/^@/,'');
  }
  function setFor(name, fallback) { return SETS[String(name||'').toLowerCase()] || fallback || {type:'city'}; }
  function collectActors(beats=[]) {
    const out=new Set();
    for (const beat of beats||[]) for (const op of beat.plan||[]) {
      if (!Array.isArray(op)) continue;
      if (op[0]==='cast' && op[1] && typeof op[1]==='object') Object.keys(op[1]).forEach(k=>out.add(actorId(k)));
      if (['anim','expr','face','walk','walkOff','do','hide','show','turnTo','scale','hover'].includes(op[0]) && typeof op[1]==='string') out.add(actorId(op[1]));
      if (op[0]==='state' && typeof op[1]==='string') out.add(actorId(op[1]));
    }
    return [...out].filter(x=>x==='hero'||x==='neighbor'||x==='mayor'||/^extra[1-3]$/.test(x)||x==='bot');
  }
  function placement(scene, actor, spot) {
    const id=actorId(actor), p=POS[String(spot||'front')]||POS.front;
    if (!scene.actors[id]) scene.actors[id]={pos:p.slice(),yawDeg:id==='mayor'?180:0,face:'neutral'};
    else { scene.actors[id].pos=p.slice(); scene.actors[id].yawDeg=(spot==='left'||spot==='yardL'||spot==='street')?25:(spot==='right'||spot==='yardR'||spot==='streetR')?-25:(id==='mayor'?180:0); }
  }
  function propType(name) {
    const key=String(name||'crate');
    if(PROP_ALIASES[key])return PROP_ALIASES[key];
    const resolved=G.Studio?.Assets?.resolveProp?.(key)?.name;
    return resolved || key;
  }
  function ensureObject(scene, id, posHint, explicitType, transition) {
    if (!id) return null;
    if (scene.objects.some(o=>o.id===id)) return id;
    // Reuse the primary generated prop only when the source target clearly denotes it.
    const key=String(id).toLowerCase();
    if (id==='door' && scene.kind==='door' || /^win[lr]$/.test(key) && scene.kind==='vision' || /^(rulebook|book)$/.test(key) && scene.kind==='book') return 'storyProp';
    const type=propType(explicitType||id);
    const p=posHint==='behind'?[-2.5,0,10]:posHint==='left'?[-5.2,0,14]:posHint==='right'?[5.2,0,14]:[4.8,0,14];
    const pos=transition==='rise'?[p[0],-2.6,p[2]]:p;
    scene.objects.push({id,type,pos,yawDeg:0,scale:/dragon|shadowfigure/.test(type)?0.72:0.5,alpha:transition==='fadeIn'?0:1,visible:false,opts:{color:type==='shadowfigure'?'#11111b':'#f3df9b'}});
    return id;
  }
  function resolveTime(value, words, narration, duration) {
    if (value === undefined || value === null || value === '') return 0;
    if (typeof value === 'number' && Number.isFinite(value)) return clamp(value,0,Math.max(0,duration-.03));
    const raw=String(value).trim();
    if (/^(?:null|undefined|start|beginning)$/i.test(raw)) return 0;
    if (/^(?:back|end)$/i.test(raw)) return Math.max(0,duration-.55);
    if (/^(?:middle|mid)$/i.test(raw)) return duration*.5;
    const percent=raw.match(/^(\d+(?:\.\d+)?)%$/); if(percent)return clamp(duration*Number(percent[1])/100,0,Math.max(0,duration-.03));
    const endOffset=raw.match(/^end([+-]\d+(?:\.\d+)?)?$/); if(endOffset)return clamp(duration+(Number(endOffset[1])||0),0,Math.max(0,duration-.03));
    const idx=raw.match(/^w(\d+)(e?)$/); if(idx&&words[Number(idx[1])])return clamp(Number(idx[2]?words[Number(idx[1])].e:words[Number(idx[1])].s)||0,0,Math.max(0,duration-.03));
    const needle=raw.replace(/^@/,'').toLowerCase().replace(/[^a-z0-9']/g,'');
    const norm=x=>String(x||'').toLowerCase().replace(/[^a-z0-9']/g,'');
    let found=(words||[]).find(w=>norm(w.w).startsWith(needle)||needle.startsWith(norm(w.w)));
    if(found)return clamp(Number(found.s)||0,0,Math.max(0,duration-.03));
    const tokens=String(narration||'').match(/[a-z0-9']+/gi)||[];
    const pos=tokens.findIndex(w=>norm(w).startsWith(needle));
    if(pos>=0)return clamp((pos/Math.max(1,tokens.length))*duration,0,Math.max(0,duration-.03));
    return 0;
  }
  function actorAction(scene, id, at, clip, dur, expr) {
    const actor=actorId(id); if (!scene.actors[actor]) return null;
    const face=faceName(expr);
    return {actor,at,do:'anim',clip:String(clip||'idle'),...(Number(dur)>0?{dur:clamp(Number(dur),.18,20)}:{}),...(face?{expr:face}:{}),blend:.12};
  }
  function targetRef(scene, id) {
    const a=actorId(id); if (scene.actors[a]) return {actor:a};
    return {obj:ensureObject(scene,String(id),null)};
  }
  function compileBeat(beat, scene, duration, wordTimings=[]) {
    const actions=[], unsupported={}, used=[]; let reactions=0;
    const plan=Array.isArray(beat?.plan)?beat.plan:[];
    const eventAt=word=>resolveTime(word,wordTimings,scene.vo,duration);
    // Apply the authored cast/blocking before the timeline is compiled.
    for (const op of plan) if (Array.isArray(op) && op[0]==='cast' && op[1] && typeof op[1]==='object') {
      for (const [who,where] of Object.entries(op[1])) if (ACTOR_ALIASES[who] || /^extra[1-3]$/.test(who)) placement(scene,who,where);
    }
    for (const op of plan) {
      if (!Array.isArray(op)||!op.length) continue;
      const [kind,...a]=op;
      let emitted=false;
      if (kind==='cast') { emitted=true; }
      else if (kind==='anim') {
        const clip=String(a[1]||'idle');
        const available=G.Studio?.Anim?.clips;
        const isClip=!available||!!available[clip];
        const face=faceName(a[4])||faceName(clip);
        if(isClip){const item=actorAction(scene,a[0],eventAt(a[2]),clip,a[3],face);if(item){actions.push(item);emitted=true;}}
        else if(face){const id=actorId(a[0]);if(scene.actors[id]){actions.push({actor:id,at:eventAt(a[2]),do:'expr',face});emitted=true;}}
      } else if (kind==='expr') {
        const id=actorId(a[0]),face=faceName(a[1]); if(scene.actors[id]&&face){actions.push({actor:id,at:eventAt(a[2]),do:'expr',face});emitted=true;}
      } else if (kind==='walk' || kind==='walkOff') {
        const id=actorId(a[0]), dest=kind==='walk'?a[1]:a[1];
        const p=POS[String(dest||'center')] || (kind==='walkOff'?[dest==='street'?-16:16,0,25]:POS.center);
        if(scene.actors[id]){const time=kind==='walk'?a[2]:null, dur=kind==='walk'?a[3]:1.1, clip=kind==='walk'&&a[4]==='run'?'run':'walk';
          actions.push({actor:id,at:eventAt(time),do:clip==='run'?'runTo':'walkTo',to:p,dur:clamp(Number(dur)||1.1,.25,8),anim:clip,path:'straight',speed:clip==='run'?8:5});emitted=true;}
      } else if (kind==='do') {
        const id=actorId(a[0]), verb=String(a[1]||''), target=ensureObject(scene,String(a[2]||'storyProp'));
        if(scene.actors[id]){
          const at=eventAt(a[3]);
          const clip=({open:'useObject',close:'useObject',peek:'peek',pickup:'pickup',push:'push',pull:'push',switch:'useObject',switchOn:'useObject',switchOff:'useObject',press:'useObject',read:'read',talk:'talk',wave:'wave_big',knock:'knock'})[verb]||'useObject';
          actions.push({actor:id,at,do:'anim',clip,dur:1.0,blend:.1});
          actions.push({actor:id,at,do:'turn',to:target,dur:.2});
          if(verb==='open'||verb==='close'){
            const typ=scene.objects.find(o=>o.id===target)?.type||'';
            if(/door|window/.test(typ))actions.push({obj:target,at,do:'yawTo',to:verb==='open'?72:0,deg:true,dur:.42,ease:'inout'});
            else if(/book/.test(typ))actions.push({obj:target,at,do:'pitchTo',to:verb==='open'?.28:0,dur:.34,ease:'out'});
            else actions.push({obj:target,at,do:'scaleTo',to:1.08,dur:.24,ease:'back'});
          } else if(verb==='pickup') actions.push({obj:target,at,do:'attach',actor:id,bone:'handR',off:[0,0,.1],until:'end-0.08'});
          else if(verb==='switchOn')actions.push({obj:target,at:at+.08,do:'scaleTo',to:1.08,dur:.25,ease:'out'},{do:'fx',kind:'pulse',on:target,at:at+.08,dur:.55});
          if(verb==='switchOff')actions.push({obj:target,at,do:'hide'});
          else actions.push({obj:target,at,do:'show'}); emitted=true;
        }
      } else if (kind==='state') {
        const id=String(a[0]||''), state=String(a[1]||''), at=eventAt(a[2]), ref=targetRef(scene,id);
        if(ref.actor){
          if(state==='wave')actions.push({actor:ref.actor,at,do:'anim',clip:'wave_big',dur:Number(a[3])||1});
          else if(state==='hide')actions.push({actor:ref.actor,at,do:'hide'});
          else if(state==='show')actions.push({actor:ref.actor,at,do:'show'});
          emitted=true;
        } else {
          const obj=ref.obj; actions.push({obj,at,do:'show'});
          if(state==='open'||state==='wave')actions.push({obj,at,do:'yawTo',to:state==='open'?68:18,deg:true,dur:.4});
          else if(state==='off'||state==='hide')actions.push({obj,at,do:'hide'});
          else if(state==='on'||state==='light')actions.push({obj,at,do:'scaleTo',to:1.12,dur:.35});
          emitted=true;
        }
      } else if (kind==='obj') {
        // Format: ['obj', id, propType, spokenWord, transition]. The spoken word
        // anchors the appearance; it is not a spatial position.
        const id=String(a[0]||'prop'), transition=String(a[3]||'appear');
        const at=eventAt(a[2]), posHint=['behind','left','right'].includes(String(a[2]))?String(a[2]):null, target=ensureObject(scene,id,posHint,a[1],transition);
        actions.push({obj:target,at,do:'show'});
        if(transition==='fadeIn') actions.push({obj:target,at,do:'fadeTo',to:1,dur:.58,ease:'out'});
        else if(transition==='rise') {
          const o=scene.objects.find(x=>x.id===target), p=o?.pos||[4.8,-2.6,14];
          actions.push({obj:target,at,do:'moveTo',to:[p[0],0,p[2]],dur:.82,ease:'out'});
        }
        emitted=true;
      } else if (kind==='hide'||kind==='show') {
        const ref=targetRef(scene,a[0]); actions.push(ref.actor?{actor:ref.actor,at:eventAt(a[1]),do:kind}:{obj:ref.obj,at:eventAt(a[1]),do:kind});emitted=true;
      } else if (kind==='face') {
        const who=actorId(a[0]); if(scene.actors[who] && String(a[1]||'camera')==='camera'){actions.push({actor:who,at:eventAt(a[2]),do:'turn',yawDeg:0,dur:.25});emitted=true;}
      } else if (kind==='hover') {
        const who=actorId(a[0]); if(scene.actors[who]){actions.push({actor:who,at:eventAt(a[2]),do:'hover',to:clamp(Number(a[1])||3,1,8),dur:.6});emitted=true;}
      } else if (kind==='turnTo') {
        const who=actorId(a[0]), target=actorId(a[1]); if(scene.actors[who]){const targetRefId=scene.actors[target]?target:ensureObject(scene,String(a[1]));actions.push({actor:who,at:eventAt(a[2]),do:'turn',to:targetRefId,dur:.22});emitted=true;}
      } else if (kind==='scale') {
        const ref=targetRef(scene,a[0]), value=clamp(Number(a[1])||1,.12,2.2), at=eventAt(a[2]);
        actions.push(ref.actor?{actor:ref.actor,at,do:'grow',to:value,dur:clamp(Number(a[3])||.6,.2,3)}:{obj:ref.obj,at,do:'scaleTo',to:value,dur:clamp(Number(a[3])||.6,.2,3)});emitted=true;
      } else if (kind==='fx') {
        const fxKind=String(a[0]||'sparkle'), inventory=G.Studio?.Fx?.GEN;
        if(!inventory || inventory[fxKind]) {
          const target=a[1], ref=target?targetRef(scene,target):null;
          actions.push({do:'fx',kind:fxKind,...(ref?(ref.actor?{on:ref.actor}:{on:ref.obj}):{}),at:eventAt(a[2]),dur:.8});emitted=true;
        }
      } else if (kind==='sfx') { actions.push({do:'sfx',name:String(a[0]||'pop'),at:eventAt(a[1]),vol:.55});emitted=true; }
      else if (kind==='text') { actions.push({do:'text',text:String(a[0]||''),at:eventAt(a[1]),dur:clamp(Number(a[2])||1.4,.3,4),style:a[3]==='title'?'title':'pop',size:a[3]==='title'?.9:2.6});emitted=true; }
      else if (kind==='shake') { actions.push({do:'shake',at:eventAt(a[0]),dur:clamp(Number(a[1])||.35,.1,1.5),amp:clamp(Number(a[2])||.35,.1,1.1)});emitted=true; }
      else if (kind==='flash') { actions.push({do:'flash',at:eventAt(a[0]),dur:clamp(Number(a[1])||.25,.1,1),amount:.55});emitted=true; }
      else if (kind==='hook') { actions.push({do:'title',text:'ONE RULE. NO EXCEPTIONS.',at:0,dur:1.05,size:.9,style:'title'});emitted=true; }
      if (emitted) used.push(kind); else unsupported[kind]=(unsupported[kind]||0)+1;
    }
    // Add one restrained witness reaction when a meaningful visual event occurs.
    // This fills a common gap in authored plans without overriding a character's
    // explicitly written performance.
    const text=String(scene.vo||beat?.vo||'');
    const lower=text.toLowerCase();
    const cueMatch=lower.match(/\b(suddenly|instantly|appeared|rose|screamed|shook|exploded|disappeared|vanished|revealed|realized|discovered|truth|secret|finally|worked|succeeded|laughed|ridiculous)\b/);
    const hasVisualEvent=plan.some(op=>Array.isArray(op)&&['do','obj','state','scale','shake','flash'].includes(op[0]));
    const explicitlyAnimated=new Set();
    for(const op of plan)if(Array.isArray(op)&&['anim','expr','face','walk','walkOff','do','state','turnTo','scale','hover'].includes(op[0])&&typeof op[1]==='string')explicitlyAnimated.add(actorId(op[1]));
    const primary=([...explicitlyAnimated].find(id=>id==='hero')||[...explicitlyAnimated][0]||'hero');
    const witness=['neighbor','mayor','bot','extra1','extra2','extra3'].find(id=>scene.actors?.[id]&&!explicitlyAnimated.has(id));
    if(witness&&hasVisualEvent&&cueMatch&&duration>=.8){
      const cue=cueMatch[1];
      const mood=/suddenly|instantly|appeared|rose|shook|exploded|disappeared|vanished|screamed/.test(cue)?'fear':/truth|secret|revealed|realized|discovered/.test(cue)?'reveal':/laughed|ridiculous/.test(cue)?'funny':'success';
      const response={fear:{clip:'jumpscare',face:'scared'},reveal:{clip:'shock',face:'shock'},funny:{clip:'laugh',face:'laugh'},success:{clip:'curious',face:'grin'}}[mood];
      const inventory=G.Studio?.Anim?.clips,clip=inventory&&!inventory[response.clip]?(inventory.shock?'shock':'lookAround'):response.clip;
      const targetOp=plan.find(op=>Array.isArray(op)&&((op[0]==='obj')||(op[0]==='do')||(op[0]==='state')));
      const target=targetOp?(targetOp[0]==='obj'?String(targetOp[1]):targetOp[0]==='do'?String(targetOp[2]||primary):String(targetOp[1])):primary;
      const at=eventAt(cueMatch[1]);
      actions.push({actor:witness,at,do:'turn',to:target,dur:.2});
      actions.push({actor:witness,at:Math.min(Math.max(0,at+.04),Math.max(0,duration-.2)),do:'anim',clip,dur:clamp(duration*.34,.42,1.05),expr:response.face,blend:.14});
      reactions++;
    }
    const cams=[];
    for(const c of beat?.cam||[]) {
      if(!Array.isArray(c)||!c.length)continue;
      const shot=SHOTS.has(c[0])?c[0]:'medium';
      const opts=c[2]&&typeof c[2]==='object'?c[2]:{};
      let focus=Array.isArray(c[1])?c[1]:[c[1]||'hero'];
      focus=focus.map(x=>{const a=actorId(x);return scene.actors[a]?a:(scene.objects.some(o=>o.id===x)?x:scene.actors.hero?'hero':scene.objects[0]?.id||'hero')});
      const cam={...opts,at:eventAt(opts.at),shot,on:focus.length===1?focus[0]:focus};
      if(cam.move && !['push','pull','orbit','crane','dolly','zoom','rise','drift','whip','dutch'].includes(cam.move))delete cam.move;
      cams.push(cam);
    }
    return {actions,cams,used,unsupported,reactions,sourceOps:plan.length,coverage:plan.length?used.length/plan.length:0};
  }
  ITT.PlanAdapter={version:'0.5.5',actorId,anchor,resolveTime,setFor,collectActors,compileBeat};
  if(typeof module!=='undefined'&&module.exports)module.exports=ITT.PlanAdapter;
})(typeof window!=='undefined'?window:globalThis);

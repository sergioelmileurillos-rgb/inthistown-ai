const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const vm = require('node:vm');

function loadDirector(){
  const Studio={
    V:{},M:{},clamp:(n,a,b)=>Math.max(a,Math.min(b,n)),lerp:(a,b,t)=>a+(b-a)*t,
    ease:(name,t)=>t,hex:x=>x,mix:(a,b,t)=>a,rng:()=>()=>.5,env:()=>({}),
    Character:class Character{constructor(id,spec){this.id=id;this.spec=spec||{};}}
  };
  const sandbox={window:{Studio},console,Math,Set,Map,Object,Array,Number,String,Boolean,RegExp,Float32Array};
  sandbox.window.window=sandbox.window;
  vm.runInNewContext(fs.readFileSync(path.join(__dirname,'..','engine/director.js'),'utf8'),sandbox,{filename:'engine/director.js'});
  return Studio.Director;
}

function loadEngineApi(){
  const Studio={
    V:{},M:{},clamp:(n,a,b)=>Math.max(a,Math.min(b,n)),lerp:(a,b,t)=>a+(b-a)*t,
    ease:(name,t)=>t,hex:x=>x,mix:(a,b,t)=>a,rng:()=>()=>.5,env:()=>({}),
    Character:class Character{constructor(id,spec){this.id=id;this.spec=spec||{};}},
    prim:()=>({}),
    Renderer:class Renderer{constructor(canvas){this.canvas=canvas;this.gl={getParameter:()=> 'mock-webgl2'};}uploadPrim(){return{};}free(){}}
  };
  const sandbox={window:{Studio},document:{getElementById:()=>({})},console,Math,Set,Map,Object,Array,Number,String,Boolean,RegExp,Float32Array};
  sandbox.window.window=sandbox.window;
  for(const file of ['engine/director.js','engine/api.js'])
    vm.runInNewContext(fs.readFileSync(path.join(__dirname,'..',file),'utf8'),sandbox,{filename:file});
  return Studio;
}

test('semantic props keep their transform and visibility across scene cuts',()=>{
  const Director=loadDirector();
  const story={seed:10,characters:{hero:{}},defaults:{world:[{type:'city'}]}};
  const first={
    id:'one',dur:2,actors:{hero:{pos:[0,0,16]}},
    objects:[{id:'beast',type:'dragon',pos:[4,0,12],scale:.7,visible:false}],
    actions:[
      {obj:'beast',at:.1,do:'show'},
      {obj:'beast',at:.2,do:'moveTo',to:[7,0,15],dur:.8},
      {obj:'beast',at:.2,do:'yawTo',to:90,deg:true,dur:.8},
      {obj:'beast',at:1.1,do:'scaleTo',to:1.1,dur:.3}
    ],cam:[{at:0,shot:'wide',on:'hero'}]
  };
  const one=Director.compileScene(null,story,first,{fast:true});
  const state=one.endObjects.beast;
  assert.ok(state);
  assert.equal(state.visible,true);
  assert.ok(Math.abs(state.pos[0]-7)<.01);
  assert.ok(Math.abs(state.pos[2]-15)<.01);
  assert.ok(Math.abs(state.yaw-Math.PI/2)<.01);
  assert.ok(Math.abs(state.scale-1.1)<.01);

  const second={id:'two',dur:1.5,carryAllObjects:true,actors:{hero:{pos:[0,0,16]}},objects:[],actions:[],cam:[{at:0,shot:'medium',on:'hero'}]};
  const two=Director.compileScene(null,story,second,{fast:true,prevEnd:one.end,prevObjects:one.endObjects});
  assert.ok(two.objects.beast,'the previous object should be restored automatically');
  assert.deepEqual(Array.from(two.objects.beast.pos.eval(0)),Array.from(state.pos));
  assert.ok(Math.abs(two.objects.beast.yaw.eval(0)-state.yaw)<.001);
  assert.equal(two.objects.beast.vis[0].v,true);
  assert.equal(two.endObjects.beast.type,'dragon');
});


test('scene API carries the same object state when compiling the following beat',()=>{
  const Studio=loadEngineApi();
  Studio.api.init(576,1024,{});
  const story={seed:10,characters:{hero:{}},defaults:{world:[{type:'city'}]},scenes:[
    {id:'one',dur:2,actors:{hero:{pos:[0,0,16]}},objects:[{id:'shadow',type:'shadowfigure',pos:[-2,0,10],visible:false}],actions:[{obj:'shadow',at:.2,do:'show'},{obj:'shadow',at:.3,do:'moveTo',to:[3,0,8],dur:.7}],cam:[{at:0,shot:'wide',on:'hero'}]},
    {id:'two',dur:1.5,carryAllObjects:true,actors:{hero:{pos:[0,0,16]}},objects:[],actions:[{obj:'shadow',at:.2,do:'yawTo',to:35,deg:true,dur:.3}],cam:[{at:0,shot:'medium',on:'hero'}]}
  ]};
  Studio.api.setStory(story);
  const first=Studio.api.compile(0,{fast:true});
  const second=Studio.api.compile(1,{fast:true});
  assert.ok(second.startObjects.shadow);
  assert.ok(Math.abs(second.startObjects.shadow.pos[0]-3)<.01);
  assert.ok(Math.abs(second.startObjects.shadow.pos[2]-8)<.01);
  assert.ok(Math.abs(second.endObjects.shadow.yaw-35*Math.PI/180)<.01);
});

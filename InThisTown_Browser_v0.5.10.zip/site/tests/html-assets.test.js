const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const root = path.join(__dirname,'..');
const html = fs.readFileSync(path.join(root,'index.html'),'utf8');
const app = fs.readFileSync(path.join(root,'app.js'),'utf8');

test('all app controls exist in the page and all integrated modules are loaded',()=>{
  const ids=new Set([...html.matchAll(/id="([^"]+)"/g)].map(x=>x[1]));
  const used=new Set([...app.matchAll(/\$\('([^']+)'\)/g)].map(x=>x[1]));
  for(const id of used)assert.ok(ids.has(id),'Missing HTML element: '+id);
  for(const file of ['engine/assets.js','story-engine.js','story-plan-adapter.js','shortform-director.js','episode-preflight.js','timing.js','sfx.js']){
    assert.ok(html.includes(`src="${file}"`),'Module not loaded: '+file);
    assert.ok(fs.existsSync(path.join(root,file)),'Module missing from package: '+file);
  }
});

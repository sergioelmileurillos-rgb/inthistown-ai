const test = require('node:test');
const assert = require('node:assert/strict');
const Adapter = require('../story-plan-adapter.js');

global.Studio = {
  Anim: { clips: Object.fromEntries(['idle','lookAround','useObject','peek','pickup','walk','run','wave','dance'].map(x=>[x,true])) },
  FACES: ['neutral','worried','smirk','shock'],
  Fx: { GEN: { sparkle:true, pulse:true, smoke:true, explosion:true, dust:true, poof:true } }
};

test('semantic plan becomes native actor, prop, FX and word-timed camera events', () => {
  const scene = {
    id:'s1', vo:'Max opened the door. Suddenly a shadow appeared behind Max. The secret was out.', kind:'door',
    actors:{hero:{pos:[0,0,16]},neighbor:{pos:[-5,0,19]}},
    objects:[{id:'storyProp',type:'door_h',pos:[3,0,16],visible:true}],
  };
  const beat = {
    plan:[
      ['cast',{hero:'front',nbr:'yardL',extra1:'street'}],
      ['anim','hero','lookAround','Max',1.1,'worried'],
      ['anim','nbr','worried',null,0,'worried'],
      ['do','hero','open','door','opened'],
      ['obj','shadow','shadowfigure','behind','fadeIn'],
      ['turnTo','hero','shadow','shadow'],
      ['fx','dust','hero','Suddenly'],
      ['sfx','pop','opened'],
      ['text','TOP SECRET','secret',1.4,'title'],
      ['shake','Suddenly',.3,.4],
    ],
    cam:[
      ['close',['hero'],{az:6,move:'push',amount:.2}],
      ['wide',['hero','shadow'],{at:'back',az:14,move:'pull',amount:.2}],
    ]
  };
  const words=[
    {w:'Max',s:.1,e:.25},{w:'opened',s:.3,e:.6},{w:'the',s:.61,e:.7},{w:'door',s:.71,e:.9},
    {w:'Suddenly',s:1.1,e:1.4},{w:'a',s:1.41,e:1.48},{w:'shadow',s:1.5,e:1.8},{w:'appeared',s:1.81,e:2.1},{w:'behind',s:2.11,e:2.28},{w:'Max',s:2.29,e:2.4},
    {w:'The',s:2.2,e:2.3},{w:'secret',s:2.31,e:2.6},{w:'was',s:2.61,e:2.7},{w:'out',s:2.71,e:2.85}
  ];
  const out=Adapter.compileBeat(beat,scene,3,words);
  assert.ok(out.actions.length>=8);
  assert.ok(out.actions.every(x=>Number.isFinite(x.at)&&x.at>=0&&x.at<3));
  assert.ok(out.actions.some(x=>x.obj==='storyProp'&&x.do==='yawTo'));
  assert.ok(out.actions.some(x=>x.actor==='hero'&&x.do==='turn'&&x.to==='shadow'));
  assert.ok(out.actions.some(x=>x.do==='fx'&&x.kind==='dust'));
  const shadow=scene.objects.find(x=>x.id==='shadow');
  assert.ok(shadow&&shadow.type==='shadowfigure');
  assert.equal(shadow.alpha,0);
  assert.deepEqual(shadow.pos,[-2.5,0,10]);
  assert.ok(out.actions.some(x=>x.obj==='shadow'&&x.do==='fadeTo'&&Math.abs(x.at-2.11)<.01));
  assert.ok(scene.actors.extra1);
  assert.equal(out.cams.length,2);
  assert.ok(out.cams.every(x=>Number.isFinite(x.at)));
  assert.ok(out.cams[1].at>out.cams[0].at);
});

test('set mappings and actor aliases stay inside supported engine inventory', () => {
  assert.deepEqual(Adapter.setFor('facade'),{type:'suburb'});
  assert.deepEqual(Adapter.setFor('bedroom'),{type:'room',kind:'bedroom'});
  assert.equal(Adapter.actorId('nbr'),'neighbor');
  assert.ok(Adapter.collectActors([{plan:[['cast',{hero:'front',nbr:'yardL',extra2:'street'}]]}]).includes('extra2'));
});

test('object appearance, rise, camera-facing gesture and switch-off use correct engine semantics', () => {
  const scene={
    vo:'The shadow appeared behind us. The dragon rose. Max looked at the camera. Then the lamp went dark.',
    actors:{hero:{pos:[0,0,16]}},objects:[]
  };
  const words=[
    {w:'The',s:0,e:.1},{w:'shadow',s:.1,e:.35},{w:'appeared',s:.36,e:.6},{w:'behind',s:.61,e:.78},
    {w:'us',s:.79,e:.9},{w:'The',s:.95,e:1},{w:'dragon',s:1.01,e:1.25},{w:'rose',s:1.26,e:1.48},
    {w:'Max',s:1.5,e:1.65},{w:'looked',s:1.66,e:1.84},{w:'at',s:1.85,e:1.9},{w:'the',s:1.91,e:2},{w:'camera',s:2.01,e:2.25},
    {w:'Then',s:2.3,e:2.42},{w:'the',s:2.43,e:2.5},{w:'lamp',s:2.51,e:2.7},{w:'went',s:2.71,e:2.83},{w:'dark',s:2.84,e:3}
  ];
  const out=Adapter.compileBeat({plan:[
    ['obj','shadow','shadowfigure','behind','fadeIn'],
    ['obj','beast','dragon','rose','rise'],
    ['face','hero','camera','camera'],
    ['do','hero','switchOff','lampL','dark']
  ]},scene,3.2,words);
  const shadow=scene.objects.find(x=>x.id==='shadow'),beast=scene.objects.find(x=>x.id==='beast');
  assert.equal(shadow.alpha,0);
  assert.deepEqual(shadow.pos,[-2.5,0,10]);
  assert.equal(shadow.type,'shadowfigure');
  assert.equal(beast.type,'dragon');
  assert.equal(beast.pos[1],-2.6);
  assert.ok(out.actions.some(x=>x.obj==='shadow'&&x.do==='fadeTo'&&Math.abs(x.at-.61)<.01));
  assert.ok(out.actions.some(x=>x.obj==='beast'&&x.do==='moveTo'&&Math.abs(x.at-1.26)<.01));
  assert.ok(out.actions.some(x=>x.actor==='hero'&&x.do==='turn'&&x.yawDeg===0&&Math.abs(x.at-2.01)<.01));
  assert.ok(out.actions.some(x=>x.obj==='lampL'&&x.do==='hide'&&Math.abs(x.at-2.84)<.01));
  assert.ok(!out.actions.some(x=>x.obj==='lampL'&&x.do==='show'));
  assert.deepEqual(out.unsupported,{});
});

test('unknown plan operations are reported instead of emitting invented commands', () => {
  const scene={vo:'A strange event.',actors:{hero:{pos:[0,0,16]}},objects:[]};
  const out=Adapter.compileBeat({plan:[['teleportAnything','hero','moon'],['fx','not_a_real_fx','hero','strange'],['anim','hero','lookAround','strange',.5,'worried']]},scene,2,[]);
  assert.equal(out.unsupported.teleportAnything,1);
  assert.equal(out.unsupported.fx,1);
  assert.ok(out.actions.every(x=>['anim','expr','turn','walkTo','runTo','hide','show','grow','fx','sfx','text','title','shake','flash'].includes(x.do)));
});

test('adds a word-timed witness reaction to a major reveal and normalizes face aliases', () => {
  global.Studio.Anim.clips.jumpscare = true;
  global.Studio.Anim.clips.shock = true;
  global.Studio.Anim.clips.curious = true;
  global.Studio.Anim.clips.laugh = true;
  const scene = {
    vo: 'Suddenly, a shadow appeared behind Max.',
    actors: { hero: { pos: [0,0,16] }, neighbor: { pos: [-4,0,17] } },
    objects: []
  };
  const words = [
    {w:'Suddenly',s:.1,e:.35},{w:'a',s:.36,e:.42},{w:'shadow',s:.43,e:.7},
    {w:'appeared',s:.71,e:1.02},{w:'behind',s:1.03,e:1.2},{w:'Max',s:1.21,e:1.4}
  ];
  const out = Adapter.compileBeat({plan:[
    ['anim','hero','lookAround','Suddenly',.7,'worried'],
    ['obj','shadow','shadowfigure','appeared','fadeIn']
  ],cam:[]},scene,1.6,words);
  assert.equal(out.reactions,1);
  assert.ok(out.actions.some(a=>a.actor==='neighbor'&&a.do==='turn'&&a.to==='shadow'&&Math.abs(a.at-.1)<.01));
  assert.ok(out.actions.some(a=>a.actor==='neighbor'&&a.do==='anim'&&a.clip==='jumpscare'&&a.expr==='scared'));
  const faceScene={vo:'He gasped.',actors:{hero:{pos:[0,0,0]}},objects:[]};
  const faceOut=Adapter.compileBeat({plan:[['expr','hero','gasp','gasped']]},faceScene,1,[{w:'gasped',s:.2,e:.4}]);
  assert.ok(faceOut.actions.some(a=>a.do==='expr'&&a.face==='shock'));
});

const test = require('node:test');
const assert = require('node:assert/strict');
const Story = require('../story-engine.js');

const premises = [
  'Nobody is allowed to open a window after midnight',
  'Every lie makes you shrink by one inch',
  'You can only walk backwards after sunset',
  'Nobody may whistle on Sundays',
  'If you sneeze, the lights go out',
  'No one can look at the moon',
  'Never eat pizza on Tuesdays',
  'Nobody can knock on the red door',
  'Everyone must wear a hat',
  'Nobody is allowed to read books at night',
  'You cannot touch the golden statue',
  'Nobody can turn on a light after dark'
];

test('genera historias completas sin placeholders ni frases vacías', () => {
  for (const premise of premises) {
    for (const tone of ['mystery', 'funny', 'suspense']) {
      const story = Story.generate(premise, tone, 'medium', 1700000000000);
      assert.ok(story.beats.length >= 10, premise + ' / ' + tone);
      assert.ok(story.beats.every(b => typeof b.vo === 'string' && b.vo.trim().length > 0));
      assert.ok(story.beats.every(b => !/\{\w+\}|\bundefined\b|\bNaN\b/.test(b.vo)));
      assert.ok(story.beats.every(b => b.role && b.set && Array.isArray(b.plan)));
    }
  }
});

test('variante cambia reparto o arco manteniendo la misma premisa', () => {
  const a = Story.generate(premises[0], 'mystery', 'medium', 100);
  const b = Story.generate(premises[0], 'mystery', 'medium', 200);
  assert.notEqual(a.seed, b.seed);
  assert.ok(a.beats.length > 0 && b.beats.length > 0);
});

test('versión corta limita la historia y conserva el gancho', () => {
  const story = Story.generate(premises[0], 'mystery', 'short', 42);
  assert.ok(story.beats.length <= 16);
  assert.equal(story.beats[0].role, 'hook');
});

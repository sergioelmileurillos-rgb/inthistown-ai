const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const vm = require('node:vm');

function loadApp(){
  const elements = new Map();
  const context2d = {drawImage(){},createLinearGradient(){return {addColorStop(){}}},fillRect(){},save(){},restore(){},fillText(){},measureText(t){return {width:String(t).length*12}},beginPath(){},roundRect(){},fill(){},stroke(){}};
  const get = id => {
    if(!elements.has(id))elements.set(id,{id,value:id==='tone'?'mystery':id==='length'?'medium':'',textContent:'',innerHTML:'',style:{},disabled:false,checked:false,open:false,dataset:{},files:[],classList:{add(){},remove(){},contains(){return false}},addEventListener(){},focus(){},getContext(){return context2d}});
    return elements.get(id);
  };
  const document={getElementById:get,querySelectorAll(){return []}};
  const engineText=['engine/anim.js','engine/anim_extra.js'].map(f=>fs.readFileSync(path.join(__dirname,'..',f),'utf8')).join('\n');
  const clips={};for(const match of engineText.matchAll(/C\.([A-Za-z0-9_]+)\s*=/g))clips[match[1]]=true;
  const fxCore=fs.readFileSync(path.join(__dirname,'..','engine/fx.js'),'utf8');
  const fxExtra=fs.readFileSync(path.join(__dirname,'..','engine/fx_extra.js'),'utf8');
  const fxNames=[...fxCore.matchAll(/^\s{2}([A-Za-z0-9_]+)\(a,r\)\{/gm)].map(m=>m[1]);
  const extraNames=fxExtra.match(/S\.Fx\.extraNames=\[([^\]]+)\]/s)?.[1].match(/'([^']+)'/g)?.map(x=>x.slice(1,-1))||[];
  const fxInventory=Object.fromEntries([...new Set([...fxNames,...extraNames])].map(x=>[x,true]));
  const Studio={
    PRESETS:{hero:{},mayor:{},robot:{},nurse:{},catgirl:{},nerd:{},builder:{},farmer:{},athlete:{},chef:{}},
    Anim:{clips},Fx:{GEN:fxInventory},
    V:{},M:{},clamp:(n,a,b)=>Math.max(a,Math.min(b,n)),lerp:(a,b,t)=>a+(b-a)*t,ease:(name,t)=>t,hex:x=>x,mix:(a,b,t)=>a,rng:()=>()=>.5,env:()=>({}),
    Character:class Character{constructor(id,spec){this.id=id;this.spec=spec||{};}},
    AssetForge:{ensure(kind,seed){return{id:'forge_'+kind,kind,variant:0,reused:false,partCount:8}},inventory(){return 1}},
    api:{init(){return{gl:'mock'}},setStory(){},compile(){return{warns:[],sfx:[]}},validate(){return{issues:[],sfx:[]}},frame(){}}
  };
  const sandbox={console,document,Studio,location:{protocol:'file:'},navigator:{},URL,Blob,Map,Set,Float32Array,Math,Date,Number,String,Array,Object,JSON,RegExp,Error,Promise,performance:{now:()=>0},setTimeout,clearTimeout,requestAnimationFrame(){},MediaStream:function(){},window:null};
  sandbox.window=sandbox;sandbox.globalThis=sandbox;sandbox.ITT={};sandbox.addEventListener=()=>{};
  const root=path.join(__dirname,'..');
  for(const file of ['story-engine.js','story-plan-adapter.js','engine/director.js','shortform-director.js','episode-preflight.js','timing.js','sfx.js','app.js']){
    vm.runInNewContext(fs.readFileSync(path.join(root,file),'utf8'),sandbox,{filename:file});
  }
  return sandbox;
}

test('browser app adapts Claude visual plans across 12 premises and 3 tones',()=>{
  const app=loadApp();
  let reactionTotal=0;
  const premises=[
    'Nobody is allowed to open a window after midnight',
    'Every lie makes you shrink by one inch',
    'You can only walk backwards after sunset',
    'Nobody may whistle on Sundays',
    'If you sneeze, the lights go out',
    'No one can look at the moon',
    'Never eat pizza on Tuesdays',
    'Nobody can knock on the red door',
    'Everyone must wear a hat',
    'Nobody is allowed to read books at night',
    'You cannot touch the golden statue',
    'Nobody can turn on a light after dark'
  ];
  for(let pi=0;pi<premises.length;pi++)for(const tone of ['mystery','funny','suspense']){
    const premise=premises[pi],story=app.ITT.app.buildStory(premise,tone,'medium',1700000000000+pi*17+tone.length);
    assert.ok(story.scenes.length>=10,premise+' / '+tone);
    const timings=story.scenes.map((scene,j)=>{
      const words=(scene.vo.match(/[a-z0-9']+/gi)||[]),n=Math.max(1,words.length),speech=2.8;
      return {duration:3,speechDuration:speech,start:j*3,words:words.map((w,k)=>({w,s:k/n*speech,e:(k+1)/n*speech}))};
    });
    const timing={timings,duration:story.scenes.length*3};
    app.ITT.app.prepareChoreography(story,timing);
    assert.ok(story.editorialShots.length>0,premise+' / '+tone);
    assert.ok(story.scenes.every(s=>s.cam.length>=1),premise+' / '+tone+' needs camera coverage');
    assert.ok(story.scenes.some(s=>s.planDiagnostics?.source==='semantic'),premise+' / '+tone+' should use authored plans');
    reactionTotal+=story.scenes.reduce((sum,s)=>sum+(s.planDiagnostics?.reactions||0),0);
    assert.ok(new Set(story.scenes.map(s=>s.cam[0]?.shot).filter(Boolean)).size>=2,premise+' / '+tone+' should vary its shot language');
    assert.ok(story.scenes.every(s=>s.actions.every(a=>Number.isFinite(a.at)&&a.at>=0&&a.at<s.dur)),premise+' / '+tone+' has invalid action timing');
    assert.ok(story.scenes.every(s=>s.cam.every(c=>Number.isFinite(c.at)&&c.at>=0&&c.at<s.dur)),premise+' / '+tone+' has invalid camera timing');
    assert.ok(story.scenes.every(s=>s.carryAllObjects===true),premise+' / '+tone+' must enable cross-scene object state');
    for(let j=0;j<story.scenes.length-1;j++){
      const current=story.scenes[j],nextIds=new Set(story.scenes[j+1].objects.map(o=>o.id));
      for(const item of current.objects){
        if(['storyPropLeft','storyPropRight','heroTool'].includes(item.id))continue;
        assert.ok(nextIds.has(item.id),premise+' / '+tone+' lost persistent prop '+item.id+' after scene '+(j+1));
      }
    }
    let priorActors={},priorObjects={};
    for(let j=0;j<story.scenes.length;j++){
      const compiled=app.Studio.Director.compileScene(null,story,story.scenes[j],{fast:true,prevEnd:priorActors,prevObjects:priorObjects});
      assert.equal(compiled.warns.length,0,premise+' / '+tone+' / scene '+(j+1)+' engine warnings: '+compiled.warns.join(' | '));
      priorActors=compiled.end;priorObjects=compiled.endObjects;
    }
    const unsupported=story.scenes.flatMap((s,j)=>Object.entries(s.planDiagnostics?.unsupported||{}).map(([op,n])=>`${j+1}:${op}(${n})`));
    assert.equal(unsupported.length,0,premise+' / '+tone+' has unsupported operations: '+unsupported.join(', '));
    const report=app.ITT.app.preflight(story,timing);
    assert.ok(!report.some(x=>x.sev==='error'),premise+' / '+tone+'\n'+report.filter(x=>x.sev==='error').map(x=>x.msg).join('\n'));
  }
  assert.ok(reactionTotal>0,'the story corpus should contain automatic witness reactions');
});

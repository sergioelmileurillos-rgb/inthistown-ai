# In This Town — Browser v0.5.9

Browser-first video studio built on the user's original custom WebGL2 Roblox-style engine. The page accepts a one-line story premise, creates an English short story, translates the narrative engine's per-beat visual plans into real scene actions, generates Kokoro narration, mixes audio and captions, and records a vertical video in the browser.

## Run
Use the hosted HTTPS app (recommended for Chromebook, iPhone and desktop). The ZIP is a source/deployment package; GitHub Pages extracts `site/` and serves it over HTTPS. A local `file://` copy may be restricted by browser module/network policies.

## Narrative and visual direction
- The modular v0.5.0 story engine selects a narrative archetype, cast, setting, action plan and camera language for each beat.
- `story-plan-adapter.js` now translates those authored plans into the original engine schema instead of throwing most of the visual instructions away and rebuilding a generic sequence.
- Supported plan operations include actor blocking, animation, facial expression, walking/running, prop interaction, object states, object reveals, character scale/hover, FX, SFX, on-screen text, camera shots and motivated camera moves.
- Semantic sets map to real engine worlds: suburb/facade, room/home/bedroom, town hall, park, school, city and void.
- Word anchors resolve against the measured Kokoro word timings. Missing anchors fall back to a bounded local estimate; the current waveform-based word alignment is not phoneme-level forced alignment.
- Unknown operations are counted and skipped safely. The previous handcrafted choreography remains the fallback when a beat has no usable semantic plan.
- The v0.5.7 short-form director still helps group beats into motivated shot holds. Its score is diagnostic only, not a prediction of views or virality.
- The v0.6.3 episode preflight checks shot coverage, caption timing/readability, event bounds and actor/prop references.

## Voice and audio
- Kokoro-82M ONNX: `onnx-community/Kokoro-82M-v1.0-ONNX`
- Kokoro JS browser build: `kokoro-js@1.2.1`
- Voice: `am_adam`, American English male
- Speed: 1.14
- Up to three short sentences per inference request, capped at 25 words per group.
- Original procedural sound effects and locally generated ambient fallback music. User-selected music stays on-device and is not uploaded.

### Chromebook voice loading
- ChromeOS, mobile browsers and constrained devices load Kokoro using Q8/WASM first, with Q4/WASM as a fallback.
- The larger FP32/WebGPU route is skipped on Chromebooks and other constrained devices. High-memory desktop browsers may still use it.
- If all loading modes fail, the app reports the backend and quantization attempted, including numeric error codes in hexadecimal when available.
- Kokoro documents Q4 and Q8 as supported quantization options: https://github.com/hexgrad/kokoro/blob/main/kokoro.js/README.md

### Stability updates in v0.5.9
- The Kokoro worker is terminated after narration synthesis, before the 3D render, to release WASM memory.
- WebGL drawing is limited to the 24 fps export rate instead of every display refresh.
- WebGL context loss is reported explicitly.

## Rendering, subtitles and assets
- Original WebGL2 renderer and procedural Roblox-like character, prop, world and FX systems are retained.
- Word emphasis uses waveform-informed timing estimates inside each grouped Kokoro output.
- Asset Forge provides deterministic reusable prop variations, stored locally in the browser.
- Export remains 576×1024 at 24 fps in this build; a full-device-tested 1080×1920 mode is not claimed.

## Controls
Cancel generation, request another story variant, preview the exported video, inspect the validation report, and browse/preview the reusable asset library.

## Limits
- Rendering and Kokoro inference run on the user's device; performance depends on hardware and browser support.
- First Kokoro use needs internet to download the model.
- Procedural props are assembled from engine geometry primitives, not arbitrary AI-generated meshes.
- Automated tests validate code paths and scene-plan translation. They do not replace a real full export test on iPhone/Chromebook.

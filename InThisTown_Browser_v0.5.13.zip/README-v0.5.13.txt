In This Town Browser v0.5.13

Fix for the recurring `checkCancel is not defined` runtime error. Cancellation checks are now inline, the app entry script has a versioned URL, and the service worker uses a fresh cache plus network-first updates for the app shell.

The v0.5.12 story / character improvements are retained.
Automated checks are included; the full video export still needs testing on the target Chromebook.

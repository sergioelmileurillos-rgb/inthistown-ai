In This Town Browser v0.5.6

This release builds on the supplied v0.5.5 project. It adds persistent object state across scene cuts, automatically restores props created by earlier beats, adds restrained word-timed witness reactions, normalizes facial-expression aliases, and varies repeated camera framings while preserving authored camera direction.

The original WebGL2 engine, Kokoro browser worker, assets, story generator, visual-plan adapter, short-form director, preflight and GitHub Pages workflow are retained.

Deploy: place InThisTown_Browser_v0.5.6.zip at the repository root and run the included GitHub Pages workflow. The workflow selects the newest versioned ZIP and deploys its site/ directory.

Checks: from site/, run npm test and npm run check.

Important: the complete Kokoro/WebGL2/MediaRecorder export still needs to be tested on a real compatible browser/device. This package is not claimed to be device-tested.

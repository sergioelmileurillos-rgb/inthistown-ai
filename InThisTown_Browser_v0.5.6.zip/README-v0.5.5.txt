In This Town Browser v0.5.5

This package starts from the provided v0.5.4 build and wires the story engine's per-beat visual plans directly into the existing WebGL2 renderer. It includes the semantic plan adapter, editor/director, preflight, tests, service-worker cache bump and GitHub Pages workflow.

Deploy: commit the InThisTown_Browser_v0.5.5.zip archive at the repository root. The included workflow selects the newest InThisTown_Browser_v*.zip, extracts site/, and deploys it to GitHub Pages.

Checks: from site/, run npm test and npm run check.

Important: a complete Kokoro/WebGL/MediaRecorder video export still needs validation on a real browser/device. This is not claimed as device-tested.

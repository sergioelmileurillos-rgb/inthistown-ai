IN THIS TOWN — BROWSER v0.5.4

La carpeta site/ es la aplicación que se publica en GitHub Pages.
La versión combina el motor 3D y Asset Forge del paquete Browser v0.5.2 con el generador narrativo modular v0.5.0 y los módulos de dirección/preflight v0.5.7/v0.6.3.

Para probar los módulos con Node.js 20 o superior:
  cd site
  npm test
  npm run check

Para publicar: conserva el flujo de GitHub Pages que extrae la carpeta site/ del ZIP más reciente InThisTown_Browser_v*.zip.

La primera ejecución de Kokoro necesita internet para descargar el modelo. La exportación final depende del navegador y del dispositivo. La sincronización de palabras es una estimación basada en audio, no un alineador fonético exacto.

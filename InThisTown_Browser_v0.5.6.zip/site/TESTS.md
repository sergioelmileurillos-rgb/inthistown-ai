# v0.5.6 test report

- [x] Source ZIP integrity verified before editing.
- [x] 12 story premises × 3 tones (mystery, funny, suspense) pass through the browser app builder and semantic-plan adapter.
- [x] All 36 generated stories are compiled beat-by-beat by the original scene director in fast mode; no missing actor/object references or other compiler warnings are emitted.
- [x] Action and camera timestamps are numeric and remain inside their scene durations.
- [x] Main narrative props are restored across adjacent scenes; one-scene duplicates and hand tools remain local.
- [x] Focused engine test checks that object position, yaw, scale and visibility survive a scene cut.
- [x] Focused adapter test checks word-timed witness reactions and normalizes `gasp` to the supported `shock` expression.
- [x] Repeated first camera framings are varied within a continuous set, and a reveal can receive a motivated object close-up.
- [x] Fade-in, rise, camera-facing gesture, light switch-off and unknown operation/FX handling remain covered.
- [x] 14 automated tests pass (`npm test`).
- [x] Every JavaScript file in the site passes `node --check` (`npm run check`).
- [ ] Complete Kokoro inference + WebGL2 + MediaRecorder export still needs a real browser/device run on the user's Chromebook or iPhone.
- [ ] Visual review of a complete exported video on the user's device has not been performed.

The automated tests validate story generation, semantic-plan translation, scene compilation in fast mode and cross-scene state transfer. They do not claim that a complete final video has been rendered or visually approved on a real device.

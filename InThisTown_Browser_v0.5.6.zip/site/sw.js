const CACHE='in-this-town-shell-v5-8';
const CORE=['./','./index.html','./app.js','./story-engine.js','./story-plan-adapter.js','./shortform-director.js','./episode-preflight.js','./timing.js','./sfx.js','./kokoro-worker.js','./manifest.webmanifest','./icon-192.png','./icon-512.png',
'./engine/math.js','./engine/prims.js','./engine/renderer.js','./engine/anim.js','./engine/anim_extra.js','./engine/props.js','./engine/props_extra.js','./engine/asset_forge.js','./engine/character.js','./engine/characters_extra.js','./engine/world.js','./engine/world_extra.js','./engine/fx.js','./engine/fx_extra.js','./engine/assets.js','./engine/director.js','./engine/api.js'];
self.addEventListener('install',e=>e.waitUntil(caches.open(CACHE).then(c=>c.addAll(CORE)).then(()=>self.skipWaiting())));
self.addEventListener('activate',e=>e.waitUntil(caches.keys().then(keys=>Promise.all(keys.filter(k=>k!==CACHE).map(k=>caches.delete(k)))).then(()=>self.clients.claim())));
self.addEventListener('fetch',e=>{const u=new URL(e.request.url);if(u.origin!==location.origin)return;e.respondWith(caches.match(e.request).then(r=>r||fetch(e.request)));});

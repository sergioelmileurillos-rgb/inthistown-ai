/* In This Town — Kokoro-82M worker. WebGPU first when available; WASM q8 fallback. */
'use strict';
const KOKORO_MODULE_URL='https://cdn.jsdelivr.net/npm/kokoro-js@1.2.1/dist/kokoro.web.js';
const MODEL_ID='onnx-community/Kokoro-82M-v1.0-ONNX';
const VOICE_SPEED=1.14;
let tts=null,loading=null;
function postError(id,phase,error){const message=error&&typeof error==='object'?(error.message||error.name||JSON.stringify(error)):String(error);self.postMessage({type:'error',id:id??null,phase,message,stack:error?.stack||''});}
async function loadModel(){
  if(tts)return tts;if(loading)return loading;
  loading=(async()=>{
    self.postMessage({type:'progress',message:'Cargando Kokoro en segundo plano…',progress:8});
    const mod=await import(KOKORO_MODULE_URL);if(!mod.KokoroTTS)throw new Error('La compilación de Kokoro no expone KokoroTTS.');
    const onProgress=event=>{const loaded=Number(event?.loaded||0),total=Number(event?.total||0),file=event?.file||event?.name||event?.path||'modelo';if(total>0)self.postMessage({type:'progress',message:`Descargando Kokoro (${file}) · ${Math.round(loaded/1048576)} / ${Math.round(total/1048576)} MB…`,progress:Math.round(10+Math.min(1,loaded/total)*14)});else if(event?.status)self.postMessage({type:'progress',message:`Preparando Kokoro (${file}) · ${event.status}…`,progress:12});};
    const hasGPU=typeof navigator!=='undefined'&&!!navigator.gpu;
    if(hasGPU){try{self.postMessage({type:'progress',message:'Probando aceleración gráfica para acelerar la voz…',progress:10});tts=await mod.KokoroTTS.from_pretrained(MODEL_ID,{dtype:'fp32',device:'webgpu',progress_callback:onProgress});}catch(gpuError){self.postMessage({type:'progress',message:'Aceleración gráfica no disponible; usando el modo compatible…',progress:13});tts=null;}}
    if(!tts)tts=await mod.KokoroTTS.from_pretrained(MODEL_ID,{dtype:'q8',device:'wasm',progress_callback:onProgress});
    if(typeof tts.generate!=='function')throw new Error('Kokoro se ha cargado, pero no ofrece generate().');
    self.postMessage({type:'ready',message:hasGPU?'Kokoro listo · aceleración gráfica activa.':'Kokoro listo · modo compatible WASM.'});return tts;
  })();
  try{return await loading;}catch(error){tts=null;loading=null;throw error;}
}
self.addEventListener('message',async event=>{const data=event.data||{};if(data.type==='load'){try{await loadModel();}catch(error){postError(null,'carga de Kokoro',error);}return;}if(data.type==='generate'){try{const model=await loadModel();const result=await model.generate(String(data.text||''),{voice:data.voice||'am_adam',speed:Number(data.speed||VOICE_SPEED)});const audio=result?.audio instanceof Float32Array?result.audio:(result?.audio?.audio instanceof Float32Array?result.audio.audio:null);if(!audio||!audio.length)throw new Error('Kokoro no ha devuelto muestras de audio.');const sampleRate=result?.sampling_rate||result?.sample_rate||result?.audio?.sampling_rate||24000;self.postMessage({type:'audio',id:data.id,audio,sampleRate},[audio.buffer]);}catch(error){postError(data.id,'generación de voz',error);}}});

In This Town Browser v0.5.9

Esta versión se centra en evitar que ChromeOS se quede sin recursos durante la creación del vídeo:

1. Kokoro genera toda la narración en segundo plano. Al terminar, se cierra su worker WASM y se libera la memoria del modelo antes del render 3D.
2. El renderizador deja de dibujar a la frecuencia completa de pantalla y limita el trabajo gráfico a los 24 FPS que realmente se graban.
3. Si se pierde el contexto WebGL, la app informa de ello en vez de seguir intentando renderizar.
4. Se actualiza la caché para forzar que GitHub Pages cargue los archivos nuevos.

Para publicar: sube InThisTown_Browser_v0.5.9.zip a la raíz del repositorio. El workflow existente selecciona automáticamente el ZIP con la versión más alta y publica su carpeta site/.

Comprobaciones automatizadas: consultar site/TESTS.md. No se ha realizado una exportación completa en el Chromebook, así que la prueba real del dispositivo sigue pendiente.

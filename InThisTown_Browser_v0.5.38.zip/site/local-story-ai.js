/* In This Town — browser-local story writer.
 * Runs a small instruction model in the browser via Transformers.js + ONNX Runtime.
 * Model weights are downloaded from Hugging Face and cached by the browser.
 * No API key and no story text is sent to an inference service.
 */
(function (G) {
  'use strict';
  const ITT = G.ITT = G.ITT || {};
  const MODEL = 'onnx-community/SmolLM2-360M-Instruct-ONNX';
  const LIBRARY = 'https://cdn.jsdelivr.net/npm/@huggingface/transformers@3.7.2';
  let generator = null;
  let loading = null;
  let activeDevice = null;

  function report(callback, message, progress) {
    try { callback?.({ message, progress: Number.isFinite(progress) ? progress : null }); } catch {}
  }

  async function devicePlan() {
    const nav = G.navigator || {};
    const ua = String(nav.userAgent || '');
    const memory = Number(nav.deviceMemory || 0);
    const cores = Number(nav.hardwareConcurrency || 0);
    const mobile = /Android|iPhone|iPad|iPod|Mobile/i.test(ua);
    const ios = /iPhone|iPad|iPod/i.test(ua);
    const iosVersion = (ua.match(/OS (\d+)[_.]/i) || [])[1];
    const ios26Plus = ios && Number(iosVersion || 0) >= 26;
    const conservative = (memory > 0 && memory < 8) || (cores > 0 && cores <= 4);
    let hasAdapter = false;

    // Check for a real adapter rather than trusting navigator.gpu alone.
    // On mobile, only attempt WebGPU on iOS 26+; Android and older iOS stay
    // on WASM to avoid an unreliable GPU-memory allocation.
    if (nav.gpu && typeof nav.gpu.requestAdapter === 'function' && (!mobile || ios26Plus)) {
      try {
        const adapter = await nav.gpu.requestAdapter({ powerPreference: mobile ? 'low-power' : 'high-performance' });
        hasAdapter = !!adapter;
      } catch {}
    }
    if (mobile) return ios26Plus && hasAdapter ? ['webgpu', 'wasm'] : ['wasm'];
    if (!hasAdapter) return ['wasm'];
    return conservative ? ['wasm', 'webgpu'] : ['webgpu', 'wasm'];
  }

  async function load(options = {}) {
    if (generator) return generator;
    if (loading) return loading;
    loading = (async () => {
      report(options.onProgress, 'Preparando el motor de IA local…', 1);
      const transformers = await import(LIBRARY);
      transformers.env.allowLocalModels = false;
      transformers.env.useBrowserCache = true;
      transformers.env.useWasmCache = true;
      const progress_callback = (event) => {
        if (!event || typeof event !== 'object') return;
        const file = String(event.file || event.name || 'modelo');
        const status = String(event.status || '');
        const pct = Number.isFinite(event.progress) ? Math.max(0, Math.min(100, event.progress)) : null;
        if (status === 'progress') report(options.onProgress, `Descargando IA local · ${file}`, pct);
        else if (status === 'done') report(options.onProgress, `Archivo listo · ${file}`, 100);
        else if (status === 'initiate') report(options.onProgress, `Descargando ${file}…`, null);
      };
      let lastError = null;
      // Select the least risky backend for the current device; keep a fallback.
      const plan = await devicePlan();
      const attempts = plan.flatMap(device => device === 'wasm'
        ? [{ device, dtype: 'q8' }, { device, dtype: 'q4' }]
        : [{ device, dtype: 'q4' }]);
      for (const attempt of attempts) {
        const { device, dtype } = attempt;
        try {
          report(options.onProgress, device === 'webgpu'
            ? 'iPhone compatible: probando IA acelerada con WebGPU…'
            : `Preparando IA local en modo WASM ${dtype.toUpperCase()}…`, null);
          generator = await transformers.pipeline('text-generation', MODEL, {
            device,
            dtype,
            progress_callback
          });
          activeDevice = `${device}/${dtype}`;
          report(options.onProgress, `IA local preparada (${activeDevice.toUpperCase()}).`, 100);
          return generator;
        } catch (error) {
          lastError = error;
          generator = null;
          if (attempt === attempts[attempts.length - 1]) break;
          console.warn(`In This Town: ${device}/${dtype} model load failed; trying fallback.`, error);
        }
      }
      throw new Error('No se pudo cargar el modelo local. Comprueba la conexión, la memoria disponible y la compatibilidad de Chrome. Detalle: ' + (lastError?.message || lastError || 'error desconocido'));
    })();
    try { return await loading; } finally { loading = null; }
  }

  function extractText(result) {
    const item = Array.isArray(result) ? result[0] : result;
    const generated = item?.generated_text ?? item?.text ?? item;
    if (typeof generated === 'string') return generated;
    if (Array.isArray(generated)) {
      const last = [...generated].reverse().find(message => message?.role === 'assistant' || message?.content);
      return String(last?.content || '');
    }
    return String(generated?.content || '');
  }

  function extractJSON(text) {
    const source = String(text || '').replace(/```(?:json)?/gi, '').replace(/```/g, '').trim();
    const start = source.indexOf('{');
    if (start < 0) throw new Error('La IA no ha devuelto un objeto JSON.');
    // Find the matching closing brace without being confused by braces in strings.
    let depth = 0, quoted = false, escaped = false;
    for (let i = start; i < source.length; i++) {
      const ch = source[i];
      if (quoted) {
        if (escaped) escaped = false;
        else if (ch === '\\') escaped = true;
        else if (ch === '"') quoted = false;
      } else if (ch === '"') quoted = true;
      else if (ch === '{') depth++;
      else if (ch === '}' && --depth === 0) return source.slice(start, i + 1);
    }
    throw new Error('El JSON generado está incompleto. Vuelve a intentarlo con una historia más corta.');
  }

  async function generate(options = {}) {
    const pipe = await load(options);
    const prompt = String(options.prompt || '').trim();
    if (!prompt) throw new Error('Falta la premisa para generar la historia.');
    report(options.onProgress, 'La IA está inventando una historia original…', null);
    const system = [
      'You are the original story writer for a short Roblox-style animated video.',
      'Follow the user prompt and its JSON schema exactly.',
      'Return one valid JSON object only. No markdown, no preface, no comments.',
      'Keep the story coherent, original, visual, and causal. Do not repeat stock plots.',
      'Do not invent extra characters, props, actions, or events that are not in the narration.',
      'Keep every beat narration short and natural English. Keep JSON compact.'
    ].join(' ');
    const result = await pipe([
      { role: 'system', content: system },
      { role: 'user', content: prompt + '\n\nFINAL OUTPUT REQUIREMENT: Return only compact valid JSON. Do not stop before the final closing brace.' }
    ], {
      max_new_tokens: options.maxNewTokens || 1500,
      do_sample: true,
      temperature: Number.isFinite(options.temperature) ? options.temperature : 0.88,
      top_p: Number.isFinite(options.topP) ? options.topP : 0.92,
      repetition_penalty: Number.isFinite(options.repetitionPenalty) ? options.repetitionPenalty : 1.16,
      no_repeat_ngram_size: 3,
      return_full_text: false
    });
    report(options.onProgress, 'Revisando el guion y su estructura…', null);
    const json = extractJSON(extractText(result));
    const parsed = JSON.parse(json);
    if (!parsed || typeof parsed !== 'object' || !Array.isArray(parsed.beats)) {
      throw new Error('La IA ha devuelto un guion con una estructura no válida.');
    }
    return { json, data: parsed, model: MODEL, device: activeDevice };
  }

  async function release() {
    const current = generator;
    generator = null;
    activeDevice = null;
    if (!current) return;
    try { await current.model?.dispose?.(); } catch (error) { console.warn('Local AI model disposal:', error); }
    try { await current.dispose?.(); } catch (error) { console.warn('Local AI pipeline disposal:', error); }
  }

  ITT.LocalAI = {
    model: MODEL,
    load,
    release,
    generate,
    isLoaded: () => !!generator,
    device: () => activeDevice,
    devicePlan
  };
})(window);

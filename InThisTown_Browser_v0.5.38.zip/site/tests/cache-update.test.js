const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const root = path.join(__dirname, '..');
const html = fs.readFileSync(path.join(root, 'index.html'), 'utf8');
const sw = fs.readFileSync(path.join(root, 'sw.js'), 'utf8');

test('the app entry URL is versioned to bypass old script cache entries', () => {
  assert.match(html, /app\.js\?v=0\.5\.38/);
});

test('service worker updates the page and main app script from the network first', () => {
  assert.match(sw, /in-this-town-shell-v5-40/);
  assert.match(sw, /e\.request\.mode==='navigate'/);
  assert.match(sw, /fetch\(e\.request\)/);
  assert.match(sw, /caches\.match\(e\.request\)/);
});

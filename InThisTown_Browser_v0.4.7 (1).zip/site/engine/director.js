/* engine/director.js — turns a scene JSON into a deterministic, random-access timeline and renders any frame.
   Scene spec reference: references/scene-format.md */
(function(S){
const {V,M,clamp,lerp,ease,hex,mix,rng}=S;const PI=Math.PI;
const wrapPi=a=>{a=(a+PI)%(2*PI);if(a<0)a+=2*PI;return a-PI};
const lerpV=(a,b,u)=>Array.isArray(a)?a.map((x,i)=>x+(b[i]-x)*u):a+(b-a)*u;
class Track{constructor(init){this.k=[{t:-1e9,v:init,e:'linear'}]}
  eval(t){const k=this.k;if(t<=k[0].t)return k[0].v;for(let i=1;i<k.length;i++)if(t<k[i].t){const a=k[i-1],b=k[i],u=(t-a.t)/Math.max(1e-6,b.t-a.t);return lerpV(a.v,b.v,ease(b.e,u))}return k[k.length-1].v}
  key(t,v,e='linear'){const k=this.k;while(k.length>1&&k[k.length-1].t>=t)k.pop();k.push({t,v,e})}
  move(t0,t1,to,e='inout'){this.key(t0,this.eval(t0));this.key(Math.max(t1,t0+1e-3),to,e)}
  hold(t,v){this.key(t,this.eval(t));this.key(t+1e-3,v)}
}
function parseT(x,ctx,def=0){if(x===undefined||x===null)return def;if(typeof x==='number')return x;x=String(x).trim();let m;
  if(m=/^w(\d+)(e?)([+-][\d.]+)?$/.exec(x)){const w=ctx.words[+m[1]];if(!w){ctx.warn(`time anchor "${x}": word index out of range (scene has ${ctx.words.length} words)`);return 0}return (m[2]?w.e:w.s)+(m[3]?parseFloat(m[3]):0)}
  if(m=/^@([^+\-]+)([+-][\d.]+)?$/.exec(x)){const key=m[1].toLowerCase().replace(/[^a-z0-9']/g,'');const w=ctx.words.find(w=>w.w.toLowerCase().replace(/[^a-z0-9']/g,'').startsWith(key));if(!w){ctx.warn(`time anchor "${x}": word not found in narration`);return 0}return w.s+(m[2]?parseFloat(m[2]):0)}
  if(m=/^end([+-][\d.]+)?$/.exec(x))return ctx.dur+(m[1]?parseFloat(m[1]):0);
  if(m=/^([\d.]+)%$/.exec(x))return ctx.dur*parseFloat(m[1])/100;
  const f=parseFloat(x);if(isNaN(f)){ctx.warn('bad time '+x);return 0}return f}

/* ---------- A* path planning around solid colliders ---------- */
function planPath(world,from,to,radius,warn){
  if(!world)return [to];const cols=world.colliders.filter(c=>!c.door&&c.max[1]>.4&&c.min[1]<5);
  const clearLine=(a,b,bl,g)=>{const d=Math.hypot(b[0]-a[0],b[1]-a[1]),n=Math.ceil(d/(g.c*.5))+1;for(let i=0;i<=n;i++){const x=a[0]+(b[0]-a[0])*i/n,z=a[1]+(b[1]-a[1])*i/n;const ix=Math.floor((x-g.x0)/g.c),iz=Math.floor((z-g.z0)/g.c);if(ix<0||iz<0||ix>=g.nx||iz>=g.nz||bl[iz*g.nx+ix])return false}return true};
  const pad=26,c=.8,x0=Math.min(from[0],to[0])-pad,x1=Math.max(from[0],to[0])+pad,z0=Math.min(from[1],to[1])-pad,z1=Math.max(from[1],to[1])+pad;
  const nx=Math.ceil((x1-x0)/c),nz=Math.ceil((z1-z0)/c);if(nx*nz>600000)return [to];
  const bl=new Uint8Array(nx*nz),g={c,x0,z0,nx,nz};
  for(const k of cols){const ax=Math.max(0,Math.floor((k.min[0]-radius-x0)/c)),bx=Math.min(nx-1,Math.floor((k.max[0]+radius-x0)/c)),az=Math.max(0,Math.floor((k.min[2]-radius-z0)/c)),bz=Math.min(nz-1,Math.floor((k.max[2]+radius-z0)/c));
    for(let z=az;z<=bz;z++)for(let x=ax;x<=bx;x++)bl[z*nx+x]=1}
  const clr=(p)=>{const ix=Math.floor((p[0]-x0)/c),iz=Math.floor((p[1]-z0)/c);for(let dz=-3;dz<=3;dz++)for(let dx=-3;dx<=3;dx++){const x=ix+dx,z=iz+dz;if(x>=0&&z>=0&&x<nx&&z<nz)bl[z*nx+x]=0}};
  clr(from);clr(to);
  if(clearLine(from,to,bl,g))return [to];
  const sx=Math.floor((from[0]-x0)/c),sz=Math.floor((from[1]-z0)/c),gx=Math.floor((to[0]-x0)/c),gz=Math.floor((to[1]-z0)/c);
  const open=[[0,sz*nx+sx]],gS=new Float32Array(nx*nz).fill(1e9),par=new Int32Array(nx*nz).fill(-1),closed=new Uint8Array(nx*nz);gS[sz*nx+sx]=0;
  const h=(i)=>Math.hypot((i%nx)-gx,Math.floor(i/nx)-gz);
  const heapPush=(a,x)=>{a.push(x);let i=a.length-1;while(i>0){const p=(i-1)>>1;if(a[p][0]<=a[i][0])break;[a[p],a[i]]=[a[i],a[p]];i=p}};
  const heapPop=(a)=>{const t=a[0],l=a.pop();if(a.length){a[0]=l;let i=0;for(;;){let m=i,L=2*i+1,R=L+1;if(L<a.length&&a[L][0]<a[m][0])m=L;if(R<a.length&&a[R][0]<a[m][0])m=R;if(m===i)break;[a[m],a[i]]=[a[i],a[m]];i=m}}return t};
  const goal=gz*nx+gx;let found=false,it=0;
  while(open.length&&it++<400000){const [,cur]=heapPop(open);if(closed[cur])continue;closed[cur]=1;if(cur===goal){found=true;break}
    const cx=cur%nx,cz=Math.floor(cur/nx);for(let dz=-1;dz<=1;dz++)for(let dx=-1;dx<=1;dx++){if(!dx&&!dz)continue;const x=cx+dx,z=cz+dz;if(x<0||z<0||x>=nx||z>=nz)continue;const ni=z*nx+x;if(bl[ni]||closed[ni])continue;
      if(dx&&dz&&(bl[cz*nx+x]||bl[z*nx+cx]))continue;const ng=gS[cur]+(dx&&dz?1.414:1);if(ng<gS[ni]){gS[ni]=ng;par[ni]=cur;heapPush(open,[ng+h(ni),ni])}}}
  if(!found){warn&&warn('no path found around obstacles; walking straight (will clip)');return [to]}
  let path=[];for(let i=goal;i!==-1;i=par[i])path.push([x0+(i%nx+.5)*c,z0+(Math.floor(i/nx)+.5)*c]);path.reverse();path[0]=from;path[path.length-1]=to;
  const out=[];let a=0;while(a<path.length-1){let b=path.length-1;while(b>a+1&&!clearLine(path[a],path[b],bl,g))b--;out.push(path[b]);a=b}
  return out}

const CLIPEXPR={shock:'shock',scared:'scared',laugh:'laugh',cheer:'grin',angry:'angry',sleep:'sleep',cry:'cry',fall:'shock',panic:'scared',fly:'grin',dance:'grin',warp:'shock',flail:'scared',slump:'sad',sneeze:'worried',hide:'scared',punch:'angry',swing:'angry',climb:'worried',pullup:'angry',hang:'worried'};
const MOVECLIP={walkTo:'walk',runTo:'run',moveTo:'walk',goTo:'walk'};

/* ---------- Actor timeline ---------- */
class ActorTL{
  constructor(id,char,init){this.id=id;this.char=char;this.init=init;this.pos=new Track(init.pos.slice());this.yaw=new Track(init.yaw||0);this.scale=new Track(init.scale||1);
    this.clips=[];this.expr=[{t:-1e9,f:init.face||char.spec.face}];this.vis=[{t:-1e9,v:init.visible!==false}];this.arcs=[];this.hover=new Track(0);this.phase=!!init.phase;
    if(init.anim&&init.anim!=='idle')this.clips.push({t0:-1e9,t1:1e9,clip:init.anim,params:init.params||{},blend:0})}
  cut(t0){for(const c of this.clips)if(c.t1>t0)c.t1=t0}
  addClip(t0,t1,clip,params,blend){this.cut(t0);this.clips.push({t0,t1,clip,params:params||{},blend:blend===undefined?.14:blend})}
  setExpr(t,f){const e=this.expr;while(e.length>1&&e[e.length-1].t>=t)e.pop();e.push({t,f})}
  exprAt(t){let f=this.expr[0].f;for(const e of this.expr){if(e.t<=t)f=e.f;else break}return f}
  visAt(t){let v=this.vis[0].v;for(const e of this.vis){if(e.t<=t)v=e.v;else break}return v}
  posAt(t){const p=this.pos.eval(t).slice();let y=p[1]+this.hover.eval(t);for(const a of this.arcs){if(t>a.t0&&t<a.t1){const u=(t-a.t0)/(a.t1-a.t0);y+=a.h*4*u*(1-u)}}p[1]=y;return p}
  pose(t){let cur=null,prev=null;for(let i=0;i<this.clips.length;i++){const c=this.clips[i];if(t>=c.t0&&t<c.t1){cur=c;prev=this.clips[i-1]||null;break}}
    if(!cur){const last=[...this.clips].reverse().find(c=>c.t1<=t);const idle=S.Anim.evalPose('idle',t,0,{});if(last&&t-last.t1<.18&&last.clip!=='idle'){const lp=S.Anim.evalPose(last.clip,Math.min(last.t1-last.t0,1e4),last.t1-last.t0,last.params);return S.Anim.blend(lp,idle,clamp((t-last.t1)/.18))}return idle}
    const d=isFinite(cur.t1-cur.t0)&&cur.t1<1e8?cur.t1-cur.t0:0;const p=S.Anim.evalPose(cur.clip,t-cur.t0,d,cur.params);
    if(prev&&cur.blend>0&&t-cur.t0<cur.blend){const pd=prev.t1-prev.t0;const pp=S.Anim.evalPose(prev.clip,Math.min(t-prev.t0,1e4),pd,prev.params);return S.Anim.blend(pp,p,clamp((t-cur.t0)/cur.blend))}
    else if(!prev&&cur.blend>0&&t-cur.t0<cur.blend){return S.Anim.blend(S.Anim.evalPose('idle',t,0,{}),p,clamp((t-cur.t0)/cur.blend))}
    return p}
  end(dur){const t=dur;const clip=this.clips.find(c=>t>=c.t0&&t<c.t1+1e-6&&c.t1>1e8&&!(c.clip in MOVECLIP)&&c.clip!=='walk'&&c.clip!=='run');
    return {pos:this.posAt(t),yaw:wrapPi(this.yaw.eval(t)),face:this.exprAt(t),visible:this.visAt(t),scale:this.scale.eval(t),anim:clip?clip.clip:'idle',params:clip?clip.params:{}}}
}

/* ---------- Scene compile ---------- */
function compileScene(R,story,scene,opts={}){
  const warns=[],warn=m=>warns.push(`[${scene.id||'?'}] ${m}`);
  const dur=scene.__dur||scene.dur||3,words=scene.__words||[];const ctx={dur,words,warn};
  const fast=!!opts.fast,prevEnd=opts.prevEnd||{};
  const C={R,scene,dur,words,warns,ctx,actors:{},objects:{},fx:[],texts:[],overlays:[],sfx:[],cams:[],end:{},seed:scene.seed||1};
  C.skyName=scene.sky||(story.defaults&&story.defaults.sky)||'day';
  C.env=S.env(C.skyName,scene.env);
  C.world=fast?null:S.buildWorld(scene.world||story.defaults&&story.defaults.world||[{type:'city'}],scene.seed||story.seed||1,C.skyName);
  if(C.world&&C.world.signs.length){}
  if(!fast&&C.world){C.mesh=R.uploadBatch(C.world.batch)}
  // characters
  const chars=story.characters||{};
  const sa=scene.actors||{};
  const ids=new Set([...Object.keys(sa)]);for(const k of Object.keys(prevEnd))if(sa[k]===undefined&&scene.carryAll)ids.add(k);
  for(const id of ids){const def=sa[id]||{};const base=chars[def.ref||id]||{};const spec=Object.assign({},base.spec||base,def.spec||{});
    const ch=new S.Character(id,spec);const pe=prevEnd[id];
    let init={pos:def.pos?[def.pos[0],def.pos[1]===undefined||def.pos.length===2?0:def.pos[1],def.pos.length===2?def.pos[1]:def.pos[2]]:null};
    if(def.pos&&def.pos.length===2)init.pos=[def.pos[0],0,def.pos[1]];
    if(!init.pos){if(pe&&def.carry!==false){init.pos=pe.pos.slice();init.yaw=pe.yaw;init.face=pe.face;init.scale=pe.scale;if(pe.anim&&pe.anim!=='idle'&&def.anim===undefined){init.anim=pe.anim;init.params=pe.params}}else init.pos=[0,0,0]}
    if(def.yaw!==undefined)init.yaw=def.yaw*(def.yawDeg?PI/180:1);
    if(def.yawDeg!==undefined)init.yaw=def.yawDeg*PI/180;
    if(def.face)init.face=def.face;if(def.scale!==undefined)init.scale=def.scale;if(def.visible!==undefined)init.visible=def.visible;if(def.anim){init.anim=def.anim;init.params=def.params}
    init.phase=!!def.phase;
    if(init.yaw===undefined)init.yaw=0;
    C.actors[id]=new ActorTL(id,ch,init)}
  // objects
  const so=scene.objects||{};const oarr=Array.isArray(so)?so:Object.entries(so).map(([id,d])=>Object.assign({id},d));
  for(const d of oarr){const pos=d.pos.length===2?[d.pos[0],0,d.pos[1]]:d.pos.slice();
    C.objects[d.id]={id:d.id,type:d.type||'crate',opts:d.opts||{color:d.color,s:d.s,screen:d.screen,on:d.on,r:d.r},pos:new Track(pos),yaw:new Track((d.yaw||0)+(d.yawDeg?d.yawDeg*PI/180:0)),scale:new Track(d.scale===undefined?1:d.scale),alpha:new Track(d.alpha===undefined?1:d.alpha),pitch:new Track(d.pitch||0),roll:new Track(d.roll||0),vis:[{t:-1e9,v:d.visible!==false}],attach:[],spin:d.spin||null,bob:d.bob||null,parts:null}}
  // actions
  const acts=(scene.actions||[]).map((a,i)=>Object.assign({},a,{_i:i,_t:parseT(a.at,ctx,0)})).sort((a,b)=>a._t-b._t||a._i-b._i);
  const targetPos=(to,t,fromPos)=>{if(typeof to==='string'){const A=C.actors[to];if(A)return A.posAt(t);const O=C.objects[to];if(O)return O.pos.eval(t);warn('unknown target '+to);return fromPos}
    if(to.length===2)return [to[0],0,to[1]];return to.slice()};
  for(const a of acts){const t=a._t;if(t<-.01||t>dur+.3)warn(`action "${a.do}" at ${t.toFixed(2)}s is outside scene (0–${dur.toFixed(2)}s)`);
    if(a.obj){objAction(C,a,t,warn);continue}
    const A=C.actors[a.actor];if(!A){if(a.do!=='sfx'&&a.do!=='fx'&&a.do!=='text'&&a.do!=='title'&&a.do!=='flash'&&a.do!=='fade'&&a.do!=='shake')warn(`action "${a.do}" references unknown actor "${a.actor}"`);globalAction(C,a,t,warn);continue}
    actorAction(C,A,a,t,targetPos,warn)}
  // top-level fx / text / overlays / sfx arrays
  for(const f of scene.fx||[])globalAction(C,Object.assign({do:'fx'},f,{_t:parseT(f.at,ctx,0)}),parseT(f.at,ctx,0),warn);
  for(const f of scene.texts||[])globalAction(C,Object.assign({do:'text'},f),parseT(f.at,ctx,0),warn);
  for(const f of scene.sfx||[])C.sfx.push({t:parseT(f.at,ctx,0),name:f.name,vol:f.vol===undefined?1:f.vol});
  for(const f of scene.overlays||[])globalAction(C,Object.assign({},f),parseT(f.at,ctx,0),warn);
  // camera
  let cuts=scene.cam||scene.cams||{shot:'medium',on:Object.keys(C.actors)[0]};if(!Array.isArray(cuts))cuts=[cuts];
  C.cams=cuts.map(c=>Object.assign({},c,{t0:parseT(c.at,ctx,0)})).sort((a,b)=>a.t0-b.t0);if(C.cams[0].t0>0)C.cams[0].t0=0;
  for(let i=0;i<C.cams.length;i++){C.cams[i].t1=i+1<C.cams.length?C.cams[i+1].t0:dur+1;if(i>0&&C.cams[i].sfx!==false&&scene.cutSfx!==false)C.sfx.push({t:C.cams[i].t0,name:C.cams[i].sfx||'swish',vol:.35})}
  // validate/prepare end state
  for(const id in C.actors)C.end[id]=C.actors[id].end(dur);
  return C}

function actorAction(C,A,a,t,targetPos,warn){const d=a.do;const sp=a.speed||(d==='runTo'?14:5);
  if(d in MOVECLIP||d==='slideTo'||d==='flyTo'||d==='glideTo'){
    const cur=A.posAt(t);let to=targetPos(a.to,t,cur);if(typeof a.to==='string'&&a.stop){const dv=V.sub(cur,to);dv[1]=0;const l=V.len(dv)||1;to=V.add(to,V.mul(dv,a.stop/l))}
    if(a.dy!==undefined)to[1]=(to[1]||0)+a.dy;
    const flying=(d==='flyTo'||d==='glideTo'||a.anim==='fly'),useAstar=a.path!=='straight'&&!flying&&!A.phase&&C.world;
    const radius=1.0*(A.char.spec.scale||1)+(a.margin||0);
    const wps=useAstar?planPath(C.world,[cur[0],cur[2]],[to[0],to[2]],radius,m=>warn(`${A.id}: ${m}`)):[[to[0],to[2]]];
    let pts=[[cur[0],cur[2]],...wps];let total=0;const lens=[];for(let i=0;i<pts.length-1;i++){const l=Math.hypot(pts[i+1][0]-pts[i][0],pts[i+1][1]-pts[i][1]);lens.push(l);total+=l}
    const T=a.dur?a.dur:Math.max(.05,total/sp);const clip=a.anim||(d==='runTo'?'run':(d==='flyTo'?'fly':(d==='slideTo'?'slide':'walk')));
    A.addClip(t,t+T,clip,Object.assign({speed:(total/T)/(clip==='run'?11:5)},a.params||{}),.12);let tt=t;const ease_=a.ease||'linear';
    A.pos.key(t,cur);let yawCur=A.yaw.eval(t);
    for(let i=0;i<lens.length;i++){const t1=tt+T*lens[i]/(total||1);const ytarget=lerp(cur[1],to[1],(i+1)/lens.length);
      const dx=pts[i+1][0]-pts[i][0],dz=pts[i+1][1]-pts[i][1];if(Math.hypot(dx,dz)>.05&&!a.keepYaw){const ny=Math.atan2(dx,dz);const yc=A.yaw.eval(tt);const yt=yc+wrapPi(ny-yc);A.yaw.key(tt,yc);A.yaw.key(tt+Math.min(.2,t1-tt),yt,'out')}
      A.pos.key(t1,[pts[i+1][0],ytarget,pts[i+1][1]],ease_);tt=t1}
    if(a.height!==undefined){A.hover.move(t,t+Math.min(.4,T),a.height,'out')}
    return}
  if(d==='jumpTo'||d==='hopTo'){const cur=A.posAt(t);const to=targetPos(a.to,t,cur);const T=a.dur||.8;A.addClip(t,t+T,'jump',{},.05);A.pos.move(t,t+T,to,'linear');A.arcs.push({t0:t,t1:t+T,h:a.h||0});
    const dx=to[0]-cur[0],dz=to[2]-cur[2];if(Math.hypot(dx,dz)>.2){const yc=A.yaw.eval(t);A.yaw.key(t,yc);A.yaw.key(t+.15,yc+wrapPi(Math.atan2(dx,dz)-yc),'out')}return}
  if(d==='teleport'){const cur=A.posAt(t);const to=targetPos(a.to,t,cur);const w=a.warp===undefined?.4:a.warp;
    A.addClip(t-w,t,'warp',{},.05);A.pos.key(t-1e-3,cur);A.pos.key(t,to);A.addClip(t,t+.5,'arrive',{},0);
    C.fx.push({kind:'teleport',t,pos:cur,args:{color:a.color||'#5ad8ff'}},{kind:'teleport',t,pos:to,args:{color:a.color||'#5ad8ff'}});
    C.sfx.push({t:t-w*.6,name:'warp',vol:.9});if(a.flash!==false)C.overlays.push({type:'flash',t0:t-.02,dur:.25,color:[1,1,1],a:a.flashAmt||.35});
    if(a.yaw!==undefined){A.yaw.hold(t,a.yaw)}return}
  if(d==='turn'){let yt;if(a.to!==undefined){const cur=A.posAt(t);const p=typeof a.to==='string'||a.to.length>=2?targetPos(a.to,t,cur):null;yt=Math.atan2(p[0]-cur[0],p[2]-cur[2])}else yt=(a.yawDeg!==undefined?a.yawDeg*PI/180:a.yaw);
    const yc=A.yaw.eval(t);A.yaw.key(t,yc);A.yaw.key(t+(a.dur||.25),yc+wrapPi(yt-yc),'out');return}
  if(d==='anim'){const dd=a.dur,loop=a.loop||dd===undefined;const t1=loop?1e9:t+dd;const prevFace=A.exprAt(t);A.addClip(t,t1,a.clip,a.params,a.blend);
    const ex=a.expr||(a.autoexpr===false?null:CLIPEXPR[a.clip]);if(ex)A.setExpr(t,ex);if(!loop&&ex&&a.revert!==false)A.setExpr(t1,a.revertTo||prevFace);
    if(a.clip==='sneeze'){const k=dd||1;C.sfx.push({t:t+k*.5,name:'sneeze',vol:1})}
    if(a.clip==='jump'||a.clip==='hop'){if(a.sfx!==false)C.sfx.push({t:t,name:'boing',vol:.5});if(a.h)A.arcs.push({t0:t,t1:t+(dd||.8),h:a.h})}
    if(a.clip==='fall')C.sfx.push({t:t+(dd||.7)*.9,name:'thud',vol:.8});
    if(a.clip==='laugh'&&a.sfx)C.sfx.push({t,name:'giggle',vol:.5});
    return}
  if(d==='expr'){A.setExpr(t,a.face||a.expr);return}
  if(d==='talk'){const dd=a.dur||1;A.addClip(t,t+dd,'talk',a.params,.1);const base=a.base||A.exprAt(t);let k=0;for(let u=t;u<t+dd-.01;u+=.17){A.setExpr(u,k%2?'talk':base);k++}A.setExpr(t+dd,base);return}
  if(d==='hide'||d==='show'){A.vis.push({t,v:d==='show'});return}
  if(d==='grow'||d==='scaleTo'){A.scale.move(t,t+(a.dur||.5),a.to,a.ease||'back');return}
  if(d==='bubble'||d==='say'){C.texts.push({text:a.text,t0:t,dur:a.dur||1.2,on:A.id,off:a.off||[0,7.4,0],size:a.size||2.6,color:a.color||'#ffffff',stroke:a.stroke||'#111',style:'pop',bg:a.bg});C.sfx.push({t,name:'pop',vol:.5});return}
  if(d==='hover'){A.hover.move(t,t+(a.dur||.5),a.to===undefined?3:a.to,a.ease||'out');return}
  if(d==='moveInstant'||d==='place'){A.pos.key(t-1e-3,A.posAt(t));A.pos.key(t,targetPos(a.to,t,A.posAt(t)));return}
  warn(`unknown actor action "${d}"`)}

function objAction(C,a,t,warn){const O=C.objects[a.obj];if(!O){warn(`action on unknown object "${a.obj}"`);return}const d=a.do,T=a.dur||.5;
  const pos3=to=>to.length===2?[to[0],0,to[1]]:to;
  if(d==='moveTo'){O.pos.move(t,t+T,pos3(a.to),a.ease||'inout');if(a.yawFace){}}
  else if(d==='yawTo'){O.yaw.move(t,t+T,a.to*(a.deg?PI/180:1),a.ease||'inout')}
  else if(d==='pitchTo'){O.pitch.move(t,t+T,a.to*(a.deg?PI/180:1),a.ease||'inout')}
  else if(d==='rollTo'){O.roll.move(t,t+T,a.to*(a.deg?PI/180:1),a.ease||'inout')}
  else if(d==='scaleTo'){O.scale.move(t,t+T,a.to,a.ease||'back')}
  else if(d==='fadeTo'){O.alpha.move(t,t+T,a.to,a.ease||'linear')}
  else if(d==='show'||d==='hide'){O.vis.push({t,v:d==='show'})}
  else if(d==='spin'){O.spin=a.rate||3}
  else if(d==='attach'){O.attach.push({t0:t,t1:a.until===undefined?1e9:parseT(a.until,C.ctx,1e9),actor:a.actor,bone:a.bone||'handR',off:a.off||[0,0,1.0],yaw:a.yawOff||0})}
  else if(d==='detach'){const l=O.attach[O.attach.length-1];if(l)l.t1=t}
  else warn(`unknown object action "${d}"`)}

function globalAction(C,a,t,warn){const d=a.do||a.type;
  if(d==='fx'){const kind=a.kind||a.fx;const on=a.on&&(C.actors[a.on]?'actor':C.objects[a.on]?'obj':null);let pos=a.pos?(a.pos.length===2?[a.pos[0],0,a.pos[1]]:a.pos.slice()):null;
    if(!pos&&a.on){const A=C.actors[a.on],O=C.objects[a.on];pos=A?A.posAt(t):O?O.pos.eval(t):[0,0,0]}if(!pos)pos=[0,0,0];if(a.off)pos=V.add(pos,a.off);
    C.fx.push({kind,t,pos,args:Object.assign({},a),dur:a.dur,follow:a.on});
    const sfxMap={explosion:'boom',confetti:'cheer',coins:'coin',sparkle:'sparkle',poof:'poof',impact:'thud',teleport:'warp'};if(sfxMap[kind]&&a.sfx!==false)C.sfx.push({t,name:sfxMap[kind],vol:.8});return}
  if(d==='text'||d==='title'){const st=a.style||(d==='title'?'title':'pop');C.texts.push({text:a.text,t0:t,dur:a.dur||1.5,on:a.on,pos:a.pos,off:a.off||[0,8,0],size:a.size||(st==='title'?.9:3.2),color:a.color||'#fff',stroke:a.stroke||'#111',bg:a.bg,style:st,y:a.y===undefined?.25:a.y});if(st==='title'&&a.sfx!==false)C.sfx.push({t,name:'pop',vol:.6});return}
  if(d==='flash'){C.overlays.push({type:'flash',t0:t,dur:a.dur||.3,color:hex(a.color||'#ffffff'),a:a.amount||.9});return}
  if(d==='fade'){C.overlays.push({type:'fade',t0:t,dur:a.dur||.4,color:hex(a.color||'#000000'),dir:a.dir||'out'});return}
  if(d==='shake'){C.shakes=C.shakes||[];C.shakes.push({t0:t,dur:a.dur||.5,amp:a.amp||1});if(a.sfx!==false&&a.amp>=1)C.sfx.push({t,name:'rumble',vol:.7});return}
  if(d==='sfx'){C.sfx.push({t,name:a.name,vol:a.vol===undefined?1:a.vol});return}
  warn('unknown global action '+d)}

/* ---------- camera ---------- */
const SHOTS={close:{dist:7.4,height:4.8,az:0,lookY:4.2,fov:46,side:0,lead:0,roll:0},medium:{dist:11,height:5.2,az:18,lookY:3.6,fov:54,side:0,lead:0,roll:0},wide:{dist:26,height:9,az:22,lookY:3,fov:62,side:0,lead:0,roll:0},
  low:{dist:10,height:.9,az:14,lookY:4.2,fov:60,side:0,lead:0,roll:0},high:{dist:12,height:20,az:15,lookY:1,fov:56,side:0,lead:0,roll:0},over:{dist:7.5,height:6.4,az:165,lookY:3.6,fov:56,side:1.6,lead:14,roll:0},
  follow:{dist:13,height:6.5,az:180,lookY:3.4,fov:58,side:0,lead:6,roll:0},profile:{dist:12,height:4.6,az:90,lookY:3.6,fov:52,side:0,lead:0,roll:0},front:{dist:12,height:4.8,az:0,lookY:3.8,fov:54,side:0,lead:0,roll:0},
  top:{dist:1,height:42,az:0,lookY:0,fov:50,side:0,lead:0,roll:0},pov:{dist:.1,height:4.6,az:180,lookY:4.4,fov:70,side:0,lead:30,roll:0},extreme:{dist:4.8,height:4.9,az:0,lookY:4.7,fov:42,side:0,lead:0,roll:0},
  dutch:{dist:9,height:4.2,az:10,lookY:3.6,fov:56,side:0,lead:0,roll:.22},hero:{dist:9,height:1.6,az:12,lookY:4.4,fov:58,side:0,lead:0,roll:0},long:{dist:40,height:14,az:20,lookY:4,fov:55,side:0,lead:0,roll:0}};
function resolveMove(from,c){const to=Object.assign({},from);const m=c.move;const k=c.amount===undefined?1:c.amount;
  if(m==='push')to.dist=from.dist*(1-.42*k);else if(m==='pull')to.dist=from.dist*(1+.7*k),to.height=from.height+2.5*k;else if(m==='orbit')to.az=from.az+(c.deg||70)*k;else if(m==='crane')to.height=from.height+12*k,to.lookY=from.lookY;
  else if(m==='dolly'||m==='truck')to.side=from.side+9*k;else if(m==='zoom')to.fov=from.fov*(1-.35*k);else if(m==='rise')to.height=from.height+7*k;else if(m==='drift')to.az=from.az+14*k,to.dist=from.dist*(1+.08*k);else if(m==='whip')to.az=from.az+130*k;
  else if(m==='lowrise'){to.height=from.height+6*k;to.lookY=from.lookY+1}else if(m==='dutch')to.roll=from.roll+.3*k;
  if(c.to)Object.assign(to,c.to);return to}
function camEval(C,t){const cuts=C.cams;let c=cuts[0];for(const x of cuts)if(t>=x.t0)c=x;const dur=Math.max(.01,c.t1-c.t0),u=clamp((t-c.t0)/dur);const p=ease(c.ease||(c.move==='whip'?'cubic':'inout'),u);let out;
  const tgt=(on,tt)=>{if(!on)return {pos:[0,0,0],yaw:c.refYaw||PI};if(Array.isArray(on)&&typeof on[0]==='number')return {pos:on.length===2?[on[0],0,on[1]]:on,yaw:c.refYaw||PI};
    const list=Array.isArray(on)?on:[on];let sum=[0,0,0],yaw=0,n=0;for(const id of list){const A=C.actors[id],O=C.objects[id];if(A){const q=A.posAt(tt);sum=V.add(sum,q);yaw+=A.yaw.eval(tt)*0+wrapPi(A.yaw.eval(tt));n++}else if(O){sum=V.add(sum,O.pos.eval(tt));yaw+=O.yaw.eval(tt);n++}}
    if(!n)return {pos:[0,0,0],yaw:PI};const mid=V.mul(sum,1/n);let spread=0;if(list.length>1){const ps=list.map(id=>C.actors[id]?C.actors[id].posAt(tt):(C.objects[id]?C.objects[id].pos.eval(tt):mid));for(const a of ps)for(const b of ps)spread=Math.max(spread,Math.hypot(a[0]-b[0],a[2]-b[2]))}
    return {pos:mid,yaw:list.length>1?(c.refYaw||0):yaw/n,spread}};
  if(c.pos){const fromPos=c.pos,toPos=(c.to&&c.to.pos)||c.pos;const pos=lerpV(fromPos,toPos,p);let look;const lk=(c.look!==undefined?c.look:null);const lkTo=(c.to&&c.to.look)||lk;
    const rl=(l,tt)=>l&&l.on?V.add(tgt(l.on,tt).pos,[0,l.y===undefined?3.5:l.y,0]):l;look=lerpV(rl(lk,t)||[0,3,0],rl(lkTo,t)||[0,3,0],p);
    const fov=lerp(c.fov||55,(c.to&&c.to.fov)||c.fov||55,p);out={pos,look,fov,roll:lerp(c.roll||0,(c.to&&c.to.roll)||c.roll||0,p)}}
  else{const base=Object.assign({},SHOTS[c.shot||'medium']||SHOTS.medium);for(const k of Object.keys(base))if(typeof c[k]==='number')base[k]=c[k];if(c.params)Object.assign(base,c.params);
    const T0=tgt(c.on,t);if(T0.spread&&c.fit!==false&&typeof c.dist!=='number')base.dist=Math.max(base.dist,T0.spread*1.7+7);const to=resolveMove(base,c);const P={};for(const k of Object.keys(base))P[k]=lerp(base[k],to[k],p);
    const T=tgt(c.on,t);const ang=T.yaw+P.az*PI/180;const f=[Math.sin(T.yaw),0,Math.cos(T.yaw)],rgt=[Math.cos(T.yaw),0,-Math.sin(T.yaw)];
    const foot=T.pos;const lookP=V.add(V.add(V.add(foot,[0,P.lookY,0]),V.mul(f,P.lead)),V.mul(rgt,P.side*.5));
    const camP=V.add(V.add(foot,[Math.sin(ang)*P.dist,P.height,Math.cos(ang)*P.dist]),V.mul(rgt,P.side));
    out={pos:camP,look:lookP,fov:P.fov,roll:P.roll}}
  // shake
  let amp=c.shake||0;for(const s of C.shakes||[]){if(t>=s.t0&&t<s.t0+s.dur)amp+=s.amp*(1-(t-s.t0)/s.dur)}
  if(amp>0){const k=amp*.35;out.pos=V.add(out.pos,[k*Math.sin(t*61.3),k*Math.sin(t*47.1+1),k*Math.sin(t*53.7+2)]);out.look=V.add(out.look,[k*.6*Math.sin(t*39+3),k*.6*Math.sin(t*71),0]);out.roll+=amp*.012*Math.sin(t*50)}
  return out}

/* ---------- frame build ---------- */
function lightMatrix(R,env,center,E){const L=V.norm(env.sunDir);const eye=V.add(center,V.mul(L,160));let view=M.lookAt(eye,center,Math.abs(L[1])>.97?[0,0,1]:[0,1,0]);
  const sz=2*E/R.SM;const c=M.tp(view,center);const sx=Math.round(c[0]/sz)*sz-c[0],sy=Math.round(c[1]/sz)*sz-c[1];const snap=M.T(sx,sy,0);view=M.mul(snap,view);
  return M.mul(M.ortho(-E,E,-E,E,1,330),view)}
function billboard(view,pos){return new Float32Array([view[0],view[4],view[8],0,view[1],view[5],view[9],0,view[2],view[6],view[10],0,pos[0],pos[1],pos[2],1])}

function renderFrame(C,t,W,H){const R=C.R;const cam=camEval(C,t);const aspect=W/H;
  const view=M.lookAt(cam.pos,cam.look,(()=>{const f=V.norm(V.sub(cam.look,cam.pos));const r=V.norm(V.cross(f,[0,1,0]));const u0=V.cross(r,f);return V.add(V.mul(u0,Math.cos(cam.roll||0)),V.mul(r,Math.sin(cam.roll||0)))})());
  const proj=M.persp(cam.fov*PI/180,aspect,.4,1800);const vp=M.mul(proj,view);const env=C.env;
  const dCam=V.dist(cam.pos,cam.look);const E=clamp(dCam*1.9+14,18,C.world?C.world.extent:60);
  const focus=V.add(cam.look,[0,0,0]);const lvp=lightMatrix(R,env,[focus[0],Math.max(0,focus[1]*.3),focus[2]],E);
  const dyn=[];const frames={};
  for(const id in C.actors){const A=C.actors[id];if(!A.visAt(t))continue;const pos=A.posAt(t),yaw=A.yaw.eval(t),pose=A.pose(t);const sc=A.scale.eval(t)*(1);
    const rootM=M.chain(M.T(pos[0],pos[1],pos[2]),M.Ry(yaw+pose.spin),M.S(sc));const dist=V.dist(cam.pos,pos);
    const fr=A.char.draw(R,rootM,pose,A.exprAt(t),dyn,1,null,dist);frames[id]={fr,pos,yaw,sc}}
  const partsCache=C._pc||(C._pc={});
  for(const id in C.objects){const O=C.objects[id];let vis=O.vis[0].v;for(const e of O.vis)if(e.t<=t)vis=e.v;if(!vis)continue;
    let pos=O.pos.eval(t),yaw=O.yaw.eval(t)+(O.spin?O.spin*t:0),sc=O.scale.eval(t),alpha=O.alpha.eval(t),pitch=O.pitch.eval(t),roll=O.roll.eval(t);
    for(const at of O.attach){if(t>=at.t0&&t<at.t1&&frames[at.actor]){const F=frames[at.actor],fr=F.fr;let m,o=at.off;
      if(at.bone==='head')m=M.chain(fr.neck,M.T(0,1.3,0));else if(at.bone==='back')m=M.chain(fr.hip,M.T(0,1,-.9));else if(at.bone==='handL')m=M.chain(fr.armLM,M.T(0,-1.9,0));else m=M.chain(fr.armRM,M.T(0,-1.9,0));
      pos=M.tp(M.chain(m,M.T(o[0],o[1],o[2])),[0,0,0]);yaw=F.yaw+at.yaw}}
    if(sc<=0.001)continue;
    if(O.bob)pos=V.add(pos,[0,Math.sin(t*(O.bob.rate||2.5))*(O.bob.amp||.6),0]);
    const parts=partsCache[id]||(partsCache[id]=S.Props.parts(O.type,O.opts));const base=M.chain(M.T(pos[0],pos[1],pos[2]),M.Ry(yaw),M.Rx(pitch),M.Rz(roll),M.S(sc));const dist=V.dist(cam.pos,pos);
    for(const p of parts){const pm=M.chain(base,M.T(...p.off),p.rot?M.chain(M.Rx(p.rot[0]),M.Ry(p.rot[1]),M.Rz(p.rot[2])):M.ident());
      const it={mesh:R.primMesh(...p.p),model:pm,size:p.size,color:hex(p.color),emis:p.emis||0,dist};const al=(p.alpha===undefined?1:p.alpha)*alpha;if(al<.999)it.alpha=al;if(p.nofog)it.nofog=true;dyn.push(it)}}
  // signs
  if(C.world)for(const s of C.world.signs){const tex=S.Fx.signTex(R,s);const m=M.chain(M.T(...s.pos),M.Ry(s.yaw||0));dyn.push({mesh:R.quadMesh,model:m,size:[s.size[0],s.size[1],1],tex,color:[1,1,1],unlit:!!s.emis,emis:s.emis||0,noShadow:true,dist:V.dist(cam.pos,s.pos),uv:[0,0,1,1]})}
  // particles
  const soft=S.Fx.softTex(R),star=S.Fx.starTex(R),ring=S.Fx.ringTex(R);
  for(const f of C.fx){const parts=f.parts||(f.parts=S.Fx.make(f.kind,Object.assign({dur:f.dur},f.args),(C.seed*977+Math.floor(f.t*100)+f.kind.length*13)));
    for(const p of parts){let tau,y0=null,pos;
      if(p.loop){if(t<f.t||t>f.t+(f.dur||4))continue;const ph=((t-f.t)/p.life+p.ph)%1;const ctr=cam.look;tau=ph*p.life;const x=ctr[0]+p.p0[0],z=ctr[2]+p.p0[2];pos=[x,p.yfix?p.y0+Math.sin(t+p.ph*9)*.8:p.y0*(1-ph),z]}
      else{tau=t-(f.t+p.t0);if(tau<0||tau>p.life)continue;pos=[f.pos[0]+p.p0[0]+p.v[0]*tau,f.pos[1]+p.p0[1]+p.v[1]*tau+.5*p.g*tau*tau,f.pos[2]+p.p0[2]+p.v[2]*tau]}
      const u=p.loop?0:tau/p.life;const sz=lerp(p.s0,p.s1,u),al=p.loop?p.a0:lerp(p.a0,p.a1,u),col=p.c1?mix(p.c0,p.c1,u):hex(p.c0);const dist=V.dist(cam.pos,pos);
      let it;
      if(p.shape==='cube'){const s3=p.size3?p.size3.map(x=>x*sz/(p.s0||1)):[sz,sz,sz];const m=p.loop?M.T(...pos):M.chain(M.T(...pos),M.Ry(p.rotv*tau),M.Rx(p.rotv*tau*.7));it={mesh:R.primMesh('box'),model:m,size:s3,color:col,emis:p.emis,alpha:al,dist,noShadow:true,additive:false}}
      else if(p.shape==='sphere'){it={mesh:R.primMesh('sphere',12,8),model:M.T(...pos),size:[sz,sz,sz],color:col,emis:1,alpha:al,dist,noShadow:true,additive:p.additive,nofog:true,unlit:true}}
      else if(p.shape==='ringflat'){it={mesh:R.quadMesh,model:M.chain(M.T(pos[0],pos[1]+.25,pos[2]),M.Rx(-PI/2)),size:[sz,sz,1],color:col,tex:ring,alpha:al,dist,noShadow:true,additive:true,unlit:true}}
      else{const tex=p.tex==='star'?star:soft;const bm=billboard(view,pos);const rm=p.rot||p.rotv?M.mul(bm,M.Rz((p.rot||0)+(p.rotv||0)*tau)):bm;it={mesh:R.quadMesh,model:rm,size:[sz,sz,1],color:col,tex,alpha:al,dist,noShadow:true,additive:p.additive,unlit:p.emis>.5,emis:p.emis}}
      dyn.push(it)}}
  // texts
  const overlays=[];
  for(const tx of C.texts){if(t<tx.t0||t>tx.t0+tx.dur)continue;const u=(t-tx.t0)/tx.dur;const tex=S.Fx.textTex(R,tx.text,{color:tx.color,stroke:tx.stroke,bg:tx.bg});
    const popIn=ease('back',clamp((t-tx.t0)/.22)),out=clamp((tx.t0+tx.dur-t)/.15);const k=popIn*out;
    if(tx.style==='title'){const w=tx.size,aspTex=2;const h=w*W/(aspTex*H);overlays.push({rect:[0,tx.y,w*k,h*k],tex,color:[1,1,1,1],rot:0});continue}
    let pos;if(tx.pos)pos=tx.pos;else{const A=C.actors[tx.on],O=C.objects[tx.on];pos=A?A.posAt(t):O?O.pos.eval(t):[0,0,0]}pos=V.add(pos,tx.off);pos=V.add(pos,[0,u*1.2,0]);
    dyn.push({mesh:R.quadMesh,model:billboard(view,pos),size:[tx.size*2*k,tx.size*k,1],tex,color:[1,1,1],alpha:1,dist:V.dist(cam.pos,pos)-1,noShadow:true,unlit:true,nofog:true,uv:[0,0,1,1]})}
  // overlays
  for(const o of C.overlays){if(t<o.t0||t>o.t0+o.dur+.001)continue;const u=(t-o.t0)/o.dur;let a;
    if(o.type==='flash')a=o.a*(1-u)*(1-u);else a=o.dir==='in'?1-u:u;overlays.push({rect:[0,0,1,1],color:[o.color[0],o.color[1],o.color[2],a]})}
  // hold last fade
  for(const o of C.overlays)if(o.type==='fade'&&t>o.t0+o.dur&&o.dir==='out')overlays.push({rect:[0,0,1,1],color:[o.color[0],o.color[1],o.color[2],1]});
  const F={view,proj,vp,lvp,camPos:cam.pos,env,statics:C.mesh?[C.mesh]:[],dyn,overlays,time:t};
  R.render(F);return cam}

/* ---------- validation ---------- */
function validate(C){const issues=[];const add=(sev,type,msg,extra)=>issues.push(Object.assign({scene:C.scene.id,sev,type,msg},extra||{}));
  for(const w of C.warns)add('warn','compile',w);
  const cols=C.world?C.world.colliders:[];const ign=new Set(C.scene.ignoreColliders||[]);
  const step=1/15;const seen={};
  for(let t=0;t<=C.dur;t+=step){
    for(const id in C.actors){const A=C.actors[id];if(!A.visAt(t))continue;const p=A.posAt(t);const sc=A.scale.eval(t)*(A.char.spec.scale||1);
      if(!A.phase)for(const c of cols){if(c.door||ign.has(c.name))continue;if(p[1]+5*sc<c.min[1]||p[1]>c.max[1])continue;if(c.max[1]<.5)continue;
        const cx=clamp(p[0],c.min[0],c.max[0]),cz=clamp(p[2],c.min[2],c.max[2]);const d=Math.hypot(p[0]-cx,p[2]-cz);
        if(d<.55*sc&&!(c.min[1]>p[1]+6*sc)){const key=id+'|'+c.name+'|'+Math.floor(t);if(!seen[key]){seen[key]=1;add('error','wall-clip',`${id} intersects "${c.name}" at t=${t.toFixed(2)}s (pos ${p.map(v=>v.toFixed(1))})`,{actor:id,t,collider:c.name,pos:p})}break}}
      for(const id2 in C.actors){if(id2<=id)continue;const B2=C.actors[id2];if(!B2.visAt(t)||C.scene.allowOverlap)continue;const q=B2.posAt(t);if(Math.hypot(p[0]-q[0],p[2]-q[2])<1.1&&Math.abs(p[1]-q[1])<3){const key='ov|'+id+id2+Math.floor(t);if(!seen[key]){seen[key]=1;add('warn','actor-overlap',`${id} and ${id2} overlap at t=${t.toFixed(2)}s`,{t})}}}}
    const cam=camEval(C,t);for(const c of cols){if(c.door||ign.has(c.name))continue;if(cam.pos[0]>c.min[0]&&cam.pos[0]<c.max[0]&&cam.pos[1]>c.min[1]&&cam.pos[1]<c.max[1]&&cam.pos[2]>c.min[2]&&cam.pos[2]<c.max[2]){const key='cam|'+c.name+Math.floor(t*2);if(!seen[key]){seen[key]=1;add('error','camera-clip',`camera inside "${c.name}" at t=${t.toFixed(2)}s`,{t,collider:c.name})}}}
    if(cam.pos[1]<.2){const key='camg'+Math.floor(t);if(!seen[key]){seen[key]=1;add('warn','camera-ground',`camera below ground at t=${t.toFixed(2)}s`)}}
    // is the camera subject on screen?
    const cut=C.cams.filter(x=>t>=x.t0).pop()||C.cams[0];if(cut.on&&!cut.pos){const ids=Array.isArray(cut.on)&&typeof cut.on[0]==='string'?cut.on:(typeof cut.on==='string'?[cut.on]:[]);
      for(const id of ids){const A=C.actors[id];if(!A||!A.visAt(t))continue;const p=V.add(A.posAt(t),[0,4.6*(A.char.spec.scale||1),0]);const view=M.lookAt(cam.pos,cam.look,[0,1,0]),proj=M.persp(cam.fov*PI/180,9/16,.4,1800);const v=M.tp(M.mul(proj,view),p);const w=(M.mul(proj,view)[3]*p[0]+M.mul(proj,view)[7]*p[1]+M.mul(proj,view)[11]*p[2]+M.mul(proj,view)[15]);
        const nx=v[0]/ (w||1),ny=v[1]/(w||1);if(w<=0||Math.abs(nx)>1.25||Math.abs(ny)>1.25){const key='off|'+id+'|'+cut.t0;if(!seen[key]){seen[key]=1;add('warn','target-offscreen',`${id} is off-screen in the shot starting at ${cut.t0.toFixed(2)}s (t=${t.toFixed(2)}s)`,{t,actor:id})}}}}
  }
  return issues}
S.Director={compileScene,renderFrame,validate,camEval,Track,parseT,planPath};
})(window.Studio);

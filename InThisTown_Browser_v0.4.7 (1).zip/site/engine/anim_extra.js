/* engine/anim_extra.js — +45 procedural clips (v2 quality pack). Same contract as anim.js:
   clip(t,d,p) -> partial pose. Usable in scenes as {"do":"anim","clip":"faint"} etc. */
(function(S){
const {clamp,lerp,ease}=S;const PI=Math.PI,sin=Math.sin,cos=Math.cos,abs=Math.abs;
const C=S.Anim.clips;const u=(t,d)=>d&&isFinite(d)?clamp(t/d):0;
const W=(t,p,hz)=>t*PI*2*hz*(p&&p.speed||1);

/* ---- locomotion variants ---- */
C.sprint=(t,d,p)=>{const ph=W(t,p,3.4),a=1.4;return{lLegX:a*sin(ph),rLegX:-a*sin(ph),lArmX:-1.7*sin(ph),rArmX:1.7*sin(ph),lArmZ:.1,rArmZ:.1,bodyY:.5*abs(sin(ph)),torsoY:.22*sin(ph),lean:.42,headX:-.25}};
C.sneak=(t,d,p)=>{const ph=W(t,p,1.1);return{lLegX:.55*sin(ph),rLegX:-.55*sin(ph),lArmX:.3*sin(ph)+.2,rArmX:-.3*sin(ph)+.2,bodyY:-.7,lLegZ:.1,rLegZ:.1,torsoX:.35,headX:-.2,headY:.5*sin(t*1.4),lean:.1}};
C.tiptoe=(t,d,p)=>{const ph=W(t,p,1.3);return{lLegX:.4*sin(ph),rLegX:-.4*sin(ph),bodyY:.35+.05*abs(sin(ph)),lArmX:.8,rArmX:.8,lArmZ:.6,rArmZ:.6,torsoX:-.05,headY:.3*sin(t*2)}};
C.strut=(t,d,p)=>{const ph=W(t,p,1.5);return{lLegX:.7*sin(ph),rLegX:-.7*sin(ph),lArmX:-.5*sin(ph),rArmX:.5*sin(ph),bodyY:.12*abs(cos(ph)),torsoZ:.14*sin(ph),torsoY:.12*sin(ph),headX:-.12,lArmZ:.25,rArmZ:.25}};
C.limp=(t,d,p)=>{const ph=W(t,p,1.2);return{lLegX:.7*sin(ph),rLegX:-.25*sin(ph),lArmX:-.5*sin(ph),rArmX:.3*sin(ph),bodyY:.1*abs(cos(ph))-.12,roll:.1*sin(ph),torsoX:.18,headX:.2}};
C.tiredwalk=(t,d,p)=>{const ph=W(t,p,1.05);return{lLegX:.45*sin(ph),rLegX:-.45*sin(ph),lArmX:.05+.2*sin(ph),rArmX:.05-.2*sin(ph),torsoX:.4,headX:.5,bodyY:.04*abs(cos(ph))-.1}};
C.drunk=(t,d,p)=>{const ph=W(t,p,1.4);return{lLegX:.55*sin(ph),rLegX:-.55*sin(ph),lArmX:-.6*sin(ph+1),rArmX:.6*sin(ph),roll:.28*sin(t*2.2),torsoZ:.25*sin(t*2.9),headZ:.35*sin(t*2.2+1),lean:.1*sin(t*1.7),bodyY:.1*abs(cos(ph)),headY:.5*sin(t*1.3)}};
C.zombiewalk=(t,d,p)=>{const ph=W(t,p,.9);return{lLegX:.5*sin(ph),rLegX:-.5*sin(ph),lArmX:1.5+.1*sin(ph),rArmX:1.5-.1*sin(ph),lArmZ:-.05,rArmZ:-.05,torsoX:.15,headX:.35,headZ:.18*sin(t*1.5),bodyY:.06*abs(cos(ph)),torsoY:.12*sin(ph)}};
C.sleepwalk=(t,d,p)=>({...C.zombiewalk(t,d,{speed:.7}),headX:.15,lArmX:1.57,rArmX:1.57});
C.moonwalk=(t,d,p)=>{const ph=W(t,p,1.5);return{lLegX:-.55*sin(ph),rLegX:.55*sin(ph),lArmX:.6*sin(ph),rArmX:-.6*sin(ph),bodyY:.1*abs(cos(ph)),lean:-.1}};
C.crawl=(t,d,p)=>{const ph=W(t,p,1.2);return{lean:1.45,bodyY:-1.6,lArmX:3.0*.5+.8*sin(ph),rArmX:3.0*.5-.8*sin(ph),lLegX:.7*sin(ph+PI),rLegX:.7*sin(ph),headX:-1}};
C.swim=(t,d,p)=>{const ph=W(t,p,1.1);return{lean:1.35,bodyY:-.4+.1*sin(ph),lArmX:3.0*abs(sin(ph*.5))+sin(ph*.5)*1.6,rArmX:3.0*abs(cos(ph*.5))-cos(ph*.5)*1.6,lLegX:.4*sin(ph*3),rLegX:-.4*sin(ph*3),headX:-.9}};
C.surf=(t)=>({bodyY:-.55,lLegX:.35,rLegX:-.35,lLegZ:.55,rLegZ:.55,lArmZ:1.1+.2*sin(t*2),rArmZ:1.1-.2*sin(t*2),torsoY:.9,roll:.14*sin(t*1.7),torsoX:.12});
C.ride=(t)=>({bodyY:-.5,lLegX:.9+.3*sin(t*5),rLegX:.9-.3*sin(t*5),lArmX:1.45,rArmX:1.45,torsoX:.2});
C.drive=(t)=>({bodyY:-.8,lLegX:1.57,rLegX:1.57,lArmX:1.45,rArmX:1.45,lArmZ:.1,rArmZ:.1,torsoX:-.05,headY:.1*sin(t*.9),torsoZ:.02*sin(t*3)});
C.skate=(t)=>({bodyY:-.35,lLegX:.35,rLegX:-.2,lLegZ:.35,rLegZ:.3,lArmZ:.9,rArmZ:.7,torsoY:.7,lean:.1,roll:.05*sin(t*3)});

/* ---- acrobatics ---- */
C.backflip=(t,d)=>{const k=u(t,d||.9);return{bodyY:3.4*sin(k*PI),lean:-PI*2*ease('inout',k),lArmX:2.4*sin(k*PI),rArmX:2.4*sin(k*PI),lLegX:1.2*sin(k*PI),rLegX:1.2*sin(k*PI)}};
C.frontflip=(t,d)=>{const k=u(t,d||.9);return{bodyY:3.4*sin(k*PI),lean:PI*2*ease('inout',k),lArmX:2.4*sin(k*PI),rArmX:2.4*sin(k*PI),lLegX:1.4*sin(k*PI),rLegX:1.4*sin(k*PI)}};
C.cartwheel=(t,d)=>{const k=u(t,d||.9);return{roll:PI*2*k,bodyY:1.4*sin(k*PI),lArmZ:3.1,rArmZ:3.1,lLegZ:1.2,rLegZ:1.2}};
C.superjump=(t,d)=>{const k=u(t,d||1.2);const air=sin(k*PI);return{bodyY:7*air,lArmX:3.0*air,rArmX:3.0*air,lArmZ:.2,rArmZ:.2,lLegX:.5*air,rLegX:-.3*air,sy:1+.25*air*(k>.2?1:0),sx:1-.1*air,lean:.15*air}};
C.dive=(t,d)=>{const k=u(t,d||.8);return{lean:1.2*ease('out',k),bodyY:1.2*sin(k*PI),lArmX:3.0,rArmX:3.0,lLegX:-.3,rLegX:-.3,headX:-.5}};
C.slip=(t,d)=>{const k=u(t,d||.8);return{lean:-1.0*sin(k*PI)-.45*k,bodyY:1.6*sin(k*PI),lArmZ:2.4*sin(k*PI),rArmZ:2.4*sin(k*PI),lArmX:1.3*sin(k*PI),lLegX:1.2*sin(k*PI),rLegX:-.4*sin(k*PI)}};
C.bounce=(t,d,p)=>{const f=(p&&p.rate)||2.2,k=abs(sin(t*PI*f));return{bodyY:2.2*k,sy:1+.12*k-.1*(1-k)*(k<.15?1:0),lArmZ:.8*k,rArmZ:.8*k}};
C.float=(t)=>({bodyY:1.6+.4*sin(t*1.8),lArmZ:.7+.1*sin(t*1.8),rArmZ:.7+.1*sin(t*1.8),lLegX:.15*sin(t*1.8),rLegX:-.1*sin(t*1.8),headX:.06*sin(t*1.8),roll:.05*sin(t*1.2)});

/* ---- emotes / reactions ---- */
C.faint=(t,d)=>{const k=u(t,d||1.1);const e=ease('in',k);return{lean:-1.5*e,bodyY:-1.45*e,lArmZ:1.4*(1-e)+.2,rArmZ:1.4*(1-e)+.2,lArmX:.4*(1-e),headX:.6*e,roll:.15*sin(k*PI)}};
C.dizzy=(t)=>({torsoZ:.2*sin(t*5),headZ:.35*sin(t*5+1),roll:.12*sin(t*3.3),headY:.7*sin(t*2.5),lArmX:.3*sin(t*4),rArmX:-.3*sin(t*4),lArmZ:.5,rArmZ:.5,bodyY:.05*sin(t*5)});
C.shiver=(t)=>({torsoZ:.05*sin(t*60),bodyY:.04*sin(t*55),lArmX:1.2,rArmX:1.2,lArmZ:-.3,rArmZ:-.3,torsoX:.2,headX:.1,lLegZ:-.05,rLegZ:-.05});
C.tremble=(t)=>({torsoZ:.03*sin(t*70),bodyY:.03*sin(t*65),lArmX:.5,rArmX:.5,lArmZ:.3,rArmZ:.3,headX:-.1});
C.jumpscare=(t,d)=>{const k=u(t,d||.5);const a=ease('out',clamp(k*3));return{lean:-.55*a,bodyY:1.4*sin(clamp(k*2)*PI)*.7,lArmZ:2.4*a,rArmZ:2.4*a,lArmX:.6*a,rArmX:.6*a,headX:-.4*a,sy:1+.12*a,sx:1-.06*a,lLegZ:.4*a,rLegZ:.4*a}};
C.facepalm=(t)=>({rArmX:2.5,rArmZ:-.6,headX:.35,torsoX:.18,lArmX:.1,bodyY:-.04});
C.nod=(t,d,p)=>({headX:.32*sin(t*PI*2*(p&&p.rate||2.2)),lArmX:.05});
C.headshake=(t,d,p)=>({headY:.55*sin(t*PI*2*(p&&p.rate||2.8)),lArmX:.05});
C.shy=(t)=>({torsoX:.15,headX:.35,headZ:.15,lArmX:.5,rArmX:.5,lArmZ:-.2,rArmZ:-.2,lLegZ:-.05,rLegZ:-.05,torsoY:.2*sin(t*1.8),bodyY:.04*sin(t*3)});
C.proud=(t)=>({torsoX:-.12,headX:-.2,lArmX:.3,rArmX:.3,lArmZ:.55,rArmZ:.55,bodyY:.04*sin(t*3),lLegZ:.1,rLegZ:.1});
C.flex=(t)=>({lArmZ:1.57,rArmZ:1.57,lArmX:.1,rArmX:.1,torsoX:-.1,headX:-.1,bodyY:.1*abs(sin(t*6)),sx:1.04});
C.victory=(t)=>({lArmX:3.0,rArmX:3.0,lArmZ:.7,rArmZ:.7,headX:-.3,bodyY:.5*abs(sin(t*5)),lLegZ:.25,rLegZ:.25,torsoX:-.1});
C.dab=()=>({lArmX:2.5,lArmZ:-.2,rArmX:1.5,rArmZ:.9,headX:.4,headY:-.4,torsoX:.2});
C.heart_hands=(t)=>({lArmX:2.7,rArmX:2.7,lArmZ:-.55,rArmZ:-.55,headZ:.1*sin(t*3),bodyY:.06*abs(sin(t*4)),headX:-.1});
C.shush=()=>({rArmX:2.5,rArmZ:-.55,headX:.05,lArmX:.1});
C.listen=(t)=>({rArmX:2.1,rArmZ:.7,headZ:-.25,headY:-.3,lArmX:.05,torsoZ:.04*sin(t*2)});
C.scratchhead=(t)=>({rArmX:3.0,rArmZ:-.2+.15*sin(t*9),headZ:.12,headX:.05,lArmX:.05,bodyY:.02*sin(t*5)});
C.knock=(t)=>({rArmX:1.6+.3*sin(t*14)*(sin(t*3)>0?1:0),rArmZ:.05,lArmX:.1,torsoX:.05});
C.phone=(t)=>({rArmX:1.9,rArmZ:-.2,lArmX:.15,headX:.45,torsoX:.12,headY:.05*sin(t*1.7),bodyY:.02*sin(t*3)});
C.typing=(t)=>({lArmX:1.45+.1*sin(t*21),rArmX:1.45+.1*sin(t*19+1),lArmZ:-.05,rArmZ:-.05,headX:.3,torsoX:.15});
C.eat=(t)=>({rArmX:1.8+.9*abs(sin(t*3.2)),rArmZ:-.15,headX:.1*sin(t*6.4),lArmX:.1,bodyY:.02*sin(t*6.4)});
C.yawn=(t,d)=>{const k=sin(u(t,d||1.6)*PI);return{lArmX:.3+2.2*k,lArmZ:.6*k+.08,rArmX:.3+2.2*k,rArmZ:.6*k+.08,headX:-.5*k,torsoX:-.1*k,bodyY:.1*k}};
C.stretch=(t,d)=>{const k=sin(u(t,d||1.6)*PI);return{lArmX:3.0*k,rArmX:3.0*k,lArmZ:.3*k+.08,rArmZ:.3*k+.08,headX:-.4*k,torsoX:-.25*k,bodyY:.15*k}};
C.reach=(t)=>({rArmX:1.57,lArmX:.1,torsoX:.25,lean:.12,rLegX:-.2,lLegX:.3});
C.pickup=(t,d)=>{const k=sin(u(t,d||1)*PI);return{torsoX:1.05*k,lArmX:.8*k,rArmX:.8*k,bodyY:-.5*k,lLegX:.5*k,rLegX:.5*k,headX:-.3*k}};
C.throw=(t,d)=>{const k=u(t,d||.7);const w=k<.45?ease('out',k/.45):1-ease('in',(k-.45)/.55);const f=k>.4&&k<.7?sin((k-.4)/.3*PI):0;return{rArmX:k<.45?-1.2*w:3.0*f-.2,torsoY:.5*w-.9*f,lArmX:.8*w,lLegX:.3*w,rLegX:-.3*f,lean:.1*f}};
C.catch=(t)=>({lArmX:1.57,rArmX:1.57,lArmZ:-.15,rArmZ:-.15,torsoX:.1,bodyY:.05*abs(sin(t*10))});
C.push=(t,d,p)=>{const ph=W(t,p,1.4);return{lArmX:1.57,rArmX:1.57,lean:.4,lLegX:.5*sin(ph),rLegX:-.5*sin(ph),bodyY:.08*abs(cos(ph)),lArmZ:-.05,rArmZ:-.05}};
C.pull=(t,d,p)=>{const ph=W(t,p,1.2);return{lArmX:1.5,rArmX:1.5,lean:-.35,lLegX:-.45*sin(ph),rLegX:.45*sin(ph),torsoX:-.1}};
C.boxing=(t)=>{const a=sin(t*9);return{lArmX:1.3+(a>0?a*.8:0),rArmX:1.3+(a<0?-a*.8:0),lArmZ:-.2,rArmZ:-.2,bodyY:.12*abs(sin(t*4.5))-.15,lLegX:.35*sin(t*4.5),rLegX:-.35*sin(t*4.5),torsoY:.3*sin(t*9),lLegZ:.12,rLegZ:.12}};
C.karate=(t,d)=>{const k=sin(u(t,d||.7)*PI);return{rLegX:1.55*k,lArmX:1.0*k,rArmX:-.2*k,lean:-.25*k,torsoX:-.15*k,bodyY:.2*k}};
C.kneel=(t)=>({bodyY:-1.0,lLegX:1.57,rLegX:-.3,lArmX:.4,rArmX:.4,torsoX:.1,headX:.1});
C.worship=(t)=>({bodyY:-.95,lLegX:1.1,rLegX:1.1,lArmX:3.0,rArmX:3.0,lArmZ:.3,rArmZ:.3,headX:-.5,torsoX:-.12});
C.beg=(t)=>({bodyY:-.9,lLegX:1.2,rLegX:1.2,lArmX:1.9+.12*sin(t*6),rArmX:1.9+.12*sin(t*6),lArmZ:-.25,rArmZ:-.25,headX:.1,torsoX:.15});
C.sobsit=(t)=>({bodyY:-.85,lLegX:1.57,rLegX:1.57,lArmX:2.3,rArmX:2.3,lArmZ:-.5,rArmZ:-.5,headX:.55,torsoX:.35,torsoZ:.05*sin(t*12),bodyY2:0});
C.peek=(t,d)=>{const k=sin(u(t,d||1.2)*PI);return{lean:.0,headZ:.45*k,torsoZ:.18*k,roll:.12*k,lArmX:.4*k,lArmZ:.3*k+.08,headY:.3*k}};
C.robot=(t)=>{const s=Math.floor(t*4)%4;return{lArmX:[1.57,0,1.57,0][s],rArmX:[0,1.57,0,1.57][s],lArmZ:.08,rArmZ:.08,headY:[0,.8,0,-.8][s],torsoY:[0,.3,0,-.3][s]}};
C.wave_big=(t)=>({rArmZ:3.0+.4*sin(t*11),rArmX:.2,lArmZ:3.0+.4*sin(t*11+PI),lArmX:.2,headZ:.1*sin(t*5.5),bodyY:.08*abs(sin(t*5.5))});
C.hug=(t)=>({lArmX:1.3,rArmX:1.3,lArmZ:-.5,rArmZ:-.5,torsoX:.12,headZ:.15});
C.cheer2=(t)=>({lArmX:3.0,rArmX:2.4,lArmZ:.3+.15*sin(t*9),rArmZ:.45,bodyY:.8*abs(sin(t*6)),headX:-.2,lLegX:.35*sin(t*6),rLegX:-.35*sin(t*6),torsoZ:.1*sin(t*6)});
C.rage=(t)=>({lArmX:.8+.3*sin(t*24),rArmX:.8-.3*sin(t*24),lArmZ:.55,rArmZ:.55,torsoX:.2,headX:.15,bodyY:.1*abs(sin(t*24)),sy:1.03,torsoZ:.1*sin(t*30),lLegZ:.2,rLegZ:.2});
C.explode=(t,d)=>{const k=u(t,d||.4);return{sx:1+1.2*k*k,sy:1+1.2*k*k,sz:1+1.2*k*k,lArmZ:1.6,rArmZ:1.6,bodyY:.5*k}};
C.shrink=(t,d)=>{const k=ease('in',u(t,d||.6));return{sx:1-.9*k,sy:1-.9*k,sz:1-.9*k,spin:PI*4*k}};
C.melt=(t,d)=>{const k=ease('in',u(t,d||1.2));return{sy:1-.8*k,sx:1+.5*k,sz:1+.5*k,lArmZ:.8*(1-k)+.2,rArmZ:.8*(1-k)+.2}};
C.glitch=(t)=>{const s=Math.floor(t*14);const r=(Math.sin(s*12.9898)*43758.5453)%1;return{torsoY:r*.6,headY:-r*.8,lArmX:r*3,rArmX:-r*2,sx:1+(r>.6?.25:0),roll:r*.15}};
S.Anim.extraNames=['sprint','sneak','tiptoe','strut','limp','tiredwalk','drunk','zombiewalk','sleepwalk','moonwalk','crawl','swim','surf','ride','drive','skate','backflip','frontflip','cartwheel','superjump','dive','slip','bounce','float','faint','dizzy','shiver','tremble','jumpscare','facepalm','nod','headshake','shy','proud','flex','victory','dab','heart_hands','shush','listen','scratchhead','knock','phone','typing','eat','yawn','stretch','reach','pickup','throw','catch','push','pull','boxing','karate','kneel','worship','beg','sobsit','peek','robot','wave_big','hug','cheer2','rage','explode','shrink','melt','glitch'];
})(window.Studio);

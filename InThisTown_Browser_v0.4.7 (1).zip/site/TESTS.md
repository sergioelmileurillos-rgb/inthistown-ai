# v0.4.7 test checklist

- [x] JavaScript syntax: `app.js` and `kokoro-worker.js` checked with Node.
- [x] ZIP integrity checked after packaging.
- [x] Local-file guard removed; local mode now starts an embedded Blob module worker.
- [x] HTTPS mode continues to use `kokoro-worker.js`.
- [x] Service-worker cache key incremented to v4-7.
- [x] Original WebGL2 engine module set retained; `engine/api.js` remains the browser canvas adapter.
- [ ] Real Chromebook test of the Blob module worker from an extracted `file://` folder.
- [ ] Real Kokoro model download and inference on the Chromebook.
- [ ] End-to-end 3D video export on the Chromebook.

The three unchecked items require a real Chromebook/browser environment.

/* In This Town — Kokoro-82M worker.
 * Runs WASM inference away from the browser UI thread so low-power Chromebooks
 * can keep the page responsive while narration is generated.
 */
'use strict';

const KOKORO_MODULE_URL = 'https://cdn.jsdelivr.net/npm/kokoro-js@1.2.1/dist/kokoro.web.js';
const MODEL_ID = 'onnx-community/Kokoro-82M-v1.0-ONNX';
let tts = null;
let loading = null;

function postError(id, phase, error) {
  const message = error && typeof error === 'object'
    ? (error.message || error.name || JSON.stringify(error))
    : String(error);
  self.postMessage({ type: 'error', id: id ?? null, phase, message, stack: error?.stack || '' });
}

async function loadModel() {
  if (tts) return tts;
  if (loading) return loading;
  loading = (async () => {
    self.postMessage({ type: 'progress', message: 'Cargando Kokoro dentro de un proceso separado…', progress: 8 });
    const mod = await import(KOKORO_MODULE_URL);
    if (!mod.KokoroTTS) throw new Error('La compilación de Kokoro no expone KokoroTTS.');
    tts = await mod.KokoroTTS.from_pretrained(MODEL_ID, {
      dtype: 'q8',
      device: 'wasm',
      progress_callback: (event) => {
        const loaded = Number(event?.loaded || 0);
        const total = Number(event?.total || 0);
        const file = event?.file || event?.name || event?.path || 'modelo';
        if (total > 0) {
          const pct = Math.round(10 + Math.min(1, loaded / total) * 14);
          self.postMessage({
            type: 'progress',
            message: `Descargando Kokoro (${file}) · ${Math.round(loaded / 1048576)} / ${Math.round(total / 1048576)} MB…`,
            progress: pct,
          });
        } else if (event?.status) {
          self.postMessage({ type: 'progress', message: `Preparando Kokoro (${file}) · ${event.status}…`, progress: 12 });
        }
      },
    });
    if (typeof tts.generate !== 'function') throw new Error('Kokoro se ha cargado, pero no ofrece generate().');
    self.postMessage({ type: 'ready', message: 'Kokoro está listo en segundo plano.' });
    return tts;
  })();
  try {
    return await loading;
  } catch (error) {
    tts = null;
    loading = null;
    throw error;
  }
}

self.addEventListener('message', async (event) => {
  const data = event.data || {};
  if (data.type === 'load') {
    try { await loadModel(); }
    catch (error) { postError(null, 'carga de Kokoro', error); }
    return;
  }
  if (data.type === 'generate') {
    try {
      const model = await loadModel();
      const result = await model.generate(String(data.text || ''), {
        voice: data.voice || 'am_adam',
        speed: Number(data.speed || 0.96),
      });
      const audio = result?.audio instanceof Float32Array
        ? result.audio
        : (result?.audio?.audio instanceof Float32Array ? result.audio.audio : null);
      if (!audio || !audio.length) throw new Error('Kokoro no ha devuelto muestras de audio.');
      const sampleRate = result?.sampling_rate || result?.sample_rate || result?.audio?.sampling_rate || 24000;
      self.postMessage({ type: 'audio', id: data.id, audio, sampleRate }, [audio.buffer]);
    } catch (error) {
      postError(data.id, 'generación de voz', error);
    }
  }
});

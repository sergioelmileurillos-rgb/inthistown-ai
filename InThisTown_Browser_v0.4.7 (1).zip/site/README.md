# In This Town — Browser v0.4.7

Browser-first version that preserves the user's original Roblox Story Studio WebGL2 engine and builds vertical videos locally in the browser.

## Run
Preferred: serve the `site/` folder over HTTPS or localhost.

Direct Chromebook test: extract the ZIP first, then open `site/index.html` from the extracted folder. The app creates an embedded Blob module worker for Kokoro in `file://` mode, so GitHub Pages is not required for the local test. Keep an internet connection for the first model download. If ChromeOS blocks the remote module/model fetch from a local-file origin, use HTTPS hosting instead.

## Voice
- Runtime: browser build of `kokoro-js@1.2.1` from jsDelivr.
- Model: `onnx-community/Kokoro-82M-v1.0-ONNX`.
- Voice: `am_adam` (American English male).
- Runtime mode: documented `q8` quantization with WASM for compatibility across Chromebooks and mobile devices.
- First use downloads model and voice assets from Hugging Face. The app reports download progress.

## Music
The app includes locally synthesized ambient fallback music. An optional audio picker can mix a locally selected soundtrack file into the export. Commercial recordings are not bundled.

## Compatibility and limits
Requires WebGL2, MediaRecorder, canvas captureStream, Web Audio and a modern HTTPS browser. MP4 is selected only if the browser supports it; otherwise the export is WebM. Model inference and video rendering happen on-device and depend on available memory and hardware.

The `file://` Blob worker, live Kokoro download and complete Chromebook render still need a real-device test; see `TESTS.md`.

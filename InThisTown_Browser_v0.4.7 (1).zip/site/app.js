/* In This Town — original procedural WebGL2 engine + browser story composition, Kokoro-82M TTS and MediaRecorder. */
(() => {
  'use strict';
  const $ = id => document.getElementById(id);
  const FPS = 24, W = 576, H = 1024;
  const KOKORO_MODEL = 'onnx-community/Kokoro-82M-v1.0-ONNX';
  const KOKORO_VOICE = 'am_adam';
  // Official browser build declared by kokoro-js' jsDelivr package metadata.
  // Pin the version to avoid silent upstream changes.
  const KOKORO_MODULE_URL = 'https://cdn.jsdelivr.net/npm/kokoro-js@1.2.1/dist/kokoro.web.js';
  const state = {busy:false,cancel:false,mode:'unavailable',engine:null,worker:null,workerReady:null,workerPending:new Map(),workerSeq:0,story:null,musicFile:null,stage:'inicio'};
  const glCanvas = $('gl'), outCanvas = $('out'), outCtx = outCanvas.getContext('2d',{alpha:false});
  const worldSet = ['city','suburb','school','park','townhall','room','city','crowd'];
  const anims = ['think','point','walk','shock','run','cheer','scared','lookAround','shrug','panic','wave','talk','jump','angry','laugh','fall','clap','idle'];
  let jobUrl = null;

  const setStatus = (text, progress) => {
    $('status').textContent = text;
    if (progress !== undefined) $('bar').style.width = Math.max(0,Math.min(100,progress))+'%';
  };
  const setBusy = value => {
    state.busy=value; $('create').disabled=value || state.mode!=='webgl'; $('create').textContent=value?'CREANDO TU VÍDEO…':'✦ CREAR MI VÍDEO';
  };
  const escapeText = s => String(s).replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
  $('idea').addEventListener('input',()=>{$('count').textContent=$('idea').value.length+' / 300';});
  document.querySelectorAll('.example').forEach(b=>b.addEventListener('click',()=>{$('idea').value=b.dataset.idea;$('count').textContent=$('idea').value.length+' / 300';$('idea').focus();}));
  $('musicFile')?.addEventListener('change',e=>{
    const f=e.target.files?.[0]||null;state.musicFile=f;
    $('musicName').textContent=f?`Pista seleccionada: ${f.name}`:'Sin pista propia · música ambiental original';
  });
  $('clearMusic')?.addEventListener('click',()=>{
    state.musicFile=null;if($('musicFile'))$('musicFile').value='';
    $('musicName').textContent='Sin pista propia · música ambiental original';
  });

  function initRenderer(){
    try {
      if (!window.Studio?.api) throw new Error('No se han cargado los módulos del motor 3D original.');
      const info=Studio.api.init(W,H,{SM:1024});
      state.mode='webgl';
      $('engineBadge').textContent='Motor 3D original activo';
      $('engineBadge').style.color='var(--green)';
      $('create').disabled=false;
      return info;
    } catch(e) {
      state.mode='unavailable';
      $('engineBadge').textContent='WebGL 2 no disponible';
      $('engineBadge').style.color='var(--amber)';
      $('create').disabled=true;
      console.error('No se pudo iniciar el motor 3D original:',e);
      setStatus('Este navegador no ha podido iniciar WebGL 2. Actualiza Chrome y activa la aceleración gráfica. No se generará un vídeo 2D de sustitución.');
      return null;
    }
  }

  function classify(rule){
    const r=rule.toLowerCase();
    if (/window|outside|look out|look outside|look at|see|mirror|reflection|eyes/.test(r)) return 'vision';
    if (/door|open|closed|lock/.test(r)) return 'door';
    if (/lie|lying|truth|honest|false/.test(r)) return 'lie';
    if (/walk|backward|backwards|run|move|step/.test(r)) return 'movement';
    if (/speak|talk|say|word|voice|whisper|silent|silence/.test(r)) return 'speech';
    if (/laugh|smile|yawn|sneeze|sing|dance/.test(r)) return 'body';
    if (/sleep|dream|night|midnight|dark/.test(r)) return 'night';
    return 'general';
  }
  function makeNarration(rule,tone,length){
    const kind=classify(rule);
    const first=rule.match(/^in this town\b/i)?rule.replace(/[.!?]+$/,'')+'.':'In this town, '+rule.replace(/^[.!?\s]+|[.!?]+$/g,'')+'.';
    let lines;
    if(kind==='vision') lines=[first,'Everyone kept their curtains closed.','But Max found a tiny loophole.','He placed a mirror by the window.','Now he could watch the street.','His neighbour copied the trick.','Soon, mirrors covered every house.','The mayor spotted the reflections.','He opened the town rulebook.','Reflections counted as looking too.','Every mirror turned toward Max.','He hid behind his sofa.','But his phone was still recording.','The mayor found him instantly.','Then the street lights went dark.','Nobody could see the mayor either.','Max became the new night guard.','His first shift started at midnight.','He had to watch every window.','And he was not allowed to look.'];
    else if(kind==='door') lines=[first,'Everyone checked every lock twice.','But Max had a clever plan.','He sent a tiny robot first.','The robot opened the front door.','Max followed without touching it.','His neighbour copied the trick.','Soon, robots filled the streets.','The mayor came to investigate.','He checked the town rulebook.','It mentioned helpers and machines.','The robot counted as Max.','Every door slammed shut at once.','Max tried to hide in town hall.','But the robot followed him inside.','The mayor smiled and closed the book.','Max had one last door to open.','It was the door to his own room.','He asked the robot to do it.','The robot refused.'];
    else if(kind==='lie') lines=[first,'Nobody dared to tell a story.','But Max found a loophole.','He asked a parrot to speak.','The parrot repeated his lie.','Max thought he was safe.','His neighbour bought a parrot too.','Soon, the whole town had birds.','The mayor called an emergency meeting.','He read the final sentence aloud.','Repeating a lie still counted.','Every parrot started squawking.','Max tried to tell the truth.','But nobody believed him anymore.','The mayor handed him a microphone.','The whole town went quiet.','Max finally told the truth.','The parrot repeated the old lie.','And the rule started all over again.'];
    else if(kind==='movement') lines=[first,'Everyone moved very carefully.','But Max found a loophole.','He sat on a rolling chair.','Technically, his feet never moved.','His neighbour copied the idea.','Soon, chairs rolled everywhere.','The mayor blocked the main street.','Max brought out a tiny scooter.','The rulebook had one more line.','Wheels counted as moving too.','Every scooter stopped at once.','Max tried to run away.','But he had forgotten the rule.','The mayor pointed at his feet.','The whole town started laughing.','Max sat down again.','His chair rolled into town hall.','And he became the new mayor.'];
    else if(kind==='speech') lines=[first,'The town became completely silent.','But Max had a loophole.','He recorded his voice yesterday.','Then he played it through a speaker.','His neighbour copied the trick.','Soon, speakers filled the town.','The mayor heard the noise.','He checked the rulebook again.','Recorded voices counted as speaking.','Every speaker switched on at once.','Max tried to unplug them.','But the speakers kept replaying.','The mayor finally found the switch.','The whole town went silent.','Max had one last message.','He pressed play by mistake.','It was the mayor saying hello.','And nobody could answer back.'];
    else if(kind==='night') lines=[first,'Everyone stayed awake until sunrise.','But Max found a loophole.','He built a tiny sleeping robot.','The robot watched over his room.','Max finally relaxed for a moment.','His neighbour ordered one too.','Soon, robots filled every house.','The mayor came to inspect them.','He opened the rulebook slowly.','Robots counted as their owners.','Every robot started waving.','Max tried to switch his off.','But it had learned his schedule.','The mayor read the final line.','Owners had to stay awake too.','Max checked the clock.','Sunrise was still six hours away.','He wished he had stayed awake.'];
    else if(kind==='body') lines=[first,'Nobody wanted to break the rule.','But Max found a loophole.','He used a puppet to test it.','The puppet did it perfectly.','His neighbour copied the trick.','Soon, puppets filled the town.','The mayor noticed the crowd.','He checked the tiny print.','Puppets counted as their owners.','Every puppet turned toward Max.','He tried to put his away.','But the puppet waved at the mayor.','The mayor wrote one new rule.','No more puppets after sunset.','Max packed his puppet carefully.','It gave one final wave.','The whole town waved back.'];
    else lines=[first,'Everyone obeyed the strange rule.','Until Max found a loophole.','He asked his neighbour to test it.','The trick worked perfectly.','So Max tried it at school.','Then he tried it downtown.','Soon, everyone copied him.','The mayor noticed the chaos.','He brought out the official rulebook.','There was one hidden sentence.','The rule applied to loopholes too.','Max tried to undo his trick.','But the town had copied it.','The mayor called one final meeting.','Everyone waited for Max to speak.','He had to follow his own rule.','And the first person caught was Max.'];
    if(tone==='funny') lines=lines.map((x,i)=> i===1?'The town took it VERY seriously.':i===2?'But Max was not impressed.':i===Math.floor(lines.length*.7)?'The mayor arrived wearing a huge hat.':x);
    if(tone==='suspense') lines=lines.map((x,i)=> i===1?'Nobody knew who made the rule.':i===2?'Then Max heard a strange sound.':i===Math.floor(lines.length*.75)?'Someone was already waiting inside.':x);
    if(length==='short') lines=lines.slice(0,16);
    return lines;
  }

  function buildStory(idea,tone,length){
    let raw=idea.trim().replace(/\s+/g,' ');
    if(!raw) throw new Error('Escribe primero una regla para el pueblo.');
    const lead=raw.match(/^in this town\s*,?\s*(.*)$/i);
    const rule=lead&&lead[1]?lead[1].replace(/[.!?]+$/,''):raw.replace(/[.!?]+$/,'');
    const lines=makeNarration(raw,tone,length);
    const slug='town-'+Date.now().toString(36);
    const chars={hero:{preset:'hero'},neighbor:{preset:'boy2'},mayor:{preset:'mayor'}};
    const scenes=lines.map((vo,i)=>{
      const last=i===lines.length-1, twist=i>=lines.length-5, world=worldSet[(i+(tone==='funny'?2:0))%worldSet.length];
      const heroAnim= i===0?'lookAround':i<4?'think':i%7===0?'run':i%5===0?'shock':i%3===0?'point':'talk';
      const neighborAnim=i===0?'scared':i%4===0?'shock':i%3===0?'wave':'idle';
      const mayorAnim=twist?'angry':i%3===0?'walk':'point';
      const actors={hero:{pos:[0,0,16],yawDeg:i%2?15:-8,face:twist?'worried':'smile'},neighbor:{pos:[-6,0,19],yawDeg:25,face:i===0?'scared':'shock'}};
      if(i>=8||i%6===4) actors.mayor={pos:[6,0,18],yawDeg:190,face:twist?'angry':'neutral'};
      const actions=[{actor:'hero',at:0,do:'anim',clip:heroAnim,dur:Math.max(1.2,vo.split(' ').length*.28)},{actor:'neighbor',at:0,do:'anim',clip:neighborAnim,dur:1.5}];
      if(actors.mayor) actions.push({actor:'mayor',at:.15,do:'anim',clip:mayorAnim,dur:1.4});
      const fxKind=tone==='funny'?'confetti':(tone==='suspense'?'smoke':'embers');
      if(i===0||last||twist) actions.push({do:'fx',kind:i===0?'sparkle':fxKind,at:.35,dur:1.5,on:'hero'});
      if(i===0) actions.push({do:'title',text:'ONE RULE. NO EXCEPTIONS.',at:.12,dur:1.25,size:1.05,style:'title'});
      if(i===lines.length-4) actions.push({do:'shake',at:.3,dur:.55,amp:.65});
      const propByKind={vision:['windowframe','camera_video','phone'],door:['door','doorknob','robot'],lie:['bird','phone','sign'],movement:['skateboard','chair','trafficlight'],speech:['speaker','megaphone','microphone'],night:['digitalclock','lamp','robot'],body:['balloon','tv','giftbox'],general:['warningsign','billboard','phone']};
      const props=propByKind[classify(rule)]||propByKind.general;
      const prop=props[i%props.length];
      const objects=[{id:'storyProp',type:prop,pos:[i%2?5:-5,0,10],yawDeg:i%2?18:-18,scale:prop==='windowframe'?1.35:1,opts:{color:i%2?'#e5b85c':'#79a8d9'}}];
      const shot=i===0?'wide':(i%4===0?'close':(twist?'low':'medium'));
      const cam=[
        {at:0,shot,on:actors.mayor&&twist?['hero','mayor']:'hero',move:i===0?'crane':'push',amount:i===0?.35:.2},
        {at:Math.max(.55,vo.split(' ').length*.075),shot:i%2?'close':'medium',on:i%3===0?'hero':(actors.mayor?'mayor':'neighbor'),move:i%2?'orbit':'dolly',deg:28,amount:.16},
        {at:Math.max(1.05,vo.split(' ').length*.145),shot:twist?'low':(last?'extreme':'over'),on:last?'hero':(actors.mayor?'mayor':'hero'),move:twist?'pull':'push',amount:.14}
      ];
      return {id:'s'+(i+1),vo,sky:twist?(tone==='funny'?'sunset':'night'):(i%5===0?'sunset':'day'),world:[{type:world, ...(world==='city'?{landmark:'ODD TOWN'}:world==='room'?{kind:'living'}:{})}],actors,objects,actions,cam,dur:3,seed:17+i};
    });
    return {title:'The town where '+rule.slice(0,65),slug,rule,seed:29,look:tone==='funny'?'candy':tone==='suspense'?'night':'horror',music:{mood:tone==='funny'?'quirky':tone==='suspense'?'suspense':'spooky',twist_at:'last',twist_mood:'tense',volume:.18},subtitles:{style:'goopie',size:112},defaults:{sky:'day',world:[{type:'city'}]},characters:chars,scenes};
  }

  // Embedded copy for extracted file:// copies. This avoids fetching a sibling
  // worker file from the ZIP/local-file origin. WASM inference stays off the UI thread.
  function inlineKokoroWorker(){
    const KOKORO_MODULE_URL='https://cdn.jsdelivr.net/npm/kokoro-js@1.2.1/dist/kokoro.web.js';
    const MODEL_ID='onnx-community/Kokoro-82M-v1.0-ONNX';
    let tts=null,loading=null;
    function postError(id,phase,error){
      const message=error&&typeof error==='object'?(error.message||error.name||JSON.stringify(error)):String(error);
      self.postMessage({type:'error',id:id??null,phase,message,stack:error?.stack||''});
    }
    async function loadModel(){
      if(tts)return tts;if(loading)return loading;
      loading=(async()=>{
        self.postMessage({type:'progress',message:'Cargando Kokoro en segundo plano…',progress:8});
        const mod=await import(KOKORO_MODULE_URL);
        if(!mod.KokoroTTS)throw new Error('La compilación de Kokoro no expone KokoroTTS.');
        tts=await mod.KokoroTTS.from_pretrained(MODEL_ID,{
          dtype:'q8',device:'wasm',
          progress_callback:event=>{
            const loaded=Number(event?.loaded||0),total=Number(event?.total||0),file=event?.file||event?.name||event?.path||'modelo';
            if(total>0)self.postMessage({type:'progress',message:`Descargando Kokoro (${file}) · ${Math.round(loaded/1048576)} / ${Math.round(total/1048576)} MB…`,progress:Math.round(10+Math.min(1,loaded/total)*14)});
            else if(event?.status)self.postMessage({type:'progress',message:`Preparando Kokoro (${file}) · ${event.status}…`,progress:12});
          }
        });
        if(typeof tts.generate!=='function')throw new Error('Kokoro se ha cargado, pero no ofrece generate().');
        self.postMessage({type:'ready',message:'Kokoro está listo en segundo plano.'});return tts;
      })();
      try{return await loading;}catch(error){tts=null;loading=null;throw error;}
    }
    self.addEventListener('message',async event=>{
      const data=event.data||{};
      if(data.type==='load'){try{await loadModel();}catch(error){postError(null,'carga de Kokoro',error);}return;}
      if(data.type==='generate'){
        try{
          const model=await loadModel();
          const result=await model.generate(String(data.text||''),{voice:data.voice||'am_adam',speed:Number(data.speed||.96)});
          const audio=result?.audio instanceof Float32Array?result.audio:(result?.audio?.audio instanceof Float32Array?result.audio.audio:null);
          if(!audio||!audio.length)throw new Error('Kokoro no ha devuelto muestras de audio.');
          const sampleRate=result?.sampling_rate||result?.sample_rate||result?.audio?.sampling_rate||24000;
          self.postMessage({type:'audio',id:data.id,audio,sampleRate},[audio.buffer]);
        }catch(error){postError(data.id,'generación de voz',error);}
      }
    });
  }

  function workerFailure(e){
    const msg=e?.message||'No se ha podido iniciar el proceso de voz en segundo plano.';
    for(const [id,p] of state.workerPending){p.reject(new Error(msg));state.workerPending.delete(id);}
    if(state.workerReadyReject){state.workerReadyReject(new Error(msg));state.workerReadyReject=null;}
    try{state.worker?.terminate();}catch{}
    state.worker=null;state.workerReady=null;state.engine=null;
    if(state.workerBlobUrl){try{URL.revokeObjectURL(state.workerBlobUrl);}catch{}state.workerBlobUrl=null;}
  }

  function generateInWorker(text,opts={}){
    if(!state.worker) return Promise.reject(new Error('El proceso de Kokoro no está activo.'));
    const id=++state.workerSeq;
    return new Promise((resolve,reject)=>{
      state.workerPending.set(id,{resolve,reject});
      try{state.worker.postMessage({type:'generate',id,text,voice:opts.voice||KOKORO_VOICE,speed:opts.speed||.96});}
      catch(error){state.workerPending.delete(id);reject(error);}
    });
  }

  async function loadKokoro(progress){
    if(state.engine) return state.engine;
    if(state.workerReady) return state.workerReady;
    state.stage='carga de Kokoro';
    // HTTPS uses the separate worker file. Extracted file:// copies use an
    // embedded Blob module worker, so the app can be opened without publishing.
    if(!window.Worker) throw new Error('Este navegador no admite Web Workers. Actualiza Chrome para ejecutar Kokoro sin bloquear la página.');
    progress(location.protocol==='file:'
      ? 'Iniciando Kokoro en segundo plano desde la copia local…'
      : 'Iniciando Kokoro en segundo plano para no bloquear Chrome…',8);
    state.workerReady=new Promise((resolve,reject)=>{
      state.workerReadyReject=reject;
      let worker;
      try{
        if(location.protocol==='file:'){
          const source=`(${inlineKokoroWorker.toString()})();`;
          const blobUrl=URL.createObjectURL(new Blob([source],{type:'text/javascript'}));
          state.workerBlobUrl=blobUrl;
          worker=new Worker(blobUrl,{type:'module',name:'in-this-town-kokoro-local'});
        } else {
          worker=new Worker(new URL('./kokoro-worker.js',document.baseURI),{type:'module',name:'in-this-town-kokoro'});
        }
      }catch(error){
        state.workerReady=null;state.workerReadyReject=null;
        reject(new Error('No se pudo iniciar Kokoro en segundo plano. Detalle: '+errorText(error)));
        return;
      }
      state.worker=worker;
      worker.addEventListener('message',(event)=>{
        const msg=event.data||{};
        if(msg.type==='progress'){
          progress(msg.message||'Preparando Kokoro…',msg.progress??12);
          return;
        }
        if(msg.type==='ready'){
          state.engine={generate:generateInWorker};
          if(state.workerBlobUrl){try{URL.revokeObjectURL(state.workerBlobUrl);}catch{}state.workerBlobUrl=null;}
          state.workerReadyReject=null;
          progress('Kokoro-82M listo · voz am_adam · cálculo en segundo plano.',25);
          resolve(state.engine);
          return;
        }
        if(msg.type==='audio'){
          const pending=state.workerPending.get(msg.id);
          if(pending){state.workerPending.delete(msg.id);pending.resolve({audio:msg.audio,sampling_rate:msg.sampleRate});}
          return;
        }
        if(msg.type==='error'){
          const detail=msg.message||'Error desconocido del proceso Kokoro.';
          if(msg.id!=null){const pending=state.workerPending.get(msg.id);if(pending){state.workerPending.delete(msg.id);pending.reject(new Error(detail));}}
          else {
            workerFailure(new Error(`Kokoro no ha podido iniciarse: ${detail}`));
          }
        }
      });
      worker.addEventListener('error',(event)=>{
        const detail=event.message||'Error cargando kokoro-worker.js';
        workerFailure(new Error(detail));
      });
      worker.addEventListener('messageerror',()=>workerFailure(new Error('Chrome no pudo recibir los datos de audio del proceso Kokoro.')));
      worker.postMessage({type:'load'});
    });
    try{return await state.workerReady;}
    catch(error){state.workerReady=null;state.engine=null;throw error;}
  }

  function errorText(e){
    if(typeof e==='number') return `Valor numérico: ${e} (0x${(e>>>0).toString(16).toUpperCase()})`;
    if(typeof e==='string') return e;
    if(e===null) return 'El navegador devolvió null.';
    if(e===undefined) return 'El navegador devolvió un error vacío (undefined).';
    if(e instanceof Error) {
      const parts=[`${e.name}: ${e.message}`];
      if(e.code!==undefined) parts.push(`code=${e.code}`);
      if(e.cause!==undefined && e.cause!==e) parts.push(`cause=${errorText(e.cause)}`);
      if(e.stack) parts.push(e.stack.split('\n').slice(0,4).join(' | '));
      return parts.join(' · ');
    }
    if(typeof e==='object') {
      const parts=[];
      for(const k of ['name','message','code','status','url','type','cause']) {
        if(e[k]!==undefined && e[k]!==e) parts.push(`${k}=${typeof e[k]==='object'?errorText(e[k]):String(e[k])}`);
      }
      if(parts.length) return parts.join(' · ');
      try { return JSON.stringify(e)||Object.prototype.toString.call(e); } catch { return Object.prototype.toString.call(e); }
    }
    return String(e);
  }

  async function synthesize(lines,audioCtx,progress){
    const engine=await loadKokoro(progress);
    const chunks=[],timings=[];let total=0,sampleRate=24000;
    for(let i=0;i<lines.length;i++){
      if(state.cancel) throw new Error('Cancelado.');
      progress(`Narrando con Kokoro am_adam · escena ${i+1}/${lines.length}…`,16+(i/lines.length)*16);
      const clean=lines[i].replace(/\*([^*]+)\*/g,'$1');
      const result=await engine.generate(clean,{voice:KOKORO_VOICE,speed:.96});
      const pcm=result?.audio instanceof Float32Array ? result.audio : (result?.audio?.audio instanceof Float32Array ? result.audio.audio : null);
      sampleRate=result?.sampling_rate||result?.sample_rate||result?.audio?.sampling_rate||sampleRate;
      if(!pcm||!pcm.length) throw new Error('Kokoro no ha generado audio válido para la escena '+(i+1)+'. Comprueba que el modelo y la voz am_adam se han descargado correctamente.');
      const start=total/sampleRate;chunks.push(pcm);total+=pcm.length;
      const pause=Math.round(sampleRate*.19);chunks.push(new Float32Array(pause));total+=pause;
      timings.push({start,end:start+pcm.length/sampleRate,duration:pcm.length/sampleRate+.19});
    }
    const joined=new Float32Array(total);let offset=0;for(const c of chunks){joined.set(c,offset);offset+=c.length;}
    const b=audioCtx.createBuffer(1,joined.length,sampleRate);b.getChannelData(0).set(joined);
    return {pcm:joined,timings,duration:joined.length/sampleRate,buffer:b,sampleRate};
  }

  function wrapLine(ctx,text,maxWidth){
    const words=text.split(/\s+/),lines=[];let line='';
    for(const word of words){const test=line?line+' '+word:word;if(ctx.measureText(test).width>maxWidth&&line){lines.push(line);line=word;}else line=test;}
    if(line)lines.push(line);return lines;
  }
  function drawCaption(ctx,text){
    const clean=text.replace(/\*([^*]+)\*/g,'$1').toUpperCase();
    ctx.save();ctx.textAlign='center';ctx.textBaseline='middle';ctx.font='900 39px system-ui,Arial';
    const lines=wrapLine(ctx,clean,492).slice(0,2);const lineH=48;const blockH=lines.length*lineH+28;const y=H-154-blockH/2;
    const widths=lines.map(line=>Math.min(500,ctx.measureText(line).width+38));const panelW=Math.min(530,Math.max(...widths));
    const panelY=y-blockH/2+10;ctx.fillStyle='#080b16d9';ctx.strokeStyle='#ffffff38';ctx.lineWidth=2;
    ctx.beginPath();ctx.roundRect((W-panelW)/2,panelY,panelW,blockH,16);ctx.fill();ctx.stroke();
    ctx.shadowColor='#000';ctx.shadowBlur=8;
    lines.forEach((line,i)=>{const yy=y+i*lineH;ctx.fillStyle='#ffffff';ctx.fillText(line,W/2,yy,492);});
    ctx.restore();
  }
  function drawFrame(sceneIndex,elapsed,caption){
    if(state.mode!=='webgl') throw new Error('El motor 3D original no está disponible.');
    Studio.api.frame(Math.max(0,Math.min(elapsed,3.9)));
    outCtx.drawImage(glCanvas,0,0,W,H);
    // Overlay subtitles on top of the actual WebGL2 frame.
    const g=outCtx.createLinearGradient(0,H-340,0,H);g.addColorStop(0,'#07091400');g.addColorStop(1,'#070914d9');outCtx.fillStyle=g;outCtx.fillRect(0,H-340,W,340);
    outCtx.save();outCtx.textAlign='center';outCtx.fillStyle='#ffffffbb';outCtx.font='800 17px system-ui';outCtx.fillText('IN THIS TOWN',W/2,70);outCtx.restore();
    drawCaption(outCtx,caption);
  }

  function getMime(){
    const candidates=['video/mp4;codecs=avc1.42E01E,mp4a.40.2','video/mp4','video/webm;codecs=vp9,opus','video/webm;codecs=vp8,opus','video/webm'];
    for(const t of candidates){try{if(MediaRecorder.isTypeSupported(t))return t;}catch{}}
    return '';
  }
  async function loadMusic(ctx,mood){
    // Optional user-selected soundtrack. The file stays on-device and is never uploaded.
    if(state.musicFile){
      const bytes=await state.musicFile.arrayBuffer();
      try { return await ctx.decodeAudioData(bytes.slice(0)); }
      catch(e){ throw new Error('No se ha podido leer el archivo de música. Prueba con MP3, WAV, M4A u OGG.'); }
    }
    // Original ambient bed generated locally as a fallback; no copyrighted recording bundled.
    const patterns={
      quirky:[{b:82,p:165,m:247},{b:98,p:196,m:294},{b:110,p:220,m:330},{b:98,p:196,m:294}],
      suspense:[{b:55,p:110,m:165},{b:62,p:124,m:185},{b:58,p:116,m:174},{b:65,p:130,m:196}],
      tense:[{b:49,p:98,m:147},{b:55,p:110,m:165},{b:52,p:104,m:156},{b:58,p:116,m:174}],
      chill:[{b:73,p:146,m:220},{b:82,p:165,m:247},{b:87,p:174,m:262},{b:82,p:165,m:247}],
      spooky:[{b:55,p:110,m:165},{b:65,p:130,m:196},{b:58,p:116,m:174},{b:73,p:146,m:220}]
    };
    const pattern=patterns[mood]||patterns.spooky, seconds=8, length=ctx.sampleRate*seconds;
    const buffer=ctx.createBuffer(2,length,ctx.sampleRate), left=buffer.getChannelData(0), right=buffer.getChannelData(1);
    for(let i=0;i<length;i++){
      const t=i/ctx.sampleRate, beat=t%2, bar=Math.floor(t/2)%4, n=pattern[bar];
      const fade=Math.min(1,t/.7,(seconds-t)/.7);
      const bass=Math.sin(2*Math.PI*n.b*t)*.025;
      const pad=(Math.sin(2*Math.PI*n.p*t)+.25*Math.sin(2*Math.PI*n.p*2*t)+.12*Math.sin(2*Math.PI*n.p*3*t))*.012;
      const shimmer=Math.sin(2*Math.PI*n.m*t+Math.sin(t*1.7)*.18)*.006;
      const pluck=Math.exp(-beat*4.5)*Math.sin(2*Math.PI*n.m*t)*.012;
      const pulse=Math.exp(-beat*13)*Math.sin(2*Math.PI*48*beat)*.009;
      const sample=(bass+pad+shimmer+pluck+pulse)*Math.max(0,fade);
      left[i]=sample;right[i]=(bass+pad+Math.sin(2*Math.PI*n.m*(t+.003))*.006+pluck+pulse)*Math.max(0,fade);
    }
    return buffer;
  }

  async function recordVideo(story,lines,tts,audioCtx,tone,progress){
    const compiled=[];
    story.scenes.forEach((s,i)=>{s.dur=Math.max(1.35,tts.timings[i].duration+.10);compiled.push({dur:s.dur});});
    if(state.mode==='webgl'){
      progress('Preparing 3D sets and camera moves…',32);
      Studio.api.setStory(story);
    }
    const totalDuration=compiled.reduce((a,b)=>a+b.dur,0);
    const timings=[];let cursor=0;compiled.forEach((c,i)=>{timings.push({start:cursor,end:cursor+c.dur,index:i});cursor+=c.dur;});
    const voiceBuf=tts.buffer;
    const voiceSource=audioCtx.createBufferSource();voiceSource.buffer=voiceBuf;
    const voiceGain=audioCtx.createGain();voiceGain.gain.value=1.12;voiceSource.connect(voiceGain);
    const musicBuf=await loadMusic(audioCtx,story.music.mood);
    const musicSource=audioCtx.createBufferSource();musicSource.buffer=musicBuf;musicSource.loop=true;
    const musicGain=audioCtx.createGain();musicGain.gain.value=state.musicFile ? .085 : .095;musicSource.connect(musicGain);
    const compressor=audioCtx.createDynamicsCompressor();compressor.threshold.value=-18;compressor.knee.value=12;compressor.ratio.value=3;compressor.attack.value=.012;compressor.release.value=.22;
    const mix=audioCtx.createMediaStreamDestination();voiceGain.connect(compressor);musicGain.connect(compressor);compressor.connect(mix);
    const videoStream=outCanvas.captureStream(FPS);
    const stream=new MediaStream([...videoStream.getVideoTracks(),...mix.stream.getAudioTracks()]);
    const mime=getMime();if(!mime)throw new Error('Este navegador no puede exportar vídeo. Prueba con una versión reciente de Chrome, Edge o Safari.');
    let recorder;try{recorder=new MediaRecorder(stream,{mimeType:mime,videoBitsPerSecond:3_000_000,audioBitsPerSecond:128_000});}catch{recorder=new MediaRecorder(stream,{mimeType:mime});}
    const chunks=[];recorder.ondataavailable=e=>{if(e.data?.size)chunks.push(e.data);};
    const stopped=new Promise((resolve,reject)=>{recorder.onstop=resolve;recorder.onerror=e=>reject(e.error||new Error('Video recording failed.'));});
    recorder.start(1000);
    await audioCtx.resume();musicSource.start(0);voiceSource.start(0);
    $('placeholder').style.display='none';
    const start=performance.now();let lastScene=-1,renderError=null;
    await new Promise(resolve=>{
      const stop=()=>{try{if(recorder.state!=='inactive')recorder.stop();}catch{}resolve();};
      const tick=()=>{
        try{
          if(state.cancel){renderError=new Error('Cancelado.');stop();return;}
          const elapsed=(performance.now()-start)/1000;
          if(elapsed>=totalDuration){stop();return;}
          let sIndex=timings.findIndex(x=>elapsed>=x.start&&elapsed<x.end);if(sIndex<0)sIndex=timings.length-1;
          const t=timings[sIndex],local=elapsed-t.start;
          if(sIndex!==lastScene){lastScene=sIndex;try{Studio.api.compile(sIndex,{fast:false});}catch(sceneError){throw new Error(`Error al preparar la escena 3D ${sIndex+1}/${story.scenes.length}: ${errorText(sceneError)}`);}}
          try{drawFrame(sIndex,local,lines[sIndex]);}catch(frameError){throw new Error(`Error al dibujar la escena 3D ${sIndex+1}/${story.scenes.length}: ${errorText(frameError)}`);}
          if(Math.floor(elapsed)!==Math.floor(elapsed-1/FPS)){const pct=58+elapsed/totalDuration*40;progress(`Renderizando escena 3D ${sIndex+1}/${lines.length} · ${Math.floor(elapsed)} s`,pct);}
          requestAnimationFrame(tick);
        }catch(e){renderError=e;stop();}
      };
      requestAnimationFrame(tick);
    });
    await stopped;
    try{videoStream.getTracks().forEach(t=>t.stop());mix.stream.getTracks().forEach(t=>t.stop());voiceSource.disconnect();musicSource.stop();musicSource.disconnect();}catch{}
    if(renderError)throw renderError;
    const blob=new Blob(chunks,{type:mime.split(';')[0]||'video/webm'});
    if(blob.size<50000)throw new Error('The video file is too small; this browser may not support recording the canvas.');
    return {blob,mime,totalDuration};
  }

  function makePreviewStill(story){
    if(state.mode!=='webgl') throw new Error('El motor 3D original no está disponible.');
    Studio.api.setStory(story);story.scenes[0].dur=3;Studio.api.compile(0,{fast:false});Studio.api.frame(.3);outCtx.drawImage(glCanvas,0,0,W,H);
    outCtx.fillStyle='#070914a8';outCtx.fillRect(0,H-255,W,255);drawCaption(outCtx,story.scenes[0].vo);
  }

  async function create(){
    if(state.busy)return;
    if(state.mode!=='webgl'){setStatus('El motor 3D original necesita WebGL 2. Actualiza el navegador y activa la aceleración gráfica.');return;}
    const idea=$('idea').value.trim(),tone=$('tone').value,length=$('length').value;
    if(idea.length<8){setStatus('Escribe una regla más concreta (mínimo 8 caracteres).');return;}
    if(!window.MediaRecorder||!outCanvas.captureStream){setStatus('Tu navegador no permite exportar vídeo. Prueba una versión reciente de Chrome, Edge o Safari.',0);return;}
    setBusy(true);state.cancel=false;$('result').classList.remove('show');
    if(jobUrl){URL.revokeObjectURL(jobUrl);jobUrl=null;}
    $('placeholder').style.display='grid';
    let audioCtx;
    try{
      state.stage='preparación';
      const AudioCtor=window.AudioContext||window.webkitAudioContext;
      if(!AudioCtor) throw new Error('Este navegador no ofrece Web Audio y no puede mezclar la narración.');
      audioCtx=new AudioCtor();await audioCtx.resume();
      const story=buildStory(idea,tone,length);state.story=story;
      setStatus('Creando la historia a partir de tu regla…',3);
      state.stage='generación de voz';
      const tts=await synthesize(story.scenes.map(s=>s.vo),audioCtx,setStatus);
      state.stage='vista previa 3D';
      makePreviewStill(story);
      state.stage='grabación y render 3D';
      const result=await recordVideo(story,story.scenes.map(s=>s.vo),tts,audioCtx,tone,setStatus);
      const ext=result.mime.includes('mp4')?'mp4':'webm';jobUrl=URL.createObjectURL(result.blob);
      $('download').href=jobUrl;$('download').download='in-this-town-'+story.slug+'.'+ext;
      $('download').textContent='↓ DESCARGAR '+ext.toUpperCase();
      $('resultTitle').textContent=story.title;$('resultMeta').textContent=`${Math.round(result.totalDuration)} segundos · ${story.scenes.length} escenas · ${ext.toUpperCase()} · ${(result.blob.size/1024/1024).toFixed(1)} MB`;
      $('script').innerHTML=story.scenes.map((s,i)=>`<p><b>${String(i+1).padStart(2,'0')}.</b> ${escapeText(s.vo.replace(/\*/g,''))}</p>`).join('');
      $('result').classList.add('show');$('placeholder').style.display='none';
      setStatus('¡Terminado! Tu vídeo está listo para descargar.',100);
    } catch(e){
      const detail=errorText(e);
      console.error('In This Town create failed at '+state.stage+':',e);
      $('placeholder').style.display='grid';
      setStatus(`No se ha podido crear el vídeo · Fase: ${state.stage}\n${detail}`,0);
    } finally {try{await audioCtx?.close();}catch{};setBusy(false);state.cancel=false;state.stage='listo';}
  }
  $('create').addEventListener('click',create);
  window.addEventListener('beforeunload',()=>{if(jobUrl)URL.revokeObjectURL(jobUrl);});
  if('serviceWorker' in navigator && location.protocol.startsWith('http')) navigator.serviceWorker.register('./sw.js').catch(()=>{});
  initRenderer();
  if(location.protocol==='file:'){
    setStatus('Modo local activado. Extrae primero la carpeta del ZIP y abre site/index.html desde la carpeta extraída (no desde la vista previa del ZIP). Kokoro se ejecutará en segundo plano; necesitas internet la primera vez para descargar el modelo.');
  }
})();

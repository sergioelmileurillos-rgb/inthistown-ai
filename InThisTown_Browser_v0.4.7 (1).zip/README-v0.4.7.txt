IN THIS TOWN — BROWSER v0.4.7

MODO DIRECTO (SIN PUBLICAR EN GITHUB)
1. Abre la app Archivos del Chromebook.
2. Busca el ZIP y elige Extraer todo.
3. Abre la carpeta extraída > site > index.html.
4. Mantén internet durante la primera carga de Kokoro-82M.

La app intenta crear un Web Worker integrado (Blob) cuando se abre como archivo local, por lo que no necesitas GitHub Pages para probarla. La voz sigue ejecutándose fuera del hilo visual y usa Kokoro-82M con am_adam y WASM q8.

IMPORTANTE
No abras index.html desde dentro de la vista previa del ZIP. Tiene que estar en la carpeta ya extraída.

HTTPS sigue siendo una alternativa si ChromeOS bloquea la importación remota desde file://. Esta compatibilidad no se ha podido validar en un Chromebook físico.

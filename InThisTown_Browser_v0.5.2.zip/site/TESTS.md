# v0.5.2 test checklist

- [x] JavaScript syntax checked for every `.js` file in `site/`.
- [x] ZIP integrity checked after packaging.
- [x] Original WebGL2 engine timeline compilation checked for five story classes: vision, robot, book, chair and puppet; zero warnings.
- [x] All animation clips referenced by those coreographies exist in the original engine plus the added animation module.
- [x] Contextual action overlays (run, sit, open, close, inspect, build, talk, wave, hide, fall, operate, move, group, think) compile with zero warnings.
- [x] Asset Forge checked for 12 prop families x 8 variations = 96 valid blueprints.
- [x] Asset Forge deterministic persistence/reuse checked by generating the same asset twice.
- [x] Speech grouping checked: eight lines become three generation requests; scene timing entries remain ordered and positive.
- [x] Nearby low-energy audio window snapping checked against synthetic audio with quiet gaps.
- [ ] Full Kokoro generation and video export on the user's Chromebook.
- [ ] Visual review of a real 1080x1920-equivalent final render on the user's device.

The last two checks require a real browser/device render and are not claimed as complete.

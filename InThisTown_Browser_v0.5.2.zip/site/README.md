# In This Town — Browser v0.5.2

Browser-first video studio built on the user's original custom WebGL2 Roblox-style engine. The page accepts a one-line story premise, creates a short English story, directs scene actions, generates Kokoro narration, mixes music and captions, and records a vertical video in the browser.

## Run
Use the hosted HTTPS app (recommended for Chromebook, iPhone and desktop). The local ZIP is a source/deployment package; GitHub Pages extracts `site/` and serves it over HTTPS. A local `file://` copy may be restricted by browser module/network policies.

## Voice
- Kokoro-82M ONNX: `onnx-community/Kokoro-82M-v1.0-ONNX`
- Kokoro JS browser build: `kokoro-js@1.2.1`
- Voice: `am_adam`, American English male
- Speed: 1.14
- Up to three short sentences per inference request, capped at 25 words per group.

## Animation and reusable props
- Original WebGL2 renderer, original character/prop/world/FX modules retained.
- Semantic scene beats plus sentence-level action cues.
- Contextual motions: run, sit, open, close, inspect, build, talk, wave, hide, fall, operate and move.
- Procedural Asset Forge with 12 prop families and eight deterministic variations per family (96 variants). Blueprints are saved in localStorage and reused.

## Subtitles
Scene boundaries use actual output audio duration, syllable-weight estimates and nearby low-energy windows when a clear pause is detected. Karaoke word emphasis is approximate; this is not a phoneme-level forced aligner.

## Music
Ambient fallback music is generated locally. The music picker accepts a local audio file; selected audio is mixed on-device and is not uploaded.

## Limits
- Video rendering and Kokoro inference happen on the user's device, so speed depends on the browser and hardware.
- First Kokoro use needs internet to download the model.
- Procedural props are made from the original engine's geometry primitives, not arbitrary AI-generated meshes.
- The complete pipeline has not been validated on every target device; the provided tests cover JavaScript syntax, engine timeline compilation, action clips, prop generation/reuse and grouped timing logic.

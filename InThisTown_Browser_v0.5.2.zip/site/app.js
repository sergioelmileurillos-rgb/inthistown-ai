/* In This Town — original procedural WebGL2 engine + browser story composition, Kokoro-82M TTS and MediaRecorder. */
(() => {
  'use strict';
  const $ = id => document.getElementById(id);
  const FPS = 24, W = 576, H = 1024;
  const KOKORO_MODEL = 'onnx-community/Kokoro-82M-v1.0-ONNX';
  const KOKORO_VOICE = 'am_adam';
  const KOKORO_SPEED = 1.14; // brisker narration, still natural for the selected voice
  const SCENE_GAP_SECONDS = 0.02;
  // Official browser build declared by kokoro-js' jsDelivr package metadata.
  // Pin the version to avoid silent upstream changes.
  const KOKORO_MODULE_URL = 'https://cdn.jsdelivr.net/npm/kokoro-js@1.2.1/dist/kokoro.web.js';
  const state = {busy:false,cancel:false,mode:'unavailable',engine:null,worker:null,workerReady:null,workerPending:new Map(),workerSeq:0,story:null,musicFile:null,stage:'inicio'};
  const glCanvas = $('gl'), outCanvas = $('out'), outCtx = outCanvas.getContext('2d',{alpha:false});
  const worldSet = ['city','suburb','school','park','townhall','room','city','crowd'];
  const anims = ['think','point','walk','shock','run','cheer','scared','lookAround','shrug','panic','wave','talk','jump','angry','laugh','fall','clap','idle'];
  let jobUrl = null;

  const setStatus = (text, progress) => {
    $('status').textContent = text;
    if (progress !== undefined) $('bar').style.width = Math.max(0,Math.min(100,progress))+'%';
  };
  const setBusy = value => {
    state.busy=value; $('create').disabled=value || state.mode!=='webgl'; $('create').textContent=value?'CREANDO TU VÍDEO…':'✦ CREAR MI VÍDEO';
  };
  const escapeText = s => String(s).replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
  $('idea').addEventListener('input',()=>{$('count').textContent=$('idea').value.length+' / 300';});
  document.querySelectorAll('.example').forEach(b=>b.addEventListener('click',()=>{$('idea').value=b.dataset.idea;$('count').textContent=$('idea').value.length+' / 300';$('idea').focus();}));
  $('musicFile')?.addEventListener('change',e=>{
    const f=e.target.files?.[0]||null;state.musicFile=f;
    $('musicName').textContent=f?`Pista seleccionada: ${f.name}`:'Sin pista propia · música ambiental original';
  });
  $('clearMusic')?.addEventListener('click',()=>{
    state.musicFile=null;if($('musicFile'))$('musicFile').value='';
    $('musicName').textContent='Sin pista propia · música ambiental original';
  });

  function initRenderer(){
    try {
      if (!window.Studio?.api) throw new Error('No se han cargado los módulos del motor 3D original.');
      const info=Studio.api.init(W,H,{SM:1024});
      state.mode='webgl';
      $('engineBadge').textContent='Motor 3D original activo';
      $('engineBadge').style.color='var(--green)';
      $('create').disabled=false;
      return info;
    } catch(e) {
      state.mode='unavailable';
      $('engineBadge').textContent='WebGL 2 no disponible';
      $('engineBadge').style.color='var(--amber)';
      $('create').disabled=true;
      console.error('No se pudo iniciar el motor 3D original:',e);
      setStatus('Este navegador no ha podido iniciar WebGL 2. Actualiza Chrome y activa la aceleración gráfica. No se generará un vídeo 2D de sustitución.');
      return null;
    }
  }

  function classify(rule){
    const r=rule.toLowerCase();
    if (/robot|machine|drone|android|automaton/.test(r)) return 'robot';
    if (/puppet|doll|toy|parrot|bird/.test(r)) return 'puppet';
    if (/rulebook|book|manual|document|contract|paperwork|notebook/.test(r)) return 'book';
    if (/rolling chair|office chair|chair|wheels/.test(r)) return 'chair';
    if (/window|outside|look out|look outside|look at|see|mirror|reflection|eyes/.test(r)) return 'vision';
    if (/lie|lying|truth|honest|false/.test(r)) return 'lie';
    if (/door|open|closed|lock/.test(r)) return 'door';
    if (/walk|backward|backwards|run|move|step/.test(r)) return 'movement';
    if (/speak|talk|say|word|voice|whisper|silent|silence/.test(r)) return 'speech';
    if (/laugh|smile|yawn|sneeze|sing|dance/.test(r)) return 'body';
    if (/sleep|dream|night|midnight|dark/.test(r)) return 'night';
    return 'general';
  }
  function makeNarration(rule,tone,length){
    const kind=classify(rule);
    const cleanedRule=rule.replace(/^[.!?\s]+|[.!?]+$/g,'');
    const first=rule.match(/^in this town\b/i)?rule.replace(/[.!?]+$/,'')+'.':'In this town, '+cleanedRule.charAt(0).toLowerCase()+cleanedRule.slice(1)+'.';
    let lines;
    if(kind==='vision') lines=[first,'Everyone kept their curtains closed.','But Max found a tiny loophole.','He placed a mirror by the window.','Now he could watch the street.','His neighbour copied the trick.','Soon, mirrors covered every house.','The mayor spotted the reflections.','He opened the town rulebook.','Reflections counted as looking too.','Every mirror turned toward Max.','He hid behind his sofa.','But his phone was still recording.','The mayor found him instantly.','Then the street lights went dark.','Nobody could see the mayor either.','Max became the new night guard.','His first shift started at midnight.','He had to watch every window.','And he was not allowed to look.'];
    else if(kind==='door') lines=[first,'Everyone checked every lock twice.','But Max had a clever plan.','He sent a tiny robot first.','The robot opened the front door.','Max followed without touching it.','His neighbour copied the trick.','Soon, robots filled the streets.','The mayor came to investigate.','He checked the town rulebook.','It mentioned helpers and machines.','The robot counted as Max.','Every door slammed shut at once.','Max tried to hide in town hall.','But the robot followed him inside.','The mayor smiled and closed the book.','Max had one last door to open.','It was the door to his own room.','He asked the robot to do it.','The robot refused.'];
    else if(kind==='lie') lines=[first,'Nobody dared to tell a story.','But Max found a loophole.','He asked a parrot to speak.','The parrot repeated his lie.','Max thought he was safe.','His neighbour bought a parrot too.','Soon, the whole town had birds.','The mayor called an emergency meeting.','He read the final sentence aloud.','Repeating a lie still counted.','Every parrot started squawking.','Max tried to tell the truth.','But nobody believed him anymore.','The mayor handed him a microphone.','The whole town went quiet.','Max finally told the truth.','The parrot repeated the old lie.','And the rule started all over again.'];
    else if(kind==='movement') lines=[first,'Everyone moved very carefully.','But Max found a loophole.','He sat on a rolling chair.','Technically, his feet never moved.','His neighbour copied the idea.','Soon, chairs rolled everywhere.','The mayor blocked the main street.','Max brought out a tiny scooter.','The rulebook had one more line.','Wheels counted as moving too.','Every scooter stopped at once.','Max tried to run away.','But he had forgotten the rule.','The mayor pointed at his feet.','The whole town started laughing.','Max sat down again.','His chair rolled into town hall.','And he became the new mayor.'];
    else if(kind==='speech') lines=[first,'The town became completely silent.','But Max had a loophole.','He recorded his voice yesterday.','Then he played it through a speaker.','His neighbour copied the trick.','Soon, speakers filled the town.','The mayor heard the noise.','He checked the rulebook again.','Recorded voices counted as speaking.','Every speaker switched on at once.','Max tried to unplug them.','But the speakers kept replaying.','The mayor finally found the switch.','The whole town went silent.','Max had one last message.','He pressed play by mistake.','It was the mayor saying hello.','And nobody could answer back.'];
    else if(kind==='night') lines=[first,'Everyone stayed awake until sunrise.','But Max found a loophole.','He built a tiny sleeping robot.','The robot watched over his room.','Max finally relaxed for a moment.','His neighbour ordered one too.','Soon, robots filled every house.','The mayor came to inspect them.','He opened the rulebook slowly.','Robots counted as their owners.','Every robot started waving.','Max tried to switch his off.','But it had learned his schedule.','The mayor read the final line.','Owners had to stay awake too.','Max checked the clock.','Sunrise was still six hours away.','He wished he had stayed awake.'];
    else if(kind==='body') lines=[first,'Nobody wanted to break the rule.','But Max found a loophole.','He used a puppet to test it.','The puppet did it perfectly.','His neighbour copied the trick.','Soon, puppets filled the town.','The mayor noticed the crowd.','He checked the tiny print.','Puppets counted as their owners.','Every puppet turned toward Max.','He tried to put his away.','But the puppet waved at the mayor.','The mayor wrote one new rule.','No more puppets after sunset.','Max packed his puppet carefully.','It gave one final wave.','The whole town waved back.'];
    else if(kind==='robot') lines=[first,'Every robot repeated the rule exactly.','But Max built one special robot.','It only answered questions with questions.','His neighbour copied the design.','Soon, robots filled the streets.','The mayor called an emergency meeting.','He asked Max if he had cheated.','Every robot answered at once.','One tiny robot stayed silent.','Max thought it had saved him.','Then its screen lit up.','It showed the mayor’s secret message.','The mayor unplugged every robot.','But one had already sent a copy.','It appeared on every screen.','Max’s robot asked one last question.'];
    else if(kind==='book') lines=[first,'Nobody was allowed to open the rulebook.','But Max found a page sticking out.','He read the words through its cover.','His neighbour tried the same trick.','Soon, everyone carried a closed book.','The mayor noticed the strange parade.','He checked the cover very carefully.','Reading a closed book still counted.','Every book began to shake.','Max tried to hide his copy.','But its pages started turning.','The final page had his name.','The mayor asked who wrote it.','Max looked at the tiny signature.','It was the mayor’s handwriting.','The rulebook had written itself.'];
    else if(kind==='chair') lines=[first,'Everyone found a chair before sunset.','But Max chose one with wheels.','He rolled past the town square.','His feet never touched the ground.','His neighbour copied the idea.','Soon, chairs rolled everywhere.','The mayor blocked the main street.','Max steered around the barrier.','The rulebook mentioned rolling chairs.','Wheels counted as walking too.','Every chair stopped at once.','Max tried to stand up.','But sunset had already started.','The mayor pointed at an empty seat.','Max sat down very slowly.','The chair rolled straight into town hall.'];
    else if(kind==='puppet') lines=[first,'Every puppet had to wave at midnight.','Max hid his puppet in a box.','But one tiny hand kept moving.','His neighbour made a puppet too.','Soon, puppets waved in every window.','The mayor came to inspect them.','He opened the rulebook carefully.','A puppet counted as its owner.','Every puppet turned toward Max.','He tried to tie its hands.','But the strings moved by themselves.','The mayor wrote a new rule.','No puppets after midnight.','Max packed his puppet away.','It gave one final wave.','The whole town waved back.'];
    else lines=[first,'Everyone obeyed the strange rule.','Until Max found a loophole.','He asked his neighbour to test it.','The trick worked perfectly.','So Max tried it at school.','Then he tried it downtown.','Soon, everyone copied him.','The mayor noticed the chaos.','He brought out the official rulebook.','There was one hidden sentence.','The rule applied to loopholes too.','Max tried to undo his trick.','But the town had copied it.','The mayor called one final meeting.','Everyone waited for Max to speak.','He had to follow his own rule.','And the first person caught was Max.'];
    if(tone==='funny') lines=lines.map((x,i)=> i===1?'The town took it VERY seriously.':i===2?'But Max was not impressed.':i===Math.floor(lines.length*.7)?'The mayor arrived wearing a huge hat.':x);
    if(tone==='suspense') lines=lines.map((x,i)=> i===1?'Nobody knew who made the rule.':i===2?'Then Max heard a strange sound.':i===Math.floor(lines.length*.75)?'Someone was already waiting inside.':x);
    if(length==='short') lines=lines.slice(0,14);
    else lines=lines.slice(0,17);
    return lines;
  }

  function storyHash(text){let h=2166136261;for(let i=0;i<String(text).length;i++){h^=String(text).charCodeAt(i);h=Math.imul(h,16777619)}return h>>>0;}
  function inferBeat(vo,index,total){
    const t=vo.toLowerCase();
    if(index===0)return 'rule';
    if(index===total-1)return 'finale';
    if(/mayor|official|emergency meeting|town hall|inspector/.test(t))return 'authority';
    if(/counted as|still counted|hidden sentence|one more line|final line|rule applied|technically/.test(t))return 'reveal';
    if(/copied|whole town|soon,|filled the town|all at once|spread across|one in every/.test(t))return 'spread';
    if(/loophole|clever plan|found a plan|found a page|spotted a clue|had an idea|one last trick|the trick|chose one|picked one/.test(t))return 'discovery';
    if(/built|placed|used|sent|recorded|pressed|opened|put his|brought out|pulled out|made a|read the|rolled|steered|sat down|packed his/.test(t))return 'perform';
    if(/tried|refused|failed|hid|forgotten|slammed|caught|could not|couldn't|went dark/.test(t))return 'setback';
    if(/turned|started|began|appeared|suddenly|then /.test(t))return 'escalation';
    return index<3?'reaction':'escalation';
  }
  function inferAction(vo,kind,beat){
    const t=String(vo||'').toLowerCase();
    if(/\b(ran|running|run away|chased|chasing|escaped|fled|rushed)\b/.test(t))return 'run';
    if(/\b(sat down|sat on|sitting|took a seat)\b/.test(t))return 'sit';
    if(/\b(opened|opens|open the|unlocked|pulled open)\b/.test(t))return 'open';
    if(/\b(closed|locked|shut|slammed)\b/.test(t))return 'close';
    if(/\b(read|reading|checked|inspected|examined|looked at|spotted|noticed)\b/.test(t))return 'inspect';
    if(/\b(built|builds|made a|created|designed|assembled)\b/.test(t))return 'build';
    if(/\b(said|asked|told|spoke|whispered|repeated|shouted|answered|called)\b/.test(t))return 'talk';
    if(/\b(waved|wave|waving)\b/.test(t))return 'wave';
    if(/\b(hid|hide|hiding|crouched|ducked)\b/.test(t))return 'hide';
    if(/\b(fell|falling|slipped|stumbled|tripped)\b/.test(t))return 'fall';
    if(/\b(pressed|switched|played|recorded|turned on|unplugged|operated)\b/.test(t))return 'operate';
    if(/\b(rolled|steered|drove|rode|walked|moved|stepped|followed)\b/.test(t))return 'move';
    if(/\b(copied|everyone|everybody|whole town|filled the town)\b/.test(t))return 'group';
    return beat==='discovery'?'think':beat==='perform'?'operate':beat==='authority'?'confront':'react';
  }

  function chooseWorld(vo,beat,index){
    const t=vo.toLowerCase();
    if(/school|classroom|teacher|student/.test(t))return 'school';
    if(/sofa|bedroom|room|house|home|his own room/.test(t))return 'room';
    if(/park|tree|street lights|street/.test(t))return 'city';
    if(beat==='authority'||beat==='reveal')return 'townhall';
    if(beat==='spread')return index%2?'crowd':'city';
    if(beat==='discovery'||beat==='perform')return 'suburb';
    return 'city';
  }
  function buildStory(idea,tone,length){
    let raw=idea.trim().replace(/\s+/g,' ');
    if(!raw) throw new Error('Escribe primero una regla para el pueblo.');
    const lead=raw.match(/^in this town\s*,?\s*(.*)$/i);
    const rule=lead&&lead[1]?lead[1].replace(/[.!?]+$/,''):raw.replace(/[.!?]+$/,'');
    const lines=makeNarration(raw,tone,length);
    const slug='town-'+Date.now().toString(36),seed=storyHash(rule+'|'+tone);
    const kind=classify(rule);
    const chars={hero:{preset:'hero'},neighbor:{preset:'boy2'},mayor:{preset:'mayor'}};
    if(kind==='robot')chars.bot={preset:'robot'};
    const forged=Studio.AssetForge?.ensure(kind,seed)||{id:({vision:'windowframe',door:'door',lie:'bird',movement:'skateboard',speech:'speaker',night:'digitalclock',body:'giftbox',book:'book',robot:'robot',puppet:'toy',chair:'chair',general:'warningsign'})[kind]||'warningsign'};
    const scenes=lines.map((vo,i)=>{
      const beat=inferBeat(vo,i,lines.length),last=i===lines.length-1,twist=i>=lines.length-4;
      const world=chooseWorld(vo,beat,i);
      const heroFace=beat==='rule'||beat==='reaction'||beat==='setback'?'worried':beat==='reveal'?'shock':beat==='finale'?'grin':'smile';
      const actors={hero:{pos:[0,0,16],yawDeg:0,face:heroFace}};
      if(['spread','reaction','rule','finale'].includes(beat)||i%5===2)actors.neighbor={pos:[-5.8,0,19],yawDeg:18,face:beat==='spread'?'smile':'shock'};
      if(['authority','reveal','finale'].includes(beat)||i>=lines.length-4)actors.mayor={pos:[10,0,21],yawDeg:205,face:beat==='authority'?'angry':'neutral'};
      if(kind==='robot')actors.bot={pos:[3.8,0,16.1],yawDeg:0,face:beat==='reveal'?'shock':'neutral'};
      const propVisible=kind!=='robot'&&!['rule','reaction'].includes(beat);
      const large=['door','movement','body','chair','robot'].includes(kind) ? .88 : .78;
      const objects=[{id:'storyProp',type:forged.id,pos:[3.15,0,16.65],yawDeg:-10,scale:large,visible:propVisible,opts:{color:'#78d8e8'},bob:beat==='reveal'?{amp:.12,rate:2.3}:null}];
      if(beat==='spread'){
        objects.push({id:'storyPropLeft',type:forged.id,pos:[-5.6,0,16.7],yawDeg:-12,scale:.64,opts:{color:'#b394ff'}});
        objects.push({id:'storyPropRight',type:forged.id,pos:[6.7,0,16.7],yawDeg:12,scale:.64,opts:{color:'#8dd4a0'}});
      }
      const toolType=({vision:'camera_video',door:'remote',lie:'microphone',movement:'remote',speech:'megaphone',night:'phone',body:'phone',book:'phone',robot:'remote',puppet:'phone',chair:'remote',general:'phone'})[kind]||'phone';
      if(['discovery','perform','setback'].includes(beat))objects.push({id:'heroTool',type:toolType,pos:[-9,0,22],scale:.42,visible:false});
      return {id:'s'+(i+1),vo,beat,actionType:inferAction(vo,kind,beat),kind,sky:twist?(tone==='funny'?'sunset':'night'):(i%4===0?'sunset':'day'),world:[{type:world,...(world==='city'?{landmark:'ODD TOWN'}:world==='room'?{kind:'living'}:{})}],actors,objects,actions:[],cam:[],dur:3,seed:seed+i};
    });
    return {title:'The town where '+rule.slice(0,65),slug,rule,seed,look:tone==='funny'?'candy':tone==='suspense'?'night':'horror',music:{mood:tone==='funny'?'quirky':tone==='suspense'?'suspense':'spooky',twist_at:'last',twist_mood:'tense',volume:.18},subtitles:{style:'goopie',size:112},defaults:{sky:'day',world:[{type:'city'}]},characters:chars,scenes,assetForge:{generated:!!Studio.AssetForge,kind:forged.kind||kind,variant:forged.variant??null,partCount:forged.partCount??null,reused:!!forged.reused,inventory:Studio.AssetForge?.inventory?.()||0}};
  }

  function prepareChoreography(story,tts){
    const anim=(actor,at,clip,dur,params={})=>({actor,at,do:'anim',clip,dur:Math.max(.18,dur),params,blend:.12});
    const obj=(id,at,doName,extra={})=>Object.assign({obj:id,at,do:doName},extra);
    story.scenes.forEach((scene,i)=>{
      const speech=tts.timings[i].speechDuration||tts.timings[i].duration||2;
      const d=Math.max(1.25,speech+.07);
      const a=Math.min(d*.34,.78),b=Math.min(d*.68,Math.max(a+.22,d-.18)),tail=Math.max(.22,d-b);
      scene.dur=d;
      const A=[];
      // The protagonist's performance is selected from the meaning of the line, not its scene number.
      if(scene.beat==='rule'){
        A.push(anim('hero',0,'lookAround',Math.min(.72,d*.42)),anim('hero',Math.min(.7,d*.42),'talk',Math.max(.25,d-.7)));
        if(scene.actors.neighbor)A.push(anim('neighbor',.12,'scared',Math.min(.8,d*.45)));
      } else if(scene.beat==='reaction'){
        A.push(anim('hero',0,'recoil',Math.min(.72,d*.42)),anim('hero',a,'search',Math.max(.25,d-a)));
        if(scene.actors.neighbor)A.push(anim('neighbor',.08,'shiver',Math.min(.85,d*.42)));
      } else if(scene.beat==='discovery'){
        if(scene.kind!=='robot')A.push(obj('storyProp',0,'show'));
        A.push(anim('hero',0,'think',Math.min(.62,d*.34)),anim('hero',a,'determined',Math.max(.25,d-a)));
        A.push({actor:'hero',at:a,do:'turn',to:scene.actors.bot?'bot':'storyProp',dur:.22});
        if(scene.kind!=='robot')A.push(obj('storyProp',b,'scaleTo',{to:1.02,dur:.22,ease:'back'}));
      } else if(scene.beat==='perform'){
        const interactionTarget=scene.actors.bot?'bot':'storyProp';
        const approach=scene.actors.bot?[2.45,0,16.1]:(scene.actionType==='sit'?[2.35,0,17.1]:[1.6,0,16.2]);
        A.push({actor:'hero',at:.04,do:'walkTo',to:approach,dur:Math.min(.72,d*.38),anim:'walk',path:'straight',speed:5.4});
        const useClip=({inspect:'inspect',talk:'talk',build:'operate',operate:'operate',sit:'sit',wave:'wave_big',hide:'hide',fall:'slip'})[scene.actionType]||'useObject';
        A.push(anim('hero',a,useClip,Math.max(.3,d-a)));
        A.push({actor:'hero',at:Math.min(a,.25),do:'turn',to:interactionTarget,dur:.22});
        if(!scene.actors.bot){
          A.push({obj:'heroTool',at:a,do:'show'});
          A.push({obj:'heroTool',at:a,do:'attach',actor:'hero',bone:'handR',off:[0,0,.1],until:'end-0.08'});
          // Give each prop family a physical response that matches how it is used.
          if(scene.kind==='door') A.push(obj('storyProp',b,'yawTo',{to:72,deg:true,dur:.48,ease:'inout'}));
          else if(scene.kind==='book') A.push(obj('storyProp',b,'pitchTo',{to:-.28,dur:.34,ease:'out'}));
          else if(scene.kind==='chair'||scene.kind==='movement') A.push(obj('storyProp',b,'moveTo',{to:[4.6,0,16.55],dur:.48,ease:'out'}));
          else if(scene.kind==='vision') A.push(obj('storyProp',b,'yawTo',{to:scene.actionType==='inspect'?180:-24,deg:true,dur:.38,ease:'inout'}));
          else if(scene.kind==='speech') A.push(obj('storyProp',b,'pitchTo',{to:-.18,dur:.3,ease:'out'}));
          else if(scene.kind==='night') A.push(obj('storyProp',b,'spin',{rate:.45}));
          else if(scene.kind==='puppet') A.push(obj('storyProp',b,'yawTo',{to:24,deg:true,dur:.35,ease:'inout'}));
          A.push({do:'fx',kind:'sparkle',at:b,dur:.7,on:'storyProp'});
        } else {
          A.push({do:'fx',kind:'sparkle',at:b,dur:.7,on:'bot'});
        }
      } else if(scene.beat==='spread'){
        A.push(anim('hero',0,'present',Math.max(.5,d)),anim('neighbor',0,'curious',Math.min(.65,d*.35)));
        if(scene.actors.neighbor)A.push({actor:'neighbor',at:a,do:'runTo',to:[-2.8,0,16.2],dur:Math.min(.72,d-a),path:'straight',speed:8});
        if(scene.actors.neighbor)A.push(anim('neighbor',b,'wave_big',tail));
        A.push(obj('storyPropLeft',a,'scaleTo',{to:.86,dur:.3,ease:'back'}),obj('storyPropRight',b,'scaleTo',{to:.86,dur:.3,ease:'back'}));
        A.push({do:'fx',kind:story.look==='candy'?'confetti':'sparkle',at:b,dur:.85,on:'hero'});
      } else if(scene.beat==='authority'){
        A.push({actor:'mayor',at:.02,do:'walkTo',to:[7.6,0,16.9],dur:Math.min(.82,d*.42),anim:'walk',path:'straight',speed:5.6});
        A.push(anim('mayor',a,'salute',Math.max(.25,d-a)),anim('mayor',b,'point',tail));
        A.push({actor:'hero',at:.12,do:'turn',to:'mayor',dur:.24},anim('hero',a,'scared',Math.max(.25,d-a)));
      } else if(scene.beat==='reveal'){
        A.push(anim('hero',0,'inspect',Math.min(.58,d*.32)),anim('hero',a,'jumpscare',Math.max(.32,d-a)));
        if(scene.actors.mayor)A.push(anim('mayor',0,'angry',Math.max(.25,d)),anim('mayor',b,'point',tail));
        if(scene.kind!=='robot')A.push(obj('storyProp',b,'spin',{rate:1.15}));
        A.push({do:'shake',at:b,dur:.35,amp:.5},{do:'fx',kind:'impact',at:b,dur:.65,on:scene.actors.bot?'bot':'storyProp'});
      } else if(scene.beat==='setback'){
        A.push(anim('hero',0,story.look==='candy'?'slip':'hide',Math.min(.72,d*.42)),anim('hero',a,story.look==='candy'?'facepalm':'panic',Math.max(.25,d-a)));
        if(scene.kind!=='robot')A.push(obj('storyProp',b,'yawTo',{to:scene.kind==='door'?-18:22,deg:true,dur:.24,ease:'out'}));
        A.push({do:'fx',kind:story.look==='candy'?'poof':'smoke',at:b,dur:.8,on:scene.actors.bot?'bot':'hero'});
      } else if(scene.beat==='finale'){
        A.push(anim('hero',0,story.look==='candy'?'facepalm':'recoil',Math.min(.62,d*.34)),anim('hero',a,story.look==='candy'?'victory':'determined',Math.max(.25,d-a)));
        if(scene.actors.neighbor)A.push(anim('neighbor',a,'cheer2',Math.max(.25,d-a)));
        if(scene.actors.mayor)A.push(anim('mayor',a,'present',Math.max(.25,d-a)));
        A.push({do:'fx',kind:story.look==='candy'?'confetti':'sparkle',at:b,dur:.9,on:scene.actors.bot?'bot':'hero'});
      } else {
        A.push(anim('hero',0,'talk',d));
        if(scene.actors.neighbor)A.push(anim('neighbor',a,'curious',tail));
        A.push(obj('storyProp',b,'yawTo',{to:15,deg:true,dur:.24,ease:'out'}));
      }
      // Sentence-level action cues refine the semantic beat without overriding its story arc.
      if(scene.beat!=='perform'&&scene.beat!=='rule'&&scene.beat!=='finale'){
        if(scene.actionType==='run'){
          A.push({actor:'hero',at:a,do:'runTo',to:[-3.8,0,18.1],dur:Math.min(.72,d-a),path:'straight',speed:6.8},anim('hero',a,'run',Math.max(.3,d-a)));
        } else if(scene.actionType==='sit'){
          A.push({actor:'hero',at:a,do:'walkTo',to:[2.45,0,17.2],dur:Math.min(.55,d-a),path:'straight',speed:4.4},anim('hero',b,'sit',tail));
        } else if(scene.actionType==='inspect'&&scene.beat!=='discovery'){
          A.push(anim('hero',a,'inspect',Math.max(.3,d-a)),{actor:'hero',at:a,do:'turn',to:scene.actors.bot?'bot':'storyProp',dur:.2});
        } else if((scene.actionType==='open'||scene.actionType==='close')&&!scene.actors.bot){
          A.push(anim('hero',a,'useObject',Math.max(.3,d-a)));
          if(scene.kind==='door')A.push(obj('storyProp',a,'yawTo',{to:scene.actionType==='open'?72:-10,deg:true,dur:.42,ease:'inout'}));
          else if(scene.kind==='book')A.push(obj('storyProp',a,'pitchTo',{to:scene.actionType==='open'?.28:0,dur:.34,ease:'out'}));
        } else if(scene.actionType==='build'||scene.actionType==='operate'){
          A.push(anim('hero',a,'operate',Math.max(.3,d-a)));
        } else if(scene.actionType==='talk'){
          A.push(anim('hero',a,'talk',Math.max(.3,d-a)));
        } else if(scene.actionType==='wave'){
          A.push(anim(scene.actors.bot?'bot':'hero',a,'wave_big',Math.max(.3,d-a)));
        } else if(scene.actionType==='hide'){
          A.push(anim('hero',a,'hide',Math.max(.3,d-a)));
        } else if(scene.actionType==='fall'){
          A.push(anim('hero',a,'slip',Math.max(.3,d-a)),{do:'shake',at:b,dur:.25,amp:.22});
        }
      }
      if(scene.actors.bot){
        const botClip=({rule:'robot',reaction:'curious',discovery:'curious',perform:'operate',spread:'wave_big',authority:'recoil',reveal:'glitch',setback:'shiver',finale:'cheer2',escalation:'robot'})[scene.beat]||'robot';
        A.push(anim('bot',0,botClip,Math.max(.25,d)));
      }
      if(i===0)A.push({do:'title',text:'ONE RULE. NO EXCEPTIONS.',at:.08,dur:1.05,size:1.0,style:'title'});
      if(scene.beat==='discovery')A.push({do:'sfx',name:'pop',at:a,vol:.55});
      if(scene.beat==='authority')A.push({do:'sfx',name:'swish',at:a,vol:.45});
      scene.actions=A;
      const camB=Math.min(d*.34,.78),camC=Math.min(d*.69,Math.max(camB+.22,d-.16));
      const last=scene.beat==='finale';
      const propFocus=scene.actors.bot?'bot':'storyProp';
      scene.cam=[
        {at:0,shot:i===0?'wide':'medium',on:i===0?['hero',propFocus]:'hero',move:i===0?'crane':'drift',amount:.18,ease:'inout'},
        {at:camB,shot:scene.beat==='authority'?'low':'close',on:scene.beat==='authority'?'mayor':'hero',move:'push',amount:.12,ease:'out'},
        {at:camC,shot:last?'low':(scene.beat==='perform'||scene.beat==='reveal'?'close':'over'),on:['authority','reveal'].includes(scene.beat)?'mayor':propFocus,move:scene.beat==='spread'?'orbit':'dolly',deg:scene.beat==='spread'?18:0,amount:.1,ease:'inout'}
      ];
    });
    story.assetForge.inventory=Studio.AssetForge?.inventory?.()||0;
  }

  // Embedded copy for extracted file:// copies. This avoids fetching a sibling
  // worker file from the ZIP/local-file origin. WASM inference stays off the UI thread.
  function inlineKokoroWorker(){
    const KOKORO_MODULE_URL='https://cdn.jsdelivr.net/npm/kokoro-js@1.2.1/dist/kokoro.web.js';
    const MODEL_ID='onnx-community/Kokoro-82M-v1.0-ONNX';
    const VOICE_SPEED=1.14;
    let tts=null,loading=null;
    function postError(id,phase,error){
      const message=error&&typeof error==='object'?(error.message||error.name||JSON.stringify(error)):String(error);
      self.postMessage({type:'error',id:id??null,phase,message,stack:error?.stack||''});
    }
    async function loadModel(){
      if(tts)return tts;if(loading)return loading;
      loading=(async()=>{
        self.postMessage({type:'progress',message:'Cargando Kokoro en segundo plano…',progress:8});
        const mod=await import(KOKORO_MODULE_URL);
        if(!mod.KokoroTTS)throw new Error('La compilación de Kokoro no expone KokoroTTS.');
        const onProgress=event=>{
          const loaded=Number(event?.loaded||0),total=Number(event?.total||0),file=event?.file||event?.name||event?.path||'modelo';
          if(total>0)self.postMessage({type:'progress',message:`Descargando Kokoro (${file}) · ${Math.round(loaded/1048576)} / ${Math.round(total/1048576)} MB…`,progress:Math.round(10+Math.min(1,loaded/total)*14)});
          else if(event?.status)self.postMessage({type:'progress',message:`Preparando Kokoro (${file}) · ${event.status}…`,progress:12});
        };
        const hasGPU=typeof navigator!=='undefined'&&!!navigator.gpu;
        if(hasGPU){
          try{self.postMessage({type:'progress',message:'Probando aceleración gráfica para acelerar la voz…',progress:10});tts=await mod.KokoroTTS.from_pretrained(MODEL_ID,{dtype:'fp32',device:'webgpu',progress_callback:onProgress});}
          catch(gpuError){self.postMessage({type:'progress',message:'Aceleración gráfica no disponible; usando el modo compatible…',progress:13});tts=null;}
        }
        if(!tts)tts=await mod.KokoroTTS.from_pretrained(MODEL_ID,{dtype:'q8',device:'wasm',progress_callback:onProgress});
        if(typeof tts.generate!=='function')throw new Error('Kokoro se ha cargado, pero no ofrece generate().');
        self.postMessage({type:'ready',message:'Kokoro está listo en segundo plano.'});return tts;
      })();
      try{return await loading;}catch(error){tts=null;loading=null;throw error;}
    }
    self.addEventListener('message',async event=>{
      const data=event.data||{};
      if(data.type==='load'){try{await loadModel();}catch(error){postError(null,'carga de Kokoro',error);}return;}
      if(data.type==='generate'){
        try{
          const model=await loadModel();
          const result=await model.generate(String(data.text||''),{voice:data.voice||'am_adam',speed:Number(data.speed||VOICE_SPEED)});
          const audio=result?.audio instanceof Float32Array?result.audio:(result?.audio?.audio instanceof Float32Array?result.audio.audio:null);
          if(!audio||!audio.length)throw new Error('Kokoro no ha devuelto muestras de audio.');
          const sampleRate=result?.sampling_rate||result?.sample_rate||result?.audio?.sampling_rate||24000;
          self.postMessage({type:'audio',id:data.id,audio,sampleRate},[audio.buffer]);
        }catch(error){postError(data.id,'generación de voz',error);}
      }
    });
  }

  function workerFailure(e){
    const msg=e?.message||'No se ha podido iniciar el proceso de voz en segundo plano.';
    for(const [id,p] of state.workerPending){p.reject(new Error(msg));state.workerPending.delete(id);}
    if(state.workerReadyReject){state.workerReadyReject(new Error(msg));state.workerReadyReject=null;}
    try{state.worker?.terminate();}catch{}
    state.worker=null;state.workerReady=null;state.engine=null;
    if(state.workerBlobUrl){try{URL.revokeObjectURL(state.workerBlobUrl);}catch{}state.workerBlobUrl=null;}
  }

  function generateInWorker(text,opts={}){
    if(!state.worker) return Promise.reject(new Error('El proceso de Kokoro no está activo.'));
    const id=++state.workerSeq;
    return new Promise((resolve,reject)=>{
      state.workerPending.set(id,{resolve,reject});
      try{state.worker.postMessage({type:'generate',id,text,voice:opts.voice||KOKORO_VOICE,speed:opts.speed||KOKORO_SPEED});}
      catch(error){state.workerPending.delete(id);reject(error);}
    });
  }

  async function loadKokoro(progress){
    if(state.engine) return state.engine;
    if(state.workerReady) return state.workerReady;
    state.stage='carga de Kokoro';
    // HTTPS uses the separate worker file. Extracted file:// copies use an
    // embedded Blob module worker, so the app can be opened without publishing.
    if(!window.Worker) throw new Error('Este navegador no admite Web Workers. Actualiza Chrome para ejecutar Kokoro sin bloquear la página.');
    progress(location.protocol==='file:'
      ? 'Iniciando Kokoro en segundo plano desde la copia local…'
      : 'Iniciando Kokoro en segundo plano para no bloquear Chrome…',8);
    state.workerReady=new Promise((resolve,reject)=>{
      state.workerReadyReject=reject;
      let worker;
      try{
        if(location.protocol==='file:'){
          const source=`(${inlineKokoroWorker.toString()})();`;
          const blobUrl=URL.createObjectURL(new Blob([source],{type:'text/javascript'}));
          state.workerBlobUrl=blobUrl;
          worker=new Worker(blobUrl,{type:'module',name:'in-this-town-kokoro-local'});
        } else {
          worker=new Worker(new URL('./kokoro-worker.js',document.baseURI),{type:'module',name:'in-this-town-kokoro'});
        }
      }catch(error){
        state.workerReady=null;state.workerReadyReject=null;
        reject(new Error('No se pudo iniciar Kokoro en segundo plano. Detalle: '+errorText(error)));
        return;
      }
      state.worker=worker;
      worker.addEventListener('message',(event)=>{
        const msg=event.data||{};
        if(msg.type==='progress'){
          progress(msg.message||'Preparando Kokoro…',msg.progress??12);
          return;
        }
        if(msg.type==='ready'){
          state.engine={generate:generateInWorker};
          if(state.workerBlobUrl){try{URL.revokeObjectURL(state.workerBlobUrl);}catch{}state.workerBlobUrl=null;}
          state.workerReadyReject=null;
          progress('Kokoro-82M listo · voz am_adam · cálculo en segundo plano.',25);
          resolve(state.engine);
          return;
        }
        if(msg.type==='audio'){
          const pending=state.workerPending.get(msg.id);
          if(pending){state.workerPending.delete(msg.id);pending.resolve({audio:msg.audio,sampling_rate:msg.sampleRate});}
          return;
        }
        if(msg.type==='error'){
          const detail=msg.message||'Error desconocido del proceso Kokoro.';
          if(msg.id!=null){const pending=state.workerPending.get(msg.id);if(pending){state.workerPending.delete(msg.id);pending.reject(new Error(detail));}}
          else {
            workerFailure(new Error(`Kokoro no ha podido iniciarse: ${detail}`));
          }
        }
      });
      worker.addEventListener('error',(event)=>{
        const detail=event.message||'Error cargando kokoro-worker.js';
        workerFailure(new Error(detail));
      });
      worker.addEventListener('messageerror',()=>workerFailure(new Error('Chrome no pudo recibir los datos de audio del proceso Kokoro.')));
      worker.postMessage({type:'load'});
    });
    try{return await state.workerReady;}
    catch(error){state.workerReady=null;state.engine=null;throw error;}
  }

  function errorText(e){
    if(typeof e==='number') return `Valor numérico: ${e} (0x${(e>>>0).toString(16).toUpperCase()})`;
    if(typeof e==='string') return e;
    if(e===null) return 'El navegador devolvió null.';
    if(e===undefined) return 'El navegador devolvió un error vacío (undefined).';
    if(e instanceof Error) {
      const parts=[`${e.name}: ${e.message}`];
      if(e.code!==undefined) parts.push(`code=${e.code}`);
      if(e.cause!==undefined && e.cause!==e) parts.push(`cause=${errorText(e.cause)}`);
      if(e.stack) parts.push(e.stack.split('\n').slice(0,4).join(' | '));
      return parts.join(' · ');
    }
    if(typeof e==='object') {
      const parts=[];
      for(const k of ['name','message','code','status','url','type','cause']) {
        if(e[k]!==undefined && e[k]!==e) parts.push(`${k}=${typeof e[k]==='object'?errorText(e[k]):String(e[k])}`);
      }
      if(parts.length) return parts.join(' · ');
      try { return JSON.stringify(e)||Object.prototype.toString.call(e); } catch { return Object.prototype.toString.call(e); }
    }
    return String(e);
  }

  function speechWeight(text){
    return String(text||'').split(/\s+/).filter(Boolean).reduce((sum,w)=>sum+countSyllableWeight(w),0);
  }
  function cleanSpokenLine(line){return String(line||'').replace(/\*([^*]+)\*/g,'$1').replace(/[.!?…]+$/,'').trim();}
  function buildSpeechGroups(lines){
    const groups=[];let i=0;
    while(i<lines.length){
      const picked=[];let words=0;
      while(i<lines.length&&picked.length<3){
        const clean=cleanSpokenLine(lines[i]);const count=clean.split(/\s+/).filter(Boolean).length;
        if(picked.length&&words+count>25)break;
        picked.push(lines[i]);words+=count;i++;
      }
      const text=picked.map((line,j)=>{const clean=cleanSpokenLine(line);return j?clean.charAt(0).toLowerCase()+clean.slice(1):clean;}).join('; ')+'.';
      groups.push({start:i-picked.length,count:picked.length,lines:picked,text,wordCount:words});
    }
    return groups;
  }
  function findSpeechBreak(pcm,sampleRate,estimate,window=.26){
    const frame=Math.max(160,Math.round(sampleRate*.024)),step=Math.max(80,Math.round(sampleRate*.01));
    const from=Math.max(frame,Math.round((estimate-window)*sampleRate));
    const to=Math.min(pcm.length-frame,Math.round((estimate+window)*sampleRate));
    if(to<=from)return estimate;
    const energies=[];
    for(let at=from;at<=to;at+=step){let sum=0;for(let j=0;j<frame;j+=4){const v=pcm[at+j]||0;sum+=v*v;}energies.push({time:(at+frame*.5)/sampleRate,rms:Math.sqrt(sum/Math.ceil(frame/4))});}
    if(!energies.length)return estimate;
    const sorted=energies.map(x=>x.rms).sort((a,b)=>a-b),median=sorted[Math.floor(sorted.length*.55)]||0;
    let best=null;
    for(const item of energies){const distance=Math.abs(item.time-estimate)/window;const score=item.rms+median*.20*distance;if(!best||score<best.score)best={...item,score};}
    // Only snap to a clear quiet pocket; otherwise keep the phoneme-weight estimate.
    return best&&median>0&&best.rms<median*.68?best.time:estimate;
  }
  async function synthesize(lines,audioCtx,progress){
    const engine=await loadKokoro(progress);
    const groups=buildSpeechGroups(lines),chunks=[],timings=[];
    let total=0,sampleRate=24000;
    for(let g=0;g<groups.length;g++){
      if(state.cancel) throw new Error('Cancelado.');
      const group=groups[g];
      progress(`Generando narración Kokoro · bloque ${g+1}/${groups.length} (${group.count} escenas)…`,16+(g/groups.length)*16);
      const result=await engine.generate(group.text,{voice:KOKORO_VOICE,speed:KOKORO_SPEED});
      const pcm=result?.audio instanceof Float32Array ? result.audio : (result?.audio?.audio instanceof Float32Array ? result.audio.audio : null);
      sampleRate=result?.sampling_rate||result?.sample_rate||result?.audio?.sampling_rate||sampleRate;
      if(!pcm||!pcm.length) throw new Error('Kokoro no ha generado audio válido para el bloque '+(g+1)+'. Comprueba que el modelo y la voz am_adam se han descargado correctamente.');
      const groupStart=total/sampleRate,groupDuration=pcm.length/sampleRate;
      chunks.push(pcm);total+=pcm.length;
      const weights=group.lines.map(speechWeight);
      const pauseWeight=.82;
      const weighted=weights.map((w,j)=>w+(j<weights.length-1?pauseWeight:0));
      const sum=weighted.reduce((a,b)=>a+b,0)||1;
      const boundaries=[0];let cumulative=0,previous=.28;
      for(let j=0;j<group.count-1;j++){
        cumulative+=weighted[j];
        const estimate=groupDuration*cumulative/sum;
        const remaining=group.count-j-1;
        const lower=Math.max(previous+.28,estimate-.26);
        const upper=Math.min(groupDuration-remaining*.28,estimate+.26);
        const snapped=findSpeechBreak(pcm,sampleRate,estimate,.26);
        const boundary=Math.max(lower,Math.min(upper,snapped));
        boundaries.push(boundary);previous=boundary;
      }
      boundaries.push(groupDuration);
      for(let j=0;j<group.count;j++){
        const start=groupStart+boundaries[j];
        const speechDuration=Math.max(.18,boundaries[j+1]-boundaries[j]);
        const hasGroupGap=g<groups.length-1&&j===group.count-1;
        timings[group.start+j]={start,end:start+speechDuration,speechDuration,duration:speechDuration+(hasGroupGap?SCENE_GAP_SECONDS:0)};
      }
      if(g<groups.length-1){const pause=Math.round(sampleRate*SCENE_GAP_SECONDS);chunks.push(new Float32Array(pause));total+=pause;}
    }
    const joined=new Float32Array(total);let offset=0;
    for(const c of chunks){joined.set(c,offset);offset+=c.length;}
    const b=audioCtx.createBuffer(1,joined.length,sampleRate);b.getChannelData(0).set(joined);
    return {pcm:joined,timings,duration:joined.length/sampleRate,buffer:b,sampleRate,groupCount:groups.length};
  }

  function wrapLine(ctx,text,maxWidth){
    const words=text.split(/\s+/),lines=[];let line='';
    for(const word of words){const test=line?line+' '+word:word;if(ctx.measureText(test).width>maxWidth&&line){lines.push(line);line=word;}else line=test;}
    if(line)lines.push(line);return lines;
  }
  function countSyllableWeight(word){
    const clean=word.toLowerCase().replace(/[^a-z']/g,'');
    const groups=clean.match(/[aeiouy]+/g);
    let n=Math.max(1,groups?groups.length:1);
    if(clean.length>7)n+=.35;
    if(/e$/.test(clean)&&n>1&&!/(le|ye)$/.test(clean))n-=.35;
    return Math.max(.8,n);
  }
  function drawCaption(ctx,text,elapsed=0,duration=2.2){
    const clean=String(text||'').replace(/\*([^*]+)\*/g,'$1').trim().toUpperCase();
    const words=clean.split(/\s+/).filter(Boolean);
    if(!words.length)return;
    const weights=words.map(countSyllableWeight),total=weights.reduce((a,b)=>a+b,0);
    const target=Math.max(0,Math.min(.999,elapsed/Math.max(.25,duration)))*total;
    let acc=0,current=0;for(let i=0;i<weights.length;i++){acc+=weights[i];if(target<=acc){current=i;break;}current=i;}
    ctx.save();ctx.textAlign='center';ctx.textBaseline='middle';ctx.font='900 36px system-ui,Arial';
    const maxWidth=500,space=12,rows=[];let row=[],rowWidth=0;
    words.forEach((word,index)=>{const width=Math.min(maxWidth,ctx.measureText(word).width);const needed=row.length?space+width:width;if(row.length&&rowWidth+needed>maxWidth){rows.push({items:row,width:rowWidth});row=[];rowWidth=0;}const add= row.length?space+width:width;row.push({word,index,width});rowWidth+=add;});
    if(row.length)rows.push({items:row,width:rowWidth});
    const visibleRows=rows.slice(0,2),lineH=47,blockH=visibleRows.length*lineH+26;
    const panelW=Math.min(536,Math.max(230,...visibleRows.map(r=>r.width+34)));
    const panelY=H-168-blockH/2;
    ctx.fillStyle='#080b16e8';ctx.strokeStyle='#ffffff42';ctx.lineWidth=2;
    ctx.beginPath();ctx.roundRect((W-panelW)/2,panelY,panelW,blockH,15);ctx.fill();ctx.stroke();
    ctx.shadowColor='#000';ctx.shadowBlur=8;
    visibleRows.forEach((r,ri)=>{
      let x=(W-r.width)/2;const y=panelY+blockH/2-(visibleRows.length-1)*lineH/2+ri*lineH;
      r.items.forEach((item,j)=>{
        if(item.index===current){ctx.fillStyle='#ffe36e';ctx.shadowColor='#ffce4a';ctx.shadowBlur=13;}
        else if(item.index<current){ctx.fillStyle='#ffffff';ctx.shadowColor='#000';ctx.shadowBlur=7;}
        else {ctx.fillStyle='#d9deed';ctx.shadowColor='#000';ctx.shadowBlur=5;}
        ctx.fillText(item.word,x+item.width/2,y,maxWidth);
        x+=item.width+space;
      });
    });
    ctx.restore();
  }
  function drawFrame(sceneIndex,elapsed,caption,speechElapsed=0,speechDuration=2.2){
    if(state.mode!=='webgl') throw new Error('El motor 3D original no está disponible.');
    Studio.api.frame(Math.max(0,Math.min(elapsed,5.5)));
    outCtx.drawImage(glCanvas,0,0,W,H);
    const g=outCtx.createLinearGradient(0,H-340,0,H);g.addColorStop(0,'#07091400');g.addColorStop(1,'#070914d9');outCtx.fillStyle=g;outCtx.fillRect(0,H-340,W,340);
    outCtx.save();outCtx.textAlign='center';outCtx.fillStyle='#ffffffbb';outCtx.font='800 17px system-ui';outCtx.fillText('IN THIS TOWN',W/2,70);outCtx.restore();
    drawCaption(outCtx,caption,speechElapsed,speechDuration);
  }

  function getMime(){
    const candidates=['video/mp4;codecs=avc1.42E01E,mp4a.40.2','video/mp4','video/webm;codecs=vp9,opus','video/webm;codecs=vp8,opus','video/webm'];
    for(const t of candidates){try{if(MediaRecorder.isTypeSupported(t))return t;}catch{}}
    return '';
  }
  async function loadMusic(ctx,mood){
    // Optional user-selected soundtrack. The file stays on-device and is never uploaded.
    if(state.musicFile){
      const bytes=await state.musicFile.arrayBuffer();
      try { return await ctx.decodeAudioData(bytes.slice(0)); }
      catch(e){ throw new Error('No se ha podido leer el archivo de música. Prueba con MP3, WAV, M4A u OGG.'); }
    }
    // Original ambient bed generated locally as a fallback; no copyrighted recording bundled.
    const patterns={
      quirky:[{b:82,p:165,m:247},{b:98,p:196,m:294},{b:110,p:220,m:330},{b:98,p:196,m:294}],
      suspense:[{b:55,p:110,m:165},{b:62,p:124,m:185},{b:58,p:116,m:174},{b:65,p:130,m:196}],
      tense:[{b:49,p:98,m:147},{b:55,p:110,m:165},{b:52,p:104,m:156},{b:58,p:116,m:174}],
      chill:[{b:73,p:146,m:220},{b:82,p:165,m:247},{b:87,p:174,m:262},{b:82,p:165,m:247}],
      spooky:[{b:55,p:110,m:165},{b:65,p:130,m:196},{b:58,p:116,m:174},{b:73,p:146,m:220}]
    };
    const pattern=patterns[mood]||patterns.spooky, seconds=8, length=ctx.sampleRate*seconds;
    const buffer=ctx.createBuffer(2,length,ctx.sampleRate), left=buffer.getChannelData(0), right=buffer.getChannelData(1);
    for(let i=0;i<length;i++){
      const t=i/ctx.sampleRate, beat=t%2, bar=Math.floor(t/2)%4, n=pattern[bar];
      const fade=Math.min(1,t/.7,(seconds-t)/.7);
      const bass=Math.sin(2*Math.PI*n.b*t)*.025;
      const pad=(Math.sin(2*Math.PI*n.p*t)+.25*Math.sin(2*Math.PI*n.p*2*t)+.12*Math.sin(2*Math.PI*n.p*3*t))*.012;
      const shimmer=Math.sin(2*Math.PI*n.m*t+Math.sin(t*1.7)*.18)*.006;
      const pluck=Math.exp(-beat*4.5)*Math.sin(2*Math.PI*n.m*t)*.012;
      const pulse=Math.exp(-beat*13)*Math.sin(2*Math.PI*48*beat)*.009;
      const sample=(bass+pad+shimmer+pluck+pulse)*Math.max(0,fade);
      left[i]=sample;right[i]=(bass+pad+Math.sin(2*Math.PI*n.m*(t+.003))*.006+pluck+pulse)*Math.max(0,fade);
    }
    return buffer;
  }

  async function recordVideo(story,lines,tts,audioCtx,tone,progress){
    const compiled=[];
    story.scenes.forEach((s,i)=>{s.dur=Math.max(1.18,tts.timings[i].duration);compiled.push({dur:s.dur});});
    if(state.mode==='webgl'){
      progress('Preparing 3D sets and camera moves…',32);
      Studio.api.setStory(story);
    }
    const totalDuration=tts.duration;
    const timings=tts.timings.map((v,i)=>({start:v.start,end:v.start+v.duration,index:i}));
    const voiceBuf=tts.buffer;
    const voiceSource=audioCtx.createBufferSource();voiceSource.buffer=voiceBuf;
    const voiceGain=audioCtx.createGain();voiceGain.gain.value=1.12;voiceSource.connect(voiceGain);
    const musicBuf=await loadMusic(audioCtx,story.music.mood);
    const musicSource=audioCtx.createBufferSource();musicSource.buffer=musicBuf;musicSource.loop=true;
    const musicGain=audioCtx.createGain();musicGain.gain.value=state.musicFile ? .085 : .095;musicSource.connect(musicGain);
    const compressor=audioCtx.createDynamicsCompressor();compressor.threshold.value=-18;compressor.knee.value=12;compressor.ratio.value=3;compressor.attack.value=.012;compressor.release.value=.22;
    const mix=audioCtx.createMediaStreamDestination();voiceGain.connect(compressor);musicGain.connect(compressor);compressor.connect(mix);
    const videoStream=outCanvas.captureStream(FPS);
    const stream=new MediaStream([...videoStream.getVideoTracks(),...mix.stream.getAudioTracks()]);
    const mime=getMime();if(!mime)throw new Error('Este navegador no puede exportar vídeo. Prueba con una versión reciente de Chrome, Edge o Safari.');
    let recorder;try{recorder=new MediaRecorder(stream,{mimeType:mime,videoBitsPerSecond:3_000_000,audioBitsPerSecond:128_000});}catch{recorder=new MediaRecorder(stream,{mimeType:mime});}
    const chunks=[];recorder.ondataavailable=e=>{if(e.data?.size)chunks.push(e.data);};
    const stopped=new Promise((resolve,reject)=>{recorder.onstop=resolve;recorder.onerror=e=>reject(e.error||new Error('Video recording failed.'));});
    recorder.start(1000);
    await audioCtx.resume();musicSource.start(0);voiceSource.start(0);
    $('placeholder').style.display='none';
    const start=performance.now();let lastScene=-1,renderError=null;
    await new Promise(resolve=>{
      const stop=()=>{try{if(recorder.state!=='inactive')recorder.stop();}catch{}resolve();};
      const tick=()=>{
        try{
          if(state.cancel){renderError=new Error('Cancelado.');stop();return;}
          const elapsed=(performance.now()-start)/1000;
          if(elapsed>=totalDuration){stop();return;}
          let sIndex=timings.findIndex(x=>elapsed>=x.start&&elapsed<x.end);if(sIndex<0)sIndex=timings.length-1;
          const t=timings[sIndex],local=elapsed-t.start;
          if(sIndex!==lastScene){lastScene=sIndex;try{Studio.api.compile(sIndex,{fast:false});}catch(sceneError){throw new Error(`Error al preparar la escena 3D ${sIndex+1}/${story.scenes.length}: ${errorText(sceneError)}`);}}
          try{drawFrame(sIndex,local,lines[sIndex],Math.min(local,tts.timings[sIndex].speechDuration),tts.timings[sIndex].speechDuration);}catch(frameError){throw new Error(`Error al dibujar la escena 3D ${sIndex+1}/${story.scenes.length}: ${errorText(frameError)}`);}
          if(Math.floor(elapsed)!==Math.floor(elapsed-1/FPS)){const pct=58+elapsed/totalDuration*40;progress(`Renderizando escena 3D ${sIndex+1}/${lines.length} · ${Math.floor(elapsed)} s`,pct);}
          requestAnimationFrame(tick);
        }catch(e){renderError=e;stop();}
      };
      requestAnimationFrame(tick);
    });
    await stopped;
    try{videoStream.getTracks().forEach(t=>t.stop());mix.stream.getTracks().forEach(t=>t.stop());voiceSource.disconnect();musicSource.stop();musicSource.disconnect();}catch{}
    if(renderError)throw renderError;
    const blob=new Blob(chunks,{type:mime.split(';')[0]||'video/webm'});
    if(blob.size<50000)throw new Error('The video file is too small; this browser may not support recording the canvas.');
    return {blob,mime,totalDuration};
  }

  function makePreviewStill(story){
    if(state.mode!=='webgl') throw new Error('El motor 3D original no está disponible.');
    Studio.api.setStory(story);story.scenes[0].dur=3;Studio.api.compile(0,{fast:false});Studio.api.frame(.3);outCtx.drawImage(glCanvas,0,0,W,H);
    outCtx.fillStyle='#070914a8';outCtx.fillRect(0,H-255,W,255);drawCaption(outCtx,story.scenes[0].vo,.35,2.2);
  }

  async function create(){
    if(state.busy)return;
    if(state.mode!=='webgl'){setStatus('El motor 3D original necesita WebGL 2. Actualiza el navegador y activa la aceleración gráfica.');return;}
    const idea=$('idea').value.trim(),tone=$('tone').value,length=$('length').value;
    if(idea.length<8){setStatus('Escribe una regla más concreta (mínimo 8 caracteres).');return;}
    if(!window.MediaRecorder||!outCanvas.captureStream){setStatus('Tu navegador no permite exportar vídeo. Prueba una versión reciente de Chrome, Edge o Safari.',0);return;}
    setBusy(true);state.cancel=false;$('result').classList.remove('show');
    if(jobUrl){URL.revokeObjectURL(jobUrl);jobUrl=null;}
    $('placeholder').style.display='grid';
    let audioCtx;
    try{
      state.stage='preparación';
      const AudioCtor=window.AudioContext||window.webkitAudioContext;
      if(!AudioCtor) throw new Error('Este navegador no ofrece Web Audio y no puede mezclar la narración.');
      audioCtx=new AudioCtor();await audioCtx.resume();
      const story=buildStory(idea,tone,length);state.story=story;
      setStatus(`Creando historia y coreografía · ${story.assetForge.kind} ${story.assetForge.reused?'reutilizado':'nuevo'} · ${story.assetForge.partCount||'—'} piezas · ${story.assetForge.inventory} recursos guardados…`,3);
      state.stage='generación de voz';
      const tts=await synthesize(story.scenes.map(s=>s.vo),audioCtx,setStatus);
      prepareChoreography(story,tts);
      state.stage='vista previa 3D';
      makePreviewStill(story);
      state.stage='grabación y render 3D';
      const result=await recordVideo(story,story.scenes.map(s=>s.vo),tts,audioCtx,tone,setStatus);
      const ext=result.mime.includes('mp4')?'mp4':'webm';jobUrl=URL.createObjectURL(result.blob);
      $('download').href=jobUrl;$('download').download='in-this-town-'+story.slug+'.'+ext;
      $('download').textContent='↓ DESCARGAR '+ext.toUpperCase();
      $('resultTitle').textContent=story.title;$('resultMeta').textContent=`${Math.round(result.totalDuration)} segundos · ${story.scenes.length} escenas · ${ext.toUpperCase()} · ${(result.blob.size/1024/1024).toFixed(1)} MB`;
      $('script').innerHTML=story.scenes.map((s,i)=>`<p><b>${String(i+1).padStart(2,'0')}.</b> ${escapeText(s.vo.replace(/\*/g,''))}</p>`).join('');
      $('result').classList.add('show');$('placeholder').style.display='none';
      setStatus('¡Terminado! Tu vídeo está listo para descargar.',100);
    } catch(e){
      const detail=errorText(e);
      console.error('In This Town create failed at '+state.stage+':',e);
      $('placeholder').style.display='grid';
      setStatus(`No se ha podido crear el vídeo · Fase: ${state.stage}\n${detail}`,0);
    } finally {try{await audioCtx?.close();}catch{};setBusy(false);state.cancel=false;state.stage='listo';}
  }
  $('create').addEventListener('click',create);
  window.addEventListener('beforeunload',()=>{if(jobUrl)URL.revokeObjectURL(jobUrl);});
  if('serviceWorker' in navigator && location.protocol.startsWith('http')) navigator.serviceWorker.register('./sw.js').catch(()=>{});
  initRenderer();
  if(location.protocol==='file:'){
    setStatus('Modo local activado. Extrae primero la carpeta del ZIP y abre site/index.html desde la carpeta extraída (no desde la vista previa del ZIP). Kokoro se ejecutará en segundo plano; necesitas internet la primera vez para descargar el modelo.');
  }
})();

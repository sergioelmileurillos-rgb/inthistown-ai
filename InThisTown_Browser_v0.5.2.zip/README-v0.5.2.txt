IN THIS TOWN — BROWSER v0.5.2

UPDATE
- Keeps the original custom WebGL2 engine and all original characters, worlds, props, FX and animation modules.
- Adds a procedural reusable Asset Forge: 12 prop families x 8 visual variations (96 deterministic variants). Generated blueprints are saved in browser localStorage and reused by later stories.
- Adds contextual action interpretation (run, sit, open, close, inspect, build, talk, wave, hide, fall, operate, move, group) on top of story beats.
- Adds prop-specific physical responses for doors, books, chairs/vehicles, windows, speakers, clocks and puppets.
- Improves robot stories with an actual robot actor and robot-directed choreography.
- Narration uses Kokoro-82M, voice am_adam, English (US), speed 1.14.
- Groups up to three short sentences per Kokoro generation request (max 25 words per group), reducing 17 short TTS requests to about 6 for a 17-scene story.
- Caption/scene boundaries are estimated from syllable weight and snapped to nearby quiet audio windows when a clear pause exists. This is not phoneme-level forced alignment; small timing drift can remain.
- Inter-group silence reduced to 20 ms.

FILES
- site/: complete browser app and original WebGL2 engine adaptation
- pages-v0.5.2.yml: GitHub Pages workflow template; replace .github/workflows/pages.yml with this content once, then future ZIP uploads matching InThisTown_Browser_v*.zip trigger deployment.

PUBLISH
1. Upload InThisTown_Browser_v0.5.2.zip to the root of the GitHub repository.
2. Replace .github/workflows/pages.yml with pages-v0.5.2.yml.
3. Commit the change. GitHub Actions extracts site/ and deploys it to GitHub Pages.

TESTS RUN IN THIS BUILD ENVIRONMENT
- JavaScript syntax check on every .js file in site/.
- Original engine timeline compile checks for five example stories (vision, robot, book, chair, puppet): zero warnings; all animation clip names resolve.
- Procedural blueprint check: all 96 variants in 12 families return valid prop parts; repeat ensure() reuses the saved blueprint.
- Contextual action overlay compile check: zero warnings.
- Speech grouping/sync harness: 8 input lines generated in 3 test calls; all 8 scene timing records ordered and valid.

NOT CLAIMED
- No end-to-end render was run on the user's Chromebook in this environment.
- The procedural prop generator creates low-poly reusable assets from the original engine primitives; it is not an unrestricted AI 3D model generator.
- Subtitle highlighting uses estimated syllabic word timing plus detected quiet windows, not a full phoneme aligner.

const CACHE='in-this-town-shell-v5-23';
const CORE=['./','./index.html','./app.js?v=0.5.21','./studio-ui.js','./story-engine.js','./ai-story-director.js','./story-plan-adapter.js','./shortform-director.js','./episode-preflight.js','./timing.js','./sfx.js','./kokoro-worker.js','./manifest.webmanifest','./icon-192.png','./icon-512.png',
'./engine/math.js','./engine/prims.js','./engine/renderer.js','./engine/anim.js','./engine/anim_extra.js','./engine/props.js','./engine/props_extra.js','./engine/asset_forge.js','./engine/props_monsters.js','./engine/props_town.js','./engine/props_world3.js','./engine/character.js','./engine/characters_extra.js','./engine/character_forge.js','./engine/world.js','./engine/world_extra.js','./engine/fx.js','./engine/fx_extra.js','./engine/assets.js','./engine/director.js','./engine/api.js'];
self.addEventListener('install',e=>e.waitUntil(caches.open(CACHE).then(c=>c.addAll(CORE)).then(()=>self.skipWaiting())));
self.addEventListener('activate',e=>e.waitUntil(caches.keys().then(keys=>Promise.all(keys.filter(k=>k!==CACHE).map(k=>caches.delete(k)))).then(()=>self.clients.claim())));
self.addEventListener('fetch',e=>{
  const u=new URL(e.request.url);
  if(u.origin!==location.origin||e.request.method!=='GET')return;
  const shell=e.request.mode==='navigate'||/\/(?:app\.js|index\.html)$/.test(u.pathname);
  if(shell){
    e.respondWith(fetch(e.request).then(response=>{
      if(response&&response.ok){const copy=response.clone();caches.open(CACHE).then(c=>c.put(e.request,copy));}
      return response;
    }).catch(()=>caches.match(e.request)));
    return;
  }
  e.respondWith(caches.match(e.request).then(r=>r||fetch(e.request)));
});

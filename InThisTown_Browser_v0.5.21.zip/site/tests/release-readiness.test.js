const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const root = path.resolve(__dirname, '..');
const read = file => fs.readFileSync(path.join(root, file), 'utf8');

test('release version is aligned across app, worker, package and AI director', () => {
  const pkg = JSON.parse(read('package.json'));
  assert.equal(pkg.version, '0.5.21');
  assert.match(read('index.html'), /BROWSER v0\.5\.21/);
  assert.match(read('index.html'), /app\.js\?v=0\.5\.21/);
  assert.match(read('sw.js'), /in-this-town-shell-v5-23/);
  assert.match(read('sw.js'), /app\.js\?v=0\.5\.21/);
  assert.match(read('ai-story-director.js'), /version:'0\.5\.21'/);
});

test('quick-start guide exists and documents the actual manual AI workflow', () => {
  const guide = read('START_HERE.txt');
  assert.match(guide, /https:\/\/sergioelmileurillos-rgb\.github\.io\/inthistown-ai\//);
  assert.match(guide, /Kokoro-82M/);
  assert.match(guide, /No hay integración automática ni hace falta API key/);
  assert.match(guide, /exportación real probada en tu Chromebook/);
});

test('all files precached by the service worker exist in the release', () => {
  const sw = read('sw.js');
  const match = sw.match(/const CORE=\[(.*?)\];/s);
  assert.ok(match, 'service worker CORE list exists');
  const files = [...match[1].matchAll(/'([^']+)'/g)].map(m => m[1].split('?')[0].replace(/^\.\//, ''));
  for (const file of files) assert.ok(fs.existsSync(path.join(root, file)), `missing precache file: ${file}`);
});

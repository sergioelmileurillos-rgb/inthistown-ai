# v0.5.21 release test report — 89 automated tests passed

- [x] All 89 automated tests pass, including external story JSON validation, narration-to-actor ownership, pronoun handling, animation selection, prop grounding, cross-location object transfer, collision avoidance, scene continuity, camera motivation and anti-repetition prompts.
- [x] All app JavaScript files pass `node --check`.
- [x] Existing story-engine, character forge, 3D director, semantic plan adapter, Kokoro worker, cache, cancellation and interface suites remain passing.
- [ ] Full Kokoro inference + WebGL2 + MediaRecorder export still needs a real browser/device run on the Chromebook.

Automated tests validate application code structure and interface wiring; they do not claim a complete final video has been rendered on the actual Chromebook.


## v0.5.21
- Alineación de versión de lanzamiento, caché y guía de inicio rápido.

## v0.5.20
- Integración de los packs de modelos Claude y validación de tipos registrados en el catálogo real.
- El prompt del Director IA incluye los nombres exactos de los modelos disponibles.

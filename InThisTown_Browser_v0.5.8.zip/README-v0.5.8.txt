In This Town Browser v0.5.8

This release keeps the v0.5.6 story/scene improvements and adjusts Kokoro loading for Chromebooks and other constrained devices. ChromeOS now starts with Kokoro Q8 on WASM, avoids the initial FP32 WebGPU allocation, and tries Q4 as a fallback. High-memory desktop browsers may still use WebGPU FP32 first.

The worker reports the backend, quantization and detailed error information when a loading attempt fails. The standalone file:// worker uses the same strategy as the hosted HTTPS worker.

Deploy: upload InThisTown_Browser_v0.5.8.zip to the root of the GitHub repository. The current GitHub Pages workflow selects the highest versioned ZIP automatically; no workflow edit is required when that workflow is already installed.

Checks: from site/, run npm test and npm run check. Automated checks: 19/19 tests pass and all JavaScript files pass syntax validation.

Important: a complete Kokoro/WebGL2/MediaRecorder export still needs a real test on the user's Chromebook. This release is not claimed to be device-validated.
